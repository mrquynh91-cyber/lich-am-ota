/**
 * Super-App Module Group 1 (v3.0.0 — PC + OPPO Find X9):
 *  1. Lập Lá số Tử Vi & Xem hạn năm (Tam Tai, Thái Tuế, Kim Lâu, Hoang Ốc, Cửu Diệu, 12 Cung + AI)
 *  2. Bói Sim, Biển số xe & Số tài khoản (Ngũ hành, Âm Dương, Tổng nút, Quẻ 80 số Kinh Dịch + AI)
 *  3. Xem tuổi hợp (Vợ chồng, Hợp tác làm ăn, Sinh con — 5 tiêu chí cổ truyền + AI)
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import { convertSolar2Lunar, TIMEZONE_VN, getYearCanChi } from './lunar.js';
import { getBirthProfile } from './auspicious.js';
import { isGeminiConfigured, askGeminiGeneral, getLastGeminiMeta } from './gemini-ai.js';
import { shareToZaloQuick } from './zalo.js';
import { compressImageSourceToBase64 } from './moles.js';
import { openSmartCamera, attachCameraControlBar, removeCameraControlBar } from './camera-helper.js';

const CAN = ['Giáp', 'Ất', 'Bính', 'Đinh', 'Mậu', 'Kỷ', 'Canh', 'Tân', 'Nhâm', 'Quý'];
const CHI = ['Tý', 'Sửu', 'Dần', 'Mão', 'Thìn', 'Tỵ', 'Ngọ', 'Mùi', 'Thân', 'Dậu', 'Tuất', 'Hợi'];
const HOURS_12 = [
  { idx: 0, label: 'Tý (23h–01h)' }, { idx: 1, label: 'Sửu (01h–03h)' }, { idx: 2, label: 'Dần (03h–05h)' },
  { idx: 3, label: 'Mão (05h–07h)' }, { idx: 4, label: 'Thìn (07h–09h)' }, { idx: 5, label: 'Tỵ (09h–11h)' },
  { idx: 6, label: 'Ngọ (11h–13h)' }, { idx: 7, label: 'Mùi (13h–15h)' }, { idx: 8, label: 'Thân (15h–17h)' },
  { idx: 9, label: 'Dậu (17h–19h)' }, { idx: 10, label: 'Tuất (19h–21h)' }, { idx: 11, label: 'Hợi (21h–23h)' }
];

const PALACE_NAMES = [
  'Mệnh', 'Phụ Mẫu', 'Phúc Đức', 'Điền Trạch', 'Quan Lộc', 'Nô Bộc',
  'Thiên Di', 'Tật Ách', 'Tài Bạch', 'Tử Tức', 'Phu Thê', 'Huynh Đệ'
];

// Classical 4x4 grid positions for 12 Địa Chi palaces (Tỵ..Thìn clockwise around center)
const TUVI_GRID_SLOTS = [
  { chiIdx: 5, row: 1, col: 1 }, { chiIdx: 6, row: 1, col: 2 }, { chiIdx: 7, row: 1, col: 3 }, { chiIdx: 8, row: 1, col: 4 },
  { chiIdx: 4, row: 2, col: 1 }, { chiIdx: 9, row: 2, col: 4 },
  { chiIdx: 3, row: 3, col: 1 }, { chiIdx: 10, row: 3, col: 4 },
  { chiIdx: 2, row: 4, col: 1 }, { chiIdx: 1, row: 4, col: 2 }, { chiIdx: 0, row: 4, col: 3 }, { chiIdx: 11, row: 4, col: 4 }
];

const ELEMENTS = ['Kim', 'Mộc', 'Thủy', 'Hỏa', 'Thổ'];
const ELEMENT_GEN = { Kim: 'Thủy', Thủy: 'Mộc', Mộc: 'Hỏa', Hỏa: 'Thổ', Thổ: 'Kim' };
const ELEMENT_CTRL = { Kim: 'Mộc', Mộc: 'Thổ', Thổ: 'Thủy', Thủy: 'Hỏa', Hỏa: 'Kim' };

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function fmtMd(raw) {
  return escHtml(raw)
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*([^*\n]+)\*(?=$|[\s,.;:!?])/g, '$1<em>$2</em>')
    .replace(/^\s*---\s*$/gm, '<hr style="border:none;border-top:1px solid #E5E7EB;margin:6px 0;" />')
    .replace(/^\s*[\*\-]\s+/gm, '• ');
}

function getYearCanIdx(y) { return ((y - 4) % 10 + 10) % 10; }
function getYearChiIdx(y) { return ((y - 4) % 12 + 12) % 12; }

export function getCungPhi(year, gender = 'male') {
  const y = Number(year);
  if (!y || y < 1900 || y > 2100) return null;
  let sum = String(y).split('').reduce((a, b) => a + Number(b), 0);
  while (sum > 9) sum = String(sum).split('').reduce((a, b) => a + Number(b), 0);
  const rem = sum % 9 || 9;
  const maleMap = { 1: 'Khảm', 2: 'Ly', 3: 'Cấn', 4: 'Đoài', 5: 'Càn', 6: 'Khôn', 7: 'Tốn', 8: 'Chấn', 9: 'Khôn' };
  const femaleMap = { 1: 'Cấn', 2: 'Càn', 3: 'Đoài', 4: 'Cấn', 5: 'Ly', 6: 'Khảm', 7: 'Khôn', 8: 'Chấn', 9: 'Tốn' };
  // Standard post-2000 / pre-2000 Kua formula (authentic Bát Trạch)
  let kua;
  if (y < 2000) {
    kua = gender === 'female' ? ((rem + 5 - 1) % 9) + 1 : ((11 - rem - 1) % 9) + 1;
  } else {
    kua = gender === 'female' ? ((rem + 6 - 1) % 9) + 1 : ((10 - rem - 1) % 9) + 1;
  }
  const kuaInfo = {
    1: { name: 'Khảm', el: 'Thủy', group: 'Đông Tứ Mệnh', goodDirs: 'Đông Nam, Đông, Nam, Bắc' },
    2: { name: 'Khôn', el: 'Thổ', group: 'Tây Tứ Mệnh', goodDirs: 'Đông Bắc, Tây, Tây Bắc, Tây Nam' },
    3: { name: 'Chấn', el: 'Mộc', group: 'Đông Tứ Mệnh', goodDirs: 'Nam, Bắc, Đông Nam, Đông' },
    4: { name: 'Tốn', el: 'Mộc', group: 'Đông Tứ Mệnh', goodDirs: 'Bắc, Nam, Đông, Đông Nam' },
    5: gender === 'female'
      ? { name: 'Cấn', el: 'Thổ', group: 'Tây Tứ Mệnh', goodDirs: 'Tây Nam, Tây Bắc, Tây, Đông Bắc' }
      : { name: 'Khôn', el: 'Thổ', group: 'Tây Tứ Mệnh', goodDirs: 'Đông Bắc, Tây, Tây Bắc, Tây Nam' },
    6: { name: 'Càn', el: 'Kim', group: 'Tây Tứ Mệnh', goodDirs: 'Tây, Đông Bắc, Tây Nam, Tây Bắc' },
    7: { name: 'Đoài', el: 'Kim', group: 'Tây Tứ Mệnh', goodDirs: 'Tây Bắc, Tây Nam, Đông Bắc, Tây' },
    8: { name: 'Cấn', el: 'Thổ', group: 'Tây Tứ Mệnh', goodDirs: 'Tây Nam, Tây Bắc, Tây, Đông Bắc' },
    9: { name: 'Ly', el: 'Hỏa', group: 'Đông Tứ Mệnh', goodDirs: 'Đông, Đông Nam, Bắc, Nam' }
  };
  return kuaInfo[kua] || { name: maleMap[rem], el: 'Thổ', group: 'Tây Tứ Mệnh', goodDirs: 'Tây, Tây Bắc, Đông Bắc, Tây Nam' };
}

function compareElements(elA, elB) {
  if (!elA || !elB) return { score: 1, label: 'Bình hòa', cls: 'warn' };
  if (elA === elB) return { score: 1.5, label: `Tương hợp (${elA} – ${elB})`, cls: 'good' };
  if (ELEMENT_GEN[elA] === elB) return { score: 2, label: `Tương sinh (${elA} sinh ${elB})`, cls: 'good' };
  if (ELEMENT_GEN[elB] === elA) return { score: 2, label: `Tương sinh (${elB} sinh ${elA})`, cls: 'good' };
  if (ELEMENT_CTRL[elA] === elB) return { score: 0, label: `Tương khắc (${elA} khắc ${elB})`, cls: 'bad' };
  if (ELEMENT_CTRL[elB] === elA) return { score: 0, label: `Tương khắc (${elB} khắc ${elA})`, cls: 'bad' };
  return { score: 1, label: 'Bình hòa', cls: 'warn' };
}

/* ==================== 1. LẬP LÁ SỐ TỬ VI & XEM HẠN NĂM ==================== */

function computeVanHan(birthYear, gender, targetYear) {
  const bChi = getYearChiIdx(birthYear);
  const tChi = getYearChiIdx(targetYear);
  const tuoiMu = targetYear - birthYear + 1;

  // 1. Tam Tai
  const tamTaiGroups = [
    { ages: [8, 0, 4], bad: [2, 3, 4], name: 'Thân – Tý – Thìn gặp Dần – Mão – Thìn' },
    { ages: [2, 6, 10], bad: [8, 9, 10], name: 'Dần – Ngọ – Tuất gặp Thân – Dậu – Tuất' },
    { ages: [5, 9, 1], bad: [11, 0, 1], name: 'Tỵ – Dậu – Sửu gặp Hợi – Tý – Sửu' },
    { ages: [11, 3, 7], bad: [5, 6, 7], name: 'Hợi – Mão – Mùi gặp Tỵ – Ngọ – Mùi' }
  ];
  const ttGrp = tamTaiGroups.find((g) => g.ages.includes(bChi));
  const ttIdx = ttGrp ? ttGrp.bad.indexOf(tChi) : -1;
  const tamTai = ttIdx >= 0
    ? { hit: true, label: `Phạm Tam Tai (Năm thứ ${ttIdx + 1}/3)`, desc: `${ttGrp.name}. Năm ${ttIdx === 1 ? 'giữa nặng nhất' : ttIdx === 0 ? 'đầu khởi sự thận trọng' : 'cuối đang dần qua'}, hạn chế mở rộng quá mạo hiểm.`, cls: 'bad' }
    : { hit: false, label: 'Không phạm Tam Tai ✓', desc: 'Không vướng hạn Tam Tai trong năm này.', cls: 'good' };

  // 2. Thái Tuế
  const diff = (tChi - bChi + 12) % 12;
  const haiPairs = [[0, 7], [1, 6], [2, 5], [3, 4], [8, 11], [9, 10]];
  const phaPairs = [[0, 9], [1, 4], [2, 11], [3, 6], [5, 8], [7, 10]];
  const hinhPairs = [[0, 3], [2, 5], [5, 8], [2, 8], [1, 10], [10, 7], [1, 7]];
  const isPair = (pairs) => pairs.some(([a, b]) => (a === bChi && b === tChi) || (b === bChi && a === tChi));
  let thaiTue = { hit: false, label: 'Không phạm Thái Tuế ✓', desc: 'Tuổi hài hòa với Thái Tuế năm xem.', cls: 'good' };
  if (diff === 0) thaiTue = { hit: true, label: 'Phạm Trực (Bản Mệnh) Thái Tuế', desc: 'Năm tuổi — dễ có biến động lớn, thay đổi công việc/môi trường; nên giữ tâm vững, làm chắc.', cls: 'bad' };
  else if (diff === 6) thaiTue = { hit: true, label: 'Phạm Xung Thái Tuế', desc: 'Lục Xung với năm xem — cẩn trọng di chuyển, ký kết hợp đồng và tránh tranh chấp.', cls: 'bad' };
  else if (isPair(hinhPairs)) thaiTue = { hit: true, label: 'Phạm Hình Thái Tuế', desc: 'Lưu ý giấy tờ pháp lý, lời ăn tiếng nói và sức khỏe.', cls: 'warn' };
  else if (isPair(haiPairs)) thaiTue = { hit: true, label: 'Phạm Hại Thái Tuế', desc: 'Đề phòng tiểu nhân hiểu lầm, chọn lọc người hợp tác kỹ lưỡng.', cls: 'warn' };
  else if (isPair(phaPairs)) thaiTue = { hit: true, label: 'Phạm Phá Thái Tuế', desc: 'Chi tiêu dễ phát sinh bất ngờ, nên giữ quỹ dự phòng.', cls: 'warn' };

  // 3. Kim Lâu
  const klRem = ((tuoiMu % 9) + 9) % 9;
  const klMap = {
    1: 'Kim Lâu Thân (kỵ bản thân)',
    3: 'Kim Lâu Thê (kỵ vợ/chồng)',
    6: 'Kim Lâu Tử (kỵ con cái)',
    8: 'Kim Lâu Lục Súc (kỵ tài sản/chăn nuôi)'
  };
  const kimLau = klMap[klRem]
    ? { hit: true, label: `Phạm ${klMap[klRem]}`, desc: `Tuổi mụ ${tuoiMu} (dư ${klRem}) — nên cân nhắc mượn tuổi nếu xây nhà hoặc chọn ngày giờ đẹp hóa giải.`, cls: 'warn' }
    : { hit: false, label: 'Không phạm Kim Lâu ✓', desc: `Tuổi mụ ${tuoiMu} — thuận lợi cưới hỏi, làm nhà, việc lớn.`, cls: 'good' };

  // 4. Hoang Ốc
  const hoRem = (((Math.floor(tuoiMu / 10) + (tuoiMu % 10) - 1) % 6) + 6) % 6;
  const hoList = [
    { name: 'Nhất Cát (Tốt)', hit: false, cls: 'good', desc: 'Làm nhà an cư lạc nghiệp, mọi sự hanh thông.' },
    { name: 'Nhị Nghi (Tốt)', hit: false, cls: 'good', desc: 'Nhà cửa hưng vượng, giàu có.' },
    { name: 'Tam Địa Sát (Xấu)', hit: true, cls: 'bad', desc: 'Kỵ động thổ làm nhà (dễ ảnh hưởng sức khỏe gia chủ).' },
    { name: 'Tứ Tấn Tài (Tốt)', hit: false, cls: 'good', desc: 'Phúc lộc tới nhà, tài vận khởi sắc.' },
    { name: 'Ngũ Thọ Tử (Xấu)', hit: true, cls: 'bad', desc: 'Kỵ xây nhà — nên mượn tuổi hợp để khởi công.' },
    { name: 'Lục Hoang Ốc (Xấu)', hit: true, cls: 'warn', desc: 'Khó thành đạt nếu tự đứng tuổi làm nhà.' }
  ];
  const hoangOc = hoList[hoRem];

  // 5. Sao Chiếu Mệnh (Cửu Diệu) & Hạn Năm
  const r9 = ((tuoiMu - 1) % 9 + 9) % 9;
  const maleStars = [
    { name: 'La Hầu', cls: 'bad', note: 'Hung tinh (kỵ tháng 1, 7 ÂL) — chú ý lời nói, giấy tờ.' },
    { name: 'Thổ Tú', cls: 'warn', note: 'Trung tinh — cẩn trọng đi xa, tránh nóng giận.' },
    { name: 'Thủy Diệu', cls: 'good', note: 'Phúc lộc tinh — có tài lộc, chú ý sông nước.' },
    { name: 'Thái Bạch', cls: 'bad', note: 'Hung tinh — giữ chặt chi tiêu, tránh đầu tư mạo hiểm.' },
    { name: 'Thái Dương', cls: 'good', note: 'Đại cát tinh — công danh sáng rạng, quý nhân trợ lực!' },
    { name: 'Vân Hớn', cls: 'warn', note: 'Trung tinh — giữ hòa khí, chăm sóc sức khỏe.' },
    { name: 'Kế Đô', cls: 'bad', note: 'Hung tinh — nên đi lễ cầu an, tránh lo âu thái quá.' },
    { name: 'Thái Âm', cls: 'good', note: 'Cát tinh — tài lộc bất động sản, hỷ tín gia đạo!' },
    { name: 'Mộc Đức', cls: 'good', note: 'Cát tinh — bình an, hanh thông mọi việc!' }
  ];
  const femaleStars = [
    { name: 'Kế Đô', cls: 'bad', note: 'Hung tinh (kỵ tháng 3, 9 ÂL) — giữ tâm an, tránh tranh cãi.' },
    { name: 'Vân Hớn', cls: 'warn', note: 'Trung tinh — chú ý sức khỏe, gia đạo hòa thuận.' },
    { name: 'Mộc Đức', cls: 'good', note: 'Cát tinh — bình an, gia đạo vui vẻ, tài lộc tốt!' },
    { name: 'Thái Âm', cls: 'good', note: 'Đại cát tinh — cực tốt về tài chính, nhà cửa, hỷ sự!' },
    { name: 'Thổ Tú', cls: 'warn', note: 'Trung tinh — đi xa cẩn thận, hạn chế xuất hành đêm.' },
    { name: 'La Hầu', cls: 'bad', note: 'Hung tinh — cẩn trọng chuyện thị phi, sức khỏe.' },
    { name: 'Thái Dương', cls: 'good', note: 'Cát tinh — công việc hanh thông, quý nhân phù trợ!' },
    { name: 'Thái Bạch', cls: 'bad', note: 'Hung tinh — quản lý tài chính chặt, tránh cho vay nóng.' },
    { name: 'Thủy Diệu', cls: 'good', note: 'Phúc tinh — có lộc kinh doanh, lưu ý sông nước.' }
  ];
  const star = (gender === 'female' ? femaleStars : maleStars)[r9];
  const hanNames = ['Huỳnh Tuyền', 'Tam Kheo', 'Ngũ Mộ', 'Thiên Tinh', 'Toán Tận', 'Thiên La', 'Địa Võng', 'Diêm Vương'];
  const han = hanNames[((tuoiMu - 1) % 8 + 8) % 8];

  return { tuoiMu, tamTai, thaiTue, kimLau, hoangOc, star, han };
}

function buildTuViChart(solarDay, solarMonth, solarYear, hourIdx, gender) {
  const lunar = convertSolar2Lunar(solarDay, solarMonth, solarYear, TIMEZONE_VN);
  const canIdx = getYearCanIdx(lunar.year);
  const chiIdx = getYearChiIdx(lunar.year);
  const prof = getBirthProfile(lunar.year);
  const isYangYear = canIdx % 2 === 0;
  const amDuongLabel = `${isYangYear ? 'Dương' : 'Âm'} ${gender === 'female' ? 'Nữ' : 'Nam'}`;

  // Cung Mệnh starts at Dần (2), forward by (lunarMonth - 1), backward by hourIdx
  const menhChi = ((2 + (lunar.month - 1) - hourIdx) % 12 + 12) % 12;
  // Cung Thân starts at Dần (2), forward by (lunarMonth - 1), forward by hourIdx
  const thanChi = ((2 + (lunar.month - 1) + hourIdx) % 12 + 12) % 12;

  // Ngũ hành Cục (simplified authentic calculation by Mệnh stem/branch)
  const danCan = ((canIdx % 5) * 2 + 2) % 10; // Ngũ Hổ Độn: Giáp/Kỷ->Bính(2), Ất/Canh->Mậu(4)...
  const menhCan = (danCan + ((menhChi - 2 + 12) % 12)) % 10;
  const canPair = Math.floor(menhCan / 2) + 1; // 1..5
  const chiPairMap = [1, 1, 2, 2, 3, 3, 1, 1, 2, 2, 3, 3];
  const cucNum = ((canPair + chiPairMap[menhChi] - 1) % 5) + 1;
  const cucList = [
    { val: 4, name: 'Kim Tứ Cục' },
    { val: 2, name: 'Thủy Nhị Cục' },
    { val: 6, name: 'Hỏa Lục Cục' },
    { val: 5, name: 'Thổ Ngũ Cục' },
    { val: 3, name: 'Mộc Tam Cục' }
  ];
  const cuc = cucList[cucNum - 1] || cucList[0];

  // An 14 Chính Tinh (Tử Vi & Thiên Phủ chains — classical algorithm)
  const q = Math.ceil(lunar.day / cuc.val);
  const rem = q * cuc.val - lunar.day;
  let tuViChi = ((2 + q - 1 + (rem % 2 === 0 ? rem : -rem)) % 12 + 12) % 12;
  const thienPhuChi = ((16 - tuViChi) % 12 + 12) % 12;

  const starsByChi = Array.from({ length: 12 }, () => []);
  const addStar = (c, name) => starsByChi[((c % 12) + 12) % 12].push(name);
  addStar(tuViChi, 'Tử Vi');
  addStar(tuViChi - 1, 'Thiên Cơ');
  addStar(tuViChi - 3, 'Thái Dương');
  addStar(tuViChi - 4, 'Vũ Khúc');
  addStar(tuViChi - 5, 'Thiên Đồng');
  addStar(tuViChi - 8, 'Liêm Trinh');

  addStar(thienPhuChi, 'Thiên Phủ');
  addStar(thienPhuChi + 1, 'Thái Âm');
  addStar(thienPhuChi + 2, 'Tham Lang');
  addStar(thienPhuChi + 3, 'Cự Môn');
  addStar(thienPhuChi + 4, 'Thiên Tướng');
  addStar(thienPhuChi + 5, 'Thiên Lương');
  addStar(thienPhuChi + 6, 'Thất Sát');
  addStar(thienPhuChi + 10, 'Phá Quân');

  const palaces = [];
  for (let i = 0; i < 12; i++) {
    const cIdx = (menhChi + i) % 12;
    palaces.push({
      palaceIdx: i,
      name: PALACE_NAMES[i],
      chiIdx: cIdx,
      chiName: CHI[cIdx],
      isMenh: i === 0,
      isThan: cIdx === thanChi,
      stars: starsByChi[cIdx]
    });
  }

  return {
    lunar,
    canChiYear: getYearCanChi(lunar.year),
    napAm: prof ? `${prof.napAmName} (${prof.element})` : '',
    amDuongLabel,
    cucName: cuc.name,
    menhChi,
    thanChi,
    palaces
  };
}

export function mountTuViModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onSendTelegram = null } = opts;
  const now = new Date();
  const defYear = Number(getState()?.auspiciousPrefs?.birthYear) || 1991;

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero">
        <div>
          <h2 class="sf-hero-title">⭐ Lập Lá Số Tử Vi &amp; Xem Hạn Năm</h2>
          <div class="sf-hero-sub">An 14 Chính tinh lên 12 cung Tử Vi, tính chuẩn Tam Tai, Thái Tuế, Kim Lâu, Hoang Ốc, Cửu Diệu &amp; AI luận giải dễ hiểu.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-tv-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <div class="sf-grid-3">
          <div class="sf-field"><label for="tv-day">Ngày sinh (DL)</label><input id="tv-day" type="number" min="1" max="31" value="15" /></div>
          <div class="sf-field"><label for="tv-month">Tháng sinh</label><input id="tv-month" type="number" min="1" max="12" value="6" /></div>
          <div class="sf-field"><label for="tv-year">Năm sinh</label><input id="tv-year" type="number" min="1920" max="2045" value="${defYear}" /></div>
        </div>
        <div class="sf-grid-3">
          <div class="sf-field">
            <label for="tv-hour">Giờ sinh</label>
            <select id="tv-hour">${HOURS_12.map((h) => `<option value="${h.idx}"${h.idx === 4 ? ' selected' : ''}>${h.label}</option>`).join('')}</select>
          </div>
          <div class="sf-field">
            <label for="tv-gender">Giới tính</label>
            <select id="tv-gender"><option value="male">👨 Nam</option><option value="female">👩 Nữ</option></select>
          </div>
          <div class="sf-field">
            <label for="tv-target-year">Xem hạn năm</label>
            <input id="tv-target-year" type="number" min="2024" max="2045" value="${now.getFullYear()}" />
          </div>
        </div>
        <div class="sf-btn-row">
          <button type="button" id="btn-tv-calc" class="sf-btn primary" style="flex:1;">⭐ Lập Lá Số &amp; Xem Hạn</button>
          <button type="button" id="btn-tv-ai" class="sf-btn ai" style="flex:1;">✨ AI Luận giải chi tiết</button>
        </div>
        <div id="tv-status" class="sf-status"></div>
      </div>

      <div id="tv-vanhan-card" class="sf-card"></div>
      <div id="tv-chart-card" class="sf-card"></div>

      <div id="tv-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong id="tv-ai-title">✨ AI Luận giải Lá Số Tử Vi &amp; Vận Hạn</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-tv-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-tv-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-tv-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div id="tv-ai-body" class="dream-result-body"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  let lastData = null;
  let lastAiText = '';
  let busy = false;

  const renderAll = () => {
    const d = Math.max(1, Math.min(31, Number(q('#tv-day').value) || 15));
    const m = Math.max(1, Math.min(12, Number(q('#tv-month').value) || 6));
    const y = Math.max(1920, Math.min(2045, Number(q('#tv-year').value) || 1991));
    const hr = Number(q('#tv-hour').value) || 0;
    const g = q('#tv-gender').value || 'male';
    const ty = Math.max(2024, Math.min(2045, Number(q('#tv-target-year').value) || now.getFullYear()));

    const chart = buildTuViChart(d, m, y, hr, g);
    const vh = computeVanHan(chart.lunar.year, g, ty);
    const cungPhi = getCungPhi(chart.lunar.year, g);
    lastData = { d, m, y, hr, g, ty, chart, vh, cungPhi };

    // 1. Render Vận hạn card
    q('#tv-vanhan-card').innerHTML = `
      <h3 class="sf-card-title">🛡️ Xem Hạn Năm ${ty} (${getYearCanChi(ty)}) — Tuổi mụ ${vh.tuoiMu}</h3>
      <div class="sf-kv-list">
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🔥 Hạn Tam Tai</strong><span class="sf-badge ${vh.tamTai.cls}">${vh.tamTai.label}</span></div><div>${escHtml(vh.tamTai.desc)}</div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>⚡ Phạm Thái Tuế</strong><span class="sf-badge ${vh.thaiTue.cls}">${vh.thaiTue.label}</span></div><div>${escHtml(vh.thaiTue.desc)}</div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🏠 Hạn Kim Lâu</strong><span class="sf-badge ${vh.kimLau.cls}">${vh.kimLau.label}</span></div><div>${escHtml(vh.kimLau.desc)}</div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🏗️ Hạn Hoang Ốc</strong><span class="sf-badge ${vh.hoangOc.cls}">${vh.hoangOc.name}</span></div><div>${escHtml(vh.hoangOc.desc)}</div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🌟 Sao Chiếu Mệnh &amp; Hạn Năm</strong><span class="sf-badge ${vh.star.cls}">Sao ${vh.star.name} • Hạn ${vh.han}</span></div><div>${escHtml(vh.star.note)}</div></div>
      </div>
    `;

    // 2. Render 12-Palace 4x4 Chart
    const byChi = Object.fromEntries(chart.palaces.map((p) => [p.chiIdx, p]));
    const cellsHtml = TUVI_GRID_SLOTS.map((slot) => {
      const p = byChi[slot.chiIdx];
      const starsStr = p.stars.length > 0 ? p.stars.join(', ') : 'Vô Chính Diệu';
      return `
        <div class="tuvi-cell${p.isMenh ? ' is-menh' : ''}" style="grid-row:${slot.row};grid-column:${slot.col};" data-pidx="${p.palaceIdx}">
          <div class="tuvi-cell-top"><span>${p.name}${p.isThan ? ' (Thân)' : ''}</span><span class="tuvi-cell-chi">${p.chiName}</span></div>
          <div class="tuvi-cell-stars">${escHtml(starsStr)}</div>
          <div class="tuvi-cell-sub">${p.isMenh ? '⭐ Cung Chủ' : ''}</div>
        </div>
      `;
    }).join('');

    q('#tv-chart-card').innerHTML = `
      <h3 class="sf-card-title">📜 Lá Số Tử Vi 12 Cung (${chart.amDuongLabel} • ${chart.canChiYear})</h3>
      <div class="tuvi-grid">
        ${cellsHtml}
        <div class="tuvi-center">
          <strong>${chart.canChiYear}</strong>
          <div>ÂL: ${chart.lunar.day}/${chart.lunar.month}/${chart.lunar.year}</div>
          <div>Mệnh: ${escHtml(chart.napAm)}</div>
          <div>${escHtml(chart.cucName)}</div>
          ${cungPhi ? `<div>Cung ${cungPhi.name} (${cungPhi.group})</div>` : ''}
        </div>
      </div>
      <div style="font-size:11.5px;color:#6B7280;">💡 Bấm <strong>"✨ AI Luận giải chi tiết"</strong> để AI dịch toàn bộ 12 cung (Mệnh, Tài Bạch, Quan Lộc, Phu Thê) &amp; hướng dẫn hóa giải hạn năm ${ty} thật dễ hiểu!</div>
    `;
  };

  q('#btn-tv-back')?.addEventListener('click', onBack);
  q('#btn-tv-calc')?.addEventListener('click', renderAll);
  q('#btn-tv-ai')?.addEventListener('click', async () => {
    renderAll();
    if (busy || !lastData) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#tv-status').className = 'sf-status err';
      q('#tv-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-tv-cfg">Nhập Key</button>';
      q('#btn-tv-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-tv-ai').disabled = true;
    q('#tv-status').className = 'sf-status';
    q('#tv-status').textContent = '✨ Gemini AI đang luận giải Lá số Tử Vi 12 cung & Vận hạn...';
    q('#tv-ai-card').classList.remove('hidden');
    q('#tv-ai-body').innerHTML = '✨ Đang luận giải...';

    try {
      const { chart, vh, cungPhi, ty, g, hr } = lastData;
      const summaryLines = chart.palaces.map((p) => `- Cung ${p.name}${p.isThan ? ' (An Thân)' : ''} tại ${p.chiName}: ${p.stars.join(', ') || 'Vô Chính Diệu'}`).join('\n');
      const prompt = `Luận giải Lá số Tử Vi & Vận hạn năm ${ty} (${getYearCanChi(ty)}) cho ${g === 'female' ? 'Nữ' : 'Nam'}, sinh ngày ${chart.lunar.day}/${chart.lunar.month}/${chart.lunar.year} ÂL (${chart.canChiYear}), giờ ${HOURS_12[hr]?.label}, Mệnh ${chart.napAm}, ${chart.cucName}, Cung phi ${cungPhi?.name} (${cungPhi?.group}).
Vận hạn năm ${ty} (tuổi mụ ${vh.tuoiMu}):
- Tam Tai: ${vh.tamTai.label}
- Thái Tuế: ${vh.thaiTue.label}
- Kim Lâu: ${vh.kimLau.label} | Hoang Ốc: ${vh.hoangOc.name}
- Sao chiếu mệnh: ${vh.star.name} | Hạn: ${vh.han}
12 Cung & Chính tinh:
${summaryLines}

Hãy dịch các thuật ngữ Hán-Việt sang tiếng Việt đời thường, dễ hiểu, tích cực (không hù dọa mê tín) theo 5 mục ngắn gọn:
**1. 🌟 Tổng quan Bản Mệnh & Tính cách (Cung Mệnh – Thân):**
**2. 💰 Công danh & Tài lộc (Quan Lộc – Tài Bạch):**
**3. 💞 Tình duyên & Gia đạo (Phu Thê – Phúc Đức):**
**4. 🛡️ Đánh giá Vận hạn năm ${ty} (Tam Tai, Thái Tuế, Sao ${vh.star.name}):**
**5. 💡 Lời khuyên hành động & Hóa giải tích cực trong năm ${ty}:**`;

      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là chuyên gia Tử Vi Đẩu Số Việt Nam hiện đại, trình bày ấm áp, thực tế, dễ hiểu, giải thích rõ thuật ngữ cổ cho người trẻ và gia đình.',
        userPrompt: prompt,
        temperature: 0.45
      }, (p) => { if (p) q('#tv-ai-body').innerHTML = fmtMd(p); });

      const meta = getLastGeminiMeta();
      lastAiText = `⭐ Lá Số Tử Vi & Vận Hạn ${ty} (${chart.canChiYear})\n\n${ans}`;
      q('#tv-ai-title').textContent = `✨ Luận giải Tử Vi & Hạn ${ty}${meta?.model ? ` (${meta.model} • ${(meta.ms / 1000).toFixed(1)}s)` : ''}`;
      q('#tv-ai-body').innerHTML = fmtMd(ans);
      q('#tv-status').textContent = '✅ Đã luận giải xong Lá số Tử Vi & Vận hạn!';
    } catch (err) {
      q('#tv-status').className = 'sf-status err';
      q('#tv-status').textContent = `⚠️ ${err?.message || 'Lỗi Gemini AI'}`;
    } finally {
      busy = false;
      q('#btn-tv-ai').disabled = false;
    }
  });

  q('#btn-tv-copy')?.addEventListener('click', async () => {
    if (!lastAiText) return;
    try { await navigator.clipboard.writeText(lastAiText); } catch (_e) {}
    q('#tv-status').textContent = '✓ Đã sao chép bài luận giải!';
  });
  q('#btn-tv-zalo')?.addEventListener('click', () => { if (lastAiText) shareToZaloQuick(lastAiText); });
  q('#btn-tv-tg')?.addEventListener('click', (e) => { if (lastAiText && onSendTelegram) onSendTelegram(escHtml(lastAiText), e.currentTarget); });

  renderAll();
}

/* ==================== 2. BÓI SIM, BIỂN SỐ XE & SỐ TÀI KHOẢN ==================== */

// Classic 80-number Kinh Dịch auspicious/inauspicious table (1..80)
const DICH_80_MEANINGS = {
  1: ['Đại Cát', 'good', 'Thái cực khai nguyên — vạn sự hanh thông, nền tảng vững bền.'],
  3: ['Cát', 'good', 'Tiến thoái như ý — danh lợi song toàn, quý nhân tương trợ.'],
  5: ['Đại Cát', 'good', 'Phúc lộc trường tồn — làm ăn phát đạt, gia đạo an khang.'],
  6: ['Cát', 'good', 'Trời ban phúc đức — gặp hung hóa cát, bình an thuận lợi.'],
  7: ['Cát', 'good', 'Ý chí kiên cường — vượt qua thử thách, thành công rực rỡ.'],
  8: ['Cát', 'good', 'Kiên định tiến tới — tích tiểu thành đại, lộc phát bền vững.'],
  11: ['Đại Cát', 'good', 'Vạn vật hồi xuân — cơ nghiệp hưng thịnh, càng về sau càng vượng.'],
  13: ['Đại Cát', 'good', 'Trí tuệ siêu quần — tài năng tỏa sáng, danh tiếng vang xa.'],
  15: ['Đại Cát', 'good', 'Phúc thọ song toàn — được nhiều người yêu mến, thuận hòa.'],
  16: ['Đại Cát', 'good', 'Quý nhân phù trợ — làm việc lớn dễ thành, tài lộc dồi dào.'],
  17: ['Cát', 'good', 'Bứt phá vươn lên — kiên trì sẽ gặt hái thành quả xứng đáng.'],
  18: ['Cát', 'good', 'Bản lĩnh vững vàng — có quyền uy và sự nghiệp ổn định.'],
  21: ['Đại Cát', 'good', 'Minh nguyệt chiếu quang — lãnh đạo sáng suốt, công danh hiển đạt.'],
  23: ['Đại Cát', 'good', 'Mặt trời mọc phương Đông — kinh doanh phát đạt mạnh mẽ.'],
  24: ['Đại Cát', 'good', 'Tài lộc dồi dào — tay trắng dựng nên cơ nghiệp vững chắc.'],
  25: ['Cát', 'good', 'Thông minh nhạy bén — khéo léo ngoại giao, gặt hái thành công.'],
  29: ['Cát', 'good', 'Trí mưu tài lược — công danh tài vận đều có bước tiến lớn.'],
  31: ['Đại Cát', 'good', 'Trí dũng song toàn — danh lợi đều đạt, hậu vận phú quý.'],
  32: ['Đại Cát', 'good', 'Ngựa quý gặp thời — cơ hội bất ngờ, thăng tiến vượt bậc.'],
  33: ['Đại Cát', 'good', 'Gia môn hưng thịnh — uy tín cao, công việc thuận buồm xuôi gió.'],
  35: ['Cát', 'good', 'Ôn hòa điềm tĩnh — cuộc sống an nhàn, tài chính ổn định.'],
  37: ['Cát', 'good', 'Uy tín và nhân hòa — làm ăn chân chính, khách hàng tin cậy.'],
  39: ['Đại Cát', 'good', 'Phú quý vinh hoa — số Thần Tài nhỏ, tài lộc khởi sắc.'],
  41: ['Đại Cát', 'good', 'Đức vọng cao dày — mọi kế hoạch lớn đều có cơ sở thành công.'],
  45: ['Đại Cát', 'good', 'Thuận phong dương phàm — vượt sóng lớn đạt thành tựu lớn.'],
  47: ['Đại Cát', 'good', 'Hoa khai nở rộ — cát khánh liên tiếp, công việc thăng hoa.'],
  48: ['Cát', 'good', 'Mưu lược vững vàng — có quý nhân đồng hành, tiền tài ổn định.'],
  52: ['Đại Cát', 'good', 'Nhìn xa trông rộng — đầu tư sáng suốt, thu hoạch dồi dào.'],
  57: ['Cát', 'good', 'Khổ tận cam lai — sau thử thách là giai đoạn cực kỳ rực rỡ.'],
  61: ['Cát', 'good', 'Danh lợi song thu — giữ sự khiêm tốn sẽ vượng phát dài lâu.'],
  63: ['Đại Cát', 'good', 'Phú quý tự lai — phúc đức đủ đầy, gia đạo bình an.'],
  65: ['Đại Cát', 'good', 'Phú quý trường thọ — công danh sự nghiệp viên mãn.'],
  67: ['Đại Cát', 'good', 'Thông đạt bốn phương — giao thương thuận lợi, quý nhân nâng đỡ.'],
  68: ['Đại Cát', 'good', 'Lộc Phát viên mãn — sáng tạo thành công, tài lộc tụ về.'],
  73: ['Cát', 'good', 'An lạc tự tại — làm việc bền bỉ, cuộc sống êm ấm.'],
  75: ['Cát', 'good', 'Thủ thành chắc chắn — bảo toàn tốt tài sản và thành quả.'],
  79: ['Đại Cát', 'good', 'Thần Tài lớn — vượng tài kinh doanh, gặp nhiều cơ hội tốt.'],
  80: ['Cát', 'good', 'Đắc địa hồi nguyên — biết điểm dừng hợp lý sẽ giữ phúc bền lâu.']
};

function analyzeNumberString(raw, mode, birthYear) {
  const digits = String(raw || '').replace(/\D/g, '');
  if (digits.length < 3) return null;
  const nums = digits.split('').map(Number);
  const sum = nums.reduce((a, b) => a + b, 0);
  const nut = sum % 10;
  const evenCount = nums.filter((n) => n % 2 === 0).length;
  const oddCount = nums.length - evenCount;
  const balanceRatio = Math.abs(evenCount - oddCount) / nums.length;

  // Last 4 digits / 80 -> Kinh Dịch 80-number index
  const tail4 = Number(digits.slice(-4));
  const rem80 = tail4 % 80 || 80;
  const dich = DICH_80_MEANINGS[rem80] || (rem80 % 2 === 1
    ? ['Trung Bình', 'warn', 'Vận số bình hòa — thành công phụ thuộc vào sự kiên trì và cẩn trọng của chủ nhân.']
    : ['Cần lưu ý', 'warn', 'Nên dùng kết hợp tư duy chắc chắn, tránh nóng vội khi giao dịch lớn.']);

  // Element by last digit (Hà Đồ: 1,6 Thủy; 2,7 Hỏa; 3,8 Mộc; 4,9 Kim; 5,0 Thổ)
  const lastD = nums[nums.length - 1];
  const digitElMap = { 0: 'Thổ', 1: 'Thủy', 2: 'Hỏa', 3: 'Mộc', 4: 'Kim', 5: 'Thổ', 6: 'Thủy', 7: 'Hỏa', 8: 'Mộc', 9: 'Kim' };
  const numEl = digitElMap[lastD];
  const userProf = birthYear ? getBirthProfile(Number(birthYear)) : null;
  const elComp = userProf ? compareElements(numEl, userProf.element) : null;

  // Special lucky patterns
  const patterns = [];
  if (/(\d)\1{3}$/.test(digits)) patterns.push('👑 Tứ quý cuối (cực hiếm & đẳng cấp)');
  else if (/(\d)\1{2}$/.test(digits)) patterns.push('🌟 Tam hoa cuối (vững chãi, dễ nhớ)');
  if (/(0123|1234|2345|3456|4567|5678|6789)$/.test(digits)) patterns.push('🚀 Sảnh tiến (sự nghiệp đi lên không ngừng)');
  if (/(68|86)$/.test(digits)) patterns.push('💰 Đuôi Lộc Phát (68/86)');
  if (/(39|79)$/.test(digits)) patterns.push('🏮 Đuôi Thần Tài (39/79)');
  if (/(38|78)$/.test(digits)) patterns.push('🌿 Đuôi Ông Địa (38/78)');
  if (/(99|88|66)$/.test(digits)) patterns.push('✨ Đuôi Kép Trường Cửu / Đại Phát');

  let score = 56;
  if (dich[0] === 'Đại Cát') score += 22;
  else if (dich[0] === 'Cát') score += 15;
  else if (dich[0] === 'Trung Bình') score += 6;
  if (nut >= 7 || nut === 0) score += 8;
  else if (nut >= 5) score += 4;
  if (balanceRatio <= 0.35) score += 7;
  if (elComp) score += elComp.score === 2 ? 10 : elComp.score === 1.5 ? 7 : elComp.score === 1 ? 3 : -6;
  if (patterns.length > 0) score += Math.min(10, patterns.length * 5);
  score = Math.max(25, Math.min(99, Math.round(score)));

  return { digits, mode, nut, evenCount, oddCount, balanceRatio, rem80, dich, numEl, userProf, elComp, patterns, score };
}

export function mountSimPlateModule(mountEl, opts = {}) {
  if (!mountEl) return { stopCamera: () => {} };
  const { isMobile = false, getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onSendTelegram = null } = opts;
  const defYear = String(getState()?.auspiciousPrefs?.birthYear || '');

  let mode = 'sim';
  let lastRes = null;
  let lastAi = '';
  let busy = false;
  let activeStream = null;
  let capturedBase64 = '';

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-amber">
        <div>
          <h2 class="sf-hero-title">📱 Bói Sim, Biển Số Xe &amp; Số Tài Khoản</h2>
          <div class="sf-hero-sub">Nhập số hoặc chụp/tải ảnh biển số xe, thẻ sim, số tài khoản — AI tự đọc số &amp; chấm điểm Ngũ hành, Âm Dương, Kinh Dịch 80 số!</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-sp-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <div class="sf-seg" id="sp-mode-seg">
          <button type="button" class="sf-seg-btn active" data-mode="sim">📱 Số điện thoại</button>
          <button type="button" class="sf-seg-btn" data-mode="plate">🚗 Biển số xe</button>
          <button type="button" class="sf-seg-btn" data-mode="bank">💳 Số tài khoản</button>
        </div>

        <!-- Photo / Camera Scan Bar for License Plate, SIM, Bank Account -->
        <div class="sf-btn-row" style="margin-bottom:8px;">
          <button type="button" id="btn-sp-cam" class="sf-btn emerald" style="flex:1;">📷 Chụp biển số / Sim / STK</button>
          <button type="button" id="btn-sp-snap" class="sf-btn ai hidden" style="flex:1;">✨ Chụp &amp; AI đọc số</button>
          <button type="button" id="btn-sp-stop" class="sf-btn hidden">Tắt cam</button>
          <label class="sf-btn" style="cursor:pointer;">
            📁 Tải ảnh lên
            <input id="sp-file" type="file" accept="image/*" class="hidden" />
          </label>
          <input id="sp-cam-fb" type="file" accept="image/*" capture="environment" class="hidden" />
        </div>

        <div id="sp-media-stage" class="mole-stage hidden" style="border-color:#D97706;min-height:190px;margin-bottom:9px;">
          <video id="sp-video" class="mole-media hidden" autoplay playsinline muted></video>
          <img id="sp-preview" class="mole-photo-img hidden" alt="Ảnh biển số / sim / tài khoản" />
        </div>

        <div class="sf-grid-2">
          <div class="sf-field">
            <label for="sp-input" id="sp-input-lbl">Nhập số điện thoại</label>
            <input id="sp-input" type="text" placeholder="VD: 0868.00.2468" maxlength="30" />
          </div>
          <div class="sf-field">
            <label for="sp-year">Năm sinh chủ sở hữu (DL)</label>
            <input id="sp-year" type="number" min="1920" max="2045" placeholder="VD: 1991" value="${escHtml(defYear)}" />
          </div>
        </div>
        <div class="sf-btn-row">
          <button type="button" id="btn-sp-calc" class="sf-btn primary" style="flex:1;">🔍 Chấm điểm ngay</button>
          <button type="button" id="btn-sp-ai" class="sf-btn ai" style="flex:1;">✨ AI Luận giải sâu</button>
        </div>
        <div id="sp-status" class="sf-status"></div>
      </div>

      <div id="sp-result-card" class="sf-card hidden"></div>

      <div id="sp-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong id="sp-ai-title">✨ AI Phân tích Phong thủy dãy số</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-sp-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-sp-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-sp-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div id="sp-ai-body" class="dream-result-body"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  const videoEl = q('#sp-video');
  const prevEl = q('#sp-preview');
  const stageEl = q('#sp-media-stage');
  const modeMeta = {
    sim: { lbl: 'Nhập số điện thoại', ph: 'VD: 0912.68.7979' },
    plate: { lbl: 'Nhập biển số xe (4 hoặc 5 số)', ph: 'VD: 30K-688.79 hoặc 68879' },
    bank: { lbl: 'Nhập số tài khoản ngân hàng', ph: 'VD: 8888.6868.79' }
  };

  const setModeUi = (nextMode) => {
    mode = ['sim', 'plate', 'bank'].includes(nextMode) ? nextMode : 'sim';
    q('#sp-mode-seg')?.querySelectorAll('.sf-seg-btn').forEach((x) => x.classList.toggle('active', x.dataset.mode === mode));
    if (q('#sp-input-lbl')) q('#sp-input-lbl').textContent = modeMeta[mode].lbl;
    if (q('#sp-input')) q('#sp-input').placeholder = modeMeta[mode].ph;
  };

  const stopCamera = () => {
    if (activeStream) {
      activeStream.getTracks().forEach((t) => { try { t.stop(); } catch (_e) {} });
      activeStream = null;
    }
    if (videoEl) { videoEl.srcObject = null; videoEl.classList.add('hidden'); }
    removeCameraControlBar(stageEl);
    q('#btn-sp-snap')?.classList.add('hidden');
    q('#btn-sp-stop')?.classList.add('hidden');
    q('#btn-sp-cam')?.classList.remove('hidden');
    if (!capturedBase64) stageEl?.classList.add('hidden');
    else prevEl?.classList.remove('hidden');
  };

  const startSpCamera = async (preferredDeviceId = null) => {
    if (!navigator.mediaDevices?.getUserMedia) {
      if (isMobile) q('#sp-cam-fb')?.click();
      else {
        q('#sp-status').className = 'sf-status err';
        q('#sp-status').textContent = '⚠️ Hãy bấm "📁 Tải ảnh lên" hoặc mở toàn trang để dùng Camera.';
      }
      return;
    }
    try {
      stopCamera();
      const ctrl = await openSmartCamera('environment', { preferredDeviceId });
      activeStream = ctrl.stream;
      stageEl?.classList.remove('hidden');
      prevEl?.classList.add('hidden');
      videoEl.srcObject = ctrl.stream;
      videoEl.classList.remove('hidden');
      try { await videoEl.play(); } catch (_e) {}
      q('#btn-sp-snap')?.classList.remove('hidden');
      q('#btn-sp-stop')?.classList.remove('hidden');
      q('#btn-sp-cam')?.classList.add('hidden');
      attachCameraControlBar(stageEl, ctrl, {
        onSwitchRearLens: (devId) => startSpCamera(devId),
        onOpenNativeCamera: isMobile ? () => { stopCamera(); q('#sp-cam-fb')?.click(); } : null
      });
    } catch (_e) {
      if (isMobile) q('#sp-cam-fb')?.click();
      else {
        q('#sp-status').className = 'sf-status err';
        q('#sp-status').textContent = '⚠️ Không mở được Camera — hãy bấm "📁 Tải ảnh lên".';
      }
    }
  };

  q('#btn-sp-back')?.addEventListener('click', () => { stopCamera(); onBack(); });
  q('#sp-mode-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    setModeUi(b.dataset.mode || 'sim');
  });

  const runCalc = () => {
    const raw = q('#sp-input').value.trim();
    const yr = q('#sp-year').value.trim();
    const res = analyzeNumberString(raw, mode, yr);
    if (!res) {
      q('#sp-status').className = 'sf-status err';
      q('#sp-status').textContent = 'Hãy nhập ít nhất 3 chữ số để chấm điểm nhé!';
      return null;
    }
    lastRes = { ...res, raw };
    q('#sp-status').textContent = '';
    const cls = res.score >= 80 ? 'good' : res.score >= 62 ? 'mid' : '';
    const verdict = res.score >= 85 ? 'Đại Cát — Dãy số cực đẹp, vượng tài!' : res.score >= 72 ? 'Cát — Dãy số đẹp, dễ dùng & thuận lợi' : res.score >= 58 ? 'Khá — Ổn định, cân bằng' : 'Trung bình — Có thể tham khảo thêm số hợp mệnh';

    q('#sp-result-card').classList.remove('hidden');
    q('#sp-result-card').innerHTML = `
      <div class="sf-score-banner">
        <div class="sf-score-circle ${cls}"><span class="sf-score-num">${res.score}</span><span class="sf-score-sub">/100đ</span></div>
        <div>
          <div style="font-weight:800;font-size:14px;color:#7F1D1D;">${escHtml(raw)}</div>
          <div style="font-size:12px;font-weight:700;color:#92400E;margin-top:2px;">${verdict}</div>
        </div>
      </div>
      <div class="sf-kv-list">
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>☯️ Quẻ Kinh Dịch (Số ${res.rem80}/80)</strong><span class="sf-badge ${res.dich[1]}">${res.dich[0]}</span></div><div>${escHtml(res.dich[2])}</div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🔥 Ngũ hành dãy số</strong><span class="sf-badge ${res.elComp ? res.elComp.cls : 'info'}">Hành ${res.numEl}</span></div><div>${res.userProf ? `Chủ tuổi ${res.userProf.canChi} (Mệnh ${res.userProf.napAmName} — ${res.userProf.element}) → <strong>${res.elComp.label}</strong>.` : 'Nhập thêm năm sinh để kiểm tra tương sinh/tương khắc với Mệnh của bạn.'}</div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>⚖️ Tổng nút &amp; Âm Dương</strong><span class="sf-badge ${res.nut >= 7 ? 'good' : 'info'}">${res.nut === 0 ? '10 nút (Bù)' : `${res.nut} nút`} • ${res.evenCount} Âm / ${res.oddCount} Dương</span></div><div>${res.balanceRatio <= 0.35 ? 'Tỷ lệ chẵn – lẻ cân bằng hài hòa (Âm Dương tương phối tốt).' : 'Thiên lệch chẵn/lẻ nhẹ — vẫn dùng tốt nếu hợp ngũ hành.'}</div></div>
        ${res.patterns.length > 0 ? `<div class="sf-kv-item"><strong>✨ Bộ số đẹp phát hiện:</strong> ${res.patterns.join(' • ')}</div>` : ''}
      </div>
    `;
    return lastRes;
  };

  const runAiNumberAnalysis = async (extraImageNote = '') => {
    const r = runCalc();
    if (!r || busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#sp-status').className = 'sf-status err';
      q('#sp-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-sp-cfg">Nhập Key</button>';
      q('#btn-sp-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-sp-ai').disabled = true;
    q('#sp-status').className = 'sf-status';
    q('#sp-status').textContent = '✨ Gemini AI đang phân tích phong thủy dãy số...';
    q('#sp-ai-card').classList.remove('hidden');
    q('#sp-ai-body').innerHTML = '✨ Đang phân tích...';
    try {
      const kindName = mode === 'plate' ? 'Biển số xe' : mode === 'bank' ? 'Số tài khoản ngân hàng' : 'Sim số điện thoại';
      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là chuyên gia phong thủy số học & Kinh Dịch Việt Nam, luận giải khách quan, văn minh, dễ hiểu, không mê tín.',
        userPrompt: `Hãy luận giải chi tiết phong thủy ${kindName}: "${r.raw}"${extraImageNote ? ` (Thông tin thêm nhìn thấy từ ảnh: ${extraImageNote})` : ''} (Điểm hệ thống: ${r.score}/100, Quẻ 80 số: số ${r.rem80} - ${r.dich[0]}, Hành ${r.numEl}, ${r.nut} nút, ${r.evenCount} chẵn/${r.oddCount} lẻ${r.userProf ? `, chủ nhân tuổi ${r.userProf.canChi} mệnh ${r.userProf.napAmName} (${r.elComp.label})` : ''}). Trình bày 4 mục ngắn gọn:
**1. 🌟 Ý nghĩa dãy số & năng lượng phong thủy:**
**2. 🔥 Mức độ hợp mệnh & công việc / đi lại / tài chính:**
**3. ✅ Điểm mạnh nổi bật & ⚠️ Điểm cần lưu ý:**
**4. 💡 Lời khuyên sử dụng / hóa giải để thêm vượng khí:**`,
        temperature: 0.45
      }, (p) => { if (p) q('#sp-ai-body').innerHTML = fmtMd(p); });
      lastAi = `📱 Luận giải ${kindName} ${r.raw} (${r.score}/100đ)\n\n${ans}`;
      q('#sp-ai-body').innerHTML = fmtMd(ans);
      q('#sp-status').textContent = '✅ Đã phân tích phong thủy xong!';
    } catch (err) {
      q('#sp-status').className = 'sf-status err';
      q('#sp-status').textContent = `⚠️ ${err?.message || 'Lỗi AI'}`;
    } finally {
      busy = false;
      q('#btn-sp-ai').disabled = false;
    }
  };

  // Vision AI: Read License Plate / Phone Number / Bank Account from captured or uploaded photo -> auto-score -> deep AI analysis!
  const scanPhotoForNumber = async (imgSrc) => {
    const { dataUrl, base64 } = compressImageSourceToBase64(imgSrc, 1280, 0.9, false);
    capturedBase64 = base64;
    stopCamera();
    stageEl?.classList.remove('hidden');
    prevEl.src = dataUrl;
    prevEl.classList.remove('hidden');

    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#sp-status').className = 'sf-status err';
      q('#sp-status').innerHTML = '🔑 Cần Gemini API Key để AI tự đọc số trên ảnh. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-sp-cfg2">Nhập Key</button>';
      q('#btn-sp-cfg2')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    if (busy) return;
    busy = true;
    q('#sp-status').className = 'sf-status';
    q('#sp-status').textContent = '✨ Gemini Vision AI đang đọc dãy số (biển số xe / SĐT / STK) từ ảnh...';
    try {
      const raw = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là công cụ OCR tiếng Việt chuyên đọc Biển số xe Việt Nam, Số điện thoại (Sim) và Số tài khoản ngân hàng từ ảnh chụp. CHỈ trả JSON chuẩn: {"type":"plate"|"sim"|"bank","number":"chuỗi số chính xác VD 30K-688.79 hoặc 0868002468","note":"mô tả ngắn màu biển/màu xe/tên ngân hàng nếu thấy"}',
        userPrompt: 'Hãy đọc chính xác biển số xe, số điện thoại hoặc số tài khoản ngân hàng nổi bật nhất trong ảnh này. Trả JSON duy nhất.',
        images: [base64],
        temperature: 0.1,
        responseMimeType: 'application/json',
        timeoutMs: 24000
      });
      const cleaned = raw.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
      const obj = JSON.parse(cleaned.match(/\{[\s\S]*\}/)?.[0] || cleaned);
      const foundNum = String(obj?.number || '').trim();
      if (!foundNum || foundNum.replace(/\D/g, '').length < 3) {
        q('#sp-status').className = 'sf-status err';
        q('#sp-status').textContent = '⚠️ AI chưa nhìn rõ dãy số trên ảnh này — hãy chụp rõ hơn hoặc nhập tay vào ô bên dưới!';
        busy = false;
        return;
      }
      if (obj?.type) setModeUi(obj.type);
      q('#sp-input').value = foundNum;
      busy = false;
      q('#sp-status').textContent = `✅ AI đã đọc được: ${foundNum}${obj?.note ? ` (${obj.note})` : ''} — đang chấm điểm & luận giải sâu...`;
      await runAiNumberAnalysis(obj?.note || '');
    } catch (err) {
      busy = false;
      q('#sp-status').className = 'sf-status err';
      q('#sp-status').textContent = `⚠️ ${err?.message || 'Lỗi đọc ảnh bằng AI'}`;
    }
  };

  const handlePhotoFile = (f) => {
    if (!f) return;
    const img = new Image();
    const u = URL.createObjectURL(f);
    img.onload = () => { URL.revokeObjectURL(u); scanPhotoForNumber(img); };
    img.onerror = () => { URL.revokeObjectURL(u); q('#sp-status').className = 'sf-status err'; q('#sp-status').textContent = '⚠️ Không đọc được file ảnh.'; };
    img.src = u;
  };

  q('#btn-sp-cam')?.addEventListener('click', () => startSpCamera(null));
  q('#btn-sp-stop')?.addEventListener('click', stopCamera);
  q('#btn-sp-snap')?.addEventListener('click', () => { if (videoEl?.videoWidth) scanPhotoForNumber(videoEl); });
  q('#sp-file')?.addEventListener('change', (e) => { handlePhotoFile(e.target.files?.[0]); e.target.value = ''; });
  q('#sp-cam-fb')?.addEventListener('change', (e) => { handlePhotoFile(e.target.files?.[0]); e.target.value = ''; });

  q('#btn-sp-calc')?.addEventListener('click', runCalc);
  q('#btn-sp-ai')?.addEventListener('click', () => runAiNumberAnalysis(''));

  q('#btn-sp-copy')?.addEventListener('click', async () => {
    if (!lastAi) return;
    try { await navigator.clipboard.writeText(lastAi); } catch (_e) {}
    q('#sp-status').textContent = '✓ Đã sao chép!';
  });
  q('#btn-sp-zalo')?.addEventListener('click', () => { if (lastAi) shareToZaloQuick(lastAi); });
  q('#btn-sp-tg')?.addEventListener('click', (e) => { if (lastAi && onSendTelegram) onSendTelegram(escHtml(lastAi), e.currentTarget); });

  return { stopCamera };
}

/* ==================== 3. XEM TUỔI HỢP (VỢ CHỒNG, LÀM ĂN & SINH CON) ==================== */

function evaluateCompatibility(yearA, genderA, yearB, genderB) {
  const pA = getBirthProfile(yearA);
  const pB = getBirthProfile(yearB);
  if (!pA || !pB) return null;

  const canA = getYearCanIdx(yearA), chiA = getYearChiIdx(yearA);
  const canB = getYearCanIdx(yearB), chiB = getYearChiIdx(yearB);
  const phiA = getCungPhi(yearA, genderA);
  const phiB = getCungPhi(yearB, genderB);

  // 1. Ngũ hành Nạp Âm (max 2.5)
  const elRes = compareElements(pA.element, pB.element);
  const sEl = elRes.score * 1.25;

  // 2. Thiên Can (max 2)
  const canHop = Math.abs(canA - canB) === 5;
  const canXung = (canA === 0 && canB === 6) || (canA === 6 && canB === 0) || (canA === 1 && canB === 7) || (canA === 7 && canB === 1) || (canA === 2 && canB === 8) || (canA === 8 && canB === 2) || (canA === 3 && canB === 9) || (canA === 9 && canB === 3);
  const canRes = canHop
    ? { score: 2, label: `Tương hợp (${CAN[canA]} – ${CAN[canB]})`, cls: 'good' }
    : canXung
      ? { score: 0.4, label: `Tương xung (${CAN[canA]} – ${CAN[canB]})`, cls: 'bad' }
      : { score: 1.3, label: `Bình hòa (${CAN[canA]} – ${CAN[canB]})`, cls: 'warn' };

  // 3. Địa Chi (max 2.5)
  const tamHop = [[8, 0, 4], [2, 6, 10], [5, 9, 1], [11, 3, 7]].some((g) => g.includes(chiA) && g.includes(chiB) && chiA !== chiB);
  const lucHop = [[0, 1], [2, 11], [3, 10], [4, 9], [5, 8], [6, 7]].some(([a, b]) => (a === chiA && b === chiB) || (b === chiA && a === chiB));
  const lucXung = Math.abs(chiA - chiB) === 6;
  const tuongHai = [[0, 7], [1, 6], [2, 5], [3, 4], [8, 11], [9, 10]].some(([a, b]) => (a === chiA && b === chiB) || (b === chiA && a === chiB));
  const chiRes = (tamHop || lucHop)
    ? { score: 2.5, label: `${tamHop ? 'Tam Hợp' : 'Lục Hợp'} (${CHI[chiA]} – ${CHI[chiB]})`, cls: 'good' }
    : chiA === chiB
      ? { score: 1.6, label: `Đồng tuổi (${CHI[chiA]} – ${CHI[chiB]})`, cls: 'info' }
      : lucXung
        ? { score: 0.3, label: `Lục Xung (${CHI[chiA]} – ${CHI[chiB]})`, cls: 'bad' }
        : tuongHai
          ? { score: 0.6, label: `Tương Hại (${CHI[chiA]} – ${CHI[chiB]})`, cls: 'warn' }
          : { score: 1.5, label: `Bình hòa (${CHI[chiA]} – ${CHI[chiB]})`, cls: 'info' };

  // 4. Cung Phi Bát Trạch (max 2)
  const sameGroup = phiA && phiB && phiA.group === phiB.group;
  const phiRes = sameGroup
    ? { score: 2, label: `Cùng ${phiA.group} (${phiA.name} – ${phiB.name}) — Tốt`, cls: 'good' }
    : { score: 0.7, label: `Khác nhóm (${phiA?.name} – ${phiB?.name}) — Cần dung hòa`, cls: 'warn' };

  // 5. Ngũ hành Cung Phi (max 1)
  const phiEl = compareElements(phiA?.el, phiB?.el);
  const sPhiEl = phiEl.score * 0.5;

  const total = Math.max(1, Math.min(10, Number((sEl + canRes.score + chiRes.score + phiRes.score + sPhiEl).toFixed(1))));
  return { pA, pB, phiA, phiB, elRes, canRes, chiRes, phiRes, phiEl, total };
}

export function mountCompatibilityModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onSendTelegram = null } = opts;
  const defYear = Number(getState()?.auspiciousPrefs?.birthYear) || 1991;

  let mode = 'marriage';
  let lastEval = null;
  let lastAi = '';
  let busy = false;

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-rose">
        <div>
          <h2 class="sf-hero-title">💑 Xem Tuổi Hợp (Vợ Chồng, Làm Ăn &amp; Sinh Con)</h2>
          <div class="sf-hero-sub">Kiểm tra chuẩn 5 tiêu chí Ngũ hành Nạp Âm, Thiên Can, Địa Chi, Cung Phi Bát Trạch &amp; AI tư vấn dung hòa.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-cp-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <div class="sf-seg" id="cp-mode-seg">
          <button type="button" class="sf-seg-btn active" data-mode="marriage">💍 Vợ chồng</button>
          <button type="button" class="sf-seg-btn" data-mode="business">🤝 Làm ăn</button>
          <button type="button" class="sf-seg-btn" data-mode="baby">👶 Sinh con</button>
        </div>

        <div class="sf-grid-2">
          <div class="sf-field">
            <label for="cp-y1" id="cp-l1">Năm sinh Chồng / Bố</label>
            <input id="cp-y1" type="number" min="1920" max="2045" value="${defYear}" />
          </div>
          <div class="sf-field">
            <label for="cp-g1">Giới tính Người 1</label>
            <select id="cp-g1"><option value="male">👨 Nam</option><option value="female">👩 Nữ</option></select>
          </div>
        </div>
        <div class="sf-grid-2">
          <div class="sf-field">
            <label for="cp-y2" id="cp-l2">Năm sinh Vợ / Đối tác</label>
            <input id="cp-y2" type="number" min="1920" max="2045" value="${defYear + 2}" />
          </div>
          <div class="sf-field">
            <label for="cp-g2">Giới tính Người 2</label>
            <select id="cp-g2"><option value="female">👩 Nữ</option><option value="male">👨 Nam</option></select>
          </div>
        </div>

        <div id="cp-baby-row" class="sf-field hidden">
          <label for="cp-y-baby">Năm dự kiến sinh con (DL)</label>
          <input id="cp-y-baby" type="number" min="2024" max="2045" value="${new Date().getFullYear() + 1}" />
        </div>

        <div class="sf-btn-row equal-2">
          <button type="button" id="btn-cp-calc" class="sf-btn primary">💑 Xem độ hợp ngay</button>
          <button type="button" id="btn-cp-ai" class="sf-btn ai">✨ AI Luận giải</button>
        </div>
        <div id="cp-status" class="sf-status"></div>
      </div>

      <div id="cp-result-card" class="sf-card hidden"></div>
      <div id="cp-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong id="cp-ai-title">✨ AI Tư vấn Hợp tuổi &amp; Cách dung hòa</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-cp-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-cp-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-cp-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div id="cp-ai-body" class="dream-result-body"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  q('#btn-cp-back')?.addEventListener('click', onBack);
  q('#cp-mode-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    mode = b.dataset.mode || 'marriage';
    q('#cp-mode-seg').querySelectorAll('.sf-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
    q('#cp-baby-row')?.classList.toggle('hidden', mode !== 'baby');
    q('#cp-l1').textContent = mode === 'business' ? 'Năm sinh Bản thân' : 'Năm sinh Chồng / Bố';
    q('#cp-l2').textContent = mode === 'business' ? 'Năm sinh Đối tác' : 'Năm sinh Vợ / Mẹ';
  });

  const runCalc = () => {
    const y1 = Number(q('#cp-y1').value) || 1991;
    const g1 = q('#cp-g1').value || 'male';
    const y2 = Number(q('#cp-y2').value) || 1993;
    const g2 = q('#cp-g2').value || 'female';
    const yb = Number(q('#cp-y-baby')?.value) || (new Date().getFullYear() + 1);

    if (mode === 'baby') {
      const rDad = evaluateCompatibility(y1, 'male', yb, 'male');
      const rMom = evaluateCompatibility(y2, 'female', yb, 'male');
      if (!rDad || !rMom) return null;
      const avg = Number(((rDad.total + rMom.total) / 2).toFixed(1));
      lastEval = { mode, y1, y2, yb, rDad, rMom, total: avg };
      const cls = avg >= 7.5 ? 'good' : avg >= 5.5 ? 'mid' : '';
      q('#cp-result-card').classList.remove('hidden');
      q('#cp-result-card').innerHTML = `
        <div class="sf-score-banner">
          <div class="sf-score-circle ${cls}"><span class="sf-score-num">${avg}</span><span class="sf-score-sub">/10đ</span></div>
          <div>
            <div style="font-weight:800;font-size:14px;color:#7F1D1D;">Sinh con năm ${yb} (${rDad.pB.canChi} — Mệnh ${rDad.pB.napAmName})</div>
            <div style="font-size:12px;color:#92400E;font-weight:700;">${avg >= 7.5 ? '🌟 Năm rất đẹp để đón bé!' : avg >= 5.5 ? '✨ Khá hài hòa với cả bố và mẹ' : '⚖️ Nên xem thêm tháng sinh tốt để dung hòa'}</div>
          </div>
        </div>
        <div class="sf-kv-list">
          <div class="sf-kv-item"><div class="sf-kv-head"><strong>👨 Với Bố (${y1} • ${rDad.pA.canChi})</strong><span class="sf-badge ${rDad.total >= 7 ? 'good' : 'warn'}">${rDad.total}/10đ</span></div><div>Mệnh: ${rDad.elRes.label} • Địa Chi: ${rDad.chiRes.label}</div></div>
          <div class="sf-kv-item"><div class="sf-kv-head"><strong>👩 Với Mẹ (${y2} • ${rMom.pA.canChi})</strong><span class="sf-badge ${rMom.total >= 7 ? 'good' : 'warn'}">${rMom.total}/10đ</span></div><div>Mệnh: ${rMom.elRes.label} • Địa Chi: ${rMom.chiRes.label}</div></div>
        </div>
      `;
      return lastEval;
    }

    const r = evaluateCompatibility(y1, g1, y2, g2);
    if (!r) return null;
    lastEval = { mode, y1, g1, y2, g2, ...r };
    const cls = r.total >= 7.5 ? 'good' : r.total >= 5.5 ? 'mid' : '';
    const verdict = r.total >= 8 ? '🌟 Rất hợp — Tương trợ bền vững!' : r.total >= 6.5 ? '✨ Khá hợp — Dễ đồng hành lâu dài' : r.total >= 5 ? '⚖️ Trung bình — Cần lắng nghe & bổ trợ nhau' : '⚠️ Có điểm xung khắc — Nên xem cách dung hòa';

    q('#cp-result-card').classList.remove('hidden');
    q('#cp-result-card').innerHTML = `
      <div class="sf-score-banner">
        <div class="sf-score-circle ${cls}"><span class="sf-score-num">${r.total}</span><span class="sf-score-sub">/10đ</span></div>
        <div>
          <div style="font-weight:800;font-size:13.5px;color:#7F1D1D;">${y1} (${r.pA.canChi}) 🤝 ${y2} (${r.pB.canChi})</div>
          <div style="font-size:12px;color:#92400E;font-weight:700;margin-top:2px;">${verdict}</div>
        </div>
      </div>
      <div class="sf-kv-list">
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🔥 Ngũ hành Nạp Âm</strong><span class="sf-badge ${r.elRes.cls}">${r.elRes.label}</span></div><div>${r.pA.napAmName} (${r.pA.element}) vs ${r.pB.napAmName} (${r.pB.element})</div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>📜 Thiên Can</strong><span class="sf-badge ${r.canRes.cls}">${r.canRes.label}</span></div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🐉 Địa Chi</strong><span class="sf-badge ${r.chiRes.cls}">${r.chiRes.label}</span></div></div>
        <div class="sf-kv-item"><div class="sf-kv-head"><strong>🧭 Cung Phi Bát Trạch</strong><span class="sf-badge ${r.phiRes.cls}">${r.phiRes.label}</span></div><div>Ngũ hành Cung: ${r.phiEl.label}</div></div>
      </div>
    `;
    return lastEval;
  };

  q('#btn-cp-calc')?.addEventListener('click', runCalc);
  q('#btn-cp-ai')?.addEventListener('click', async () => {
    const r = runCalc();
    if (!r || busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#cp-status').className = 'sf-status err';
      q('#cp-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-cp-cfg">Nhập Key</button>';
      q('#btn-cp-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-cp-ai').disabled = true;
    q('#cp-status').className = 'sf-status';
    q('#cp-status').textContent = '✨ Gemini AI đang phân tích độ hợp & gợi ý hóa giải...';
    q('#cp-ai-card').classList.remove('hidden');
    q('#cp-ai-body').innerHTML = '✨ Đang phân tích...';
    try {
      const mLbl = mode === 'marriage' ? 'Vợ chồng / Hôn nhân' : mode === 'business' ? 'Hợp tác làm ăn kinh doanh' : `Sinh con năm ${r.yb}`;
      const prompt = mode === 'baby'
        ? `Phân tích sinh con năm ${r.yb} (${r.rDad.pB.canChi}, mệnh ${r.rDad.pB.napAmName}) cho Bố ${r.y1} (${r.rDad.pA.canChi}) và Mẹ ${r.y2} (${r.rMom.pA.canChi}). Điểm tổng ${r.total}/10. Nêu điểm thuận lợi, tháng sinh đẹp trong năm ${r.yb} và lời khuyên tích cực.`
        : `Phân tích hợp tuổi ${mLbl} giữa ${r.y1} (${r.pA.canChi}, mệnh ${r.pA.napAmName}) và ${r.y2} (${r.pB.canChi}, mệnh ${r.pB.napAmName}). Điểm ${r.total}/10 (Ngũ hành: ${r.elRes.label}; Thiên Can: ${r.canRes.label}; Địa Chi: ${r.chiRes.label}; Cung Phi: ${r.phiRes.label}). Nêu điểm hợp, điểm cần lưu ý và cách dung hòa thực tế, tích cực (không gây hoang mang).`;
      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là chuyên gia tư vấn hợp tuổi, tâm lý gia đình và phong thủy Việt Nam tích cực, văn minh.',
        userPrompt: prompt,
        temperature: 0.45
      }, (p) => { if (p) q('#cp-ai-body').innerHTML = fmtMd(p); });
      lastAi = `💑 Xem tuổi hợp (${mLbl}) — ${r.total}/10đ\n\n${ans}`;
      q('#cp-ai-body').innerHTML = fmtMd(ans);
      q('#cp-status').textContent = '✅ Đã phân tích xong!';
    } catch (err) {
      q('#cp-status').className = 'sf-status err';
      q('#cp-status').textContent = `⚠️ ${err?.message || 'Lỗi AI'}`;
    } finally {
      busy = false;
      q('#btn-cp-ai').disabled = false;
    }
  });

  q('#btn-cp-copy')?.addEventListener('click', async () => {
    if (!lastAi) return;
    try { await navigator.clipboard.writeText(lastAi); } catch (_e) {}
    q('#cp-status').textContent = '✓ Đã sao chép!';
  });
  q('#btn-cp-zalo')?.addEventListener('click', () => { if (lastAi) shareToZaloQuick(lastAi); });
  q('#btn-cp-tg')?.addEventListener('click', (e) => { if (lastAi && onSendTelegram) onSendTelegram(escHtml(lastAi), e.currentTarget); });

  runCalc();
}
