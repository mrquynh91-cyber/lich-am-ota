/**
 * Zalo Quick-Share & Custom Webhook Helper (Zalo OA / n8n / Make / Discord / Lark)
 * Lets Vietnamese users share any day, reminder, or prayer to Zalo in 1 tap,
 * or automatically POST notifications to a custom Webhook URL.
 */

export const DEFAULT_ZALO_WEBHOOK_SETTINGS = {
  enabled: false,
  webhookUrl: '',
  sendTimed: true,
  sendHolidays: true
};

/**
 * Copy formatted message to clipboard and open Zalo Web / Zalo App so user can paste & send immediately
 */
export async function shareToZaloQuick(plainText) {
  let copied = false;
  try {
    await navigator.clipboard.writeText(plainText);
    copied = true;
  } catch (_e) {
    // Fallback textarea copy
    try {
      const ta = document.createElement('textarea');
      ta.value = plainText;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      copied = document.execCommand('copy');
      ta.remove();
    } catch (_e2) {}
  }

  // Inside OPPO Find X9 Native APK: open native Android Share Sheet straight to Zalo!
  if (typeof window !== 'undefined' && window.AndroidBridge && typeof window.AndroidBridge.shareText === 'function') {
    try {
      window.AndroidBridge.shareText(plainText);
      return { ok: true, mode: 'android_share', copied };
    } catch (_err) {}
  }

  // On mobile Web Share API if supported (iPhone 13 Safari & Android Chrome share sheet includes Zalo!)
  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function' && /Android|iPhone|iPad/i.test(navigator.userAgent || '')) {
    try {
      await navigator.share({ title: 'Lịch Âm Việt Nam', text: plainText });
      return { ok: true, mode: 'native_share', copied };
    } catch (_err) {
      // User dismissed or unsupported -> fall back to Zalo link
    }
  }

  try {
    window.open('https://chat.zalo.me/', '_blank', 'noopener');
  } catch (_e) {}

  return { ok: true, mode: 'zalo_web', copied };
}

/**
 * Send JSON payload to a configured Webhook URL (Zalo Bot / n8n / Make / Discord / custom endpoint)
 */
export async function sendWebhookNotification({ webhookUrl, title, text, meta = {} }) {
  const url = String(webhookUrl || '').trim();
  if (!url || !/^https?:\/\//i.test(url)) {
    return { ok: false, error: 'URL Webhook phải bắt đầu bằng https:// hoặc http://' };
  }

  try {
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: 'LichAmVietNam',
        title,
        text,
        content: `${title}\n${text}`, // Compatible with Discord/Zalo/n8n/Make webhooks
        meta,
        timestamp: new Date().toISOString()
      })
    });
    if (!resp.ok) {
      return { ok: false, error: `Webhook trả về HTTP ${resp.status}` };
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `Lỗi gọi Webhook: ${err?.message || 'kiểm tra URL hoặc mạng'}` };
  }
}
