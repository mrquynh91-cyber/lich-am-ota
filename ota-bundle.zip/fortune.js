/**
 * Luận giải Quẻ Đình Chùa & Lá Số Tử Vi (Chụp ảnh / Tải ảnh tờ giấy + Gemini Vision AI)
 * Dùng chung cho cả PC Chrome Extension, PC Tray App & OPPO Find X9 APK (v2.14.0).
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import { compressImageSourceToBase64 } from './moles.js';
import { openSmartCamera, attachCameraControlBar, removeCameraControlBar } from './camera-helper.js';
import {
  isGeminiConfigured,
  analyzeFortuneOrHoroscopeWithGemini,
  getLastGeminiMeta
} from './gemini-ai.js';
import { shareToZaloQuick } from './zalo.js';
import { getYearCanChi } from './lunar.js';

export const FORTUNE_TYPES = [
  { id: 'auto', label: '✨ Tự nhận diện' },
  { id: 'que-xam', label: '🏮 Quẻ xăm Đình Chùa' },
  { id: 'tu-vi', label: '⭐ Lá số Tử Vi' },
  { id: 'kinh-dich', label: '☯️ Kinh Dịch / Bát Tự' }
];

export const FORTUNE_TOPICS = [
  { id: 'tong-quan', label: '🌟 Tổng quan' },
  { id: 'su-nghiep', label: '💼 Công danh' },
  { id: 'tai-loc', label: '💰 Tài lộc' },
  { id: 'tinh-duyen', label: '💞 Tình duyên' },
  { id: 'suc-khoe', label: '🏥 Sức khỏe' },
  { id: 'gia-dao', label: '🏠 Gia đạo / Xuất hành' }
];

export const FORTUNE_GRADES = [
  {
    id: 'thuong-thuong',
    badge: '🌟 Đại Cát',
    cls: 'good',
    title: 'Thượng Thượng / Thượng Đại Cát',
    desc: 'Quẻ rất tốt — thiên thời, địa lợi, nhân hòa đang hội tụ. Dự định lớn có quý nhân nâng đỡ, dễ đạt kết quả mỹ mãn.',
    advice: 'Nên mạnh dạn triển khai kế hoạch đã chuẩn bị kỹ, đồng thời giữ tâm khiêm nhường và chia sẻ phúc lành để lộc bền lâu.'
  },
  {
    id: 'thuong-cat',
    badge: '✨ Cát',
    cls: 'good',
    title: 'Thượng Cát / Thượng Quẻ',
    desc: 'Vận trình hanh thông, công việc và gia đạo đều có tín hiệu khởi sắc rõ rệt. Khó khăn cũ dần được tháo gỡ.',
    advice: 'Kiên trì theo đuổi mục tiêu, tránh chủ quan; việc thiện nhỏ mỗi ngày sẽ càng nhân thêm may mắn.'
  },
  {
    id: 'trung-cat',
    badge: '🍀 Khá Tốt',
    cls: 'good',
    title: 'Trung Cát / Trung Thượng',
    desc: 'Bình an ổn định, có cơ hội tốt nhưng cần thêm thời gian và sự nhẫn nại mới gặt hái trọn vẹn.',
    advice: 'Làm chắc từng bước, ưu tiên chữ tín và sự hợp tác hài hòa, không nên nóng vội đốt cháy giai đoạn.'
  },
  {
    id: 'trung-binh',
    badge: '⚖️ Bình Hòa',
    cls: 'neutral',
    title: 'Trung Bình / Bình Quẻ',
    desc: 'Mọi sự ở mức quân bình — không quá trắc trở nhưng cũng chưa phải lúc bứt phá mạnh mẽ. Cát hay hung phần lớn do mình quyết định.',
    advice: 'Giữ nhịp sống điều độ, củng cố nội lực, học hỏi thêm và chờ thời cơ chín muồi hơn.'
  },
  {
    id: 'trung-ha',
    badge: '⚠️ Cẩn Trọng',
    cls: 'warn',
    title: 'Trung Hạ / Hạ Trung',
    desc: 'Lời nhắc nhở cần thận trọng trong giao dịch, lời ăn tiếng nói và sức khỏe; dễ gặp vài trở ngại nhỏ ngoài dự tính.',
    advice: 'Chậm lại để kiểm tra kỹ giấy tờ, tránh tranh cãi và đầu tư mạo hiểm — "cẩn tắc vô áy náy".'
  },
  {
    id: 'ha-ha',
    badge: '🛡️ Hóa Giải',
    cls: 'warn',
    title: 'Hạ Hạ (Quẻ Nhắc Nhở & Tu Tâm)',
    desc: 'Theo tinh thần nhà Phật, quẻ Hạ không phải án định xấu mà là chuông cảnh tỉnh sớm giúp bạn tránh rủi ro trước khi xảy ra.',
    advice: 'Tạm hoãn việc lớn chưa gấp, ưu tiên giữ sức khỏe, hòa khí gia đình, làm việc thiện và bình tĩnh vượt qua giai đoạn thử thách.'
  }
];

export const TUVI_12_PALACES = [
  { id: 'menh', name: '1. Cung Mệnh', tag: 'Bản mệnh & Tính cách', desc: 'Cung quan trọng nhất trên lá số Tử Vi — thể hiện cốt cách, tư duy, năng lực bẩm sinh, ngoại hình và định hướng cuộc đời.' },
  { id: 'phu-mau', name: '2. Cung Phụ Mẫu', tag: 'Cha mẹ & Cấp trên', desc: 'Cho biết duyên phận với cha mẹ, nền tảng gia đình thuở nhỏ, đồng thời phản ánh mối quan hệ với lãnh đạo, thầy cô.' },
  { id: 'phuc-duc', name: '3. Cung Phúc Đức', tag: 'Phúc phần & Tinh thần', desc: 'Chỉ âm đức dòng họ, sự an yên trong tâm hồn, tuổi thọ và độ may mắn âm thầm nâng đỡ khi gặp gian nan.' },
  { id: 'dien-trach', name: '4. Cung Điền Trạch', tag: 'Nhà cửa & Bất động sản', desc: 'Chủ về nhà cửa, đất đai, nơi ăn chốn ở, tài sản tích lũy cố định và môi trường làm việc.' },
  { id: 'quan-loc', name: '5. Cung Quan Lộc', tag: 'Công danh & Nghề nghiệp', desc: 'Phản ánh đường học vấn, sự nghiệp, chức vụ, ngành nghề phù hợp và mức độ thăng tiến trong công việc.' },
  { id: 'no-boc', name: '6. Cung Nô Bộc', tag: 'Bạn bè & Đối tác', desc: 'Thể hiện quan hệ với bạn bè, đồng nghiệp, cộng sự, nhân viên cấp dưới — xem có nhiều người giúp đỡ hay cần chọn bạn kỹ.' },
  { id: 'thien-di', name: '7. Cung Thiên Di', tag: 'Xuất hành & Xã hội', desc: 'Cho biết vận thế khi đi xa, giao tiếp ngoài xã hội, cơ hội lập nghiệp phương xa và sự an toàn trên đường di chuyển.' },
  { id: 'tat-ach', name: '8. Cung Tật Ách', tag: 'Sức khỏe & Phòng ngừa', desc: 'Cảnh báo sớm những điểm nhạy cảm về sức khỏe, thể trạng cần lưu ý rèn luyện và giữ gìn trong từng đại vận.' },
  { id: 'tai-bach', name: '9. Cung Tài Bạch', tag: 'Tiền tài & Quản lý', desc: 'Nói về cách kiếm tiền, nguồn thu nhập chính/phụ, khả năng giữ tiền và vận tài lộc qua các giai đoạn.' },
  { id: 'tu-tuc', name: '10. Cung Tử Tức', tag: 'Con cái & Hậu thế', desc: 'Thể hiện duyên con cái, tính cách và sự hiếu thuận của con cháu, cũng như mối quan hệ với học trò / người kế thừa.' },
  { id: 'phu-the', name: '11. Cung Phu Thê', tag: 'Hôn nhân & Tình duyên', desc: 'Phản ánh mẫu người bạn đời, đời sống vợ chồng, sự hòa hợp tình cảm và cách gìn giữ hạnh phúc gia đình.' },
  { id: 'huynh-de', name: '12. Cung Huynh Đệ', tag: 'Anh chị em & Cộng lực', desc: 'Cho biết tình cảm, sự gắn kết và mức độ hỗ trợ qua lại giữa anh chị em ruột hoặc bạn bè thân thiết như người nhà.' }
];

const HISTORY_LS_KEY = 'lich_am_fortune_history_v1';

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatMd(raw) {
  const safe = escHtml(String(raw || ''));
  return safe
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*([^*\n]+)\*(?=$|[\s,.;:!?])/g, '$1<em>$2</em>')
    .replace(/^\s*---\s*$/gm, '<hr style="border:none;border-top:1px solid #E5E7EB;margin:6px 0;" />')
    .replace(/^\s*[\*\-]\s+/gm, '• ');
}

function loadHistory() {
  try {
    const raw = localStorage.getItem(HISTORY_LS_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch (_e) {
    return [];
  }
}

function saveHistory(arr) {
  try {
    localStorage.setItem(HISTORY_LS_KEY, JSON.stringify((arr || []).slice(0, 15)));
  } catch (_e) { /* ignore */ }
}

/**
 * Mount the full interactive Temple Fortune Slip & Tử Vi Horoscope photo scanner into any container (PC or Mobile).
 */
export function mountFortuneModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const {
    isMobile = false,
    getState = () => ({}),
    onBack = () => {},
    onOpenGeminiSettings = () => {},
    onSendTelegram = null
  } = opts;

  let docType = 'auto';
  let focusTopic = 'tong-quan';
  let gender = 'male';
  let activeFacing = 'environment'; // Cam sau mặc định cho chụp giấy rõ nét không lật chữ!
  let activeStream = null;
  let capturedImages = []; // [{ dataUrl, base64, label }] (tối đa 2 mặt giấy)
  let busy = false;
  let lastPlainText = '';
  let refTab = 'grades'; // 'grades' | 'palaces'
  let activePalaceId = TUVI_12_PALACES[0].id;
  let speechPlaying = false;

  const initBirthYear = String(getState()?.auspiciousPrefs?.birthYear || '');

  mountEl.innerHTML = `
    <div class="ft-layout">
      <div class="ft-main-col">
        <div class="card ft-ai-card">
          <div class="ft-head">
            <div>
              <h2 class="ft-title">📜 Luận giải Quẻ Đình Chùa &amp; Lá Số Tử Vi</h2>
              <div class="ft-sub">Chụp hoặc tải ảnh tờ quẻ xăm đình chùa, lá số Tử Vi (hỗ trợ cả 2 mặt giấy) — Gemini AI đọc chữ Hán-Nôm/Việt, dịch nghĩa và luận giải chi tiết (không lưu ảnh).</div>
            </div>
            <button type="button" class="ft-back-btn" id="btn-ft-back">← Thêm</button>
          </div>

          <div class="ft-section-lbl">Loại tờ giấy muốn luận giải:</div>
          <div id="ft-type-pills" class="ft-pills-wrap">
            ${FORTUNE_TYPES.map((t, i) => `<button type="button" class="ft-pill${i === 0 ? ' active' : ''}" data-type="${t.id}">${t.label}</button>`).join('')}
          </div>

          <div class="ft-person-row">
            <div class="ft-person-gender">
              <span class="ft-mini-lbl">Giới tính:</span>
              <div id="ft-gender-pills" class="ft-pills-wrap" style="margin-bottom:0;">
                <button type="button" class="ft-pill active" data-gender="male">👨 Nam</button>
                <button type="button" class="ft-pill" data-gender="female">👩 Nữ</button>
              </div>
            </div>
            <div class="ft-person-year">
              <label for="ft-birth-year" class="ft-mini-lbl">Năm sinh (tùy chọn):</label>
              <input id="ft-birth-year" type="number" inputmode="numeric" min="1920" max="2050" placeholder="VD: 1991" value="${escHtml(initBirthYear)}" />
            </div>
          </div>
          <div id="ft-year-badge" class="ft-year-badge hidden"></div>

          <div class="ft-section-lbl">Việc đang cầu xin / quan tâm nhất:</div>
          <div id="ft-topic-pills" class="ft-pills-wrap">
            ${FORTUNE_TOPICS.map((t, i) => `<button type="button" class="ft-pill${i === 0 ? ' active' : ''}" data-topic="${t.id}">${t.label}</button>`).join('')}
          </div>

          <div class="mole-stage ft-stage" id="ft-stage">
            <video id="ft-video" class="mole-media hidden" autoplay playsinline muted></video>
            <img id="ft-preview" class="mole-photo-img hidden" alt="Ảnh tờ quẻ / lá số Tử Vi" />
            <div id="ft-cam-guide" class="mole-face-guide hidden" aria-hidden="true">
              <div class="ft-doc-frame"></div>
              <span id="ft-cam-guide-lbl">Giữ tờ giấy phẳng, đủ sáng, rõ chữ trong khung</span>
            </div>
            <div id="ft-empty-placeholder" class="mole-placeholder">
              <div style="font-size: 38px; margin-bottom: 4px;">📜</div>
              <div>Bấm <strong>📷 Chụp tờ giấy</strong> hoặc <strong>📁 Tải ảnh Quẻ / Lá số</strong> để AI luận giải ngay</div>
              <div style="font-size: 11px; opacity: 0.8; margin-top: 4px;">Hỗ trợ chụp/tải tối đa 2 mặt (Mặt trước &amp; Mặt sau)</div>
            </div>
          </div>

          <div id="ft-thumbs-bar" class="ft-thumbs-bar hidden"></div>

          <div class="mole-actions-bar">
            <button type="button" id="btn-ft-cam-back" class="btn-primary">📷 Chụp tờ giấy</button>
            <button type="button" id="btn-ft-snap" class="btn-ai-inline hidden">✨ Chụp ảnh này</button>
            <button type="button" id="btn-ft-switch-cam" class="${isMobile ? 'btn-chip' : 'btn-outline btn-xs'} hidden">🔄 Đổi cam</button>
            <button type="button" id="btn-ft-stop-cam" class="${isMobile ? 'btn-chip' : 'btn-ghost btn-xs'} hidden">Tắt cam</button>
            <label class="${isMobile ? 'btn-chip primary' : 'btn-outline'}" style="cursor: pointer; display: inline-flex; align-items: center; gap: 4px;">
              📁 Tải ảnh lên
              <input id="ft-file-input" type="file" accept="image/*" multiple class="hidden" />
            </label>
            <input id="ft-cam-fallback" type="file" accept="image/*" capture="environment" class="hidden" />
            <button type="button" id="btn-ft-analyze" class="btn-ai-inline hidden">✨ Luận giải bằng AI</button>
          </div>

          <div class="ft-note-row">
            <input id="ft-extra-note" type="text" placeholder="Ghi chú thêm (tùy chọn — VD: Rút quẻ ở chùa Hà, hỏi dự định mở cửa hàng tháng tới...)" maxlength="200" />
          </div>

          <div id="ft-ai-status" class="ft-status"></div>

          <div id="ft-result-card" class="dream-result-card hidden">
            <div class="dream-result-head">
              <strong id="ft-result-title">✨ Luận giải Quẻ &amp; Lá Số Tử Vi</strong>
              <div class="ft-res-actions">
                <button type="button" id="btn-ft-speak" class="${isMobile ? 'btn-chip' : 'btn-outline btn-xs'}">🔊 Đọc</button>
                <button type="button" id="btn-ft-copy" class="${isMobile ? 'btn-chip' : 'btn-outline btn-xs'}">📋 Chép</button>
                <button type="button" id="btn-ft-zalo" class="${isMobile ? 'btn-chip zalo' : 'btn-zalo-quick'}">💬 Zalo</button>
                <button type="button" id="btn-ft-tg" class="${isMobile ? 'btn-chip tg' : 'btn-tg-quick'}">✈️ TG</button>
              </div>
            </div>
            <div id="ft-result-body" class="dream-result-body"></div>
          </div>
        </div>

        <div id="ft-history-card" class="card hidden">
          <div class="ft-head" style="margin-bottom: 6px;">
            <h3 class="ft-ref-title" style="margin:0;">🕘 Quẻ &amp; Lá số đã luận giải gần đây</h3>
            <button type="button" id="btn-ft-clear-hist" class="${isMobile ? 'btn-chip' : 'btn-ghost btn-xs'}">Xóa lịch sử</button>
          </div>
          <div id="ft-history-list" class="ft-history-list"></div>
        </div>
      </div>

      <div class="ft-ref-col">
        <div class="card">
          <h3 class="ft-ref-title">📖 Sổ tay tra nhanh Đình Chùa &amp; Tử Vi</h3>
          <div class="ft-ref-tabs">
            <button type="button" class="ft-ref-tab active" data-reftab="grades">🏮 6 Hạng Quẻ Xăm</button>
            <button type="button" class="ft-ref-tab" data-reftab="palaces">⭐ 12 Cung Tử Vi</button>
          </div>
          <div id="ft-ref-body"></div>
        </div>
      </div>
    </div>
  `;

  const q = (sel) => mountEl.querySelector(sel);
  const videoEl = q('#ft-video');
  const previewEl = q('#ft-preview');
  const guideEl = q('#ft-cam-guide');
  const guideLbl = q('#ft-cam-guide-lbl');
  const emptyEl = q('#ft-empty-placeholder');
  const thumbsBar = q('#ft-thumbs-bar');
  const camBackBtn = q('#btn-ft-cam-back');
  const snapBtn = q('#btn-ft-snap');
  const switchCamBtn = q('#btn-ft-switch-cam');
  const stopCamBtn = q('#btn-ft-stop-cam');
  const fileInp = q('#ft-file-input');
  const camFallbackInp = q('#ft-cam-fallback');
  const analyzeBtn = q('#btn-ft-analyze');
  const birthYearInp = q('#ft-birth-year');
  const yearBadge = q('#ft-year-badge');
  const noteInp = q('#ft-extra-note');
  const statusEl = q('#ft-ai-status');
  const resCard = q('#ft-result-card');
  const resTitle = q('#ft-result-title');
  const resBody = q('#ft-result-body');
  const speakBtn = q('#btn-ft-speak');
  const histCard = q('#ft-history-card');
  const histList = q('#ft-history-list');
  const refBody = q('#ft-ref-body');

  const setStatus = (msg, isErr = false) => {
    if (!statusEl) return;
    statusEl.textContent = msg || '';
    statusEl.className = isErr ? 'ft-status err' : 'ft-status';
  };

  const updateYearBadge = () => {
    const y = Number(birthYearInp?.value || 0);
    if (y >= 1920 && y <= 2050) {
      yearBadge?.classList.remove('hidden');
      if (yearBadge) yearBadge.textContent = `🎂 Tuổi ${getYearCanChi(y)} (${y}) — AI sẽ gắn luận giải theo tuổi này`;
    } else {
      yearBadge?.classList.add('hidden');
    }
  };
  updateYearBadge();
  birthYearInp?.addEventListener('input', updateYearBadge);

  const stopSpeech = () => {
    speechPlaying = false;
    try { window.speechSynthesis?.cancel(); } catch (_e) {}
    if (speakBtn) speakBtn.textContent = '🔊 Đọc';
  };

  const stopCamera = () => {
    if (activeStream) {
      activeStream.getTracks().forEach((tr) => { try { tr.stop(); } catch (_e) {} });
      activeStream = null;
    }
    if (videoEl) {
      videoEl.srcObject = null;
      videoEl.classList.add('hidden');
    }
    removeCameraControlBar(q('#ft-stage'));
    guideEl?.classList.add('hidden');
    snapBtn?.classList.add('hidden');
    switchCamBtn?.classList.add('hidden');
    stopCamBtn?.classList.add('hidden');
    camBackBtn?.classList.remove('hidden');
    if (capturedImages.length === 0) {
      emptyEl?.classList.remove('hidden');
    } else {
      previewEl?.classList.remove('hidden');
    }
  };

  const renderThumbs = () => {
    if (!thumbsBar) return;
    if (capturedImages.length === 0) {
      thumbsBar.classList.add('hidden');
      thumbsBar.innerHTML = '';
      previewEl?.classList.add('hidden');
      emptyEl?.classList.remove('hidden');
      analyzeBtn?.classList.add('hidden');
      return;
    }
    emptyEl?.classList.add('hidden');
    previewEl?.classList.remove('hidden');
    if (previewEl) previewEl.src = capturedImages[capturedImages.length - 1].dataUrl;
    analyzeBtn?.classList.remove('hidden');
    if (analyzeBtn && !busy) {
      analyzeBtn.textContent = capturedImages.length > 1
        ? `✨ Luận giải ${capturedImages.length} ảnh tờ giấy bằng AI`
        : '✨ Luận giải Quẻ / Lá số bằng AI';
    }

    thumbsBar.classList.remove('hidden');
    thumbsBar.innerHTML = '';
    capturedImages.forEach((imgObj, idx) => {
      const chip = document.createElement('div');
      chip.className = 'ft-thumb-chip';
      chip.innerHTML = `
        <img src="${imgObj.dataUrl}" alt="Ảnh ${idx + 1}" />
        <span>Mặt ${idx + 1}</span>
        <button type="button" class="ft-thumb-del" title="Xóa ảnh này">✕</button>
      `;
      chip.addEventListener('click', (ev) => {
        if (ev.target.closest('.ft-thumb-del')) return;
        if (previewEl) previewEl.src = imgObj.dataUrl;
      });
      chip.querySelector('.ft-thumb-del')?.addEventListener('click', () => {
        capturedImages.splice(idx, 1);
        renderThumbs();
      });
      thumbsBar.appendChild(chip);
    });

    if (capturedImages.length < 2) {
      const addHint = document.createElement('button');
      addHint.type = 'button';
      addHint.className = 'ft-thumb-add';
      addHint.textContent = '+ Thêm mặt sau';
      addHint.addEventListener('click', () => fileInp?.click());
      thumbsBar.appendChild(addHint);
    }
  };

  const renderHistory = () => {
    if (!histCard || !histList) return;
    const items = loadHistory();
    if (items.length === 0) {
      histCard.classList.add('hidden');
      histList.innerHTML = '';
      return;
    }
    histCard.classList.remove('hidden');
    histList.innerHTML = '';
    items.forEach((item) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'ft-hist-item';
      btn.innerHTML = `
        <div class="ft-hist-title">📜 ${escHtml(item.title || 'Luận giải Quẻ / Lá số')}</div>
        <div class="ft-hist-meta">${escHtml(item.meta || '')}</div>
      `;
      btn.addEventListener('click', () => {
        stopSpeech();
        lastPlainText = item.text || '';
        resCard?.classList.remove('hidden');
        if (resTitle) resTitle.textContent = `📜 ${item.title || 'Luận giải đã lưu'}`;
        if (resBody) resBody.innerHTML = formatMd(item.text || '');
        resCard?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      });
      histList.appendChild(btn);
    });
  };

  const runAiAnalyze = async () => {
    if (capturedImages.length === 0 || busy) return;
    const appState = getState();
    if (!isGeminiConfigured(appState?.geminiSettings)) {
      if (statusEl) {
        statusEl.className = 'ft-status err';
        statusEl.innerHTML = '🔑 Bạn chưa nhập Gemini API Key miễn phí để đọc &amp; luận giải ảnh giấy. <button type="button" class="btn-ai-inline btn-xs" id="btn-ft-cfg">Nhập Key ngay</button>';
        q('#btn-ft-cfg')?.addEventListener('click', onOpenGeminiSettings);
      }
      return;
    }

    stopSpeech();
    busy = true;
    if (analyzeBtn) { analyzeBtn.disabled = true; analyzeBtn.textContent = '⏳ AI đang đọc chữ & luận giải...'; }
    setStatus(`✨ Gemini Vision đang đọc kỹ nội dung ${capturedImages.length} ảnh tờ giấy & luận giải chi tiết...`);
    resCard?.classList.remove('hidden');
    if (resTitle) resTitle.textContent = '✨ Đang đọc & luận giải Quẻ / Lá Số...';
    if (resBody) resBody.innerHTML = '✨ Đang nhận diện chữ trên tờ giấy (Hán-Nôm / Tiếng Việt / 12 cung Tử Vi) và phân tích ý nghĩa...';

    try {
      const typeLabel = FORTUNE_TYPES.find((t) => t.id === docType)?.label || 'Tự nhận diện';
      const topicLabel = FORTUNE_TOPICS.find((t) => t.id === focusTopic)?.label || 'Tổng quan';
      const bYear = String(birthYearInp?.value || '').trim();
      const extraNote = String(noteInp?.value || '').trim();

      const fullAns = await analyzeFortuneOrHoroscopeWithGemini(
        appState.geminiSettings,
        capturedImages.map((x) => x.base64),
        {
          docType,
          docTypeLabel: typeLabel,
          focusTopic,
          focusTopicLabel: topicLabel,
          gender,
          birthYear: bYear,
          extraNote
        },
        appState,
        new Date(),
        (partial) => {
          if (partial && resBody) resBody.innerHTML = formatMd(partial);
        }
      );

      const meta = getLastGeminiMeta();
      const firstLine = (String(fullAns).split('\n').find((l) => l.trim().length > 4) || typeLabel)
        .replace(/[\*#]/g, '')
        .trim()
        .slice(0, 70);
      const speedTag = meta?.model ? ` (${meta.model} • ${(meta.ms / 1000).toFixed(1)}s)` : '';

      lastPlainText = `📜 Luận giải Quẻ Đình Chùa & Lá Số Tử Vi (${gender === 'female' ? 'Nữ' : 'Nam'}${bYear ? ` • ${bYear}` : ''})\n\n${fullAns}`;
      if (resTitle) resTitle.textContent = `✨ Kết quả Luận giải${speedTag}`;
      if (resBody) resBody.innerHTML = formatMd(fullAns);
      setStatus(`✅ Đã đọc và luận giải xong${speedTag}! Bạn có thể bấm 🔊 Đọc, Sao chép hoặc gửi Zalo/Telegram.`);

      const now = new Date();
      const dateStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const hist = loadHistory();
      hist.unshift({
        id: `ft-${Date.now()}`,
        title: firstLine,
        meta: `${dateStr} • ${topicLabel}${bYear ? ` • Tuổi ${bYear}` : ''}`,
        text: fullAns
      });
      saveHistory(hist);
      renderHistory();
      resCard?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (err) {
      setStatus(`⚠️ ${err?.message || 'Lỗi đọc và luận giải ảnh bằng Gemini AI'}`, true);
    } finally {
      busy = false;
      if (analyzeBtn) analyzeBtn.disabled = false;
      renderThumbs();
    }
  };

  const addImageFromSource = (source, autoAnalyze = true) => {
    const { dataUrl, base64 } = compressImageSourceToBase64(source, 1400, 0.92, false);
    if (capturedImages.length >= 2) {
      capturedImages[1] = { dataUrl, base64 };
    } else {
      capturedImages.push({ dataUrl, base64 });
    }
    stopCamera();
    renderThumbs();
    if (autoAnalyze && capturedImages.length === 1) {
      runAiAnalyze();
    } else {
      setStatus(`📷 Đã thêm Mặt ${capturedImages.length}! Bấm "✨ Luận giải ${capturedImages.length} ảnh tờ giấy bằng AI" để phân tích cả 2 mặt.`);
    }
  };

  const handleFiles = (fileList) => {
    const files = Array.from(fileList || []).slice(0, 2);
    if (files.length === 0) return;
    stopCamera();
    // If picking 2 files at once, replace current list cleanly
    if (files.length === 2) capturedImages = [];
    let loaded = 0;
    files.forEach((file) => {
      const img = new Image();
      const objUrl = URL.createObjectURL(file);
      img.onload = () => {
        const { dataUrl, base64 } = compressImageSourceToBase64(img, 1400, 0.92, false);
        URL.revokeObjectURL(objUrl);
        if (capturedImages.length >= 2) capturedImages[1] = { dataUrl, base64 };
        else capturedImages.push({ dataUrl, base64 });
        loaded++;
        if (loaded === files.length) {
          renderThumbs();
          runAiAnalyze();
        }
      };
      img.onerror = () => {
        URL.revokeObjectURL(objUrl);
        setStatus('⚠️ Không đọc được file ảnh này. Hãy chọn ảnh JPG/PNG khác.', true);
      };
      img.src = objUrl;
    });
  };

  const startCamera = async (facing = 'environment', preferredDeviceId = null) => {
    activeFacing = facing;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      if (isMobile && camFallbackInp) {
        camFallbackInp.setAttribute('capture', facing);
        camFallbackInp.click();
      } else {
        setStatus('⚠️ Không hỗ trợ Camera trực tiếp ở cửa sổ này — hãy bấm "📁 Tải ảnh lên" hoặc "Mở toàn trang ↗".', true);
      }
      return;
    }
    try {
      stopCamera();
      const ctrl = await openSmartCamera(facing, { preferredDeviceId });
      activeStream = ctrl.stream;
      if (videoEl) {
        videoEl.srcObject = ctrl.stream;
        videoEl.classList.remove('hidden');
        try { await videoEl.play(); } catch (_e) {}
      }
      previewEl?.classList.add('hidden');
      emptyEl?.classList.add('hidden');
      guideEl?.classList.remove('hidden');
      if (guideLbl) {
        guideLbl.textContent = facing === 'environment'
          ? 'Cam sau 1x — giữ tờ giấy quẻ / lá số phẳng, rõ chữ rồi bấm Chụp'
          : 'Cam trước — đưa tờ giấy đủ sáng vào giữa khung';
      }
      snapBtn?.classList.remove('hidden');
      switchCamBtn?.classList.remove('hidden');
      attachCameraControlBar(q('#ft-stage'), ctrl, {
        onSwitchRearLens: facing === 'environment' ? (devId) => startCamera('environment', devId) : null,
        onOpenNativeCamera: isMobile && camFallbackInp ? () => { stopCamera(); camFallbackInp.setAttribute('capture', facing); camFallbackInp.click(); } : null
      });
      stopCamBtn?.classList.remove('hidden');
      camBackBtn?.classList.add('hidden');
      setStatus('📷 Giữ chắc tay để chữ trên tờ giấy sắc nét rồi bấm "✨ Chụp ảnh này".');
    } catch (_err) {
      if (isMobile && camFallbackInp) {
        setStatus('📸 Chuyển sang chụp bằng Camera máy (hoặc chạm "📁 Tải ảnh lên").');
        camFallbackInp.setAttribute('capture', facing);
        camFallbackInp.click();
      } else {
        setStatus('⚠️ Không mở được Camera — hãy bấm "📁 Tải ảnh lên" để chọn ảnh tờ giấy từ máy tính.', true);
      }
    }
  };

  // Bind controls
  q('#btn-ft-back')?.addEventListener('click', () => {
    stopCamera();
    stopSpeech();
    onBack();
  });

  q('#ft-type-pills')?.addEventListener('click', (e) => {
    const b = e.target.closest('.ft-pill');
    if (!b) return;
    docType = b.dataset.type || 'auto';
    q('#ft-type-pills').querySelectorAll('.ft-pill').forEach((x) => x.classList.toggle('active', x === b));
  });

  q('#ft-gender-pills')?.addEventListener('click', (e) => {
    const b = e.target.closest('.ft-pill');
    if (!b) return;
    gender = b.dataset.gender || 'male';
    q('#ft-gender-pills').querySelectorAll('.ft-pill').forEach((x) => x.classList.toggle('active', x === b));
  });

  q('#ft-topic-pills')?.addEventListener('click', (e) => {
    const b = e.target.closest('.ft-pill');
    if (!b) return;
    focusTopic = b.dataset.topic || 'tong-quan';
    q('#ft-topic-pills').querySelectorAll('.ft-pill').forEach((x) => x.classList.toggle('active', x === b));
  });

  camBackBtn?.addEventListener('click', () => startCamera('environment'));
  switchCamBtn?.addEventListener('click', () => startCamera(activeFacing === 'environment' ? 'user' : 'environment'));
  stopCamBtn?.addEventListener('click', stopCamera);

  snapBtn?.addEventListener('click', () => {
    if (!videoEl || !videoEl.videoWidth) return;
    addImageFromSource(videoEl, true);
  });

  fileInp?.addEventListener('change', (e) => {
    handleFiles(e.target.files);
    e.target.value = '';
  });
  camFallbackInp?.addEventListener('change', (e) => {
    handleFiles(e.target.files);
    e.target.value = '';
  });

  analyzeBtn?.addEventListener('click', runAiAnalyze);

  speakBtn?.addEventListener('click', () => {
    if (!lastPlainText) return;
    if (speechPlaying) {
      stopSpeech();
      return;
    }
    if (!('speechSynthesis' in window)) {
      setStatus('⚠️ Thiết bị chưa hỗ trợ đọc giọng nói trực tiếp.', true);
      return;
    }
    try {
      window.speechSynthesis.cancel();
      const plain = lastPlainText.replace(/[\*#_`]/g, '').replace(/\s+/g, ' ').trim();
      const utt = new SpeechSynthesisUtterance(plain);
      utt.lang = 'vi-VN';
      utt.rate = 0.96;
      const voices = window.speechSynthesis.getVoices() || [];
      const viVoice = voices.find((v) => /vi/i.test(v.lang));
      if (viVoice) utt.voice = viVoice;
      utt.onend = () => stopSpeech();
      utt.onerror = () => stopSpeech();
      speechPlaying = true;
      speakBtn.textContent = '⏹ Dừng';
      window.speechSynthesis.speak(utt);
    } catch (_e) {
      stopSpeech();
    }
  });

  q('#btn-ft-copy')?.addEventListener('click', async () => {
    if (!lastPlainText) return;
    try { await navigator.clipboard.writeText(lastPlainText); } catch (_e) {}
    setStatus('✓ Đã sao chép bài luận giải!');
  });

  q('#btn-ft-zalo')?.addEventListener('click', async (e) => {
    if (!lastPlainText) return;
    const b = e.currentTarget;
    const orig = b.textContent;
    b.textContent = '⏳...';
    await shareToZaloQuick(lastPlainText);
    b.textContent = '✓ Zalo';
    setTimeout(() => { b.textContent = orig; }, 1600);
  });

  q('#btn-ft-tg')?.addEventListener('click', (e) => {
    if (!lastPlainText || typeof onSendTelegram !== 'function') return;
    onSendTelegram(escHtml(lastPlainText), e.currentTarget);
  });

  q('#btn-ft-clear-hist')?.addEventListener('click', () => {
    saveHistory([]);
    renderHistory();
  });

  // Offline Reference Guide (6 Fortune Grades + 12 Tử Vi Palaces)
  const renderRef = () => {
    if (!refBody) return;
    if (refTab === 'grades') {
      refBody.innerHTML = `<div class="ft-ref-list">${FORTUNE_GRADES.map((g) => `
        <div class="ft-grade-card">
          <div class="ft-grade-head">
            <strong>${escHtml(g.title)}</strong>
            <span class="dream-omen-badge ${g.cls}">${g.badge}</span>
          </div>
          <div class="ft-grade-desc">${escHtml(g.desc)}</div>
          <div class="ft-grade-adv"><strong>💡 Tâm thế:</strong> ${escHtml(g.advice)}</div>
        </div>
      `).join('')}</div>`;
      return;
    }

    const cur = TUVI_12_PALACES.find((p) => p.id === activePalaceId) || TUVI_12_PALACES[0];
    refBody.innerHTML = `
      <div class="ft-palace-detail">
        <div class="ft-grade-head" style="margin-bottom:5px;">
          <strong>⭐ ${escHtml(cur.name)}</strong>
          <span class="dream-omen-badge good">${escHtml(cur.tag)}</span>
        </div>
        <div class="ft-grade-desc" style="margin-bottom:0;">${escHtml(cur.desc)}</div>
      </div>
      <div class="mole-spot-pills" id="ft-palace-pills">
        ${TUVI_12_PALACES.map((p) => `<button type="button" class="mole-spot-pill${p.id === activePalaceId ? ' active' : ''}" data-pid="${p.id}">${escHtml(p.name)}</button>`).join('')}
      </div>
    `;
    q('#ft-palace-pills')?.addEventListener('click', (ev) => {
      const btn = ev.target.closest('.mole-spot-pill');
      if (!btn) return;
      activePalaceId = btn.dataset.pid || TUVI_12_PALACES[0].id;
      renderRef();
    });
  };

  mountEl.querySelectorAll('.ft-ref-tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      refTab = btn.dataset.reftab === 'palaces' ? 'palaces' : 'grades';
      mountEl.querySelectorAll('.ft-ref-tab').forEach((x) => x.classList.toggle('active', x === btn));
      renderRef();
    });
  });

  renderHistory();
  renderRef();

  return {
    stopCamera,
    stopSpeech,
    syncBirthYear: () => {
      const y = String(getState()?.auspiciousPrefs?.birthYear || '');
      if (y && birthYearInp && !birthYearInp.value) {
        birthYearInp.value = y;
        updateYearBadge();
      }
    }
  };
}
