/**
 * Mobile Storage & Native Android Bridge Helper
 * - Persists all personal data in localStorage (private per device, zero hardcoded personal data)
 * - Supports full JSON Backup / Restore (so user can sync/transfer data easily)
 * - Automatically syncs upcoming reminders, water slots & holidays to native Android AlarmManager
 *   whenever running inside the OPPO Find X9 APK (window.AndroidBridge).
 */

import { DEFAULT_SETTINGS, getUpcomingEvents } from './holidays.js';
import {
  DEFAULT_WATER_SETTINGS,
  computeWaterSchedule,
  getNextReminderTimestamp,
  formatDateKey,
  pad2
} from './reminders.js';
import { DEFAULT_PRAYER_PREFS } from './prayers.js';
import { DEFAULT_WEATHER_PREFS } from './weather.js';
import { DEFAULT_ZALO_WEBHOOK_SETTINGS } from './zalo.js';
import { DEFAULT_GEMINI_SETTINGS } from './gemini-ai.js';
import { DEFAULT_CLOUD_SYNC_CONFIG, buildTelegramLockUrl } from './cloud-sync.js';

export const APP_VERSION = '3.6.2';
const STORAGE_PREFIX = 'lich_am_vn_mobile::';

export const DEFAULT_TELEGRAM_SETTINGS = {
  enabled: false,
  botToken: '',
  chatId: '',
  chatTitle: '',
  sendTimed: true,
  sendHolidays: true,
  sendWater: false
};

export const DEFAULT_AUSPICIOUS_PREFS = {
  birthYear: '',
  taskId: 'khai_truong',
  customTitle: '',
  onlyGood: true,
  sortBy: 'score'
};

function readJson(key, fallback) {
  try {
    const raw = localStorage.getItem(`${STORAGE_PREFIX}${key}`);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return parsed !== null && parsed !== undefined ? parsed : fallback;
  } catch (_e) {
    return fallback;
  }
}

function writeJson(key, value) {
  try {
    localStorage.setItem(`${STORAGE_PREFIX}${key}`, JSON.stringify(value));
  } catch (err) {
    console.warn(`Storage write failed for ${key}:`, err);
  }
}

export function loadMobileData() {
  return {
    settings: { ...DEFAULT_SETTINGS, ...(readJson('settings', {}) || {}) },
    customEvents: Array.isArray(readJson('customEvents', [])) ? readJson('customEvents', []) : [],
    waterSettings: { ...DEFAULT_WATER_SETTINGS, ...(readJson('waterSettings', {}) || {}) },
    waterLog: readJson('waterLog', {}) || {},
    timedReminders: Array.isArray(readJson('timedReminders', [])) ? readJson('timedReminders', []) : [],
    highlightedRanges: Array.isArray(readJson('highlightedRanges', [])) ? readJson('highlightedRanges', []) : [],
    auspiciousPrefs: { ...DEFAULT_AUSPICIOUS_PREFS, ...(readJson('auspiciousPrefs', {}) || {}) },
    telegramSettings: { ...DEFAULT_TELEGRAM_SETTINGS, ...(readJson('telegramSettings', {}) || {}) },
    prayerPrefs: { ...DEFAULT_PRAYER_PREFS, ...(readJson('prayerPrefs', {}) || {}) },
    weatherPrefs: { ...DEFAULT_WEATHER_PREFS, ...(readJson('weatherPrefs', {}) || {}) },
    zaloSettings: { ...DEFAULT_ZALO_WEBHOOK_SETTINGS, ...(readJson('zaloSettings', {}) || {}) },
    geminiSettings: { ...DEFAULT_GEMINI_SETTINGS, ...(readJson('geminiSettings', {}) || {}) },
    cloudSyncConfig: { ...DEFAULT_CLOUD_SYNC_CONFIG, ...(readJson('cloudSyncConfig', {}) || {}) },
    cloudDeletedIds: readJson('cloudDeletedIds', {}) || {},
    localAllowAutoTelegram: readJson('localAllowAutoTelegram', true) !== false,
    firedKeys: readJson('firedKeys', {}) || {}
  };
}

export function saveMobileField(key, value) {
  writeJson(key, value);
}

export function exportAllDataJson(state) {
  return JSON.stringify(
    {
      app: 'LichAmVietNam',
      version: APP_VERSION,
      exportedAt: new Date().toISOString(),
      settings: state.settings,
      customEvents: state.customEvents,
      waterSettings: state.waterSettings,
      waterLog: state.waterLog,
      timedReminders: state.timedReminders,
      highlightedRanges: state.highlightedRanges,
      auspiciousPrefs: state.auspiciousPrefs,
      telegramSettings: state.telegramSettings,
      prayerPrefs: state.prayerPrefs,
      weatherPrefs: state.weatherPrefs,
      zaloSettings: state.zaloSettings,
      geminiSettings: state.geminiSettings
    },
    null,
    2
  );
}

export function importAllDataJson(jsonText) {
  const parsed = JSON.parse(jsonText);
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('File sao lưu không hợp lệ.');
  }
  const fields = [
    'settings',
    'customEvents',
    'waterSettings',
    'waterLog',
    'timedReminders',
    'highlightedRanges',
    'auspiciousPrefs',
    'telegramSettings',
    'prayerPrefs',
    'weatherPrefs',
    'zaloSettings',
    'geminiSettings'
  ];
  for (const k of fields) {
    if (parsed[k] !== undefined) {
      writeJson(k, parsed[k]);
    }
  }
  return loadMobileData();
}

export function isRunningInAndroidApk() {
  return typeof window !== 'undefined' && Boolean(window.AndroidBridge);
}

/**
 * Build a flat list of next upcoming alarms (timed reminders, water slots for next 24h, holidays for next 14 days)
 * and push them to native Android AlarmManager if running inside the APK.
 */
export function syncNativeAndroidAlarms(state) {
  if (!isRunningInAndroidApk() || typeof window.AndroidBridge.syncAlarms !== 'function') {
    return;
  }

  const nowMs = Date.now();
  const alarms = [];

  const tgEnabled = Boolean(
    state.localAllowAutoTelegram !== false &&
    state.telegramSettings?.enabled &&
    state.telegramSettings?.botToken &&
    state.telegramSettings?.chatId
  );
  const tgToken = tgEnabled ? String(state.telegramSettings.botToken).trim() : '';
  const tgChatId = tgEnabled ? String(state.telegramSettings.chatId).trim() : '';

  // 1. Timed reminders (next occurrence for each active reminder)
  for (const rem of state.timedReminders || []) {
    if (rem.done) continue;
    const nextMs = getNextReminderTimestamp(rem, nowMs);
    if (!nextMs) continue;
    const nd = new Date(nextMs);
    const occDateKey = formatDateKey(nd.getFullYear(), nd.getMonth() + 1, nd.getDate());
    const allowTg = Boolean(tgEnabled && state.telegramSettings?.sendTimed !== false && rem.sendTelegram !== false);
    const tgLockUrl = allowTg
      ? buildTelegramLockUrl(state.cloudSyncConfig, `timed_${rem.id}_${occDateKey}_${rem.time}`)
      : '';
    alarms.push({
      id: `rem_${rem.id}`,
      channel: 'reminders',
      triggerAtMillis: nextMs,
      title: `⏰ ${rem.title}`,
      body: `${rem.time}${rem.note ? ` — ${rem.note}` : ''}`,
      date: occDateKey,
      sendTelegram: allowTg,
      tgBotToken: allowTg ? tgToken : '',
      tgChatId: allowTg ? tgChatId : '',
      tgLockUrl
    });
  }

  // 2. Water reminder slots (remaining slots today + all slots tomorrow)
  if (state.waterSettings?.enabled) {
    const sched = computeWaterSchedule(state.waterSettings);
    if (sched.valid) {
      const now = new Date(nowMs);
      for (let dayOff = 0; dayOff <= 1; dayOff++) {
        const base = new Date(now.getFullYear(), now.getMonth(), now.getDate() + dayOff);
        for (const slot of sched.slots) {
          const ts = new Date(
            base.getFullYear(),
            base.getMonth(),
            base.getDate(),
            Math.floor(slot.minutes / 60),
            slot.minutes % 60,
            0,
            0
          ).getTime();
          if (ts > nowMs + 10000) {
            alarms.push({
              id: `water_${formatDateKey(base.getFullYear(), base.getMonth() + 1, base.getDate())}_${slot.label}`,
              channel: 'water',
              triggerAtMillis: ts,
              title: '💧 Đến giờ uống nước!',
              body: `Cữ ${slot.index + 1}/${sched.slots.length} lúc ${slot.label} — Uống 1 ly nước giữ sức khỏe nhé!`,
              date: formatDateKey(base.getFullYear(), base.getMonth() + 1, base.getDate())
            });
          }
        }
      }
    }
  }

  // 3. Holiday / Mùng 1 / Rằm alerts for the next 14 days
  if (state.settings?.notificationsEnabled !== false) {
    const notifyHour = Number(state.settings?.notifyHour ?? 8);
    const offsets = Array.isArray(state.settings?.notifyDaysBefore) ? state.settings.notifyDaysBefore : [0, 1];
    const upcoming = getUpcomingEvents(new Date(nowMs), 18, state.customEvents || [], {
      includeSolar: state.settings?.remindSolarHolidays !== false,
      includeLunar: state.settings?.remindLunarHolidays !== false,
      includeMung1Ram: state.settings?.remindMung1Ram !== false
    });

    for (const ev of upcoming) {
      const evOffsets = new Set(offsets.map(Number));
      if (Number(ev.remindBeforeDays) > 0) {
        evOffsets.add(0);
        evOffsets.add(Number(ev.remindBeforeDays));
      }
      for (const off of evOffsets) {
        let evHour = notifyHour;
        let evMin = 0;
        if (ev.remindTime && /^\d{1,2}:\d{2}$/.test(ev.remindTime)) {
          const [hh, mm] = ev.remindTime.split(':').map(Number);
          evHour = hh;
          evMin = mm;
        }
        const fireDate = new Date(ev.solar.year, ev.solar.month - 1, ev.solar.day - Number(off), evHour, evMin, 0, 0);
        if (fireDate.getTime() > nowMs + 10000) {
          const prefix = off === 0 ? 'Hôm nay' : off === 1 ? 'Ngày mai' : `Còn ${off} ngày nữa`;
          alarms.push({
            id: `hol_${ev.id}_${ev.solar.year}_${ev.solar.month}_${ev.solar.day}_${off}`,
            channel: 'holidays',
            triggerAtMillis: fireDate.getTime(),
            title: `🏮 ${prefix}: ${ev.name}`,
            body: `Ngày ${pad2(ev.solar.day)}/${pad2(ev.solar.month)}/${ev.solar.year} (${ev.lunar.day}/${ev.lunar.month} ÂL)`,
            date: formatDateKey(ev.solar.year, ev.solar.month, ev.solar.day)
          });
        }
      }
    }
  }

  // Sort by soonest & cap to 60 alarms to stay well within Android AlarmManager limits
  alarms.sort((a, b) => a.triggerAtMillis - b.triggerAtMillis);
  try {
    window.AndroidBridge.syncAlarms(JSON.stringify(alarms.slice(0, 60)));
  } catch (err) {
    console.warn('AndroidBridge.syncAlarms error:', err);
  }

  // Also sync cloud config to native Kotlin so closed-app background sync fetches new PC reminders every 2m!
  if (typeof window.AndroidBridge.syncCloudSyncConfig === 'function') {
    try {
      const cfg = state.cloudSyncConfig || {};
      window.AndroidBridge.syncCloudSyncConfig(JSON.stringify({
        enabled: Boolean(cfg.enabled),
        provider: cfg.provider || 'firebase',
        firebaseUrl: cfg.firebaseUrl || '',
        roomKey: cfg.roomKey || '',
        localAllowAutoTelegram: state.localAllowAutoTelegram !== false
      }));
    } catch (err) {
      console.warn('AndroidBridge.syncCloudSyncConfig error:', err);
    }
  }
}

export function triggerNativeTestNotification() {
  if (isRunningInAndroidApk() && typeof window.AndroidBridge.showTestNotification === 'function') {
    window.AndroidBridge.showTestNotification();
    return true;
  }
  return false;
}

export function openAndroidBatterySettings() {
  if (isRunningInAndroidApk() && typeof window.AndroidBridge.openBatterySettings === 'function') {
    window.AndroidBridge.openBatterySettings();
    return true;
  }
  return false;
}

export function requestAndroidExactAlarmPermission() {
  if (isRunningInAndroidApk() && typeof window.AndroidBridge.requestExactAlarmPermission === 'function') {
    window.AndroidBridge.requestExactAlarmPermission();
    return true;
  }
  return false;
}

export function getAndroidAlarmHealth() {
  if (isRunningInAndroidApk() && typeof window.AndroidBridge.getAlarmHealthStatus === 'function') {
    try {
      return JSON.parse(window.AndroidBridge.getAlarmHealthStatus());
    } catch (_e) {
      return null;
    }
  }
  return null;
}
