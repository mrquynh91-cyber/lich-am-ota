/**
 * Bản đồ Nốt Ruồi Nhân Tướng Học Việt Nam (18 vị trí kinh điển — Nam & Nữ)
 * Dùng kèm tính năng Quét Khuôn Mặt bằng Camera + Gemini Vision AI.
 */

export const FACE_MOLE_SPOTS = [
  { id: 'giua-tran', num: 1, x: 100, y: 46, name: 'Giữa trán (Thiên Trung)', omen: 'good', omenLabel: '🌟 Quý nhân & Sự nghiệp', male: 'Thông minh, có tầm nhìn xa, dễ gặp quý nhân nâng đỡ trên đường công danh, hậu vận vững vàng.', female: 'Độc lập, sắc sảo, có khả năng lãnh đạo và tự chủ tài chính rất tốt.' },
  { id: 'an-duong', num: 2, x: 100, y: 74, name: 'Ấn Đường (Giữa hai chân mày)', omen: 'good', omenLabel: '✨ Cát tướng / Tài lộc', male: 'Nốt ruồi son ở Ấn Đường là đại cát (lộc quan trường, lãnh đạo); nốt ruồi đen nhắc giữ tâm điềm tĩnh, tránh nóng vội.', female: 'Thông tuệ, có duyên với công việc quản lý hoặc kinh doanh, gia đạo hưng vượng.' },
  { id: 'chan-may-trai', num: 3, x: 64, y: 72, name: 'Trong / Đuôi chân mày trái', omen: 'good', omenLabel: '💰 "Ẩn châu" — Phú quý', male: 'Tướng "thảo lý tàng châu" (ngọc ẩn trong cỏ): tài năng tiềm ẩn, có lộc bất ngờ và được bạn bè tin cậy.', female: 'Khéo léo, nhân hậu, vượng phu ích tử, giỏi thu vén tài chính gia đình.' },
  { id: 'chan-may-phai', num: 4, x: 136, y: 72, name: 'Trong / Đuôi chân mày phải', omen: 'good', omenLabel: '✨ Nhân duyên & Quý nhân', male: 'Sống tình cảm, giao tiếp khéo, dễ thành công trong lĩnh vực kinh doanh, đối ngoại.', female: 'Cuộc sống an nhàn, dễ gặp người bạn đời biết yêu thương và chia sẻ.' },
  { id: 'thai-duong', num: 5, x: 38, y: 84, name: 'Thái Dương (Dịch Mã)', omen: 'good', omenLabel: '✈️ Lộc đi xa / Kinh doanh', male: 'Hợp đi xa lập nghiệp, làm ăn giao thương, du lịch hoặc công việc linh hoạt.', female: 'Năng động, quảng giao, gặp nhiều may mắn khi thay đổi môi trường hoặc xuất hành.' },
  { id: 'duoi-mat', num: 6, x: 150, y: 95, name: 'Đuôi mắt (Gian Môn)', omen: 'neutral', omenLabel: '💞 Đào hoa & Cảm xúc', male: 'Có sức hút, đào hoa và nhạy cảm; cần giữ sự chân thành, rõ ràng trong chuyện tình cảm.', female: 'Duyên dáng, giàu cảm xúc và dễ thu hút người khác; nên chọn bạn đời chín chắn.' },
  { id: 'le-duong', num: 7, x: 66, y: 108, name: 'Dưới mắt (Lệ Đường)', omen: 'neutral', omenLabel: '💧 Giàu tình cảm', male: 'Sống sâu sắc, trọng nghĩa tình, hay suy nghĩ cho gia đình và con cái.', female: 'Dịu dàng, giàu lòng trắc ẩn; nên giữ tinh thần lạc quan, tránh lo âu thái quá.' },
  { id: 'song-mui', num: 8, x: 100, y: 104, name: 'Sống mũi (Tật Ách)', omen: 'neutral', omenLabel: '⚖️ Chú ý sức khỏe', male: 'Nên chú trọng rèn luyện thể lực, nghỉ ngơi điều độ; bù lại có ý chí kiên trì vượt khó.', female: 'Tính cách thẳng thắn, chân thành; chú ý giữ gìn sức khỏe và cân bằng công việc.' },
  { id: 'dau-mui', num: 9, x: 100, y: 127, name: 'Đầu mũi (Chuẩn Đầu — Cung Tài Bạch)', omen: 'good', omenLabel: '💰 Cung Tài Bạch', male: 'Nốt ruồi son là điềm tụ tài; nốt ruồi đen nhắc quản lý chi tiêu chặt chẽ, tránh tin người quá nhanh.', female: 'Có duyên kiếm tiền nhưng cũng hay chi tiêu cho người thân — nên có quỹ tiết kiệm riêng.' },
  { id: 'canh-mui', num: 10, x: 118, y: 128, name: 'Cánh mũi (Kim Giáp)', omen: 'good', omenLabel: '🍀 Lộc kinh doanh', male: 'Nhạy bén với tiền bạc và cơ hội làm ăn, biết xoay xở tốt trong hoàn cảnh khó.', female: 'Thông minh, hoạt bát, giỏi giao tiếp và dễ gặp lộc bất ngờ từ nghề tay trái.' },
  { id: 'go-ma-trai', num: 11, x: 54, y: 128, name: 'Gò má trái (Quyền Cốt)', omen: 'good', omenLabel: '🌟 Uy tín & Ý chí', male: 'Có chính kiến mạnh mẽ, bản lĩnh lãnh đạo, được đồng nghiệp và cấp dưới nể trọng.', female: 'Bản lĩnh, đảm đang, giỏi tổ chức công việc và bảo vệ gia đình.' },
  { id: 'go-ma-phai', num: 12, x: 146, y: 128, name: 'Gò má phải', omen: 'good', omenLabel: '✨ Giao tiếp & Hợp tác', male: 'Hòa nhã, có duyên hợp tác làm ăn, biết cách giữ hòa khí trong tập thể.', female: 'Duyên dáng, khéo ứng xử, dễ được mọi người xung quanh quý mến.' },
  { id: 'nhan-trung', num: 13, x: 100, y: 144, name: 'Nhân Trung', omen: 'good', omenLabel: '👶 Phúc khí & Con cháu', male: 'Sức sống dồi dào, hậu vận đông con nhiều cháu, gia đình ấm cúng.', female: 'Có phúc phần về đường con cái, tính tình cởi mở và thân thiện.' },
  { id: 'moi-tren', num: 14, x: 92, y: 156, name: 'Trên môi / Môi trên', omen: 'good', omenLabel: '🍽 Lộc ăn uống & Nói năng', male: 'Có tài ăn nói thuyết phục, hay được mời dự tiệc, cuộc sống không lo thiếu thốn.', female: 'Duyên ăn nói, ấm áp, hay gặp lộc ăn uống và may mắn trong giao tiếp.' },
  { id: 'khoe-mieng', num: 15, x: 124, y: 162, name: 'Khóe miệng (Nốt ruồi duyên)', omen: 'good', omenLabel: '✨ Tụ tài & Duyên dáng', male: 'Tướng "thực lộc" — ăn nói khéo léo, dễ thành công trong bán hàng, thương lượng.', female: 'Rất có duyên, thông minh lanh lợi, dễ gặp quý nhân và lộc ăn mặc.' },
  { id: 'cam', num: 16, x: 100, y: 192, name: 'Cằm (Địa Các)', omen: 'good', omenLabel: '🏠 Điền sản & Hậu vận', male: 'Càng về trung niên và hậu vận càng vượng, dễ tích lũy nhà cửa đất đai.', female: 'Hiền hậu, ổn định, về sau hưởng phúc điền sản và gia đình yên ấm.' },
  { id: 'tai', num: 17, x: 24, y: 118, name: 'Vành tai / Dái tai', omen: 'good', omenLabel: '🌟 Trường thọ & Phúc đức', male: 'Thông minh từ nhỏ, hiếu thảo, có phúc tướng trường thọ và tài lộc bền lâu.', female: 'Phúc hậu, nhân từ, hay gặp may mắn và được gia đình thương yêu.' },
  { id: 'co', num: 18, x: 100, y: 222, name: 'Cổ (Giữa cổ / Hõm cổ)', omen: 'good', omenLabel: '💎 Phú quý tiềm ẩn', male: 'Có chí tiến thủ, không ngại gian khó, dễ tạo dựng cơ nghiệp vững chắc.', female: 'Giàu tình cảm, biết chăm lo cho gia đình và có duyên tích lũy tài sản.' }
];

/**
 * Resize & compress any File/Blob or <video> frame into a lightweight base64 JPEG (~55-95KB)
 * so Gemini Vision uploads & responds quickly!
 * @param {boolean} mirrorX - Set true for Front Camera capture (flips horizontally); false for Rear Camera / uploaded photos.
 */
export function compressImageSourceToBase64(source, maxDim = 640, quality = 0.78, mirrorX = false) {
  const sw = source.videoWidth || source.naturalWidth || source.width || 640;
  const sh = source.videoHeight || source.naturalHeight || source.height || 640;
  const scale = Math.min(1, maxDim / Math.max(sw, sh));
  const dw = Math.max(1, Math.round(sw * scale));
  const dh = Math.max(1, Math.round(sh * scale));

  const canvas = document.createElement('canvas');
  canvas.width = dw;
  canvas.height = dh;
  const ctx = canvas.getContext('2d');
  if (mirrorX) {
    ctx.translate(dw, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(source, 0, 0, dw, dh);
  const dataUrl = canvas.toDataURL('image/jpeg', quality);
  return {
    dataUrl,
    base64: dataUrl.replace(/^data:image\/jpeg;base64,/, '')
  };
}
