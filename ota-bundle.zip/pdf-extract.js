/**
 * Zero-dependency PDF text extractor for Chrome Extension (uses native DecompressionStream).
 * Extracts plain literal strings ((...) Tj / [...] TJ) from FlateDecode and uncompressed PDF streams —
 * works cleanly with airline e-ticket PDFs (VietJet, Vietnam Airlines, Bamboo, Traveloka, etc.).
 */

async function inflateBytes(bytes) {
  if (!bytes || bytes.length < 2) return null;
  // Skip JPEG / PNG binary streams immediately
  if ((bytes[0] === 0xff && bytes[1] === 0xd8) || (bytes[0] === 0x89 && bytes[1] === 0x50)) {
    return null;
  }

  // Standard PDF FlateDecode uses zlib header: CMF low nibble == 8 and (CMF*256 + FLG) % 31 == 0
  const looksLikeZlib = (bytes[0] & 0x0f) === 8 && (((bytes[0] << 8) + bytes[1]) % 31 === 0);
  const formats = looksLikeZlib ? ['deflate', 'deflate-raw'] : ['deflate-raw'];

  for (const format of formats) {
    try {
      const ds = new DecompressionStream(format);
      const writer = ds.writable.getWriter();
      // Attach rejection handlers to both write/close and closed so Chrome never reports an unhandled rejection
      writer.closed.catch(() => {});
      const writePromise = writer.write(bytes).then(() => writer.close()).catch(() => {});
      const readPromise = new Response(ds.readable).arrayBuffer();
      const [buf] = await Promise.all([readPromise, writePromise]);
      if (buf && buf.byteLength > 0) {
        return new Uint8Array(buf);
      }
    } catch (_e) {
      // Try next format or treat as uncompressed
    }
  }
  return null;
}

function bytesToLatin1(bytes) {
  let out = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    out += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return out;
}

function unescapePdfString(str) {
  return str
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\\t/g, '\t')
    .replace(/\\\(/g, '(')
    .replace(/\\\)/g, ')')
    .replace(/\\\\/g, '\\');
}

function decodeHexPdfString(hex) {
  const clean = hex.replace(/\s+/g, '');
  if (clean.length < 2) return '';
  // UTF-16BE with BOM (FEFF)
  if (clean.toUpperCase().startsWith('FEFF') && clean.length >= 6) {
    let out = '';
    for (let i = 4; i + 3 < clean.length; i += 4) {
      out += String.fromCharCode(parseInt(clean.slice(i, i + 4), 16));
    }
    return out;
  }
  // Check if looks like ASCII hex (printable bytes)
  let ascii = '';
  let printable = 0;
  const pairs = Math.floor(clean.length / 2);
  for (let i = 0; i + 1 < clean.length; i += 2) {
    const code = parseInt(clean.slice(i, i + 2), 16);
    if (code >= 32 && code <= 126) {
      printable++;
      ascii += String.fromCharCode(code);
    } else if (code === 10 || code === 13 || code === 9) {
      printable++;
      ascii += ' ';
    }
  }
  return pairs > 0 && printable / pairs > 0.85 ? ascii : '';
}

function extractPdfOperatorsText(contentStr) {
  const parts = [];
  // Match (text) Tj, <hex> Tj, and [...] TJ
  const regex = /\(((?:\\.|[^\\()])*)\)\s*Tj|<([0-9A-Fa-f\s]+)>\s*Tj|\[((?:[^\[\]]|\((?:\\.|[^\\()])*\))*)\]\s*TJ/g;
  let m;
  while ((m = regex.exec(contentStr)) !== null) {
    if (m[1] !== undefined) {
      const s = unescapePdfString(m[1]).trim();
      if (s) parts.push(s);
    } else if (m[2] !== undefined) {
      const s = decodeHexPdfString(m[2]).trim();
      if (s) parts.push(s);
    } else if (m[3] !== undefined) {
      const inner = [];
      const subRe = /\(((?:\\.|[^\\()])*)\)|<([0-9A-Fa-f\s]+)>/g;
      let sm;
      while ((sm = subRe.exec(m[3])) !== null) {
        if (sm[1] !== undefined) inner.push(unescapePdfString(sm[1]));
        else if (sm[2] !== undefined) inner.push(decodeHexPdfString(sm[2]));
      }
      const joined = inner.join('').trim();
      if (joined) parts.push(joined);
    }
  }
  return parts.join(' ');
}

function findSequence(haystack, needle, startIdx) {
  outer: for (let i = startIdx; i <= haystack.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (haystack[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}

/**
 * Extract readable text from a PDF ArrayBuffer
 */
export async function extractTextFromPdfBuffer(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  const enc = new TextEncoder();
  const STREAM_START = enc.encode('stream');
  const STREAM_END = enc.encode('endstream');

  const collected = [];
  let pos = 0;

  while (pos < bytes.length) {
    const sIdx = findSequence(bytes, STREAM_START, pos);
    if (sIdx === -1) break;

    // Advance past "stream" + CR/LF
    let dataStart = sIdx + STREAM_START.length;
    if (bytes[dataStart] === 0x0d && bytes[dataStart + 1] === 0x0a) dataStart += 2;
    else if (bytes[dataStart] === 0x0a || bytes[dataStart] === 0x0d) dataStart += 1;
    else {
      pos = dataStart;
      continue;
    }

    const eIdx = findSequence(bytes, STREAM_END, dataStart);
    if (eIdx === -1) break;

    let dataEnd = eIdx;
    while (dataEnd > dataStart && (bytes[dataEnd - 1] === 0x0a || bytes[dataEnd - 1] === 0x0d)) {
      dataEnd--;
    }

    const streamBytes = bytes.subarray(dataStart, dataEnd);
    pos = eIdx + STREAM_END.length;

    // Skip huge streams (> 400KB) or embedded image/font binary streams for speed & cleanliness
    if (streamBytes.length === 0 || streamBytes.length > 400000) continue;
    const dictSlice = bytesToLatin1(bytes.subarray(Math.max(0, sIdx - 320), sIdx));
    if (/\/Subtype\s*\/Image|\/DCTDecode|\/JPXDecode|\/CCITTFaxDecode/i.test(dictSlice)) {
      continue;
    }

    let decodedStr = null;
    const isFlate = /\/FlateDecode/i.test(dictSlice);
    const inflated = isFlate || (streamBytes[0] & 0x0f) === 8 ? await inflateBytes(streamBytes) : null;
    if (inflated) {
      decodedStr = bytesToLatin1(inflated);
    } else if (!isFlate && streamBytes.length < 150000) {
      decodedStr = bytesToLatin1(streamBytes);
    }

    if (decodedStr && (decodedStr.includes('Tj') || decodedStr.includes('TJ'))) {
      const txt = extractPdfOperatorsText(decodedStr);
      if (txt) collected.push(txt);
    }
  }

  return collected.join('\n').replace(/\s+/g, ' ').trim();
}
