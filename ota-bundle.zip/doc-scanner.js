/**
 * AI Document Scanner Pro (v3.2.1 — OPPO Find X9 AI-Grade Upgrade)
 *  - Instant Pixel-Exact Local CV 4-Corner Detector (Paper Segmentation + Convex Hull + 4-Line RANSAC Intersection)
 *    with Hybrid Gemini Vision AI fallback — ZERO table/background border left around white paper!
 *  - OPPO-Style Illumination Normalization ("Xóa bóng" shadow & color-cast removal) + 3x3 Unsharp Mask ("Tăng nét chữ")
 *  - 5 Scan Modes: Màu (AI), Đen trắng, Độ xám, Tiết kiệm mực, Nguyên gốc + Before/After comparison + Magnifier Loupe
 *  - Multi-page upload auto-scan + Export JPG, A4 Binary PDF 1.4, AI OCR Word (.doc), AI Table Excel (.xls / .csv)
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import { isGeminiConfigured, askGeminiGeneral } from './gemini-ai.js';
import { shareToZaloQuick } from './zalo.js';
import { openSmartCamera, attachCameraControlBar, removeCameraControlBar } from './camera-helper.js';

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function uint8ToBase64(bytes) {
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

function base64ToUint8(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function saveExportedFile(filename, mimeType, bytesOrString) {
  const bytes = typeof bytesOrString === 'string'
    ? new TextEncoder().encode(bytesOrString)
    : bytesOrString;

  if (typeof window !== 'undefined' && window.AndroidBridge && typeof window.AndroidBridge.saveBase64File === 'function') {
    const b64 = uint8ToBase64(bytes);
    const ok = window.AndroidBridge.saveBase64File(filename, mimeType, b64);
    if (ok) return true;
  }

  const blob = new Blob([bytes], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    a.remove();
    URL.revokeObjectURL(url);
  }, 500);
  return true;
}

function dist2D(a, b) {
  return Math.hypot(a[0] - b[0], a[1] - b[1]);
}

function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

/* ==================== PIXEL-EXACT LOCAL CV PAPER DETECTOR ==================== */

function otsuThreshold(vals) {
  const hist = new Uint32Array(256);
  const n = vals.length;
  for (let i = 0; i < n; i++) hist[vals[i]]++;
  let sum = 0;
  for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sumB = 0, wB = 0, maxVar = -1, bestT = 128;
  for (let t = 0; t < 256; t++) {
    wB += hist[t];
    if (wB === 0) continue;
    const wF = n - wB;
    if (wF === 0) break;
    sumB += t * hist[t];
    const mB = sumB / wB;
    const mF = (sum - sumB) / wF;
    const diff = mB - mF;
    const between = wB * wF * diff * diff;
    if (between > maxVar) {
      maxVar = between;
      bestT = t;
    }
  }
  return bestT;
}

function morphBinary(mask, w, h, radius, dilate = true) {
  const tmp = new Uint8Array(w * h);
  const out = new Uint8Array(w * h);
  // Horizontal pass
  for (let y = 0; y < h; y++) {
    const row = y * w;
    for (let x = 0; x < w; x++) {
      let val = dilate ? 0 : 1;
      const x0 = Math.max(0, x - radius);
      const x1 = Math.min(w - 1, x + radius);
      for (let xx = x0; xx <= x1; xx++) {
        if (dilate ? mask[row + xx] === 1 : mask[row + xx] === 0) {
          val = dilate ? 1 : 0;
          break;
        }
      }
      tmp[row + x] = val;
    }
  }
  // Vertical pass
  for (let y = 0; y < h; y++) {
    const y0 = Math.max(0, y - radius);
    const y1 = Math.min(h - 1, y + radius);
    for (let x = 0; x < w; x++) {
      let val = dilate ? 0 : 1;
      for (let yy = y0; yy <= y1; yy++) {
        if (dilate ? tmp[yy * w + x] === 1 : tmp[yy * w + x] === 0) {
          val = dilate ? 1 : 0;
          break;
        }
      }
      out[y * w + x] = val;
    }
  }
  return out;
}

function convexHull(points) {
  if (points.length <= 3) return points.slice();
  const pts = points.slice().sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower = [];
  for (const p of pts) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper = [];
  for (let i = pts.length - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
    upper.push(p);
  }
  lower.pop();
  upper.pop();
  return lower.concat(upper);
}

function quadArea(q) {
  let s = 0;
  for (let i = 0; i < 4; i++) {
    const j = (i + 1) % 4;
    s += q[i][0] * q[j][1] - q[j][0] * q[i][1];
  }
  return Math.abs(s) * 0.5;
}

function orderCornersTLTRBRBL(pts) {
  // Sort around centroid, then rotate so index 0 is top-left (min x+y)
  const cx = pts.reduce((s, p) => s + p[0], 0) / 4;
  const cy = pts.reduce((s, p) => s + p[1], 0) / 4;
  const sorted = pts.slice().sort((a, b) => Math.atan2(a[1] - cy, a[0] - cx) - Math.atan2(b[1] - cy, b[0] - cx));
  let tlIdx = 0, bestSum = Infinity;
  for (let i = 0; i < 4; i++) {
    const s = sorted[i][0] + sorted[i][1];
    if (s < bestSum) { bestSum = s; tlIdx = i; }
  }
  const out = [];
  for (let i = 0; i < 4; i++) out.push(sorted[(tlIdx + i) % 4]);
  // Ensure clockwise order in screen coords (TL -> TR -> BR -> BL)
  const cross = (out[1][0] - out[0][0]) * (out[2][1] - out[0][1]) - (out[1][1] - out[0][1]) * (out[2][0] - out[0][0]);
  if (cross < 0) return [out[0], out[3], out[2], out[1]];
  return out;
}

function maxAreaQuadFromHull(hull) {
  const m = hull.length;
  if (m < 4) return null;
  // Seed 4 vertices at extreme diagonals
  const pickBest = (fn) => {
    let bi = 0, bv = -Infinity;
    for (let i = 0; i < m; i++) {
      const v = fn(hull[i]);
      if (v > bv) { bv = v; bi = i; }
    }
    return bi;
  };
  const idx = [
    pickBest((p) => -p[0] - p[1]),
    pickBest((p) => p[0] - p[1]),
    pickBest((p) => p[0] + p[1]),
    pickBest((p) => -p[0] + p[1])
  ];
  // Coordinate ascent on hull indices to find true max-area inscribed quadrilateral (handles any rotation!)
  let improved = true;
  let iter = 0;
  while (improved && iter < 12) {
    improved = false;
    iter++;
    for (let k = 0; k < 4; k++) {
      let bestI = idx[k];
      let bestA = quadArea([hull[idx[0]], hull[idx[1]], hull[idx[2]], hull[idx[3]]]);
      for (let i = 0; i < m; i++) {
        if (i === idx[(k + 1) % 4] || i === idx[(k + 2) % 4] || i === idx[(k + 3) % 4]) continue;
        const cand = idx.slice();
        cand[k] = i;
        const a = quadArea([hull[cand[0]], hull[cand[1]], hull[cand[2]], hull[cand[3]]]);
        if (a > bestA + 1e-4) {
          bestA = a;
          bestI = i;
          improved = true;
        }
      }
      idx[k] = bestI;
    }
  }
  return orderCornersTLTRBRBL(idx.map((i) => hull[i]));
}

function pointSegDistAndT(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay;
  const len2 = dx * dx + dy * dy || 1e-9;
  const t = ((px - ax) * dx + (py - ay) * dy) / len2;
  const tc = clamp(t, 0, 1);
  const cx = ax + tc * dx, cy = ay + tc * dy;
  return { dist: Math.hypot(px - cx, py - cy), t };
}

/**
 * Fit robust line ax + by + c = 0 (with a^2 + b^2 = 1) using IRLS Huber weighting.
 */
function fitRobustLine(pts, fallbackA, fallbackB) {
  if (!pts || pts.length < 6) {
    const dx = fallbackB[0] - fallbackA[0];
    const dy = fallbackB[1] - fallbackA[1];
    const len = Math.hypot(dx, dy) || 1;
    const a = -dy / len, b = dx / len;
    return [a, b, -(a * fallbackA[0] + b * fallbackA[1])];
  }
  const weights = new Float64Array(pts.length).fill(1);
  let line = [0, 1, 0];
  for (let iter = 0; iter < 5; iter++) {
    let wSum = 0, mx = 0, my = 0;
    for (let i = 0; i < pts.length; i++) {
      const w = weights[i];
      wSum += w;
      mx += w * pts[i][0];
      my += w * pts[i][1];
    }
    if (wSum < 1e-6) break;
    mx /= wSum; my /= wSum;
    let sxx = 0, sxy = 0, syy = 0;
    for (let i = 0; i < pts.length; i++) {
      const w = weights[i];
      const dx = pts[i][0] - mx;
      const dy = pts[i][1] - my;
      sxx += w * dx * dx;
      sxy += w * dx * dy;
      syy += w * dy * dy;
    }
    // Smallest eigenvector of 2x2 covariance matrix = line normal (a, b)
    const theta = 0.5 * Math.atan2(2 * sxy, sxx - syy);
    const a = -Math.sin(theta);
    const b = Math.cos(theta);
    const c = -(a * mx + b * my);
    line = [a, b, c];
    for (let i = 0; i < pts.length; i++) {
      const r = Math.abs(a * pts[i][0] + b * pts[i][1] + c);
      weights[i] = r <= 1.8 ? 1 : 1.8 / r;
    }
  }
  return line;
}

function intersectLines(l1, l2) {
  const det = l1[0] * l2[1] - l2[0] * l1[1];
  if (Math.abs(det) < 1e-6) return null;
  const x = (l1[1] * l2[2] - l2[1] * l1[2]) / det;
  const y = (l2[0] * l1[2] - l1[0] * l2[2]) / det;
  return [x, y];
}

/**
 * Pure-JS Pixel-Exact Paper Boundary Detector (~30ms offline!).
 * Handles white/cream/cool-tinted paper on colored tables (like blue desk with ceiling lamp glares),
 * wooden desks, dark surfaces, tilted/perspective angles.
 */
function detectPaperCornersCV(img) {
  const sw = img.naturalWidth || img.width;
  const sh = img.naturalHeight || img.height;
  const maxSide = 320;
  const sc = Math.min(1, maxSide / Math.max(sw, sh));
  const w = Math.max(80, Math.round(sw * sc));
  const h = Math.max(80, Math.round(sh * sc));

  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0, w, h);
  const px = ctx.getImageData(0, 0, w, h).data;

  // 1. Estimate table/background median RGB from outer 5% frame (immune to bright lamp glare dots!)
  const brR = [], brG = [], brB = [];
  const bw = Math.max(4, Math.round(w * 0.05));
  const bh = Math.max(4, Math.round(h * 0.05));
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (x < bw || x >= w - bw || y < bh || y >= h - bh) {
        const i = (y * w + x) * 4;
        brR.push(px[i]); brG.push(px[i + 1]); brB.push(px[i + 2]);
      }
    }
  }
  const med = (arr) => {
    arr.sort((a, b) => a - b);
    return arr[Math.floor(arr.length / 2)] || 0;
  };
  const bgR = med(brR), bgG = med(brG), bgB = med(brB);
  const bgLuma = 0.299 * bgR + 0.587 * bgG + 0.114 * bgB;
  const bgSat = Math.max(bgR, bgG, bgB) - Math.min(bgR, bgG, bgB);

  // 2. Compute "Paperness" channel (0..255): bright + low saturation + distinct from background
  const score = new Uint8Array(w * h);
  for (let i = 0, p = 0; p < w * h; p++, i += 4) {
    const r = px[i], g = px[i + 1], b = px[i + 2];
    const luma = 0.299 * r + 0.587 * g + 0.114 * b;
    const sat = Math.max(r, g, b) - Math.min(r, g, b);
    const dr = r - bgR, dg = g - bgG, db = b - bgB;
    const bgDist = Math.sqrt(dr * dr + dg * dg + db * db);
    // Paper is brighter/less saturated than background OR strongly different from colored table
    const satBonus = bgSat > 32 ? (255 - sat) * 0.42 : (255 - sat) * 0.22;
    const distBonus = Math.min(255, bgDist * 1.15) * (bgSat > 28 || bgLuma < 170 ? 0.52 : 0.35);
    const val = luma * 0.48 + satBonus + distBonus - 58;
    score[p] = val < 0 ? 0 : val > 255 ? 255 : val | 0;
  }

  // 3. Otsu threshold + Morphological Closing (fuses dark printed text into solid white sheet) + Opening
  const th = Math.max(70, Math.min(215, otsuThreshold(score)));
  let mask = new Uint8Array(w * h);
  for (let p = 0; p < w * h; p++) mask[p] = score[p] >= th ? 1 : 0;

  mask = morphBinary(mask, w, h, 3, true);
  mask = morphBinary(mask, w, h, 3, false);
  mask = morphBinary(mask, w, h, 2, false);
  mask = morphBinary(mask, w, h, 2, true);

  // 4. Connected components: pick largest paper blob near center
  const labels = new Int32Array(w * h);
  const queue = new Int32Array(w * h);
  let bestLabel = 0, bestScore = 0, bestArea = 0;
  let nextLabel = 1;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const start = y * w + x;
      if (mask[start] !== 1 || labels[start] !== 0) continue;
      const lbl = nextLabel++;
      let qh = 0, qt = 0;
      queue[qt++] = start;
      labels[start] = lbl;
      let area = 0, sumX = 0, sumY = 0;
      let minX = w, maxX = 0, minY = h, maxY = 0;
      while (qh < qt) {
        const cur = queue[qh++];
        const cy = (cur / w) | 0;
        const cx = cur - cy * w;
        area++;
        sumX += cx; sumY += cy;
        if (cx < minX) minX = cx;
        if (cx > maxX) maxX = cx;
        if (cy < minY) minY = cy;
        if (cy > maxY) maxY = cy;
        if (cx > 0 && mask[cur - 1] === 1 && labels[cur - 1] === 0) { labels[cur - 1] = lbl; queue[qt++] = cur - 1; }
        if (cx + 1 < w && mask[cur + 1] === 1 && labels[cur + 1] === 0) { labels[cur + 1] = lbl; queue[qt++] = cur + 1; }
        if (cy > 0 && mask[cur - w] === 1 && labels[cur - w] === 0) { labels[cur - w] = lbl; queue[qt++] = cur - w; }
        if (cy + 1 < h && mask[cur + w] === 1 && labels[cur + w] === 0) { labels[cur + w] = lbl; queue[qt++] = cur + w; }
      }
      const areaRatio = area / (w * h);
      if (areaRatio < 0.08 || areaRatio > 0.96) continue;
      const mx = sumX / area / w;
      const my = sumY / area / h;
      const centerDist = Math.hypot(mx - 0.5, my - 0.5);
      const bboxFill = area / Math.max(1, (maxX - minX + 1) * (maxY - minY + 1));
      if (bboxFill < 0.42) continue;
      const compScore = areaRatio * (1.25 - centerDist) * bboxFill;
      if (compScore > bestScore) {
        bestScore = compScore;
        bestLabel = lbl;
        bestArea = area;
      }
    }
  }

  if (!bestLabel) return null;

  // 5. Extract outer contour pixels of the paper blob
  const boundary = [];
  for (let y = 1; y < h - 1; y++) {
    const row = y * w;
    for (let x = 1; x < w - 1; x++) {
      const idx = row + x;
      if (labels[idx] !== bestLabel) continue;
      if (
        labels[idx - 1] !== bestLabel ||
        labels[idx + 1] !== bestLabel ||
        labels[idx - w] !== bestLabel ||
        labels[idx + w] !== bestLabel
      ) {
        boundary.push([x, y]);
      }
    }
  }
  // Include image-edge pixels of the blob in case paper touches frame
  for (let x = 0; x < w; x++) {
    if (labels[x] === bestLabel) boundary.push([x, 0]);
    if (labels[(h - 1) * w + x] === bestLabel) boundary.push([x, h - 1]);
  }
  for (let y = 1; y < h - 1; y++) {
    if (labels[y * w] === bestLabel) boundary.push([0, y]);
    if (labels[y * w + (w - 1)] === bestLabel) boundary.push([w - 1, y]);
  }
  if (boundary.length < 30) return null;

  // 6. Convex hull -> Initial maximum-area 4-corner quad
  const hull = convexHull(boundary);
  const initQuad = maxAreaQuadFromHull(hull);
  if (!initQuad) return null;

  // Check how rectangular/quadrilateral the blob really is (IoU / fill vs hull)
  const qArea = quadArea(initQuad);
  const rectangularity = bestArea / Math.max(1, qArea);
  if (rectangularity < 0.68 || rectangularity > 1.25) return null;

  // 7. Robust 4-Edge Line Fitting (IRLS) + Exact Line Intersection (handles curled corners / fingers!)
  const sideBuckets = [[], [], [], []];
  const maxSnapDist = Math.max(6, Math.min(w, h) * 0.055);
  for (const pt of boundary) {
    let bestSide = -1, bestD = maxSnapDist, bestT = 0;
    for (let s = 0; s < 4; s++) {
      const a = initQuad[s], b = initQuad[(s + 1) % 4];
      const { dist, t } = pointSegDistAndT(pt[0], pt[1], a[0], a[1], b[0], b[1]);
      if (dist < bestD) { bestD = dist; bestSide = s; bestT = t; }
    }
    // Exclude 10% near corners so curled corners never skew straight paper edges
    if (bestSide >= 0 && bestT >= 0.09 && bestT <= 0.91) {
      sideBuckets[bestSide].push(pt);
    }
  }

  const lines = [0, 1, 2, 3].map((s) => fitRobustLine(sideBuckets[s], initQuad[s], initQuad[(s + 1) % 4]));
  const refined = [
    intersectLines(lines[3], lines[0]), // TL = Left ∩ Top
    intersectLines(lines[0], lines[1]), // TR = Top ∩ Right
    intersectLines(lines[1], lines[2]), // BR = Right ∩ Bottom
    intersectLines(lines[2], lines[3])  // BL = Bottom ∩ Left
  ];

  let finalPx = initQuad;
  if (refined.every((p) => p && Number.isFinite(p[0]) && Number.isFinite(p[1]) && p[0] >= -w * 0.05 && p[0] <= w * 1.05 && p[1] >= -h * 0.05 && p[1] <= h * 1.05)) {
    const rArea = quadArea(refined);
    if (rArea > qArea * 0.8 && rArea < qArea * 1.25) {
      finalPx = orderCornersTLTRBRBL(refined);
    }
  }

  // 8. Convert to normalized [0..1] + tiny 0.7% inward trim so ZERO blue/table edge sliver remains!
  let norm = finalPx.map(([x, y]) => [clamp(x / w, 0.002, 0.998), clamp(y / h, 0.002, 0.998)]);
  const cx = norm.reduce((s, p) => s + p[0], 0) / 4;
  const cy = norm.reduce((s, p) => s + p[1], 0) / 4;
  norm = norm.map(([nx, ny]) => [
    clamp(nx + (cx - nx) * 0.009, 0.002, 0.998),
    clamp(ny + (cy - ny) * 0.009, 0.002, 0.998)
  ]);

  const areaRatio = bestArea / (w * h);
  const contrastSignal = clamp((bgSat * 0.5 + Math.abs(220 - bgLuma) * 0.6) / 100, 0.35, 1.0);
  const confidence = clamp(rectangularity * 0.65 + contrastSignal * 0.35, 0, 1);

  return { corners: norm, confidence, areaRatio };
}

/* ==================== 3x3 HOMOGRAPHY & OPPO-GRADE ENHANCEMENT ==================== */

function computeHomography(dstPts, srcPts) {
  const A = [];
  const b = [];
  for (let i = 0; i < 4; i++) {
    const [x, y] = dstPts[i];
    const [u, v] = srcPts[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]);
    b.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]);
    b.push(v);
  }
  const n = 8;
  for (let col = 0; col < n; col++) {
    let maxRow = col;
    for (let row = col + 1; row < n; row++) {
      if (Math.abs(A[row][col]) > Math.abs(A[maxRow][col])) maxRow = row;
    }
    [A[col], A[maxRow]] = [A[maxRow], A[col]];
    [b[col], b[maxRow]] = [b[maxRow], b[col]];
    const piv = A[col][col] || 1e-12;
    for (let row = col + 1; row < n; row++) {
      const f = A[row][col] / piv;
      for (let k = col; k < n; k++) A[row][k] -= f * A[col][k];
      b[row] -= f * b[col];
    }
  }
  const h = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    let sum = b[i];
    for (let k = i + 1; k < n; k++) sum -= A[i][k] * h[k];
    h[i] = sum / (A[i][i] || 1e-12);
  }
  return [h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1];
}

/**
 * Compute smooth local paper background illumination map (R, G, B) on a 1/8 downscaled grid
 * using separable Max-Filter (erases dark printed text) + separable Box-Blur (smooths shadow field).
 */
function buildIlluminationMap(rgba, w, h) {
  const step = Math.max(4, Math.round(Math.max(w, h) / 180));
  const gw = Math.max(16, Math.ceil(w / step));
  const gh = Math.max(16, Math.ceil(h / step));
  const bgR = new Float32Array(gw * gh);
  const bgG = new Float32Array(gw * gh);
  const bgB = new Float32Array(gw * gh);

  // Sample local bright 85th-percentile-ish max within each cell (ignores dark ink strokes!)
  for (let gy = 0; gy < gh; gy++) {
    const y0 = gy * step;
    const y1 = Math.min(h, y0 + step);
    for (let gx = 0; gx < gw; gx++) {
      const x0 = gx * step;
      const x1 = Math.min(w, x0 + step);
      let mr = 0, mg = 0, mb = 0;
      for (let y = y0; y < y1; y += 2) {
        const row = y * w;
        for (let x = x0; x < x1; x += 2) {
          const i = (row + x) * 4;
          if (rgba[i] > mr) mr = rgba[i];
          if (rgba[i + 1] > mg) mg = rgba[i + 1];
          if (rgba[i + 2] > mb) mb = rgba[i + 2];
        }
      }
      const gi = gy * gw + gx;
      bgR[gi] = mr; bgG[gi] = mg; bgB[gi] = mb;
    }
  }

  const dilate1D = (src, rad) => {
    const tmp = new Float32Array(gw * gh);
    const dst = new Float32Array(gw * gh);
    for (let y = 0; y < gh; y++) {
      const r = y * gw;
      for (let x = 0; x < gw; x++) {
        let m = 0;
        const a = Math.max(0, x - rad), b = Math.min(gw - 1, x + rad);
        for (let k = a; k <= b; k++) if (src[r + k] > m) m = src[r + k];
        tmp[r + x] = m;
      }
    }
    for (let y = 0; y < gh; y++) {
      const a = Math.max(0, y - rad), b = Math.min(gh - 1, y + rad);
      for (let x = 0; x < gw; x++) {
        let m = 0;
        for (let k = a; k <= b; k++) if (tmp[k * gw + x] > m) m = tmp[k * gw + x];
        dst[y * gw + x] = m;
      }
    }
    return dst;
  };

  const blur1D = (src, rad) => {
    const tmp = new Float32Array(gw * gh);
    const dst = new Float32Array(gw * gh);
    for (let y = 0; y < gh; y++) {
      const r = y * gw;
      for (let x = 0; x < gw; x++) {
        let s = 0, cnt = 0;
        const a = Math.max(0, x - rad), b = Math.min(gw - 1, x + rad);
        for (let k = a; k <= b; k++) { s += src[r + k]; cnt++; }
        tmp[r + x] = s / cnt;
      }
    }
    for (let y = 0; y < gh; y++) {
      const a = Math.max(0, y - rad), b = Math.min(gh - 1, y + rad);
      for (let x = 0; x < gw; x++) {
        let s = 0, cnt = 0;
        for (let k = a; k <= b; k++) { s += tmp[k * gw + x]; cnt++; }
        dst[y * gw + x] = s / cnt;
      }
    }
    return dst;
  };

  const dR = blur1D(blur1D(dilate1D(bgR, 3), 5), 4);
  const dG = blur1D(blur1D(dilate1D(bgG, 3), 5), 4);
  const dB = blur1D(blur1D(dilate1D(bgB, 3), 5), 4);
  return { gw, gh, step, r: dR, g: dG, b: dB };
}

/**
 * Warp + OPPO-Grade Local Shadow Removal + Text Crispness Unsharp Mask.
 * filterMode: 'magic' (Màu AI) | 'bw' (Đen trắng) | 'gray' (Độ xám) | 'econ' (Tiết kiệm mực) | 'original' (Nguyên gốc)
 */
function renderWarpedDocument(srcImg, cornersNorm, opts = {}) {
  const {
    filterMode = 'magic',
    removeShadow = true,
    sharpenText = true,
    straightenLines = true,
    manualDeg = 0,
    manualArch = 0,
    manualTiltTop = 0,
    maxOutDim = 1800
  } = typeof opts === 'string' ? { filterMode: opts } : opts;

  const sw = srcImg.naturalWidth || srcImg.width;
  const sh = srcImg.naturalHeight || srcImg.height;
  const srcPts = cornersNorm.map(([nx, ny]) => [nx * sw, ny * sh]);

  const topW = dist2D(srcPts[0], srcPts[1]);
  const botW = dist2D(srcPts[3], srcPts[2]);
  const leftH = dist2D(srcPts[0], srcPts[3]);
  const rightH = dist2D(srcPts[1], srcPts[2]);

  let outW = Math.max(240, Math.round(Math.max(topW, botW)));
  let outH = Math.max(240, Math.round(Math.max(leftH, rightH)));
  const scale = Math.min(1, maxOutDim / Math.max(outW, outH));
  outW = Math.max(200, Math.round(outW * scale));
  outH = Math.max(200, Math.round(outH * scale));

  // Read source pixels
  const srcCanvas = document.createElement('canvas');
  srcCanvas.width = sw;
  srcCanvas.height = sh;
  const sCtx = srcCanvas.getContext('2d');
  sCtx.drawImage(srcImg, 0, 0, sw, sh);
  const sData = sCtx.getImageData(0, 0, sw, sh).data;

  const outCanvas = document.createElement('canvas');
  outCanvas.width = outW;
  outCanvas.height = outH;
  const oCtx = outCanvas.getContext('2d');
  const outImgData = oCtx.createImageData(outW, outH);
  const dData = outImgData.data;

  const dstPts = [[0, 0], [outW - 1, 0], [outW - 1, outH - 1], [0, outH - 1]];
  const H = computeHomography(dstPts, srcPts);

  // Pass 1: Perspective Warp with Bilinear Interpolation
  for (let y = 0; y < outH; y++) {
    const h1y = H[1] * y + H[2];
    const h4y = H[4] * y + H[5];
    const h7y = H[7] * y + H[8];
    for (let x = 0; x < outW; x++) {
      const denom = H[6] * x + h7y;
      const sx = (H[0] * x + h1y) / denom;
      const sy = (H[3] * x + h4y) / denom;
      const di = (y * outW + x) * 4;

      if (sx < 0 || sy < 0 || sx >= sw - 1 || sy >= sh - 1) {
        dData[di] = 255; dData[di + 1] = 255; dData[di + 2] = 255; dData[di + 3] = 255;
        continue;
      }
      const x0 = sx | 0;
      const y0 = sy | 0;
      const fx = sx - x0;
      const fy = sy - y0;
      const i00 = (y0 * sw + x0) * 4;
      const i10 = i00 + 4;
      const i01 = i00 + sw * 4;
      const i11 = i01 + 4;
      const w00 = (1 - fx) * (1 - fy);
      const w10 = fx * (1 - fy);
      const w01 = (1 - fx) * fy;
      const w11 = fx * fy;

      dData[di] = sData[i00] * w00 + sData[i10] * w10 + sData[i01] * w01 + sData[i11] * w11;
      dData[di + 1] = sData[i00 + 1] * w00 + sData[i10 + 1] * w10 + sData[i01 + 1] * w01 + sData[i11 + 1] * w11;
      dData[di + 2] = sData[i00 + 2] * w00 + sData[i10 + 2] * w10 + sData[i01 + 2] * w01 + sData[i11 + 2] * w11;
      dData[di + 3] = 255;
    }
  }

  // Pass 2: OPPO-style Local Illumination Normalization ("Xóa bóng" + Color-cast removal)
  const shouldNormalize = removeShadow && filterMode !== 'original';
  if (shouldNormalize) {
    const illum = buildIlluminationMap(dData, outW, outH);
    const { gw, gh, r: iR, g: iG, b: iB } = illum;
    const sxScale = (gw - 1) / Math.max(1, outW - 1);
    const syScale = (gh - 1) / Math.max(1, outH - 1);

    for (let y = 0; y < outH; y++) {
      const fyFull = y * syScale;
      const gy0 = fyFull | 0;
      const gy1 = Math.min(gh - 1, gy0 + 1);
      const wy = fyFull - gy0;
      const r0 = gy0 * gw, r1 = gy1 * gw;
      for (let x = 0; x < outW; x++) {
        const fxFull = x * sxScale;
        const gx0 = fxFull | 0;
        const gx1 = Math.min(gw - 1, gx0 + 1);
        const wx = fxFull - gx0;
        const w00 = (1 - wx) * (1 - wy), w10 = wx * (1 - wy), w01 = (1 - wx) * wy, w11 = wx * wy;
        const c00 = r0 + gx0, c10 = r0 + gx1, c01 = r1 + gx0, c11 = r1 + gx1;

        const br = Math.max(45, iR[c00] * w00 + iR[c10] * w10 + iR[c01] * w01 + iR[c11] * w11);
        const bg = Math.max(45, iG[c00] * w00 + iG[c10] * w10 + iG[c01] * w01 + iG[c11] * w11);
        const bb = Math.max(45, iB[c00] * w00 + iB[c10] * w10 + iB[c01] * w01 + iB[c11] * w11);

        const di = (y * outW + x) * 4;
        dData[di] = clamp((dData[di] / br) * 255, 0, 255);
        dData[di + 1] = clamp((dData[di + 1] / bg) * 255, 0, 255);
        dData[di + 2] = clamp((dData[di + 2] / bb) * 255, 0, 255);
      }
    }
  }

  // Pass 3: Fast 3x3 Unsharp Mask ("Tăng cường văn bản") on Luminance for laser-crisp Vietnamese accents
  if (sharpenText && filterMode !== 'original') {
    const lumaBuf = new Float32Array(outW * outH);
    for (let p = 0, i = 0; p < outW * outH; p++, i += 4) {
      lumaBuf[p] = 0.299 * dData[i] + 0.587 * dData[i + 1] + 0.114 * dData[i + 2];
    }
    const amt = filterMode === 'bw' ? 0.85 : 0.62;
    for (let y = 1; y < outH - 1; y++) {
      const row = y * outW;
      for (let x = 1; x < outW - 1; x++) {
        const p = row + x;
        const center = lumaBuf[p];
        const avg = (
          lumaBuf[p - outW - 1] + lumaBuf[p - outW] + lumaBuf[p - outW + 1] +
          lumaBuf[p - 1] + center + lumaBuf[p + 1] +
          lumaBuf[p + outW - 1] + lumaBuf[p + outW] + lumaBuf[p + outW + 1]
        ) / 9;
        const delta = (center - avg) * amt;
        if (Math.abs(delta) > 2.2) {
          const di = p * 4;
          dData[di] = clamp(dData[di] + delta, 0, 255);
          dData[di + 1] = clamp(dData[di + 1] + delta, 0, 255);
          dData[di + 2] = clamp(dData[di + 2] + delta, 0, 255);
        }
      }
    }
  }

  // Pass 4: Final Scan Mode Tone Curve (Pure White Paper + Deep Crisp Ink + Preserved Stamps)
  if (filterMode !== 'original') {
    for (let i = 0; i < dData.length; i += 4) {
      let r = dData[i], g = dData[i + 1], b = dData[i + 2];
      const luma = 0.299 * r + 0.587 * g + 0.114 * b;
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      const sat = mx - mn;

      if (filterMode === 'magic') {
        if (luma > 218 && sat < 30) {
          // Pure snow-white paper background (#FFFFFF) — zero speckling!
          r = g = b = 255;
        } else if (sat < 32) {
          // Neutral gray/black text -> crisp laser dark ink
          const t = luma < 185 ? clamp((luma - 185) * 1.48 + 185, 0, 255) : clamp((luma - 185) * 2.1 + 185, 0, 255);
          r = g = b = t;
        } else {
          // Preserve vivid colored seals, red stamps, blue signatures & photos!
          const boost = 1.18;
          r = clamp(luma + (r - luma) * boost, 0, 255);
          g = clamp(luma + (g - luma) * boost, 0, 255);
          b = clamp(luma + (b - luma) * boost, 0, 255);
        }
      } else if (filterMode === 'bw') {
        const v = luma > 202 ? 255 : luma < 118 ? 12 : clamp((luma - 160) * 3.0 + 128, 0, 255);
        r = g = b = v;
      } else if (filterMode === 'gray') {
        const v = luma > 224 ? 255 : clamp((luma - 135) * 1.32 + 135, 0, 255);
        r = g = b = v;
      } else if (filterMode === 'econ') {
        // Ink-saver mode: ultra-clean white background + crisp medium-dark charcoal text
        const v = luma > 204 ? 255 : clamp(52 + (luma / 204) * 188, 48, 255);
        r = g = b = v;
      }

      dData[i] = r; dData[i + 1] = g; dData[i + 2] = b;
    }
  }

  oCtx.putImageData(outImgData, 0, 0);

  // Pass 5: 2D Multi-Band Automatic Text-Line Deskew & Curved-Line Dewarp + Optional Manual Fine Straightening
  let appliedDeskewDeg = 0;
  let appliedDewarpPx = 0;
  const hasManualAdj = Math.abs(manualDeg) >= 0.05 || Math.abs(manualArch) >= 0.5 || Math.abs(manualTiltTop) >= 0.5;
  if ((straightenLines && filterMode !== 'original') || hasManualAdj) {
    const res = straightenTextLinesOnCanvas(outCanvas, {
      autoStraighten: straightenLines && filterMode !== 'original',
      manualDeg,
      manualArch,
      manualTiltTop
    });
    appliedDeskewDeg = res.deskewDeg;
    appliedDewarpPx = res.dewarpPx;
  }
  outCanvas._deskewDeg = appliedDeskewDeg;
  outCanvas._dewarpPx = appliedDewarpPx;
  return outCanvas;
}

function solveLinearSystem(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let col = 0; col < n; col++) {
    let mr = col;
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(M[r][col]) > Math.abs(M[mr][col])) mr = r;
    }
    [M[col], M[mr]] = [M[mr], M[col]];
    const piv = M[col][col];
    if (Math.abs(piv) < 1e-10) return null;
    for (let r = col + 1; r < n; r++) {
      const f = M[r][col] / piv;
      for (let k = col; k <= n; k++) M[r][k] -= f * M[col][k];
    }
  }
  const x = new Float64Array(n);
  for (let i = n - 1; i >= 0; i--) {
    let s = M[i][n];
    for (let k = i + 1; k < n; k++) s -= M[i][k] * x[k];
    x[i] = s / M[i][i];
  }
  return x;
}

/**
 * Huber-IRLS Weighted Least Squares Solver for arbitrary basis functions phi(sample).
 * Immune to outliers (logos, stray dots, curved corners, short lines).
 */
function fitHuberBasis(samples, basisFn, numParams, ridge = 1e-4, huberDelta = 3.5) {
  if (!samples || samples.length < numParams + 4) return null;
  const weights = new Float64Array(samples.length).fill(1);
  let coef = new Float64Array(numParams);
  const phis = samples.map((s) => basisFn(s));

  for (let iter = 0; iter < 4; iter++) {
    const ATA = Array.from({ length: numParams }, () => new Float64Array(numParams));
    const ATb = new Float64Array(numParams);
    for (let i = 0; i < samples.length; i++) {
      const w = weights[i] * (samples[i].w || 1);
      const phi = phis[i];
      const y = samples[i].val;
      for (let r = 0; r < numParams; r++) {
        const wpr = w * phi[r];
        ATb[r] += wpr * y;
        for (let c = r; c < numParams; c++) ATA[r][c] += wpr * phi[c];
      }
    }
    for (let r = 0; r < numParams; r++) {
      ATA[r][r] += ridge;
      for (let c = 0; c < r; c++) ATA[r][c] = ATA[c][r];
    }
    const sol = solveLinearSystem(ATA, ATb);
    if (!sol) return null;
    coef = sol;

    for (let i = 0; i < samples.length; i++) {
      const phi = phis[i];
      let pred = 0;
      for (let k = 0; k < numParams; k++) pred += coef[k] * phi[k];
      const err = Math.abs(samples[i].val - pred);
      weights[i] = err <= huberDelta ? 1 : huberDelta / err;
    }
  }
  return coef;
}

/**
 * OPPO AI-Grade Text-Line & Margin Straightening Engine (v3.4.1):
 *  1) High-res Horizontal RLSA (Run-Length Smoothing) fuses each individual printed text line
 *     into a continuous horizontal ribbon (ZERO periodic-line aliasing!)
 *  2) Traces exact vertical centerline y(x) of EVERY text line across the entire page
 *  3) Fits an 8-parameter 2D Huber-IRLS smooth surface dy(u, v) = u*(a0 + a1*v + a2*v^2) + u^2*(...) + u^3*(...)
 *     that straightens global tilt, top-vs-bottom keystone, curved arches & S-waves in ONE pass!
 *  4) Traces full-width Left & Right text margins across all lines and straightens them vertically dx(u, v)!
 *  5) Single bilinear resampling pass -> ruler-horizontal lines + ruler-vertical margins + razor-crisp text!
 */
function straightenTextLinesOnCanvas(canvas, cfg = {}) {
  const { autoStraighten = true, manualDeg = 0, manualArch = 0, manualTiltTop = 0 } = cfg;
  const w = canvas.width;
  const h = canvas.height;
  if (w < 180 || h < 180) return { deskewDeg: 0, dewarpPx: 0 };

  let appliedDeskew = 0;
  let appliedDewarpPx = 0;

  const rotateCanvasByDeg = (deg) => {
    const rotCanvas = document.createElement('canvas');
    rotCanvas.width = w;
    rotCanvas.height = h;
    const rCtx = rotCanvas.getContext('2d');
    rCtx.fillStyle = '#FFFFFF';
    rCtx.fillRect(0, 0, w, h);
    rCtx.translate(w / 2, h / 2);
    rCtx.rotate((deg * Math.PI) / 180);
    rCtx.drawImage(canvas, -w / 2, -h / 2);
    const oCtx = canvas.getContext('2d');
    oCtx.clearRect(0, 0, w, h);
    oCtx.drawImage(rotCanvas, 0, 0);
  };

  // Basis for 2D vertical line flattening: zero at u=0 so vertical line spacing is 100% preserved!
  const dyBasis = (s) => {
    const u = s.u, u2 = u * u, u3 = u2 * u;
    const v = s.v, v2 = v * v;
    return [u, u2, u3, u * v, u2 * v, u3 * v, u * v2, u2 * v2];
  };
  let dyCoef = new Float64Array(8);
  let dxLeftCoef = null;
  let dxRightCoef = null;
  let marginSpanMinX = w * 0.12;
  let marginSpanMaxX = w * 0.88;

  if (autoStraighten) {
    // High enough resolution (~760px wide) so 10pt lines stay crisply separated (~12px tall + ~10px white gap)!
    const sc = Math.min(1, 760 / w);
    const dw = Math.max(240, Math.round(w * sc));
    const dh = Math.max(240, Math.round(h * sc));
    const invScX = w / dw;
    const invScY = h / dh;

    const tmp = document.createElement('canvas');
    tmp.width = dw;
    tmp.height = dh;
    const tCtx = tmp.getContext('2d');
    tCtx.drawImage(canvas, 0, 0, dw, dh);
    const px = tCtx.getImageData(0, 0, dw, dh).data;

    // 1. Binary dark-ink mask inside inner margins
    const xPad = Math.round(dw * 0.03);
    const yPad = Math.round(dh * 0.025);
    const bin = new Uint8Array(dw * dh);
    for (let y = yPad; y < dh - yPad; y++) {
      const row = y * dw;
      for (let x = xPad; x < dw - xPad; x++) {
        const i = (row + x) * 4;
        if (0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2] < 192) {
          bin[row + x] = 1;
        }
      }
    }

    // 2. Horizontal RLSA (Run-Length Smoothing): bridge inter-character & inter-word gaps (<= 2.6% width)
    const maxGap = Math.max(8, Math.round(dw * 0.026));
    const rlsa = new Uint8Array(bin);
    for (let y = yPad; y < dh - yPad; y++) {
      const row = y * dw;
      let lastOne = -1;
      for (let x = xPad; x < dw - xPad; x++) {
        if (bin[row + x] === 1) {
          if (lastOne >= 0 && x - lastOne <= maxGap) {
            for (let k = lastOne + 1; k < x; k++) rlsa[row + k] = 1;
          }
          lastOne = x;
        }
      }
    }
    // Bridge 1px vertical gaps inside characters (e.g. Vietnamese diacritics like ắ, ệ, ộ) without merging lines!
    const rlsa2 = new Uint8Array(rlsa);
    for (let y = yPad + 1; y < dh - yPad - 1; y++) {
      const row = y * dw;
      for (let x = xPad; x < dw - xPad; x++) {
        if (rlsa[row + x] === 0 && rlsa[row - dw + x] === 1 && rlsa[row + dw + x] === 1) {
          rlsa2[row + x] = 1;
        }
      }
    }

    // 3. Connected Components -> Trace EVERY individual text line ribbon!
    const visited = new Uint8Array(dw * dh);
    const queue = new Int32Array(dw * dh);
    const minLineW = Math.round(dw * 0.18);
    const maxMedThick = Math.max(8, Math.round(dh * 0.026));
    const maxBboxH = Math.round(dh * 0.095); // allows tilted/curved lines!

    const colMinY = new Int16Array(dw);
    const colMaxY = new Int16Array(dw);
    const dySamples = [];
    const bodyLeftPts = [];
    const bodyRightPts = [];
    let tracedLineCount = 0;

    for (let y = yPad; y < dh - yPad; y++) {
      const row = y * dw;
      for (let x = xPad; x < dw - xPad; x++) {
        const start = row + x;
        if (rlsa2[start] !== 1 || visited[start] === 1) continue;

        let qh = 0, qt = 0;
        queue[qt++] = start;
        visited[start] = 1;
        let minX = x, maxX = x, minY = y, maxY = y;

        while (qh < qt) {
          const cur = queue[qh++];
          const cy = (cur / dw) | 0;
          const cx = cur - cy * dw;
          if (cx < minX) minX = cx;
          if (cx > maxX) maxX = cx;
          if (cy < minY) minY = cy;
          if (cy > maxY) maxY = cy;
          if (cx > 0 && rlsa2[cur - 1] === 1 && !visited[cur - 1]) { visited[cur - 1] = 1; queue[qt++] = cur - 1; }
          if (cx + 1 < dw && rlsa2[cur + 1] === 1 && !visited[cur + 1]) { visited[cur + 1] = 1; queue[qt++] = cur + 1; }
          if (cy > 0 && rlsa2[cur - dw] === 1 && !visited[cur - dw]) { visited[cur - dw] = 1; queue[qt++] = cur - dw; }
          if (cy + 1 < dh && rlsa2[cur + dw] === 1 && !visited[cur + dw]) { visited[cur + dw] = 1; queue[qt++] = cur + dw; }
        }

        const bw = maxX - minX + 1;
        const bh = maxY - minY + 1;
        if (bw < minLineW || bh < 3 || bh > maxBboxH) continue;

        // Compute per-column vertical span [colMinY, colMaxY] ONLY for pixels of this component
        for (let cx = minX; cx <= maxX; cx++) { colMinY[cx] = 32767; colMaxY[cx] = -1; }
        for (let i = 0; i < qt; i++) {
          const cur = queue[i];
          const cy = (cur / dw) | 0;
          const cx = cur - cy * dw;
          if (cy < colMinY[cx]) colMinY[cx] = cy;
          if (cy > colMaxY[cx]) colMaxY[cx] = cy;
        }

        // Check median vertical thickness -> cleanly rejects photos, stamps, or vertically merged blobs!
        const thicks = [];
        for (let cx = minX; cx <= maxX; cx += 2) {
          if (colMaxY[cx] >= colMinY[cx]) thicks.push(colMaxY[cx] - colMinY[cx] + 1);
        }
        if (thicks.length < 12) continue;
        thicks.sort((a, b) => a - b);
        const medThick = thicks[thicks.length >> 1];
        if (medThick < 2 || medThick > maxMedThick) continue;

        // Extract clean centerline y(x) across this ribbon (ignoring columns touching another line)
        const rawXs = [];
        const rawYs = [];
        const maxColThick = Math.max(medThick * 2.1, medThick + 6);
        for (let cx = minX + 2; cx <= maxX - 2; cx += 4) {
          const t = colMaxY[cx] - colMinY[cx] + 1;
          if (t >= 2 && t <= maxColThick) {
            rawXs.push(cx);
            rawYs.push((colMinY[cx] + colMaxY[cx]) * 0.5);
          }
        }
        if (rawXs.length < 8) continue;

        // 5-point moving median smoothing along the ribbon to suppress ascender/descender jitter
        const smYs = new Float64Array(rawYs.length);
        for (let i = 0; i < rawYs.length; i++) {
          const a = Math.max(0, i - 2), b = Math.min(rawYs.length - 1, i + 2);
          const win = [];
          for (let k = a; k <= b; k++) win.push(rawYs[k]);
          win.sort((p, q) => p - q);
          smYs[i] = win[win.length >> 1];
        }

        // Anchor ribbon's flat target yBase at its horizontal center (closest to u = 0)
        const midX = dw * 0.5;
        let anchorIdx = rawXs.length >> 1;
        let bestMidDist = Infinity;
        for (let i = 0; i < rawXs.length; i++) {
          const d = Math.abs(rawXs[i] - midX);
          if (d < bestMidDist) { bestMidDist = d; anchorIdx = i; }
        }
        // If line spans across center, anchor at center; otherwise use median Y of line
        let yBase;
        if (minX < midX && maxX > midX) {
          yBase = smYs[anchorIdx];
        } else {
          const sortedY = Array.from(smYs).sort((a, b) => a - b);
          yBase = sortedY[sortedY.length >> 1];
        }

        const vNorm = yBase / dh - 0.5;
        const lineWeight = Math.min(2.5, bw / (dw * 0.55));
        for (let i = 0; i < rawXs.length; i++) {
          const uNorm = rawXs[i] / dw - 0.5;
          const dyFullPx = (smYs[i] - yBase) * invScY;
          if (Math.abs(dyFullPx) <= h * 0.08) {
            dySamples.push({ u: uNorm, v: vNorm, val: dyFullPx, w: lineWeight });
          }
        }
        tracedLineCount++;

        // Collect full-width body lines for left/right vertical margin straightening!
        if (bw >= dw * 0.52) {
          bodyLeftPts.push({ v: vNorm, val: minX * invScX, w: 1 });
          bodyRightPts.push({ v: vNorm, val: maxX * invScX, w: 1 });
        }
      }
    }

    // 4. Solve smooth 8-parameter 2D surface dy(u, v) from all traced text lines
    if (tracedLineCount >= 4 && dySamples.length >= 40) {
      const sol = fitHuberBasis(dySamples, dyBasis, 8, 1e-3, 3.0);
      if (sol) {
        // Verify RMS error actually improved (prevents false warp on pure photos)
        let sqBefore = 0, sqAfter = 0;
        for (const s of dySamples) {
          const phi = dyBasis(s);
          let pred = 0;
          for (let k = 0; k < 8; k++) pred += sol[k] * phi[k];
          sqBefore += s.val * s.val;
          const err = s.val - pred;
          sqAfter += err * err;
        }
        if (sqAfter < sqBefore * 0.92) {
          dyCoef = sol;
          // Report approximate global slope in degrees for status display
          appliedDeskew = Math.round((Math.atan2(dyCoef[0], w) * 180 / Math.PI) * 10) / 10;
        }
      }
    }

    // 5. Straighten Left & Right Vertical Margins (eliminates residual keystone/trapezoid skew!)
    const fitMarginCurve = (pts) => {
      if (pts.length < 6) return null;
      // Keep points near the dominant margin (within 4.5% of page width of median) to ignore indented lines
      const vals = pts.map((p) => p.val).sort((a, b) => a - b);
      const med = vals[vals.length >> 1];
      const tol = w * 0.045;
      const inliers = pts.filter((p) => Math.abs(p.val - med) <= tol);
      if (inliers.length < 5) return null;
      return fitHuberBasis(inliers, (s) => [1, s.v, s.v * s.v], 3, 1e-3, 4.0);
    };
    dxLeftCoef = fitMarginCurve(bodyLeftPts);
    dxRightCoef = fitMarginCurve(bodyRightPts);
    if (dxLeftCoef) marginSpanMinX = dxLeftCoef[0];
    if (dxRightCoef) marginSpanMaxX = dxRightCoef[0];
    if (marginSpanMaxX - marginSpanMinX < w * 0.35) {
      dxLeftCoef = null;
      dxRightCoef = null;
    }
  }

  // 6. Check if combined 2D vertical + horizontal straightening has meaningful correction
  let maxAbsDy = 0;
  for (const v of [-0.45, 0, 0.45]) {
    for (const u of [-0.46, 0.46]) {
      const phi = dyBasis({ u, v });
      let dy = 0;
      for (let k = 0; k < 8; k++) dy += dyCoef[k] * phi[k];
      if (Math.abs(dy) > maxAbsDy) maxAbsDy = Math.abs(dy);
    }
  }
  let maxAbsDx = 0;
  for (const v of [-0.45, 0.45]) {
    if (dxLeftCoef) maxAbsDx = Math.max(maxAbsDx, Math.abs(dxLeftCoef[1] * v + dxLeftCoef[2] * v * v));
    if (dxRightCoef) maxAbsDx = Math.max(maxAbsDx, Math.abs(dxRightCoef[1] * v + dxRightCoef[2] * v * v));
  }

  const manualSpan = Math.abs(manualArch) + Math.abs(manualTiltTop);
  if (maxAbsDy >= 1.2 || maxAbsDx >= 2.0 || manualSpan >= 0.5) {
    appliedDewarpPx = Math.round(maxAbsDy * 2);
    const oCtx = canvas.getContext('2d');
    const srcImg = oCtx.getImageData(0, 0, w, h);
    const dstImg = oCtx.createImageData(w, h);
    const sp = srcImg.data;
    const dp = dstImg.data;
    const maxDy = h * 0.085;
    const maxDx = w * 0.045;
    const mSpan = Math.max(1, marginSpanMaxX - marginSpanMinX);

    // Precompute X terms (u, u^2, u^3) for blazing-fast O(w*h) 2D bilinear warp
    const uArr = new Float32Array(w);
    const u2Arr = new Float32Array(w);
    const u3Arr = new Float32Array(w);
    const mAlpha = new Float32Array(w);
    for (let x = 0; x < w; x++) {
      const u = x / w - 0.5;
      uArr[x] = u;
      u2Arr[x] = u * u;
      u3Arr[x] = u * u * u;
      mAlpha[x] = clamp((x - marginSpanMinX) / mSpan, -0.25, 1.25);
    }

    for (let y = 0; y < h; y++) {
      const v = y / h - 0.5;
      const v2 = v * v;
      // Row polynomial coefficients in u: dy(u) = c1*u + c2*u^2 + c3*u^3
      const c1 = dyCoef[0] + dyCoef[3] * v + dyCoef[6] * v2 + manualTiltTop * (-2 * v);
      const c2 = dyCoef[1] + dyCoef[4] * v + dyCoef[7] * v2 + manualArch * 4;
      const c3 = dyCoef[2] + dyCoef[5] * v;

      // Row left/right horizontal margin shift
      const shiftL = dxLeftCoef ? clamp(dxLeftCoef[1] * v + dxLeftCoef[2] * v2, -maxDx, maxDx) : 0;
      const shiftR = dxRightCoef ? clamp(dxRightCoef[1] * v + dxRightCoef[2] * v2, -maxDx, maxDx) : 0;
      const useDx = Math.abs(shiftL) > 0.5 || Math.abs(shiftR) > 0.5;

      const rowOut = y * w;
      for (let x = 0; x < w; x++) {
        const dy = clamp(c1 * uArr[x] + c2 * u2Arr[x] + c3 * u3Arr[x], -maxDy, maxDy);
        const dx = useDx
          ? (dxLeftCoef && dxRightCoef
            ? shiftL * (1 - mAlpha[x]) + shiftR * mAlpha[x]
            : (dxLeftCoef ? shiftL : shiftR))
          : 0;

        const sx = x + dx;
        const sy = y + dy;
        const di = (rowOut + x) * 4;
        if (sx < 0 || sy < 0 || sx >= w - 1 || sy >= h - 1) {
          dp[di] = 255; dp[di + 1] = 255; dp[di + 2] = 255; dp[di + 3] = 255;
          continue;
        }
        const x0 = sx | 0, y0 = sy | 0;
        const fx = sx - x0, fy = sy - y0;
        const i00 = (y0 * w + x0) * 4;
        const i10 = i00 + 4;
        const i01 = i00 + w * 4;
        const i11 = i01 + 4;
        const w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
        dp[di] = sp[i00] * w00 + sp[i10] * w10 + sp[i01] * w01 + sp[i11] * w11;
        dp[di + 1] = sp[i00 + 1] * w00 + sp[i10 + 1] * w10 + sp[i01 + 1] * w01 + sp[i11 + 1] * w11;
        dp[di + 2] = sp[i00 + 2] * w00 + sp[i10 + 2] * w10 + sp[i01 + 2] * w01 + sp[i11 + 2] * w11;
        dp[di + 3] = 255;
      }
    }
    oCtx.putImageData(dstImg, 0, 0);
  }

  // Optional Manual Fine Rotation (°)
  if (Math.abs(manualDeg) >= 0.05) {
    rotateCanvasByDeg(manualDeg);
  }

  return { deskewDeg: appliedDeskew, dewarpPx: appliedDewarpPx };
}

/* ==================== PURE-JS MULTI-PAGE BINARY PDF 1.4 WRITER ==================== */

function buildMultiPagePdfBytes(pagesJpegList) {
  const enc = new TextEncoder();
  const chunks = [];
  let offset = 0;
  const pushStr = (s) => { const u = enc.encode(s); chunks.push(u); offset += u.length; };
  const pushBytes = (u) => { chunks.push(u); offset += u.length; };

  pushStr('%PDF-1.4\n%\xFF\xFF\xFF\xFF\n');

  const offsets = [0];
  const n = pagesJpegList.length;
  const pageIds = [];
  for (let i = 0; i < n; i++) pageIds.push(5 + i * 3);

  const beginObj = (id) => { offsets[id] = offset; pushStr(`${id} 0 obj\n`); };

  beginObj(1);
  pushStr('<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');

  beginObj(2);
  pushStr(`<< /Type /Pages /Count ${n} /Kids [${pageIds.map((id) => `${id} 0 R`).join(' ')}] >>\nendobj\n`);

  const A4_W = 595.28;
  const A4_H = 841.89;
  const MARGIN = 14;

  pagesJpegList.forEach((pg, i) => {
    const imgId = 3 + i * 3;
    const cntId = 4 + i * 3;
    const pageId = 5 + i * 3;
    const jpgBytes = base64ToUint8(pg.base64);

    const isLand = pg.width > pg.height * 1.12;
    const pW = isLand ? A4_H : A4_W;
    const pH = isLand ? A4_W : A4_H;
    const availW = pW - MARGIN * 2;
    const availH = pH - MARGIN * 2;
    const scale = Math.min(availW / pg.width, availH / pg.height);
    const drawW = (pg.width * scale).toFixed(2);
    const drawH = (pg.height * scale).toFixed(2);
    const dx = ((pW - pg.width * scale) / 2).toFixed(2);
    const dy = ((pH - pg.height * scale) / 2).toFixed(2);

    beginObj(imgId);
    pushStr(`<< /Type /XObject /Subtype /Image /Width ${pg.width} /Height ${pg.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpgBytes.length} >>\nstream\n`);
    pushBytes(jpgBytes);
    pushStr('\nendstream\nendobj\n');

    const streamStr = `q\n${drawW} 0 0 ${drawH} ${dx} ${dy} cm\n/Im0 Do\nQ\n`;
    const streamBytes = enc.encode(streamStr);
    beginObj(cntId);
    pushStr(`<< /Length ${streamBytes.length} >>\nstream\n`);
    pushBytes(streamBytes);
    pushStr('endstream\nendobj\n');

    beginObj(pageId);
    pushStr(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pW.toFixed(2)} ${pH.toFixed(2)}] /Resources << /XObject << /Im0 ${imgId} 0 R >> >> /Contents ${cntId} 0 R >>\nendobj\n`);
  });

  const xrefPos = offset;
  const totalObjs = 2 + n * 3;
  pushStr(`xref\n0 ${totalObjs + 1}\n0000000000 65535 f \n`);
  for (let id = 1; id <= totalObjs; id++) {
    pushStr(`${String(offsets[id]).padStart(10, '0')} 00000 n \n`);
  }
  pushStr(`trailer\n<< /Size ${totalObjs + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`);

  const totalLen = chunks.reduce((a, u) => a + u.length, 0);
  const out = new Uint8Array(totalLen);
  let pos = 0;
  for (const u of chunks) { out.set(u, pos); pos += u.length; }
  return out;
}

/* ==================== WORD (.doc) & EXCEL (.xls / .csv) BUILDERS ==================== */

function buildWordDocHtml(title, ocrHtmlBody, embeddedDataUrls = []) {
  const imgsHtml = embeddedDataUrls.length > 0
    ? `<hr/><h3 style="color:#7F1D1D;">Bản ảnh tài liệu đã căn chỉnh</h3>` +
      embeddedDataUrls.map((u, i) => `<p><strong>Trang ${i + 1}:</strong><br/><img src="${u}" style="max-width:620px;height:auto;border:1px solid #ccc;" /></p>`).join('')
    : '';
  return `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>${escHtml(title)}</title>
<style>
  @page { size: A4; margin: 2cm; }
  body { font-family: "Times New Roman", serif; font-size: 13pt; line-height: 1.5; color: #111; }
  h1, h2, h3 { color: #1E293B; }
  table { border-collapse: collapse; width: 100%; margin: 10px 0; }
  th, td { border: 1px solid #444; padding: 5px 8px; text-align: left; }
  th { background: #F1F5F9; font-weight: bold; }
</style></head>
<body>${ocrHtmlBody}${imgsHtml}</body></html>`;
}

function buildExcelXlsHtml(sheetName, rows) {
  const safeRows = (Array.isArray(rows) ? rows : []).filter((r) => Array.isArray(r) && r.length > 0);
  const trHtml = safeRows.map((row, rIdx) => {
    const tag = rIdx === 0 ? 'th' : 'td';
    return `<tr>${row.map((cell) => `<${tag} style="border:1px solid #94A3B8;padding:5px 8px;${rIdx === 0 ? 'background:#FEF3C7;font-weight:bold;' : ''}">${escHtml(String(cell ?? ''))}</${tag}>`).join('')}</tr>`;
  }).join('');
  return `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8">
<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>${escHtml(sheetName.slice(0, 30))}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
</head><body><table style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:11pt;">${trHtml}</table></body></html>`;
}

function buildCsvUtf8Bom(rows) {
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  return '\uFEFF' + (Array.isArray(rows) ? rows : []).map((r) => (Array.isArray(r) ? r.map(esc).join(',') : '')).join('\r\n');
}

/* ==================== MAIN UI MODULE ==================== */

export function mountDocScannerModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { isMobile = false, getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {} } = opts;

  let pages = []; // [{ id, origImg, origDataUrl, corners: [[x,y]x4], filter, removeShadow, sharpenText, warpedDataUrl, warpedBase64, warpedW, warpedH }]
  let curIdx = -1;
  let activeStream = null;
  let busy = false;
  let draggingCorner = -1;
  let showOriginalCompare = false;
  let lastWordHtml = '';
  let lastExcelRows = [];

  const stampName = () => {
    const d = new Date();
    const p2 = (x) => String(x).padStart(2, '0');
    return `QuetTaiLieu_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}`;
  };

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-sky">
        <div>
          <h2 class="sf-hero-title">📄 Quét Tài Liệu AI Pro (Chuẩn Cam AI)</h2>
          <div class="sf-hero-sub">Chỉ cần tải ảnh lên — tự bắt sát 4 mép giấy không thừa viền, xóa bóng trắng nét như máy scan &amp; Xuất Ảnh, PDF, Word, Excel.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-ds-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <div class="sf-btn-row" style="margin-bottom:9px;">
          <label class="sf-btn primary" style="cursor:pointer;flex:1;">
            📁 Tải ảnh lên (Tự quét ngay)
            <input id="ds-file" type="file" accept="image/*" multiple class="hidden" />
          </label>
          <button type="button" id="btn-ds-cam" class="sf-btn">📷 Chụp tài liệu</button>
          <button type="button" id="btn-ds-snap" class="sf-btn ai hidden">✨ Chụp trang này</button>
          <button type="button" id="btn-ds-stop" class="sf-btn hidden">Tắt cam</button>
          <input id="ds-cam-fb" type="file" accept="image/*" capture="environment" class="hidden" />
        </div>

        <!-- Live Camera Stage -->
        <div id="ds-cam-stage" class="mole-stage hidden" style="border-color:#0284C7;min-height:240px;">
          <video id="ds-video" class="mole-media" autoplay playsinline muted></video>
          <div class="mole-face-guide" aria-hidden="true">
            <div class="ft-doc-frame"></div>
            <span>Đặt tờ giấy trong khung rồi bấm Chụp — tự cắt sát mép &amp; xóa bóng</span>
          </div>
        </div>

        <!-- Empty placeholder -->
        <div id="ds-empty" class="mole-stage" style="border-color:#0284C7;min-height:175px;cursor:pointer;">
          <div class="mole-placeholder">
            <div style="font-size:42px;margin-bottom:4px;">📄✨</div>
            <div>Chạm để <strong>📁 Tải ảnh tài liệu lên</strong> (tự động cắt phẳng &amp; làm trắng nét ngay!)</div>
            <div style="font-size:11.5px;opacity:0.86;margin-top:4px;">Hỗ trợ chọn nhiều trang cùng lúc • Xóa bóng đổ • Xuất JPG, PDF A4, Word (.doc), Excel (.xls)</div>
          </div>
        </div>

        <!-- Multi-page strip -->
        <div id="ds-pages-strip" class="ft-thumbs-bar hidden" style="margin-top:6px;"></div>

        <!-- Interactive Corner Editor & Warped Preview -->
        <div id="ds-editor-area" class="hidden">
          <div class="sf-seg" id="ds-view-seg" style="margin-top:6px;">
            <button type="button" class="sf-seg-btn active" data-v="result">✨ Bản đã căn phẳng</button>
            <button type="button" class="sf-seg-btn" data-v="crop">✂️ Chỉnh 4 góc giấy</button>
          </div>

          <!-- Crop Canvas View with Magnifier Loupe -->
          <div id="ds-crop-box" class="hidden" style="text-align:center;margin-bottom:8px;">
            <div style="font-size:11.5px;font-weight:700;color:#0369A1;margin-bottom:5px;">👆 Kéo 4 chấm tròn xanh đặt đúng 4 góc giấy (có kính lúp phóng to khi kéo)</div>
            <div id="ds-crop-wrap" style="position:relative;display:inline-block;max-width:100%;touch-action:none;line-height:0;border-radius:10px;overflow:hidden;border:1.5px solid #0284C7;">
              <canvas id="ds-crop-canvas" style="display:block;max-width:100%;height:auto;"></canvas>
            </div>
            <div class="sf-btn-row" style="justify-content:center;margin-top:7px;">
              <button type="button" id="btn-ds-cv-corners" class="sf-btn emerald">🎯 Tự bắt mép giấy</button>
              <button type="button" id="btn-ds-ai-corners" class="sf-btn ai">✨ Gemini AI bắt góc</button>
              <button type="button" id="btn-ds-full-corners" class="sf-btn">↺ Toàn ảnh</button>
              <button type="button" id="btn-ds-apply-warp" class="sf-btn primary">✅ Áp dụng</button>
            </div>
          </div>

          <!-- Straightened Preview View with OPPO-style AI Scanning Sweep Overlay & Horizontal Ruler Grid -->
          <div id="ds-result-view" style="text-align:center;margin-bottom:8px;">
            <div id="ds-preview-stage" class="ds-preview-stage">
              <img id="ds-warped-img" class="ds-warped-img" alt="Bản scan đã căn chỉnh" />
              <div id="ds-ruler-grid" class="ds-ruler-grid hidden" aria-hidden="true"></div>
              <div id="ds-scan-fx" class="ds-scan-fx hidden">
                <div class="ds-scan-glow"></div>
                <div class="ds-scan-line"></div>
                <div id="ds-scan-fx-label" class="ds-scan-fx-label">✨ Đang tăng cường hình ảnh &amp; văn bản...</div>
              </div>
              <span id="ds-compare-badge" class="ds-compare-badge hidden">Ảnh gốc chưa quét</span>
            </div>

            <!-- 5 OPPO-Style Scan Modes -->
            <div class="sf-pills" id="ds-filter-pills" style="justify-content:center;margin-top:9px;">
              <button type="button" class="sf-pill active" data-f="magic">✨ Màu (AI)</button>
              <button type="button" class="sf-pill" data-f="bw">📄 Đen trắng</button>
              <button type="button" class="sf-pill" data-f="gray">🌫️ Độ xám</button>
              <button type="button" class="sf-pill" data-f="econ">💡 Tiết kiệm mực</button>
              <button type="button" class="sf-pill" data-f="original">🖼️ Nguyên gốc</button>
            </div>

            <!-- OPPO-style Quick Enhancement Toggles & Tools -->
            <div class="sf-btn-row" style="justify-content:center;margin-bottom:4px;">
              <button type="button" id="btn-ds-straight-panel" class="sf-btn ds-toggle-on">📐 Căn thẳng dòng chữ</button>
              <button type="button" id="btn-ds-toggle-shadow" class="sf-btn ds-toggle-on">☀️ Xóa bóng: Bật</button>
              <button type="button" id="btn-ds-toggle-sharp" class="sf-btn ds-toggle-on">🔍 Tăng nét: Bật</button>
              <button type="button" id="btn-ds-compare" class="sf-btn">👁 So sánh gốc</button>
              <button type="button" id="btn-ds-rotate" class="sf-btn">↻ Xoay 90°</button>
              <button type="button" id="btn-ds-del-page" class="sf-btn" style="color:#DC2626;">🗑 Xóa</button>
            </div>

            <!-- Interactive Text-Line Straightening Panel (with Live Horizontal Ruler Overlay!) -->
            <div id="ds-straight-box" class="ds-straight-box hidden">
              <div class="sf-btn-row" style="justify-content:space-between;margin-bottom:6px;">
                <strong style="font-size:12px;color:#0369A1;">📐 Căn chỉnh dòng chữ thẳng hàng (nhìn theo thước kẻ xanh)</strong>
                <div style="display:flex;gap:5px;">
                  <button type="button" id="btn-ds-toggle-straight" class="sf-btn ds-toggle-on" style="padding:3px 8px;font-size:11px;">✨ Tự động 2D: Bật</button>
                  <button type="button" id="btn-ds-straight-reset" class="sf-btn" style="padding:3px 8px;font-size:11px;">↺ Mặc định</button>
                </div>
              </div>
              <div class="ds-slider-row">
                <span>Xoay góc chữ: <strong id="ds-lbl-deg">0.0°</strong></span>
                <div class="ds-slider-ctrl">
                  <button type="button" id="btn-ds-deg-minus" class="sf-btn" style="padding:2px 7px;font-size:11px;">↺ -0.5°</button>
                  <input id="ds-rng-deg" type="range" min="-8" max="8" step="0.2" value="0" style="flex:1;accent-color:#0284C7;" />
                  <button type="button" id="btn-ds-deg-plus" class="sf-btn" style="padding:2px 7px;font-size:11px;">↻ +0.5°</button>
                </div>
              </div>
              <div class="ds-slider-row">
                <span>Nắn cong dòng chữ (vồng giữa): <strong id="ds-lbl-arch">0</strong></span>
                <input id="ds-rng-arch" type="range" min="-45" max="45" step="1" value="0" style="width:100%;accent-color:#0284C7;" />
              </div>
              <div class="ds-slider-row" style="margin-bottom:0;">
                <span>Chỉnh nghiêng trên/dưới (méo vát): <strong id="ds-lbl-tilt">0</strong></span>
                <input id="ds-rng-tilt" type="range" min="-45" max="45" step="1" value="0" style="width:100%;accent-color:#0284C7;" />
              </div>
            </div>
          </div>
        </div>

        <div id="ds-status" class="sf-status"></div>
      </div>

      <!-- Export Panel: Image, PDF, Word, Excel -->
      <div id="ds-export-card" class="sf-card hidden">
        <h3 class="sf-card-title" style="color:#0369A1;">📤 Xuất tài liệu (<span id="ds-page-count">0</span> trang)</h3>
        <div class="sf-field">
          <label for="ds-filename">Tên file xuất ra:</label>
          <input id="ds-filename" type="text" value="${stampName()}" maxlength="70" />
        </div>
        <div class="sf-grid-2" style="margin-bottom:8px;">
          <button type="button" id="btn-ds-exp-img" class="sf-btn emerald">🖼️ Xuất Ảnh (.JPG)</button>
          <button type="button" id="btn-ds-exp-pdf" class="sf-btn primary">📕 Xuất PDF (A4)</button>
          <button type="button" id="btn-ds-exp-word" class="sf-btn ai">📘 AI Xuất Word (.doc)</button>
          <button type="button" id="btn-ds-exp-excel" class="sf-btn" style="background:#047857;border-color:#047857;color:#FFF;">📗 AI Xuất Excel (.xls)</button>
        </div>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:600;color:#475569;">
          <input type="checkbox" id="ds-word-with-img" checked />
          Chèn kèm ảnh bản scan vào cuối file Word (.doc)
        </label>
        <div id="ds-export-status" class="sf-status"></div>
      </div>

      <!-- OCR Preview Card -->
      <div id="ds-ocr-card" class="sf-card hidden">
        <div class="sf-btn-row" style="justify-content:space-between;margin-bottom:8px;">
          <strong id="ds-ocr-title" style="font-size:13.5px;color:#0F172A;">📝 Xem trước nội dung AI trích xuất</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-ds-ocr-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-ds-ocr-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-ds-ocr-dl" class="sf-btn emerald" style="padding:4px 9px;font-size:11px;">⬇️ Tải lại file</button>
          </div>
        </div>
        <div id="ds-ocr-body" style="max-height:280px;overflow:auto;font-size:12.5px;line-height:1.5;border:1px solid #E2E8F0;border-radius:9px;padding:9px;background:#FFFDF9;"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  const videoEl = q('#ds-video');
  const cropCanvas = q('#ds-crop-canvas');
  let viewMode = 'result';
  let straightPanelOpen = false;
  let lastExportKind = 'word';

  const setStatus = (m, err = false) => {
    q('#ds-status').className = err ? 'sf-status err' : 'sf-status';
    q('#ds-status').textContent = m || '';
  };
  const setExpStatus = (m, err = false) => {
    q('#ds-export-status').className = err ? 'sf-status err' : 'sf-status';
    q('#ds-export-status').textContent = m || '';
  };

  const setScanOverlay = (on, label = '✨ Đang tăng cường hình ảnh & văn bản...') => {
    const fx = q('#ds-scan-fx');
    const lbl = q('#ds-scan-fx-label');
    if (lbl && label) lbl.textContent = label;
    if (fx) fx.classList.toggle('hidden', !on);
  };

  const stopCamera = () => {
    if (activeStream) {
      activeStream.getTracks().forEach((t) => { try { t.stop(); } catch (_e) {} });
      activeStream = null;
    }
    if (videoEl) videoEl.srcObject = null;
    removeCameraControlBar(q('#ds-cam-stage'));
    q('#ds-cam-stage').classList.add('hidden');
    q('#btn-ds-snap').classList.add('hidden');
    q('#btn-ds-stop').classList.add('hidden');
    q('#btn-ds-cam').classList.remove('hidden');
    if (pages.length === 0) q('#ds-empty').classList.remove('hidden');
  };

  const rebuildPageWarp = (pg) => {
    if (!pg || !pg.origImg) return;
    const canvas = renderWarpedDocument(pg.origImg, pg.corners, {
      filterMode: pg.filter,
      removeShadow: pg.removeShadow,
      sharpenText: pg.sharpenText,
      straightenLines: pg.straightenLines !== false,
      manualDeg: pg.manualDeg || 0,
      manualArch: pg.manualArch || 0,
      manualTiltTop: pg.manualTiltTop || 0,
      maxOutDim: 1800
    });
    const dataUrl = canvas.toDataURL('image/jpeg', 0.93);
    pg.warpedDataUrl = dataUrl;
    pg.warpedBase64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');
    pg.warpedW = canvas.width;
    pg.warpedH = canvas.height;
    pg.deskewDeg = canvas._deskewDeg || 0;
    pg.dewarpPx = canvas._dewarpPx || 0;
  };

  const drawCropOverlay = () => {
    const pg = pages[curIdx];
    if (!pg || !cropCanvas) return;
    const img = pg.origImg;
    const maxW = Math.min(460, mountEl.clientWidth - 40 || 340);
    const scale = Math.min(1, maxW / img.width, 400 / img.height);
    const cw = Math.max(200, Math.round(img.width * scale));
    const ch = Math.max(180, Math.round(img.height * scale));
    cropCanvas.width = cw;
    cropCanvas.height = ch;
    const ctx = cropCanvas.getContext('2d');
    ctx.drawImage(img, 0, 0, cw, ch);

    const pts = pg.corners.map(([nx, ny]) => [nx * cw, ny * ch]);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.42)';
    ctx.fillRect(0, 0, cw, ch);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < 4; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(img, 0, 0, cw, ch);
    ctx.restore();

    // Glowing cyan/emerald edge outline
    ctx.strokeStyle = '#00E5FF';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < 4; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
    ctx.stroke();

    pts.forEach(([px, py], i) => {
      ctx.beginPath();
      ctx.arc(px, py, 10, 0, Math.PI * 2);
      ctx.fillStyle = draggingCorner === i ? '#F59E0B' : '#0284C7';
      ctx.fill();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#FFFFFF';
      ctx.stroke();
    });

    // Precision Magnifying Loupe while dragging a corner!
    if (draggingCorner >= 0 && draggingCorner < 4) {
      const [nx, ny] = pg.corners[draggingCorner];
      const lr = 42;
      const lx = nx > 0.5 ? lr + 10 : cw - lr - 10;
      const ly = lr + 10;
      const srcX = nx * img.width;
      const srcY = ny * img.height;
      const zoomBox = Math.max(40, Math.min(img.width, img.height) * 0.14);

      ctx.save();
      ctx.beginPath();
      ctx.arc(lx, ly, lr, 0, Math.PI * 2);
      ctx.clip();
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(lx - lr, ly - lr, lr * 2, lr * 2);
      ctx.drawImage(img, srcX - zoomBox / 2, srcY - zoomBox / 2, zoomBox, zoomBox, lx - lr, ly - lr, lr * 2, lr * 2);
      // Crosshair inside loupe
      ctx.strokeStyle = '#00E5FF';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(lx - 14, ly); ctx.lineTo(lx + 14, ly);
      ctx.moveTo(lx, ly - 14); ctx.lineTo(lx, ly + 14);
      ctx.stroke();
      ctx.restore();

      ctx.beginPath();
      ctx.arc(lx, ly, lr, 0, Math.PI * 2);
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#FFFFFF';
      ctx.stroke();
    }
  };

  const renderUI = () => {
    const has = pages.length > 0 && curIdx >= 0;
    q('#ds-empty').classList.toggle('hidden', has || !q('#ds-cam-stage').classList.contains('hidden'));
    q('#ds-editor-area').classList.toggle('hidden', !has);
    q('#ds-export-card').classList.toggle('hidden', !has);
    q('#ds-pages-strip').classList.toggle('hidden', !has);
    q('#ds-page-count').textContent = String(pages.length);

    if (!has) return;
    const pg = pages[curIdx];
    q('#ds-warped-img').src = showOriginalCompare ? pg.origDataUrl : pg.warpedDataUrl;
    q('#ds-compare-badge').classList.toggle('hidden', !showOriginalCompare);
    q('#btn-ds-compare').classList.toggle('ds-toggle-on', showOriginalCompare);
    q('#btn-ds-compare').textContent = showOriginalCompare ? '✨ Xem bản scan' : '👁 So sánh gốc';

    q('#ds-straight-box')?.classList.toggle('hidden', !straightPanelOpen);
    q('#ds-ruler-grid')?.classList.toggle('hidden', !straightPanelOpen || showOriginalCompare);
    q('#btn-ds-straight-panel')?.classList.toggle('ds-toggle-on', straightPanelOpen || pg.straightenLines !== false);
    q('#btn-ds-toggle-straight').classList.toggle('ds-toggle-on', pg.straightenLines !== false);
    q('#btn-ds-toggle-straight').textContent = pg.straightenLines !== false ? '✨ Tự động 2D: Bật' : '✨ Tự động 2D: Tắt';
    if (q('#ds-rng-deg')) q('#ds-rng-deg').value = String(pg.manualDeg || 0);
    if (q('#ds-lbl-deg')) q('#ds-lbl-deg').textContent = `${(pg.manualDeg || 0).toFixed(1)}°`;
    if (q('#ds-rng-arch')) q('#ds-rng-arch').value = String(pg.manualArch || 0);
    if (q('#ds-lbl-arch')) q('#ds-lbl-arch').textContent = String(pg.manualArch || 0);
    if (q('#ds-rng-tilt')) q('#ds-rng-tilt').value = String(pg.manualTiltTop || 0);
    if (q('#ds-lbl-tilt')) q('#ds-lbl-tilt').textContent = String(pg.manualTiltTop || 0);
    q('#btn-ds-toggle-shadow').classList.toggle('ds-toggle-on', pg.removeShadow);
    q('#btn-ds-toggle-shadow').textContent = pg.removeShadow ? '☀️ Xóa bóng: Bật' : '☀️ Xóa bóng: Tắt';
    q('#btn-ds-toggle-sharp').classList.toggle('ds-toggle-on', pg.sharpenText);
    q('#btn-ds-toggle-sharp').textContent = pg.sharpenText ? '🔍 Tăng nét: Bật' : '🔍 Tăng nét: Tắt';

    q('#ds-filter-pills').querySelectorAll('.sf-pill').forEach((p) => p.classList.toggle('active', p.dataset.f === pg.filter));
    q('#ds-crop-box').classList.toggle('hidden', viewMode !== 'crop');
    q('#ds-result-view').classList.toggle('hidden', viewMode !== 'result');
    q('#ds-view-seg').querySelectorAll('.sf-seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.v === viewMode));
    if (viewMode === 'crop') drawCropOverlay();

    // Multi-page thumbnail strip
    const strip = q('#ds-pages-strip');
    strip.innerHTML = '';
    pages.forEach((p, idx) => {
      const chip = document.createElement('div');
      chip.className = 'ft-thumb-chip';
      if (idx === curIdx) chip.style.borderColor = '#0284C7';
      chip.innerHTML = `<img src="${p.warpedDataUrl}" alt="Trang ${idx + 1}" /><span>Trang ${idx + 1}</span>`;
      chip.addEventListener('click', () => { showOriginalCompare = false; curIdx = idx; renderUI(); });
      strip.appendChild(chip);
    });
    const addBtn = document.createElement('button');
    addBtn.type = 'button';
    addBtn.className = 'ft-thumb-add';
    addBtn.textContent = '+ Thêm trang';
    addBtn.addEventListener('click', () => q('#ds-file')?.click());
    strip.appendChild(addBtn);
  };

  // Gemini Vision AI backup corner detector (used on demand or when local CV has low confidence on white-on-white background)
  const runGeminiDetectCorners = async (pageObj) => {
    const st = getState();
    if (!pageObj || !isGeminiConfigured(st?.geminiSettings)) {
      if (!isGeminiConfigured(st?.geminiSettings)) {
        setStatus('💡 Chưa nhập Gemini API Key — thuật toán bắt mép giấy tự động ngoại tuyến đã chạy xong! Bạn có thể chỉnh thêm ở "✂️ Chỉnh 4 góc giấy".', false);
      }
      return false;
    }
    busy = true;
    setScanOverlay(true, '✨ Gemini AI đang dò lại chính xác 4 góc tờ giấy...');
    setStatus('✨ Gemini Vision AI đang nhận diện 4 góc tờ giấy...');
    try {
      const c = document.createElement('canvas');
      const sc = Math.min(1, 880 / Math.max(pageObj.origImg.width, pageObj.origImg.height));
      c.width = Math.round(pageObj.origImg.width * sc);
      c.height = Math.round(pageObj.origImg.height * sc);
      c.getContext('2d').drawImage(pageObj.origImg, 0, 0, c.width, c.height);
      const b64 = c.toDataURL('image/jpeg', 0.86).replace(/^data:image\/jpeg;base64,/, '');

      const raw = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Detect the EXACT 4 inner corners of the white paper document page, strictly EXCLUDING any table/desk background around the edges. Return ONLY valid JSON: {"corners":[[tl_x,tl_y],[tr_x,tr_y],[br_x,br_y],[bl_x,bl_y]]} in 0..1000 coordinates (x=left..right, y=top..bottom). Be tight on the paper edge so zero table margin is included.',
        userPrompt: 'Return exact 4 paper corners [TL, TR, BR, BL] in 0..1000 coordinates, strictly inside the white paper edge (zero blue/desk border). JSON only.',
        images: [b64],
        temperature: 0.05,
        responseMimeType: 'application/json',
        timeoutMs: 20000
      });
      const cleaned = raw.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
      const obj = JSON.parse(cleaned.match(/\{[\s\S]*\}/)?.[0] || cleaned);
      const pts = obj?.corners;
      if (Array.isArray(pts) && pts.length === 4) {
        let norm = pts.map(([x, y]) => [
          clamp(Number(x) > 1 ? Number(x) / 1000 : Number(x), 0.004, 0.996),
          clamp(Number(y) > 1 ? Number(y) / 1000 : Number(y), 0.004, 0.996)
        ]);
        norm = orderCornersTLTRBRBL(norm);
        if (dist2D(norm[0], norm[1]) > 0.16 && dist2D(norm[0], norm[3]) > 0.16) {
          pageObj.corners = norm;
          rebuildPageWarp(pageObj);
          renderUI();
          setStatus('✅ Gemini AI đã căn phẳng sát mép & làm sắc nét tờ giấy!');
          return true;
        }
      }
      return false;
    } catch (_err) {
      return false;
    } finally {
      busy = false;
      setScanOverlay(false);
    }
  };

  // Automatic 1-tap upload -> OPPO-style CV edge detection + glow animation + shadow removal + sharpening!
  const addPageFromImage = async (img, origDataUrl) => {
    const pg = {
      id: `pg-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      origImg: img,
      origDataUrl,
      corners: [[0.02, 0.02], [0.98, 0.02], [0.98, 0.98], [0.02, 0.98]],
      filter: 'magic',
      removeShadow: true,
      sharpenText: true,
      straightenLines: true,
      manualDeg: 0,
      manualArch: 0,
      manualTiltTop: 0,
      warpedDataUrl: origDataUrl,
      warpedBase64: '',
      warpedW: img.width,
      warpedH: img.height
    };
    pages.push(pg);
    curIdx = pages.length - 1;
    viewMode = 'result';
    showOriginalCompare = false;
    renderUI();

    // Play sleek OPPO-style AI scan sweep while running local CV + warp + illumination normalization!
    setScanOverlay(true, '✨ Đang nhận diện 4 góc mép giấy...');
    setStatus('✨ Đang tự động bắt mép giấy, căn phẳng & xóa bóng...');

    await new Promise((r) => setTimeout(r, 120));
    const cvRes = detectPaperCornersCV(img);
    if (cvRes && cvRes.corners) {
      pg.corners = cvRes.corners;
    }

    setScanOverlay(true, '✨ Xóa bóng, tăng nét & tự căn thẳng hàng chữ...');
    await new Promise((r) => setTimeout(r, 160));
    rebuildPageWarp(pg);
    renderUI();

    // Keep glow sweep briefly so user feels the crisp transformation, then reveal!
    await new Promise((r) => setTimeout(r, 380));
    setScanOverlay(false);

    const alignNote = (pg.deskewDeg || pg.dewarpPx)
      ? ` • 📐 Đã tự căn thẳng hàng${pg.deskewDeg ? ` (${pg.deskewDeg > 0 ? '+' : ''}${pg.deskewDeg}°)` : ''}${pg.dewarpPx ? ` & làm phẳng dòng cong` : ''}`
      : '';
    if (cvRes && cvRes.confidence >= 0.52) {
      setStatus(`✅ Đã cắt sát mép giấy, xóa bóng & làm nét văn bản${alignNote}! (${pg.warpedW}×${pg.warpedH}px)`);
    } else if (isGeminiConfigured(getState()?.geminiSettings)) {
      // Low-contrast surface (e.g. white paper on white table): refine automatically with Gemini Vision!
      const ok = await runGeminiDetectCorners(pg);
      if (!ok) setStatus('✅ Đã quét & lọc trắng nét tài liệu! Bạn có thể tinh chỉnh góc ở tab "✂️ Chỉnh 4 góc giấy".');
    } else {
      setStatus('✅ Đã quét, xóa bóng & làm nét văn bản! (Nếu nền trùng màu giấy, kéo nhẹ 4 góc ở tab "✂️ Chỉnh 4 góc giấy").');
    }
  };

  const handleFiles = (fileList) => {
    const files = Array.from(fileList || []).slice(0, 10);
    if (!files.length) return;
    stopCamera();
    // Process sequentially so each uploaded photo gets full CV corner detection & warp cleanly
    (async () => {
      for (const file of files) {
        await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const dataUrl = String(reader.result || '');
            const img = new Image();
            img.onload = async () => {
              await addPageFromImage(img, dataUrl);
              resolve();
            };
            img.onerror = resolve;
            img.src = dataUrl;
          };
          reader.onerror = resolve;
          reader.readAsDataURL(file);
        });
      }
    })();
  };

  // Draggable 4-corner touch/mouse interaction with Magnifier Loupe
  const getCanvasNormPos = (ev) => {
    const rect = cropCanvas.getBoundingClientRect();
    const clientX = ev.touches ? ev.touches[0].clientX : ev.clientX;
    const clientY = ev.touches ? ev.touches[0].clientY : ev.clientY;
    return [
      clamp((clientX - rect.left) / rect.width, 0.002, 0.998),
      clamp((clientY - rect.top) / rect.height, 0.002, 0.998)
    ];
  };
  const onDragStart = (ev) => {
    const pg = pages[curIdx];
    if (!pg) return;
    const [nx, ny] = getCanvasNormPos(ev);
    let best = -1, bestD = 0.16;
    pg.corners.forEach((pt, i) => {
      const d = Math.hypot(pt[0] - nx, pt[1] - ny);
      if (d < bestD) { bestD = d; best = i; }
    });
    if (best >= 0) {
      draggingCorner = best;
      ev.preventDefault();
      drawCropOverlay();
    }
  };
  const onDragMove = (ev) => {
    if (draggingCorner < 0 || !pages[curIdx]) return;
    ev.preventDefault();
    pages[curIdx].corners[draggingCorner] = getCanvasNormPos(ev);
    drawCropOverlay();
  };
  const onDragEnd = () => {
    if (draggingCorner < 0) return;
    draggingCorner = -1;
    if (pages[curIdx]) rebuildPageWarp(pages[curIdx]);
    drawCropOverlay();
  };
  cropCanvas.addEventListener('mousedown', onDragStart);
  cropCanvas.addEventListener('touchstart', onDragStart, { passive: false });
  window.addEventListener('mousemove', onDragMove);
  window.addEventListener('touchmove', onDragMove, { passive: false });
  window.addEventListener('mouseup', onDragEnd);
  window.addEventListener('touchend', onDragEnd);

  // Tap empty stage to upload right away!
  q('#ds-empty')?.addEventListener('click', () => q('#ds-file')?.click());

  // Camera & UI Controls (Smart Wide 1x Camera + Zoom/Lens Bar + Native Camera option!)
  const startDocCamera = async (preferredDeviceId = null) => {
    if (!navigator.mediaDevices?.getUserMedia) {
      if (isMobile) q('#ds-cam-fb')?.click();
      else setStatus('⚠️ Hãy bấm "📁 Tải ảnh lên" hoặc mở toàn trang để dùng Camera.', true);
      return;
    }
    try {
      stopCamera();
      const ctrl = await openSmartCamera('environment', { preferredDeviceId });
      activeStream = ctrl.stream;
      videoEl.srcObject = ctrl.stream;
      try { await videoEl.play(); } catch (_e) {}
      q('#ds-empty').classList.add('hidden');
      q('#ds-cam-stage').classList.remove('hidden');
      q('#btn-ds-snap').classList.remove('hidden');
      q('#btn-ds-stop').classList.remove('hidden');
      q('#btn-ds-cam').classList.add('hidden');
      attachCameraControlBar(q('#ds-cam-stage'), ctrl, {
        onSwitchRearLens: (devId) => startDocCamera(devId),
        onOpenNativeCamera: isMobile ? () => { stopCamera(); q('#ds-cam-fb')?.click(); } : null
      });
    } catch (_e) {
      if (isMobile) q('#ds-cam-fb')?.click();
      else setStatus('⚠️ Không mở được Camera — hãy bấm "📁 Tải ảnh lên".', true);
    }
  };
  q('#btn-ds-back')?.addEventListener('click', () => { stopCamera(); onBack(); });
  q('#btn-ds-cam')?.addEventListener('click', () => startDocCamera(null));
  q('#btn-ds-stop')?.addEventListener('click', stopCamera);
  q('#btn-ds-snap')?.addEventListener('click', () => {
    if (!videoEl?.videoWidth) return;
    const c = document.createElement('canvas');
    c.width = videoEl.videoWidth;
    c.height = videoEl.videoHeight;
    c.getContext('2d').drawImage(videoEl, 0, 0);
    const dataUrl = c.toDataURL('image/jpeg', 0.94);
    const img = new Image();
    img.onload = () => { stopCamera(); addPageFromImage(img, dataUrl); };
    img.src = dataUrl;
  });
  q('#ds-file')?.addEventListener('change', (e) => { handleFiles(e.target.files); e.target.value = ''; });
  q('#ds-cam-fb')?.addEventListener('change', (e) => { handleFiles(e.target.files); e.target.value = ''; });

  q('#ds-view-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    viewMode = b.dataset.v || 'result';
    showOriginalCompare = false;
    if (viewMode === 'result' && pages[curIdx]) rebuildPageWarp(pages[curIdx]);
    renderUI();
  });

  q('#ds-filter-pills')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-pill');
    if (!b || !pages[curIdx]) return;
    showOriginalCompare = false;
    pages[curIdx].filter = b.dataset.f || 'magic';
    rebuildPageWarp(pages[curIdx]);
    renderUI();
  });

  q('#btn-ds-straight-panel')?.addEventListener('click', () => {
    straightPanelOpen = !straightPanelOpen;
    renderUI();
  });

  q('#btn-ds-toggle-straight')?.addEventListener('click', () => {
    if (!pages[curIdx]) return;
    showOriginalCompare = false;
    pages[curIdx].straightenLines = pages[curIdx].straightenLines === false;
    rebuildPageWarp(pages[curIdx]);
    renderUI();
  });

  q('#btn-ds-straight-reset')?.addEventListener('click', () => {
    const pg = pages[curIdx];
    if (!pg) return;
    pg.straightenLines = true;
    pg.manualDeg = 0;
    pg.manualArch = 0;
    pg.manualTiltTop = 0;
    rebuildPageWarp(pg);
    renderUI();
    setStatus('✅ Đã đặt lại căn thẳng dòng chữ 2D tự động!');
  });

  let straightDebounce = null;
  const applyStraightSlider = () => {
    const pg = pages[curIdx];
    if (!pg) return;
    showOriginalCompare = false;
    pg.manualDeg = Number(q('#ds-rng-deg')?.value || 0);
    pg.manualArch = Number(q('#ds-rng-arch')?.value || 0);
    pg.manualTiltTop = Number(q('#ds-rng-tilt')?.value || 0);
    if (q('#ds-lbl-deg')) q('#ds-lbl-deg').textContent = `${pg.manualDeg.toFixed(1)}°`;
    if (q('#ds-lbl-arch')) q('#ds-lbl-arch').textContent = String(pg.manualArch);
    if (q('#ds-lbl-tilt')) q('#ds-lbl-tilt').textContent = String(pg.manualTiltTop);
    clearTimeout(straightDebounce);
    straightDebounce = setTimeout(() => {
      rebuildPageWarp(pg);
      renderUI();
    }, 90);
  };
  q('#ds-rng-deg')?.addEventListener('input', applyStraightSlider);
  q('#ds-rng-arch')?.addEventListener('input', applyStraightSlider);
  q('#ds-rng-tilt')?.addEventListener('input', applyStraightSlider);
  q('#btn-ds-deg-minus')?.addEventListener('click', () => {
    const r = q('#ds-rng-deg');
    if (!r) return;
    r.value = String(clamp(Number(r.value) - 0.5, -8, 8).toFixed(1));
    applyStraightSlider();
  });
  q('#btn-ds-deg-plus')?.addEventListener('click', () => {
    const r = q('#ds-rng-deg');
    if (!r) return;
    r.value = String(clamp(Number(r.value) + 0.5, -8, 8).toFixed(1));
    applyStraightSlider();
  });

  q('#btn-ds-toggle-shadow')?.addEventListener('click', () => {
    if (!pages[curIdx]) return;
    showOriginalCompare = false;
    pages[curIdx].removeShadow = !pages[curIdx].removeShadow;
    rebuildPageWarp(pages[curIdx]);
    renderUI();
  });

  q('#btn-ds-toggle-sharp')?.addEventListener('click', () => {
    if (!pages[curIdx]) return;
    showOriginalCompare = false;
    pages[curIdx].sharpenText = !pages[curIdx].sharpenText;
    rebuildPageWarp(pages[curIdx]);
    renderUI();
  });

  q('#btn-ds-compare')?.addEventListener('click', () => {
    if (!pages[curIdx]) return;
    showOriginalCompare = !showOriginalCompare;
    renderUI();
  });

  q('#btn-ds-cv-corners')?.addEventListener('click', () => {
    const pg = pages[curIdx];
    if (!pg) return;
    const cv = detectPaperCornersCV(pg.origImg);
    if (cv?.corners) {
      pg.corners = cv.corners;
      rebuildPageWarp(pg);
      drawCropOverlay();
      setStatus('✅ Đã bắt lại sát 4 mép giấy tự động!');
    } else {
      setStatus('⚠️ Nền ảnh hơi trùng màu tờ giấy — hãy thử "✨ Gemini AI bắt góc" hoặc kéo tay 4 chấm xanh nhé!', true);
    }
  });

  q('#btn-ds-ai-corners')?.addEventListener('click', () => {
    if (pages[curIdx] && !busy) runGeminiDetectCorners(pages[curIdx]);
  });

  q('#btn-ds-full-corners')?.addEventListener('click', () => {
    if (!pages[curIdx]) return;
    pages[curIdx].corners = [[0.005, 0.005], [0.995, 0.005], [0.995, 0.995], [0.005, 0.995]];
    rebuildPageWarp(pages[curIdx]);
    drawCropOverlay();
  });

  q('#btn-ds-apply-warp')?.addEventListener('click', () => {
    if (!pages[curIdx]) return;
    showOriginalCompare = false;
    rebuildPageWarp(pages[curIdx]);
    viewMode = 'result';
    renderUI();
    setStatus('✅ Đã áp dụng góc cắt mới & làm nét văn bản!');
  });

  q('#btn-ds-rotate')?.addEventListener('click', () => {
    const pg = pages[curIdx];
    if (!pg) return;
    showOriginalCompare = false;
    const c = document.createElement('canvas');
    c.width = pg.origImg.height;
    c.height = pg.origImg.width;
    const ctx = c.getContext('2d');
    ctx.translate(c.width / 2, c.height / 2);
    ctx.rotate(Math.PI / 2);
    ctx.drawImage(pg.origImg, -pg.origImg.width / 2, -pg.origImg.height / 2);
    const dataUrl = c.toDataURL('image/jpeg', 0.94);
    const rotated = new Image();
    rotated.onload = () => {
      pg.origImg = rotated;
      pg.origDataUrl = dataUrl;
      // Rotate normalized corners 90° clockwise: (x, y) -> (1 - y, x)
      pg.corners = orderCornersTLTRBRBL(pg.corners.map(([nx, ny]) => [1 - ny, nx]));
      rebuildPageWarp(pg);
      renderUI();
    };
    rotated.src = dataUrl;
  });

  q('#btn-ds-del-page')?.addEventListener('click', () => {
    if (curIdx < 0) return;
    pages.splice(curIdx, 1);
    curIdx = pages.length > 0 ? Math.min(curIdx, pages.length - 1) : -1;
    showOriginalCompare = false;
    renderUI();
  });

  // 1. Export Image (.jpg)
  q('#btn-ds-exp-img')?.addEventListener('click', () => {
    if (!pages.length) return;
    const base = (q('#ds-filename').value.trim() || stampName()).replace(/\.[^.]+$/, '');
    pages.forEach((pg, idx) => {
      const fname = pages.length === 1 ? `${base}.jpg` : `${base}_Trang${idx + 1}.jpg`;
      saveExportedFile(fname, 'image/jpeg', base64ToUint8(pg.warpedBase64));
    });
    setExpStatus(`✅ Đã xuất ${pages.length} ảnh sắc nét (.JPG) vào thư mục Tải xuống!`);
  });

  // 2. Export Multi-page A4 PDF (.pdf)
  q('#btn-ds-exp-pdf')?.addEventListener('click', () => {
    if (!pages.length) return;
    const base = (q('#ds-filename').value.trim() || stampName()).replace(/\.[^.]+$/, '');
    const pdfBytes = buildMultiPagePdfBytes(pages.map((p) => ({ base64: p.warpedBase64, width: p.warpedW, height: p.warpedH })));
    saveExportedFile(`${base}.pdf`, 'application/pdf', pdfBytes);
    setExpStatus(`✅ Đã xuất file PDF chuẩn A4 (${pages.length} trang — ${(pdfBytes.length / 1024).toFixed(0)} KB)!`);
  });

  // 3. AI OCR -> Export Word (.doc)
  q('#btn-ds-exp-word')?.addEventListener('click', async () => {
    if (!pages.length || busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#ds-export-status').className = 'sf-status err';
      q('#ds-export-status').innerHTML = '🔑 Cần Gemini API Key để chuyển ảnh sang chữ Word (.doc). <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-ds-cfg1">Nhập Key</button>';
      q('#btn-ds-cfg1')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-ds-exp-word').disabled = true;
    setExpStatus(`✨ Gemini AI đang OCR đọc văn bản & bố cục ${Math.min(2, pages.length)} trang để tạo file Word (.doc)...`);
    try {
      const htmlBody = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là công cụ OCR tài liệu tiếng Việt chính xác tuyệt đối. Hãy đọc TOÀN BỘ văn bản, tiêu đề, danh sách và bảng biểu trong ảnh tài liệu và xuất ra đoạn HTML sạch (chỉ gồm các thẻ <h2>, <h3>, <p>, <ul>, <li>, <table>, <tr>, <th>, <td>, <strong> — KHÔNG bọc ```html hay <html>/<body>). Giữ nguyên chính xác chữ tiếng Việt có dấu, ngày tháng, con số, mã hiệu.',
        userPrompt: 'Hãy OCR toàn bộ tài liệu này thành HTML sạch giữ nguyên bố cục đoạn văn và bảng biểu để xuất sang Microsoft Word.',
        images: pages.slice(0, 2).map((p) => p.warpedBase64),
        temperature: 0.1,
        thinkingLevel: 'LOW',
        timeoutMs: 32000
      });
      lastWordHtml = htmlBody.replace(/^```(?:html)?/i, '').replace(/```$/i, '').trim();
      lastExportKind = 'word';
      const base = (q('#ds-filename').value.trim() || stampName()).replace(/\.[^.]+$/, '');
      const includeImg = Boolean(q('#ds-word-with-img')?.checked);
      const docContent = buildWordDocHtml(base, lastWordHtml, includeImg ? pages.map((p) => p.warpedDataUrl) : []);
      saveExportedFile(`${base}.doc`, 'application/msword', docContent);

      q('#ds-ocr-card').classList.remove('hidden');
      q('#ds-ocr-title').textContent = '📘 Xem trước nội dung Word (.doc) đã xuất';
      q('#ds-ocr-body').innerHTML = lastWordHtml;
      setExpStatus(`✅ Đã chuyển OCR & xuất file Word "${base}.doc" thành công!`);
    } catch (err) {
      setExpStatus(`⚠️ ${err?.message || 'Lỗi xuất Word'}`, true);
    } finally {
      busy = false;
      q('#btn-ds-exp-word').disabled = false;
    }
  });

  // 4. AI Table OCR -> Export Excel (.xls + .csv)
  q('#btn-ds-exp-excel')?.addEventListener('click', async () => {
    if (!pages.length || busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#ds-export-status').className = 'sf-status err';
      q('#ds-export-status').innerHTML = '🔑 Cần Gemini API Key để trích bảng sang Excel (.xls). <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-ds-cfg2">Nhập Key</button>';
      q('#btn-ds-cfg2')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-ds-exp-excel').disabled = true;
    setExpStatus('✨ Gemini AI đang bóc tách bảng biểu / cột hàng sang Excel (.xls)...');
    try {
      const raw = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là công cụ OCR bảng biểu sang Excel chính xác tuyệt đối. Trích xuất toàn bộ bảng/hóa đơn/danh sách trong ảnh thành JSON chuẩn (CHỈ trả JSON): {"sheetName":"DuLieu","rows":[["Cot 1","Cot 2"],["Gia tri 1","Gia tri 2"]]}. Nếu là văn bản thường không có kẻ bảng, hãy tách hợp lý thành các cột ["Mục","Nội dung"]. Giữ nguyên tiếng Việt có dấu và con số chính xác.',
        userPrompt: 'Bóc tách toàn bộ dữ liệu bảng / danh sách trong tài liệu này thành JSON {"sheetName":"...","rows":[[...]]}.',
        images: pages.slice(0, 2).map((p) => p.warpedBase64),
        temperature: 0.1,
        responseMimeType: 'application/json',
        timeoutMs: 32000
      });
      const cleaned = raw.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
      const obj = JSON.parse(cleaned.match(/\{[\s\S]*\}/)?.[0] || cleaned);
      const rows = Array.isArray(obj?.rows) ? obj.rows : [];
      if (rows.length === 0) throw new Error('Không trích xuất được dòng dữ liệu nào.');

      lastExcelRows = rows;
      lastExportKind = 'excel';
      const base = (q('#ds-filename').value.trim() || stampName()).replace(/\.[^.]+$/, '');
      const xlsHtml = buildExcelXlsHtml(obj.sheetName || 'TaiLieu', rows);
      saveExportedFile(`${base}.xls`, 'application/vnd.ms-excel', xlsHtml);

      q('#ds-ocr-card').classList.remove('hidden');
      q('#ds-ocr-title').textContent = `📗 Xem trước bảng Excel (${rows.length} dòng) đã xuất`;
      q('#ds-ocr-body').innerHTML = `<table style="border-collapse:collapse;width:100%;font-size:11.5px;">${rows.map((r, ri) => `<tr>${r.map((c) => `<${ri === 0 ? 'th' : 'td'} style="border:1px solid #CBD5E1;padding:4px 6px;${ri === 0 ? 'background:#FEF3C7;' : ''}">${escHtml(c)}</${ri === 0 ? 'th' : 'td'}>`).join('')}</tr>`).join('')}</table>`;
      setExpStatus(`✅ Đã trích xuất ${rows.length} dòng & tải file Excel "${base}.xls" thành công!`);
    } catch (err) {
      setExpStatus(`⚠️ ${err?.message || 'Lỗi xuất Excel'}`, true);
    } finally {
      busy = false;
      q('#btn-ds-exp-excel').disabled = false;
    }
  });

  q('#btn-ds-ocr-copy')?.addEventListener('click', async () => {
    const txt = q('#ds-ocr-body')?.innerText || '';
    if (!txt) return;
    try { await navigator.clipboard.writeText(txt); } catch (_e) {}
    setExpStatus('✓ Đã sao chép toàn bộ nội dung OCR!');
  });
  q('#btn-ds-ocr-zalo')?.addEventListener('click', () => {
    const txt = q('#ds-ocr-body')?.innerText || '';
    if (txt) shareToZaloQuick(txt);
  });
  q('#btn-ds-ocr-dl')?.addEventListener('click', () => {
    const base = (q('#ds-filename').value.trim() || stampName()).replace(/\.[^.]+$/, '');
    if (lastExportKind === 'excel' && lastExcelRows.length) {
      saveExportedFile(`${base}.csv`, 'text/csv;charset=utf-8', buildCsvUtf8Bom(lastExcelRows));
      setExpStatus(`✅ Đã tải thêm bản CSV "${base}.csv"!`);
    } else if (lastWordHtml) {
      const includeImg = Boolean(q('#ds-word-with-img')?.checked);
      saveExportedFile(`${base}.doc`, 'application/msword', buildWordDocHtml(base, lastWordHtml, includeImg ? pages.map((p) => p.warpedDataUrl) : []));
      setExpStatus(`✅ Đã tải lại "${base}.doc"!`);
    }
  });

  return { stopCamera };
}
