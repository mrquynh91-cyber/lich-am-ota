/**
 * Gemini AI Integration Engine for Lịch Âm Việt Nam (PC + OPPO Find X9) — Gemini 4 Turbo v2.13.0
 * Optimizations for fast responses, zero mid-sentence cutoffs & anti-congestion resilience:
 *  1. Upgraded to Gemini 4 lineup (gemini-4-hydrogen, gemini-4-neon, gemini-4-carbon, gemini-4-argon)
 *     plus high-speed Gemini 3.8 Flash & Gemini 3.5 Flash-Lite separate server pools.
 *  2. Smart thinkingLevel: 'LOW' on Gemini 4 & 3.8 (avoids slow 15s HIGH default & HTTP 400 MINIMAL)
 *     with automatic self-healing HTTP 400 fallback & caching.
 *  3. Atomic full-response JSON calls with native 65K output ceiling + finishReason === 'STOP' verification.
 *  4. Fast 10.5s congestion cutoff in Auto mode + immediate rotation across distinct model pools on 503/429/timeout.
 *  5. Live `ListModels` discovery (`listAvailableGeminiModels`) so users can scan & pick newest models from their Key.
 */

import {
  THU_VN,
  TIMEZONE_VN,
  convertSolar2Lunar,
  convertLunar2Solar,
  getYearCanChi,
  getMonthCanChi,
  getDayCanChi,
  getFullDayDetails,
  LUNAR_MONTH_NAMES
} from './lunar.js';
import { getUpcomingEvents } from './holidays.js';
import { pad2, formatDateKey, REPEAT_LABELS, getNextReminderTimestamp } from './reminders.js';

export const DEFAULT_GEMINI_SETTINGS = {
  enabled: false,
  apiKey: '',
  proxyUrl: '',
  proxyToken: '',
  model: 'auto'
};

function normalizeProxyBase(proxyUrl) {
  let u = String(proxyUrl || '').trim().replace(/\/+$/, '');
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  return u;
}

function resolveGeminiAuth(cfgOrKey) {
  if (typeof cfgOrKey === 'string') {
    return { apiKey: cfgOrKey.trim(), proxyUrl: '', proxyToken: '' };
  }
  return {
    apiKey: String(cfgOrKey?.apiKey || '').trim(),
    proxyUrl: normalizeProxyBase(cfgOrKey?.proxyUrl || ''),
    proxyToken: String(cfgOrKey?.proxyToken || '').trim()
  };
}

function buildGeminiFetchTarget(auth, apiPath, extraQuery = '', isJson = false) {
  const headers = {};
  if (isJson) headers['Content-Type'] = 'application/json';
  if (auth.proxyUrl) {
    if (auth.proxyToken) headers['X-LichAm-Token'] = auth.proxyToken;
    const q = extraQuery ? `?${extraQuery}` : '';
    return { url: `${auth.proxyUrl}${apiPath}${q}`, headers };
  }
  const q = extraQuery ? `${extraQuery}&key=${encodeURIComponent(auth.apiKey)}` : `key=${encodeURIComponent(auth.apiKey)}`;
  return { url: `https://generativelanguage.googleapis.com${apiPath}?${q}`, headers };
}

export const GEMINI_MODELS = [
  { id: 'auto', label: '⚡ Tự động chọn model mới & nhanh nhất (Gemini 4 / 3.8)' },
  { id: 'gemini-4-hydrogen', label: '🚀 Gemini 4 Hydrogen (Thế hệ 4 — Siêu nhanh & thông minh)' },
  { id: 'gemini-4-neon', label: '✨ Gemini 4 Neon (Thế hệ 4 — Cân bằng cao cấp)' },
  { id: 'gemini-4-carbon', label: '🧠 Gemini 4 Carbon (Thế hệ 4 — Thông minh nhất)' },
  { id: 'gemini-4-argon', label: '💎 Gemini 4 Argon (Thế hệ 4 — Phân tích sâu)' },
  { id: 'gemini-3.8-flash', label: '⚡ Gemini 3.8 Flash (Ổn định & Đa phương thức)' },
  { id: 'gemini-3.5-flash-lite', label: '💨 Gemini 3.5 Flash-Lite (Cực nhẹ, phản hồi tức thì)' },
  { id: 'gemini-flash-latest', label: '🔄 Gemini Flash Latest (Luôn tự cập nhật)' }
];

const FAST_PRESET_MODELS = [
  'gemini-4-hydrogen',
  'gemini-3.8-flash',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'gemini-3.5-flash-lite',
  'gemini-4-neon',
  'gemini-flash-lite-latest',
  'gemini-flash-latest'
];

const DEPRECATED_MODELS = new Set([
  'gemini-2.0-flash',
  'gemini-1.5-flash',
  'gemini-1.5-pro',
  'gemini-3.8-flash-lite'
]);
const RETRYABLE_STATUSES = new Set([404, 408, 429, 500, 502, 503, 504]);
const FAST_MODEL_LS_KEY = 'lich_am_gemini_fast_model_v6';
const THINK_MODE_LS_KEY = 'lich_am_gemini_think_mode_v5';

function loadCachedFastModel() {
  try {
    const v = localStorage.getItem(FAST_MODEL_LS_KEY) || '';
    return v && !DEPRECATED_MODELS.has(v.toLowerCase()) ? v : '';
  } catch (_e) {
    return '';
  }
}

function saveCachedFastModel(m) {
  if (!m) return;
  cachedWorkingModel = m;
  try {
    localStorage.setItem(FAST_MODEL_LS_KEY, m);
  } catch (_e) { /* ignore */ }
}

function loadThinkModeMap() {
  try {
    const raw = localStorage.getItem(THINK_MODE_LS_KEY);
    const obj = raw ? JSON.parse(raw) : {};
    return obj && typeof obj === 'object' ? obj : {};
  } catch (_e) {
    return {};
  }
}

function saveModelThinkMode(model, mode) {
  if (!model) return;
  modelThinkMode[model] = mode; // 'LOW' | 'NONE'
  try {
    localStorage.setItem(THINK_MODE_LS_KEY, JSON.stringify(modelThinkMode));
  } catch (_e) { /* ignore */ }
}

let cachedWorkingModel = loadCachedFastModel();
let cachedLiveModels = null;
const modelThinkMode = loadThinkModeMap();
const modelCooldownUntil = new Map();

function markModelCooldown(model, status) {
  if (!model) return;
  const durMs = status === 404 ? 30 * 60 * 1000 : 180 * 1000;
  modelCooldownUntil.set(model, Date.now() + durMs);
  if (cachedWorkingModel === model) {
    cachedWorkingModel = '';
    if (status === 404) {
      try { localStorage.removeItem(FAST_MODEL_LS_KEY); } catch (_e) {}
    }
  }
}

function isModelOnCooldown(model) {
  const until = modelCooldownUntil.get(model);
  if (!until) return false;
  if (Date.now() >= until) {
    modelCooldownUntil.delete(model);
    return false;
  }
  return true;
}

async function fetchWithTimeout(url, init, timeoutMs = 11000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error('REQUEST_TIMEOUT')), timeoutMs);
  try {
    const resp = await fetch(url, { ...init, signal: controller.signal });
    clearTimeout(timer);
    return resp;
  } catch (err) {
    clearTimeout(timer);
    throw err;
  }
}

export function isGeminiConfigured(cfg) {
  if (!cfg || cfg.enabled === false) return false;
  const auth = resolveGeminiAuth(cfg);
  return Boolean(auth.proxyUrl.length > 10 || auth.apiKey.length > 10);
}

/**
 * Query Google's official ListModels endpoint (with 6s timeout) to return ranked live Gemini 4 / 3.x models.
 */
async function discoverLiveGeminiModels(cfgOrKey, forceRefresh = false) {
  if (!forceRefresh && Array.isArray(cachedLiveModels) && cachedLiveModels.length > 0) {
    return cachedLiveModels;
  }
  try {
    const auth = resolveGeminiAuth(cfgOrKey);
    const { url, headers } = buildGeminiFetchTarget(auth, '/v1beta/models', '', false);
    const resp = await fetchWithTimeout(
      url,
      { method: 'GET', headers },
      6000
    );
    if (!resp.ok) return [];
    const data = await resp.json().catch(() => ({}));
    const models = (data?.models || [])
      .filter((m) => Array.isArray(m.supportedGenerationMethods) && m.supportedGenerationMethods.includes('generateContent'))
      .map((m) => String(m.name || '').replace(/^models\//, ''))
      .filter((name) => /^gemini-/i.test(name) && !/embedding|imagen|veo|tts|audio|robotics|computer-use|deep-research|aqa/i.test(name));

    if (models.length === 0) return [];

    const rankModel = (name) => {
      const n = name.toLowerCase();
      if (DEPRECATED_MODELS.has(n)) return -100;
      let score = 0;
      const verMatch = n.match(/gemini-(\d+(?:\.\d+)?)/);
      if (verMatch) score += parseFloat(verMatch[1]) * 30;
      if (n.includes('hydrogen')) score += 28; // Fastest Gemini 4 flagship
      if (n.includes('neon')) score += 20;
      if (n.includes('argon')) score += 14;
      if (n.includes('carbon')) score += 12;
      if (n.includes('flash')) score += 22;
      if (n.includes('lite')) score += 12;
      if (!n.includes('preview') && !n.includes('exp')) score += 10;
      if (n.includes('latest')) score += 6;
      return score;
    };

    models.sort((a, b) => rankModel(b) - rankModel(a));
    cachedLiveModels = models.slice(0, 14);
    return cachedLiveModels;
  } catch (_e) {
    return [];
  }
}

/**
 * Public helper for Settings UI: scans Google AI Studio for the exact live Gemini models enabled on the user's API key.
 */
export async function listAvailableGeminiModels(cfg) {
  const auth = resolveGeminiAuth(cfg);
  if (!auth.proxyUrl && !auth.apiKey) {
    return { ok: false, models: [], message: 'Vui lòng nhập Gemini API Key hoặc link Cầu nối Proxy trước khi quét model.' };
  }
  const models = await discoverLiveGeminiModels(auth, true);
  if (!models || models.length === 0) {
    return { ok: false, models: [], message: 'Không lấy được danh sách model. Hãy kiểm tra kết nối mạng, Proxy hoặc API Key.' };
  }
  return {
    ok: true,
    models,
    message: `Tìm thấy ${models.length} model khả dụng (mới & nhanh nhất: ${models[0]}).`
  };
}

let lastGeminiMeta = { model: '', ms: 0, finishReason: '' };
export function getLastGeminiMeta() {
  return lastGeminiMeta;
}

function buildRequestPayload(model, opts, forcedThinkMode = null) {
  const {
    systemInstruction = '',
    contents = [],
    temperature = 0.5,
    responseMimeType = ''
  } = opts || {};

  // Clean, fast, truncation-free Gemini REST payload:
  // - Omits maxOutputTokens (uses full native 65,536-token ceiling -> NEVER truncates mid-sentence!)
  // - Gemini 4 (hydrogen/neon/argon/carbon) & 3.8 default to slow HIGH thinking if omitted, and reject MINIMAL (400):
  //   use thinkingLevel: 'LOW' for fast ~1-2s full replies, with automatic 400 fallback to 'NONE'.
  const payload = {
    contents,
    generationConfig: {
      temperature
    }
  };
  if (systemInstruction) {
    payload.systemInstruction = { parts: [{ text: systemInstruction }] };
  }
  if (responseMimeType) {
    payload.generationConfig.responseMimeType = responseMimeType;
  }

  const m = String(model || '').toLowerCase();
  const isGen4Or38 = /^gemini-4\b|^gemini-3\.8\b/.test(m);
  const requestedThink = opts?.thinkingLevel === 'MEDIUM' ? 'MEDIUM' : 'LOW';
  const defaultMode = isGen4Or38 ? requestedThink : 'NONE';
  const cachedMode = modelThinkMode[model];
  const mode = forcedThinkMode || (cachedMode === 'NONE' ? 'NONE' : (opts?.thinkingLevel === 'MEDIUM' && isGen4Or38 ? 'MEDIUM' : (cachedMode || defaultMode)));

  if ((mode === 'LOW' || mode === 'MEDIUM') && isGen4Or38) {
    payload.generationConfig.thinkingConfig = { thinkingLevel: mode };
  } else if (mode !== 'NONE' && /gemini-2\.5/.test(m)) {
    payload.generationConfig.thinkingConfig = { thinkingBudget: 0 };
  }
  return { payload, usedThinkMode: mode };
}

function nextThinkFallbackMode(usedMode) {
  if (usedMode === 'MEDIUM') return 'LOW';
  if (usedMode === 'MINIMAL') return 'LOW';
  if (usedMode === 'LOW') return 'NONE';
  return null;
}

function isThinkingConfigReject(status, data) {
  if (status !== 400) return false;
  const msg = String(data?.error?.message || '').toLowerCase();
  return msg.includes('thinking') || msg.includes('invalid argument') || msg.includes('unknown name');
}

function resolveInitialModel(cfg) {
  const rawModel = String(cfg?.model || 'auto').trim();
  if (!rawModel || rawModel === 'auto' || DEPRECATED_MODELS.has(rawModel.toLowerCase())) {
    if (cachedWorkingModel && !isModelOnCooldown(cachedWorkingModel)) {
      return cachedWorkingModel;
    }
    for (const m of FAST_PRESET_MODELS) {
      if (!isModelOnCooldown(m)) return m;
    }
    if (Array.isArray(cachedLiveModels)) {
      for (const m of cachedLiveModels) {
        if (!isModelOnCooldown(m)) return m;
      }
    }
    return cachedWorkingModel || FAST_PRESET_MODELS[0];
  }
  return rawModel;
}

async function callSingleGeminiModel(authOrKey, model, opts, forcedThinkMode = null) {
  const auth = resolveGeminiAuth(authOrKey);
  const { url, headers } = buildGeminiFetchTarget(auth, `/v1beta/models/${encodeURIComponent(model)}:generateContent`, '', true);
  const { payload, usedThinkMode } = buildRequestPayload(model, opts, forcedThinkMode);
  const isHeavyPinned = /gemini-4-(carbon|argon)/i.test(model);
  const timeoutMs = opts?.timeoutMs || (isHeavyPinned ? 30000 : 16500);

  let resp;
  try {
    resp = await fetchWithTimeout(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    }, timeoutMs);
  } catch (netErr) {
    const isTimeout = netErr?.name === 'AbortError' || String(netErr?.message || '').includes('TIMEOUT');
    return { ok: false, status: isTimeout ? 408 : 0, networkError: true, timeout: isTimeout, error: netErr };
  }

  const data = await resp.json().catch(() => ({}));
  if (!resp.ok && isThinkingConfigReject(resp.status, data)) {
    const nextMode = nextThinkFallbackMode(usedThinkMode);
    if (nextMode) {
      saveModelThinkMode(model, nextMode);
      return callSingleGeminiModel(auth, model, opts, nextMode);
    }
  }
  return { ok: resp.ok, status: resp.status, data };
}

/**
 * Streaming SSE call (`streamGenerateContent?alt=sse`) with header timeout, chunk watchdog,
 * self-healing MINIMAL -> LOW -> NONE thinkingConfig fallback, and finishReason verification!
 */
async function streamSingleGeminiModel(authOrKey, model, opts, onDelta, forcedThinkMode = null) {
  const auth = resolveGeminiAuth(authOrKey);
  const { url, headers } = buildGeminiFetchTarget(auth, `/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent`, 'alt=sse', true);
  const { payload, usedThinkMode } = buildRequestPayload(model, opts, forcedThinkMode);
  const headerTimeoutMs = opts?.timeoutMs || 15000;

  let resp;
  try {
    resp = await fetchWithTimeout(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    }, headerTimeoutMs);
  } catch (netErr) {
    const isTimeout = netErr?.name === 'AbortError' || String(netErr?.message || '').includes('TIMEOUT');
    return { ok: false, status: isTimeout ? 408 : 0, networkError: true, timeout: isTimeout, error: netErr, partialText: '', finishReason: '' };
  }

  if (!resp.ok) {
    const data = await resp.json().catch(() => ({}));
    if (isThinkingConfigReject(resp.status, data)) {
      const nextMode = nextThinkFallbackMode(usedThinkMode);
      if (nextMode) {
        saveModelThinkMode(model, nextMode);
        return streamSingleGeminiModel(auth, model, opts, onDelta, nextMode);
      }
    }
    return { ok: false, status: resp.status, data, partialText: '', finishReason: '' };
  }

  const processSseLine = (line, stateObj) => {
    if (!line.startsWith('data:')) return;
    const raw = line.slice(5).trim();
    if (!raw || raw === '[DONE]') return;
    try {
      const obj = JSON.parse(raw);
      const cand = obj?.candidates?.[0];
      if (cand?.finishReason) stateObj.finishReason = cand.finishReason;
      const parts = cand?.content?.parts || [];
      let chunk = '';
      for (const p of parts) {
        if (p.text && !p.thought) chunk += p.text;
      }
      if (chunk) {
        stateObj.fullText += chunk;
        if (typeof onDelta === 'function') {
          onDelta(stateObj.fullText.replace(/\[\[ADD_REMINDER:[\s\S]*$/, '').trim());
        }
      }
    } catch (_e) { /* skip incomplete JSON chunk */ }
  };

  if (!resp.body || typeof resp.body.getReader !== 'function') {
    const txt = await resp.text();
    const st = { fullText: '', finishReason: '' };
    for (const line of txt.split(/\r?\n/)) processSseLine(line, st);
    return { ok: true, status: 200, text: st.fullText.trim(), finishReason: st.finishReason };
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  const st = { fullText: '', finishReason: '' };

  try {
    while (true) {
      let chunkTimer = null;
      const readRes = await Promise.race([
        reader.read(),
        new Promise((_, reject) => {
          chunkTimer = setTimeout(() => reject(new Error('STREAM_STALL')), 15000);
        })
      ]);
      clearTimeout(chunkTimer);

      const { value, done } = readRes;
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || '';
      for (const line of lines) processSseLine(line, st);
    }
    // Flush any remaining trailing SSE line!
    buffer += decoder.decode();
    if (buffer.trim()) {
      for (const line of buffer.split(/\r?\n/)) processSseLine(line, st);
    }
  } catch (streamErr) {
    try { reader.cancel(); } catch (_e) {}
    return {
      ok: false,
      status: 0,
      networkError: true,
      timeout: String(streamErr?.message || '').includes('STALL'),
      error: streamErr,
      partialText: st.fullText.trim(),
      finishReason: st.finishReason
    };
  }

  return { ok: true, status: 200, text: st.fullText.trim(), finishReason: st.finishReason };
}

function getFastPresetFallbacks(currentModel, errMsg) {
  const candidates = [];
  const pushCand = (m) => {
    if (m && !candidates.includes(m) && m !== currentModel && !isModelOnCooldown(m)) candidates.push(m);
  };
  const suggestedMatch = String(errMsg || '').match(/models\/(gemini-[a-z0-9.\-]+)/i);
  if (suggestedMatch && suggestedMatch[1]) pushCand(suggestedMatch[1]);
  for (const fb of FAST_PRESET_MODELS) pushCand(fb);
  if (Array.isArray(cachedLiveModels)) {
    for (const lm of cachedLiveModels) pushCand(lm);
  }
  return candidates.slice(0, 6);
}

function formatGeminiError(res) {
  if (res?.timeout) {
    return new Error('Phản hồi từ máy chủ Gemini bị chậm bất thường (quá giờ chờ). Vui lòng thử lại ngay nhé!');
  }
  if (res?.networkError) {
    return new Error('Kết nối mạng tới máy chủ Google Gemini bị gián đoạn. Vui lòng kiểm tra Wi-Fi/4G và bấm thử lại.');
  }
  const msg = res?.data?.error?.message || `HTTP ${res?.status || 'ERR'}`;
  if (res?.status === 400 && /API key/i.test(msg)) {
    return new Error('API Key không hợp lệ. Vui lòng kiểm tra lại tại Google AI Studio.');
  }
  if (res?.status === 503) {
    return new Error('Máy chủ Gemini Google đang quá tải tạm thời (503). API Key của bạn ĐÃ ĐÚNG — hãy thử lại sau vài giây nhé!');
  }
  if (res?.status === 429) {
    return new Error('Đã chạm giới hạn lượt gọi miễn phí tạm thời (429). Vui lòng đợi 10–30 giây rồi thử lại.');
  }
  return new Error(`Lỗi Gemini (${res?.status || 'ERR'}): ${msg}`);
}

/**
 * Low-level non-streaming call with fast preset failover, network retry, and lazy model discovery.
 */
async function callGeminiApi(cfg, opts) {
  const auth = resolveGeminiAuth(cfg);
  if (!auth.proxyUrl && !auth.apiKey) throw new Error('NO_API_KEY');

  const t0 = Date.now();
  let model = resolveInitialModel(cfg);
  let res = await callSingleGeminiModel(auth, model, opts);

  const shouldFailover = (r) => !r.ok && (r.networkError || RETRYABLE_STATUSES.has(r.status));
  const extractResult = (r) => {
    const cand = r?.data?.candidates?.[0];
    const parts = cand?.content?.parts || [];
    const text = parts.filter((p) => !p.thought).map((p) => p.text || '').join('').trim();
    const finishReason = cand?.finishReason || '';
    return { text, finishReason };
  };

  if (shouldFailover(res)) {
    if (!res.networkError || res.timeout) markModelCooldown(model, res.status || 503);
    const fastList = getFastPresetFallbacks(model, res.data?.error?.message);

    // If it was a brief network blip, allow 1 quick retry on the same model after 350ms
    if (res.networkError && !res.timeout) {
      await new Promise((r) => setTimeout(r, 350));
      res = await callSingleGeminiModel(auth, model, opts);
    }

    if (shouldFailover(res)) {
      for (const nextModel of fastList) {
        // Immediate rotation on 503/408/404 (distinct server pools!), minimal 250ms spacing on 429
        if (res.status === 429) await new Promise((r) => setTimeout(r, 250));
        const retry = await callSingleGeminiModel(auth, nextModel, opts);
        if (retry.ok) {
          model = nextModel;
          res = retry;
          break;
        }
        if (RETRYABLE_STATUSES.has(retry.status) || retry.timeout) markModelCooldown(nextModel, retry.status || 503);
        if (!shouldFailover(retry)) {
          res = retry;
          break;
        }
        if (res.status === 404 && retry.status !== 404) res = retry;
      }
    }

    // Lazy ListModels discovery ONLY if all fast presets failed
    if (shouldFailover(res)) {
      const liveList = await discoverLiveGeminiModels(auth);
      const tried = new Set([model, ...fastList]);
      for (const nextModel of liveList) {
        if (tried.has(nextModel)) continue;
        const retry = await callSingleGeminiModel(auth, nextModel, opts);
        if (retry.ok) {
          model = nextModel;
          res = retry;
          break;
        }
        if (!shouldFailover(retry)) {
          res = retry;
          break;
        }
      }
    }

    // Final calm backoff retry on stable 2.5-flash / flash-latest when Google free-tier has transient 503/500 spike
    if (shouldFailover(res) && res.status !== 404) {
      await new Promise((r) => setTimeout(r, 1100));
      const calmPool = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-flash-latest'];
      for (const calmModel of calmPool) {
        const retry = await callSingleGeminiModel(auth, calmModel, opts);
        if (retry.ok) {
          model = calmModel;
          res = retry;
          break;
        }
      }
    }
  }

  if (!res.ok) throw formatGeminiError(res);

  let { text, finishReason } = extractResult(res);
  // If a model ever stops abnormally (empty or non-STOP), try 1 healthy fallback model so user always gets a complete reply!
  if (!text || (finishReason && finishReason !== 'STOP' && finishReason !== 'SAFETY')) {
    const fb = getFastPresetFallbacks(model, '')[0];
    if (fb) {
      const retry = await callSingleGeminiModel(auth, fb, opts);
      if (retry.ok) {
        const alt = extractResult(retry);
        if (alt.text && (alt.finishReason === 'STOP' || alt.text.length > text.length)) {
          model = fb;
          text = alt.text;
          finishReason = alt.finishReason;
        }
      }
    }
  }

  saveCachedFastModel(model);
  lastGeminiMeta = { model, ms: Date.now() - t0, finishReason: finishReason || 'STOP' };
  if (!text) throw new Error('Gemini chưa trả về nội dung đầy đủ. Vui lòng thử lại.');
  return text;
}

/**
 * Atomic full-response wrapper (replaces unstable SSE streaming that caused mid-word cutoffs
 * on mobile WebViews & proxies). Delivers 100% complete verified text on the first try!
 */
async function callGeminiApiStreaming(cfg, opts, onDelta) {
  const fullText = await callGeminiApi(cfg, opts);
  if (typeof onDelta === 'function') {
    onDelta(fullText.replace(/\[\[ADD_REMINDER:[\s\S]*$/, '').trim());
  }
  return fullText;
}

/**
 * Test API key & model connectivity (clears cooldowns, tests newest Gemini 4/3.8 model, and scans live models!).
 */
export async function testGeminiConnection(cfg) {
  const apiKey = String(cfg?.apiKey || '').trim();
  if (!apiKey) {
    return { ok: false, message: 'Vui lòng nhập Gemini API Key trước.' };
  }
  modelCooldownUntil.clear();
  const t0 = Date.now();
  try {
    const [reply, liveModels] = await Promise.all([
      callGeminiApi(cfg, {
        contents: [{ role: 'user', parts: [{ text: 'Trả lời đúng 1 dòng ngắn tiếng Việt: Kết nối Gemini AI thành công!' }] }],
        temperature: 0.1
      }),
      discoverLiveGeminiModels(apiKey, true).catch(() => [])
    ]);
    const ms = Date.now() - t0;
    const sec = (ms / 1000).toFixed(1);
    const activeModel = lastGeminiMeta.model || cachedWorkingModel || '';
    const used = activeModel ? ` (${activeModel} • ${sec}s)` : ` (${sec}s)`;
    return {
      ok: true,
      model: activeModel,
      ms,
      liveModels: Array.isArray(liveModels) ? liveModels : [],
      message: `${reply.slice(0, 90)}${used}`
    };
  } catch (err) {
    return { ok: false, message: err?.message === 'NO_API_KEY' ? 'Vui lòng nhập Gemini API Key trước.' : (err?.message || 'Lỗi kết nối Gemini.') };
  }
}

/**
 * Build lean, high-signal Vietnamese context of the user's current app state for fast TTFT.
 */
export function buildAppContextSummary(state, now = new Date()) {
  const todaySolar = { day: now.getDate(), month: now.getMonth() + 1, year: now.getFullYear() };
  const todayLunar = convertSolar2Lunar(todaySolar.day, todaySolar.month, todaySolar.year, TIMEZONE_VN);
  const todayDow = THU_VN[now.getDay()];
  const todayDetails = getFullDayDetails(todaySolar.day, todaySolar.month, todaySolar.year, TIMEZONE_VN);

  const sel = state?.selectedDate || todaySolar;
  const selLunar = convertSolar2Lunar(sel.day, sel.month, sel.year, TIMEZONE_VN);
  const selDetails = getFullDayDetails(sel.day, sel.month, sel.year, TIMEZONE_VN);

  const todayQuality = todayDetails?.hoangDaoDay?.type || '';
  const todayStar = todayDetails?.hoangDaoDay?.starName ? ` (${todayDetails.hoangDaoDay.starName})` : '';
  const todayTruc = todayDetails?.truc?.name || '';
  const selQuality = selDetails?.hoangDaoDay?.type || '';
  const selStar = selDetails?.hoangDaoDay?.starName ? ` (${selDetails.hoangDaoDay.starName})` : '';
  const selTruc = selDetails?.truc?.name || '';
  const selHours = (selDetails?.hours?.hoangDao || []).map((h) => `${h.chi} (${h.range})`).join(', ');

  const lines = [];
  lines.push(`HIỆN TẠI: ${todayDow} ${pad2(todaySolar.day)}/${pad2(todaySolar.month)}/${todaySolar.year} ${pad2(now.getHours())}:${pad2(now.getMinutes())} | ÂL: ${todayLunar.day}/${todayLunar.month}${todayLunar.leap ? 'N' : ''}/${todayLunar.year} (${getYearCanChi(todayLunar.year)}, ngày ${getDayCanChi(todayLunar.jd).name}, ${todayQuality}${todayStar}${todayTruc ? `, ${todayTruc}` : ''}).`);
  lines.push(`NGÀY ĐANG CHỌN: ${pad2(sel.day)}/${pad2(sel.month)}/${sel.year} DL (${selLunar.day}/${selLunar.month}${selLunar.leap ? 'N' : ''}/${selLunar.year} ÂL, ${getDayCanChi(selLunar.jd).name}, ${selQuality}${selStar}${selTruc ? `, ${selTruc}` : ''}${selHours ? `, Giờ tốt: ${selHours}` : ''}).`);

  const birthYear = state?.auspiciousPrefs?.birthYear;
  if (birthYear) lines.push(`TUỔI GIA CHỦ: ${birthYear} (${getYearCanChi(Number(birthYear))}).`);
  const homeowner = state?.prayerPrefs?.homeownerName;
  const addr = state?.prayerPrefs?.address;
  if (homeowner || addr) lines.push(`TÍN CHỦ: ${homeowner || '-'} | ĐC: ${addr || '-'}.`);

  const nowMs = now.getTime();
  const activeRems = (state?.timedReminders || [])
    .filter((r) => r && !r.done)
    .map((r) => ({ r, nextTs: getNextReminderTimestamp(r, nowMs) }))
    .filter((x) => x.nextTs !== null)
    .sort((a, b) => a.nextTs - b.nextTs)
    .slice(0, 40)
    .map((x) => x.r);
  if (activeRems.length > 0) {
    lines.push('NHẮC NHỞ SẮP TỚI (CÒN HẠN — ĐỌC CHÍNH XÁC TỪNG DÒNG):');
    for (const r of activeRems) {
      const [ry, rm, rd] = (r.date || '').split('-');
      const vnDate = ry && rm && rd ? `${rd}/${rm}/${ry}` : (r.date || '');
      lines.push(`- Ngày ${vnDate} lúc ${r.time || ''}: ${r.title} (${REPEAT_LABELS[r.repeat || 'none'] || 'Một lần'})${r.note ? ` | Ghi chú: ${r.note}` : ''}`);
    }
  } else {
    lines.push('NHẮC NHỞ SẮP TỚI: Trống.');
  }

  const hlRanges = (state?.highlightedRanges || []).slice(0, 20);
  if (hlRanges.length > 0) {
    lines.push('KHOẢNG NGÀY ĐÁNH DẤU / BÔI MÀU (CHUYẾN ĐI / LỊCH BAY / SỰ KIỆN):');
    for (const h of hlRanges) {
      lines.push(`- ${h.startDate} đến ${h.endDate}: ${h.title}${h.note ? ` | ${h.note}` : ''}`);
    }
  }

  const customEvs = (state?.customEvents || []).slice(0, 25);
  if (customEvs.length > 0) {
    lines.push('GIỖ / SINH NHẬT / CÁ NHÂN:');
    for (const c of customEvs) {
      const kind = c.kind === 'gio' ? 'Giỗ' : c.kind === 'sinhnhat' ? 'SN' : 'SK';
      lines.push(`- [${kind}] ${c.name}: ${c.day}/${c.month} ${c.calendar === 'lunar' ? 'ÂL' : 'DL'}${c.originYear ? ` (${c.originYear})` : ''}`);
    }
  }

  const upcomingHols = getUpcomingEvents(now, 30, state?.customEvents || [], {
    includeSolar: true,
    includeLunar: true,
    includeMung1Ram: true
  }).slice(0, 8);
  if (upcomingHols.length > 0) {
    lines.push('LỄ / M1 / RẰM 30 NGÀY TỚI:');
    for (const ev of upcomingHols) {
      lines.push(`- Còn ${ev.daysUntil}n (${pad2(ev.solar.day)}/${pad2(ev.solar.month)} DL / ${ev.lunar.day}/${ev.lunar.month} ÂL): ${ev.name}`);
    }
  }

  // Live Weather & 7-Day Daily Forecast (from Open-Meteo already loaded in app!)
  const wx = state?.weatherData;
  if (wx && (wx.current || wx.dailyByDate)) {
    const loc = wx.locationName || 'Vị trí hiện tại';
    const cur = wx.current;
    if (cur) {
      const aqiTxt = cur.aqi !== null && cur.aqi !== undefined ? `, AQI ${cur.aqi} (${cur.aqiInfo?.label || ''})` : '';
      const uvTxt = cur.uv !== null && cur.uv !== undefined ? `, UV ${cur.uv}` : '';
      lines.push(`THỜI TIẾT HIỆN TẠI (${loc}): ${cur.temp}°C (cảm giác ${cur.feelsLike}°C), ${cur.label}, độ ẩm ${cur.humidity}%, gió ${cur.wind} km/h${aqiTxt}${uvTxt}.`);
    }
    const daily = wx.dailyByDate || {};
    const dailyLines = [];
    for (let offset = 0; offset <= 7; offset++) {
      const dt = new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset);
      const key = formatDateKey(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
      const d = daily[key];
      if (!d) continue;
      const tag = offset === 0 ? 'Hôm nay' : offset === 1 ? 'Ngày mai' : offset === 2 ? 'Ngày kia' : THU_VN[dt.getDay()];
      dailyLines.push(`- ${tag} (${pad2(dt.getDate())}/${pad2(dt.getMonth() + 1)}/${dt.getFullYear()}): ${d.label}, ${d.tMin}–${d.tMax}°C, khả năng mưa ${d.rainProb}%${d.uvMax !== null && d.uvMax !== undefined ? `, UV tối đa ${d.uvMax}` : ''}`);
    }
    if (dailyLines.length > 0) {
      lines.push(`DỰ BÁO THỜI TIẾT 7 NGÀY TỚI (${loc}):`);
      lines.push(...dailyLines);
    }
  }

  return lines.join('\n');
}

/**
 * Interactive Lunar Calendar & Personal Schedule Assistant Chat (with live SSE streaming!).
 */
export async function chatWithLunarAssistant(cfg, historyMessages, userMessage, state, now = new Date(), onDelta = null) {
  const ctx = buildAppContextSummary(state, now);
  const systemInstruction = `Bạn là Trợ lý AI chính xác và nhanh gọn trong app "Lịch Âm Việt Nam".
Dữ liệu thực tế từ app của người dùng:
${ctx}

QUY TẮC BẮT BUỘC:
1. CHỈ trả lời ĐÚNG trọng tâm câu hỏi mới nhất của người dùng (VD: nếu hỏi lịch bay thì CHỈ trả lời lịch bay, KHÔNG liệt kê thêm ngày giỗ hay lễ Tết không liên quan).
2. Trích dẫn CHÍNH XÁC từng ngày, giờ, tiêu đề và ghi chú có trong dữ liệu ở trên. TUYỆT ĐỐI KHÔNG tự bịa, không gộp nhầm số hiệu chuyến bay hay thay đổi giờ. Nếu không có dữ liệu khớp, hãy nói rõ là chưa thấy trong danh sách.
3. Trình bày gọn gàng, sạch sẽ bằng tiếng Việt.
4. Nếu người dùng nhờ ĐẶT/TẠO nhắc nhở mới, xác nhận 1 câu ngắn và thêm ở dòng cuối đúng cú pháp (JSON 1 dòng):
[[ADD_REMINDER:{"title":"Nội dung ngắn","date":"YYYY-MM-DD","time":"HH:MM","repeat":"none","note":""}]]`;

  const contents = [];
  const recent = (historyMessages || []).slice(-6);
  for (const m of recent) {
    contents.push({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(m.text || '') }]
    });
  }
  contents.push({
    role: 'user',
    parts: [{ text: String(userMessage || '').trim() }]
  });

  const opts = {
    systemInstruction,
    contents,
    temperature: 0.45,
    maxOutputTokens: 4096,
    thinkingLevel: 'MINIMAL'
  };

  const rawReply = typeof onDelta === 'function'
    ? await callGeminiApiStreaming(cfg, opts, onDelta)
    : await callGeminiApi(cfg, opts);

  const suggestedReminders = [];
  const cleanText = rawReply.replace(/\[\[ADD_REMINDER:(\{[\s\S]*?\})\]\]/g, (_full, jsonStr) => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed && parsed.title && /^\d{4}-\d{2}-\d{2}$/.test(parsed.date || '')) {
        suggestedReminders.push({
          title: String(parsed.title).trim().slice(0, 150),
          date: parsed.date,
          time: /^\d{2}:\d{2}$/.test(parsed.time || '') ? parsed.time : '08:00',
          repeat: ['none', 'daily', 'weekly', 'monthly', 'yearly', 'lunar-monthly', 'lunar-yearly'].includes(parsed.repeat)
            ? parsed.repeat
            : 'none',
          note: String(parsed.note || '').trim().slice(0, 150)
        });
      }
    } catch (_e) { /* ignore */ }
    return '';
  }).trim();

  return { text: cleanText || rawReply, suggestedReminders };
}

/**
 * Extract 1 or MANY structured reminders from complex natural Vietnamese speech, Zalo messages, or Lunar dates.
 */
export async function parseRemindersWithGemini(cfg, inputText, now = new Date()) {
  const todayKey = formatDateKey(now.getFullYear(), now.getMonth() + 1, now.getDate());
  const todayDow = THU_VN[now.getDay()];
  const lunar = convertSolar2Lunar(now.getDate(), now.getMonth() + 1, now.getFullYear(), TIMEZONE_VN);

  const systemInstruction = `Phân tích lịch hẹn tiếng Việt thành JSON.
Hôm nay: ${todayDow} ${pad2(now.getDate())}/${pad2(now.getMonth() + 1)}/${now.getFullYear()} (${todayKey}), ÂL ${lunar.day}/${lunar.month}/${lunar.year}, giờ ${pad2(now.getHours())}:${pad2(now.getMinutes())}.
Trả về JSON: {"reminders":[{"title":"...","date":"YYYY-MM-DD","time":"HH:MM","repeat":"none","note":"","prevEve":false,"prevEveTime":"20:00","lunarDate":null}]}
Quy tắc: chiều/tối đổi sang 24h (3h chiều->15:00); nếu có ngày Âm lịch điền lunarDate:{"day":D,"month":M,"year":Y}; repeat trong ["none","daily","weekly","monthly","yearly","lunar-monthly","lunar-yearly"]; không có giờ thì mặc định "08:00". CHỈ trả JSON.`;

  const raw = await callGeminiApi(cfg, {
    systemInstruction,
    contents: [{ role: 'user', parts: [{ text: String(inputText || '').trim() }] }],
    temperature: 0.1,
    maxOutputTokens: 4096,
    responseMimeType: 'application/json',
    thinkingLevel: 'MINIMAL'
  });

  const cleaned = raw.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (_e) {
    const mObj = cleaned.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
    if (!mObj) throw new Error('AI trả về định dạng chưa chuẩn, vui lòng bấm thử lại.');
    parsed = JSON.parse(mObj[0]);
  }
  const arr = Array.isArray(parsed) ? parsed : (Array.isArray(parsed?.reminders) ? parsed.reminders : []);

  const validRepeats = new Set(['none', 'daily', 'weekly', 'monthly', 'yearly', 'lunar-monthly', 'lunar-yearly']);
  const results = [];

  for (const item of arr) {
    if (!item || !item.title) continue;
    let dateStr = /^\d{4}-\d{2}-\d{2}$/.test(item.date || '') ? item.date : todayKey;

    if (item.lunarDate && Number(item.lunarDate.day) >= 1 && Number(item.lunarDate.month) >= 1) {
      const ld = Number(item.lunarDate.day);
      const lm = Number(item.lunarDate.month);
      let ly = Number(item.lunarDate.year) || lunar.year;
      let conv = convertLunar2Solar(ld, lm, ly, false, TIMEZONE_VN);
      if (conv) {
        const dt = new Date(conv.year, conv.month - 1, conv.day, 23, 59, 0);
        if (dt.getTime() < now.getTime() - 3600000 && !item.lunarDate.year) {
          const nextConv = convertLunar2Solar(ld, lm, ly + 1, false, TIMEZONE_VN);
          if (nextConv) conv = nextConv;
        }
        dateStr = formatDateKey(conv.year, conv.month, conv.day);
      }
    }

    results.push({
      title: String(item.title).trim().slice(0, 150),
      date: dateStr,
      time: /^\d{2}:\d{2}$/.test(item.time || '') ? item.time : '08:00',
      repeat: validRepeats.has(item.repeat) ? item.repeat : 'none',
      note: String(item.note || '').trim().slice(0, 150),
      prevEve: Boolean(item.prevEve),
      prevEveTime: /^\d{2}:\d{2}$/.test(item.prevEveTime || '') ? item.prevEveTime : '20:00'
    });
  }

  return results;
}

/**
 * Compose an authentic Vietnamese Văn khấn with LIVE SSE STREAMING so text appears in <1 second!
 * Format streamed:
 *   TIÊU ĐỀ: ...
 *   LỄ VẬT: ...
 *   ---
 *   <Toàn văn bài văn khấn>
 */
export async function generateCustomPrayerWithGemini(cfg, promptText, solar, lunar, prefs = {}, onDelta = null) {
  const dayLabel = lunar.day <= 10 ? `Mùng ${lunar.day}` : lunar.day === 15 ? 'Rằm (15)' : `${lunar.day}`;
  const monthLabel = `tháng ${LUNAR_MONTH_NAMES[lunar.month] || lunar.month}${lunar.leap ? ' (Nhuận)' : ''}`;
  const yearCanChi = getYearCanChi(lunar.year);
  const monthCanChi = getMonthCanChi(lunar.month, lunar.year);
  const dayCanChi = getDayCanChi(lunar.jd).name;
  const solarFull = `${pad2(solar.day)}/${pad2(solar.month)}/${solar.year}`;
  const homeowner = String(prefs.homeownerName || '').trim() || '[Họ tên tín chủ / Gia chủ]';
  const address = String(prefs.address || '').trim() || '[Địa chỉ nhà / Nơi thờ cúng]';
  const defaultOccasion = `Ngày ${dayLabel} ${monthLabel} năm ${yearCanChi} (${solarFull} DL)`;

  const systemInstruction = `Soạn 1 bài Văn khấn cổ truyền Việt Nam trang trọng, chuẩn mực, súc tích.
Điền sẵn: Ngày ${dayLabel} ${monthLabel} năm ${yearCanChi} (Tháng ${monthCanChi}, Ngày ${dayCanChi}, DL ${solarFull}), Tín chủ: ${homeowner}, Địa chỉ: ${address}.
BẮT BUỘC trả lời đúng định dạng thuần sau (không bọc markdown):
TIÊU ĐỀ: [Tên ngắn gọn bài văn khấn]
LỄ VẬT: [Gợi ý lễ vật 1 dòng ngắn gọn]
---
[Toàn văn bài văn khấn, mở đầu và kết thúc bằng Nam mô A Di Đà Phật! (3 lần)]`;

  const parseStreamedPrayer = (rawText) => {
    const t = String(rawText || '').trim();
    const titleM = t.match(/^TIÊU ĐỀ:\s*(.+)$/im);
    const offM = t.match(/^LỄ VẬT:\s*(.+)$/im);
    const sepIdx = t.indexOf('---');
    const content = sepIdx >= 0
      ? t.slice(sepIdx + 3).trim()
      : t.replace(/^TIÊU ĐỀ:.*$/im, '').replace(/^LỄ VẬT:.*$/im, '').trim();
    return {
      title: (titleM?.[1] || `Văn khấn ${promptText}`).trim(),
      occasion: defaultOccasion,
      offerings: (offM?.[1] || 'Hương hoa tươi, trầu cau, ngũ quả, nước sạch, trà và lễ vật tùy tâm gia chủ.').trim(),
      content
    };
  };

  const opts = {
    systemInstruction,
    contents: [{ role: 'user', parts: [{ text: `Soạn bài văn khấn: ${String(promptText || '').trim()}` }] }],
    temperature: 0.45,
    maxOutputTokens: 4096,
    thinkingLevel: 'MINIMAL'
  };

  const raw = typeof onDelta === 'function'
    ? await callGeminiApiStreaming(cfg, opts, (partial) => onDelta(parseStreamedPrayer(partial)))
    : await callGeminiApi(cfg, opts);

  const parsed = parseStreamedPrayer(raw);
  if (!parsed.content) {
    throw new Error('Không thể tạo nội dung bài văn khấn. Vui lòng thử lại.');
  }
  return parsed;
}


/* ==================== GEMINI AI NATIVE TTS (ĐỌC VĂN KHẤN BẰNG GIỌNG AI) ==================== */

export const GEMINI_TTS_VOICES = [
  { id: 'Kore', label: '👩 Nữ trang nghiêm (Kore)' },
  { id: 'Charon', label: '👨 Nam trầm ấm (Charon)' },
  { id: 'Aoede', label: '👩 Nữ nhẹ nhàng (Aoede)' },
  { id: 'Orus', label: '👨 Nam đĩnh đạc (Orus)' }
];

let cachedTtsModel = '';

async function discoverLiveTtsModels(cfgOrKey) {
  try {
    const auth = resolveGeminiAuth(cfgOrKey);
    const { url, headers } = buildGeminiFetchTarget(auth, '/v1beta/models', '', false);
    const resp = await fetch(url, { headers });
    if (!resp.ok) return [];
    const data = await resp.json().catch(() => ({}));
    return (data?.models || [])
      .filter((m) => Array.isArray(m.supportedGenerationMethods) && m.supportedGenerationMethods.includes('generateContent'))
      .map((m) => String(m.name || '').replace(/^models\//, ''))
      .filter((name) => /tts/i.test(name));
  } catch (_e) {
    return [];
  }
}

/**
 * Convert raw 16-bit linear PCM (little-endian, mono, 24kHz) base64 returned by Gemini TTS
 * into a standard playable WAV Blob (works natively in Chrome, Edge WebView2, and Android WebView!).
 */
function pcm16Base64ToWavBlob(base64Pcm, sampleRate = 24000, numChannels = 1) {
  const binStr = atob(base64Pcm);
  const dataLen = binStr.length;
  const buf = new ArrayBuffer(44 + dataLen);
  const view = new DataView(buf);
  const writeStr = (off, s) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataLen, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM header size
  view.setUint16(20, 1, true); // AudioFormat = 1 (PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * numChannels * 2, true); // ByteRate
  view.setUint16(32, numChannels * 2, true); // BlockAlign
  view.setUint16(34, 16, true); // BitsPerSample
  writeStr(36, 'data');
  view.setUint32(40, dataLen, true);

  const bytes = new Uint8Array(buf, 44);
  for (let i = 0; i < dataLen; i++) {
    bytes[i] = binStr.charCodeAt(i);
  }
  return new Blob([buf], { type: 'audio/wav' });
}

function base64ToBlob(base64, mimeType) {
  const binStr = atob(base64);
  const bytes = new Uint8Array(binStr.length);
  for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
  return new Blob([bytes], { type: mimeType || 'audio/wav' });
}

/**
 * Expand Vietnamese ritual repetition cues for reverent TTS chanting:
 * e.g. "Nam mô A Di Đà Phật! (3 lần)" -> repeats the chant 3 separate times instead of reading "ba lần",
 * and removes silent gesture notes like "(3 lạy)" / "(vái 3 vái)".
 */
export function expandPrayerForSpeech(rawText) {
  const normalized = String(rawText || '')
    .replace(/\[([^\]]+)\]/g, '$1')
    .replace(/\r\n/g, '\n')
    .trim();
  if (!normalized) return '';

  const expandedLines = [];
  for (const rawLine of normalized.split('\n')) {
    const line = rawLine.trim();
    if (!line) {
      expandedLines.push('');
      continue;
    }
    const repMatch = line.match(/^(.*?)\s*\((?:đọc\s*)?(\d+)\s*lần[^)]*\)\s*[.!]?$/i);
    if (repMatch && repMatch[1].trim()) {
      const phrase = repMatch[1].trim();
      const count = Math.max(1, Math.min(5, Number(repMatch[2]) || 3));
      for (let i = 0; i < count; i++) {
        expandedLines.push(phrase);
      }
      continue;
    }
    const cleaned = line
      .replace(/\s*\(\s*(?:(?:vái|lạy|cúi\s*lạy|khấn)\s*\d*|\d+\s*(?:lạy|vái))[^)]*\)/gi, '')
      .trim();
    if (cleaned) expandedLines.push(cleaned);
  }
  return expandedLines.join('\n').trim();
}

/**
 * Split a long Vietnamese prayer into clean, natural paragraph chunks (~480 chars each)
 * so Gemini TTS begins playback quickly and can prefetch the next chunk seamlessly!
 */
export function splitPrayerIntoSpeechChunks(rawText, maxChars = 480) {
  const clean = expandPrayerForSpeech(rawText);
  if (!clean) return [];

  const paragraphs = clean.split(/\n{2,}/).map((p) => p.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
  const chunks = [];
  let cur = '';
  for (const para of paragraphs) {
    if (!cur) {
      cur = para;
    } else if ((cur.length + 2 + para.length) <= maxChars) {
      cur = `${cur}\n${para}`;
    } else {
      chunks.push(cur);
      cur = para;
    }
  }
  if (cur) chunks.push(cur);
  return chunks;
}

async function callSingleGeminiTts(authOrKey, model, textChunk, voiceName) {
  const auth = resolveGeminiAuth(authOrKey);
  const { url, headers } = buildGeminiFetchTarget(auth, `/v1beta/models/${encodeURIComponent(model)}:generateContent`, '', true);
  const prompt = `Đọc diễn cảm, trang nghiêm, trầm ấm, chậm rãi và rõ ràng đoạn văn khấn cổ truyền Việt Nam sau đây (chỉ đọc đúng lời khấn, không thêm lời bình):\n\n${textChunk}`;
  const payload = {
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: {
            voiceName: voiceName || 'Kore'
          }
        }
      }
    }
  };

  const resp = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload)
  });
  const data = await resp.json().catch(() => ({}));
  return { ok: resp.ok, status: resp.status, data };
}

/**
 * Synthesize a Vietnamese prayer chunk using Gemini AI Native TTS.
 * Returns { blob, url, model } ready for <audio> playback!
 */
export async function synthesizePrayerChunkWithGemini(cfg, textChunk, voiceName = 'Kore') {
  const auth = resolveGeminiAuth(cfg);
  if (!auth.proxyUrl && !auth.apiKey) throw new Error('NO_API_KEY');

  const candidates = [];
  const pushM = (m) => { if (m && !candidates.includes(m)) candidates.push(m); };
  if (cachedTtsModel) pushM(cachedTtsModel);
  pushM('gemini-2.5-flash-preview-tts');
  pushM('gemini-2.5-pro-preview-tts');

  let res = null;
  let usedModel = candidates[0];

  for (const m of candidates) {
    usedModel = m;
    res = await callSingleGeminiTts(auth, m, textChunk, voiceName);
    if (res.ok) break;
    if (!RETRYABLE_STATUSES.has(res.status)) break;
  }

  // If preset TTS models returned 404/503, dynamically discover any live *-tts models on this API key!
  if (!res?.ok && RETRYABLE_STATUSES.has(res?.status)) {
    const liveTts = await discoverLiveTtsModels(auth);
    for (const m of liveTts) {
      if (candidates.includes(m)) continue;
      usedModel = m;
      res = await callSingleGeminiTts(auth, m, textChunk, voiceName);
      if (res.ok) break;
    }
  }

  if (!res?.ok) {
    throw formatGeminiError(res);
  }

  const parts = res.data?.candidates?.[0]?.content?.parts || [];
  const audioPart = parts.find((p) => p?.inlineData?.data);
  if (!audioPart) {
    throw new Error('Gemini TTS không trả về dữ liệu âm thanh.');
  }

  cachedTtsModel = usedModel;
  const mime = String(audioPart.inlineData.mimeType || 'audio/L16;codec=pcm;rate=24000');
  const b64 = audioPart.inlineData.data;

  let blob;
  if (/pcm|L16/i.test(mime)) {
    const rateMatch = mime.match(/rate=(\d+)/i);
    const rate = rateMatch ? Number(rateMatch[1]) : 24000;
    blob = pcm16Base64ToWavBlob(b64, rate, 1);
  } else {
    blob = base64ToBlob(b64, mime);
  }

  return {
    blob,
    url: URL.createObjectURL(blob),
    model: usedModel
  };
}


/* ==================== FAST NATIVE VIETNAMESE TTS (<1s!) & DREAM DECODER (v2.8.0) ==================== */

/**
 * Split Vietnamese prayer into crisp sentence chunks (<=170 chars) for instant Google Vietnamese TTS!
 * Expands "(3 lần)" into 3 actual reverent chants instead of reading the words "ba lần".
 */
export function splitPrayerIntoFastVnSentences(rawText, maxChars = 170) {
  const clean = expandPrayerForSpeech(rawText);
  if (!clean) return [];

  const out = [];
  const lines = clean.split(/\n+/).map((l) => l.trim()).filter(Boolean);
  for (const line of lines) {
    if (line.length <= maxChars) {
      out.push(line);
      continue;
    }
    const parts = line.split(/(?<=[.!?…;,:])\s+/);
    let cur = '';
    for (const p of parts) {
      if (!cur) {
        cur = p;
      } else if (cur.length + 1 + p.length <= maxChars) {
        cur = `${cur} ${p}`;
      } else {
        out.push(cur);
        cur = p;
      }
    }
    if (cur) out.push(cur);
  }
  return out;
}

/**
 * Instant (<0.5s), 100% authentic Northern Vietnamese (vi-VN) TTS via Google Translate TTS endpoint!
 * Zero API key needed, zero English-accent mispronunciation, returns playable audio/mpeg Blob URL.
 */
export async function synthesizeFastVnVoiceChunk(sentenceText) {
  const q = String(sentenceText || '').trim();
  if (!q) throw new Error('Empty sentence');
  const url = `https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=vi&client=gtx&q=${encodeURIComponent(q)}`;
  const resp = await fetch(url);
  if (!resp.ok) {
    throw new Error(`VN TTS HTTP ${resp.status}`);
  }
  const blob = await resp.blob();
  if (!blob || blob.size < 200) {
    throw new Error('VN TTS empty audio');
  }
  return URL.createObjectURL(blob);
}

/**
 * Decode a user's dream with Gemini AI (live SSE streaming!) — combines Vietnamese folklore (Sổ Mơ),
 * modern psychology, positive advice, and traditional lucky numbers, personalized with Lunar date & birth year!
 */
export async function decodeDreamWithGemini(cfg, dreamText, state, now = new Date(), onDelta = null) {
  const todaySolar = { day: now.getDate(), month: now.getMonth() + 1, year: now.getFullYear() };
  const todayLunar = convertSolar2Lunar(todaySolar.day, todaySolar.month, todaySolar.year, TIMEZONE_VN);
  const birthYear = state?.auspiciousPrefs?.birthYear;
  const ageInfo = birthYear ? `Năm sinh người mơ: ${birthYear} (Tuổi ${getYearCanChi(Number(birthYear))}).` : '';

  const systemInstruction = `Bạn là chuyên gia Giải Mã Giấc Mơ (Giải Mộng) am hiểu sâu sắc văn hóa dân gian Việt Nam (Sổ Mơ cổ truyền) kết hợp tâm lý học hiện đại.
Thông tin ngữ cảnh hôm nay: Ngày ${pad2(todaySolar.day)}/${pad2(todaySolar.month)}/${todaySolar.year} DL (${todayLunar.day}/${todayLunar.month}/${todayLunar.year} ÂL — năm ${getYearCanChi(todayLunar.year)}, ngày ${getDayCanChi(todayLunar.jd).name}). ${ageInfo}

Hãy giải mã giấc mơ của người dùng bằng tiếng Việt ấm áp, tích cực, rõ ràng, không gây hoang mang mê tín, trình bày đúng 5 mục ngắn gọn:
**1. 🌟 Đánh giá chung:** (Điềm lành / Lời nhắc nhở / Giải tỏa tâm lý)
**2. 🏮 Theo văn hóa dân gian & Sổ Mơ Việt Nam:** (ý nghĩa biểu tượng truyền thống)
**3. 🧠 Góc nhìn tâm lý học:** (giải thích nguyên nhân tâm lý gần gũi)
**4. 💡 Lời khuyên tích cực:** (1–2 gợi ý thực tế nhẹ nhàng)
**5. 🍀 Con số may mắn tham khảo (dân gian):** (2–3 cặp số tham khảo vui vẻ)`;

  const opts = {
    systemInstruction,
    contents: [{ role: 'user', parts: [{ text: `Giải mã giúp tôi giấc mơ này: ${String(dreamText || '').trim()}` }] }],
    temperature: 0.55,
    maxOutputTokens: 4096,
    thinkingLevel: 'MINIMAL'
  };

  return typeof onDelta === 'function'
    ? callGeminiApiStreaming(cfg, opts, onDelta)
    : callGeminiApi(cfg, opts);
}


/**
 * Multimodal Gemini Vision AI: Scan a user's portrait photo to detect facial moles/beauty marks,
 * return exact image-percentage coordinates (x: 0..100, y: 0..100) for plotting directly on the user's photo,
 * and provide a culturally authentic Vietnamese Nhân Tướng Học reading.
 */
export async function analyzeFaceMolesWithGemini(cfg, base64Jpeg, gender = 'male', extraNote = '', state = {}, onDelta = null, manualPins = []) {
  const genderLabel = gender === 'female' ? 'Nữ giới' : 'Nam giới';
  const birthYear = state?.auspiciousPrefs?.birthYear;
  const ageStr = birthYear ? `Năm sinh tham khảo: ${birthYear} (Tuổi ${getYearCanChi(Number(birthYear))}).` : '';

  const validManualPins = Array.isArray(manualPins)
    ? manualPins.filter((p) => Number.isFinite(p?.x) && Number.isFinite(p?.y))
    : [];
  const manualHint = validManualPins.length > 0
    ? `\nĐẶC BIỆT — NGƯỜI DÙNG ĐÃ TỰ CHẤM ${validManualPins.length} VỊ TRÍ TRÊN ẢNH (tọa độ % từ mép trái x và mép trên y):\n` +
      validManualPins.map((p, idx) => `- Chấm #${idx + 1}: x=${p.x.toFixed(1)}%, y=${p.y.toFixed(1)}%${p.label ? ` (${p.label})` : ''}`).join('\n') +
      `\nHãy ƯU TIÊN quan sát đúng từng vị trí chấm ở trên, gọi đúng tên vùng khuôn mặt tại tọa độ đó, luận giải chi tiết từng chấm và giữ nguyên tọa độ (x, y) chính xác của các chấm đó trong [[MOLES_JSON:...]] (có thể bổ sung thêm nốt ruồi rõ khác nếu thấy).`
    : '';

  const systemInstruction = `Bạn là chuyên gia Nhân Tướng Học cổ truyền Việt Nam & Á Đông kết hợp thị giác máy tính độ chính xác cao.
Người dùng cung cấp 1 bức ảnh chân dung độ phân giải cao (${genderLabel}). ${ageStr}${manualHint}

QUY TRÌNH QUÉT CHI TIẾT 8 VÙNG (KHÔNG BỎ SÓT NỐT RUỒI NHỎ 1–2mm!):
Hãy phóng to trong đầu và rà soát LẦN LƯỢT từng vùng từ trên xuống dưới, từ trái sang phải ảnh để phát hiện TẤT CẢ các nốt ruồi thật (bao gồm cả nốt ruồi đen/nâu nhỏ li ti, nốt ruồi mờ, nốt ruồi son):
1. Trán & 2 bên Thái dương (trái ảnh / phải ảnh)
2. Chân mày bên trái ảnh, Ấn đường (giữa 2 mày), chân mày bên phải ảnh
3. Quanh 2 mắt: mí trên, đuôi mắt, bọng mắt & **vùng dưới mắt bên trái ảnh + dưới mắt bên phải ảnh**
4. Sống mũi, đầu mũi & 2 bên cánh mũi
5. Gò má, má giữa & vùng má sát tai (bên trái ảnh và bên phải ảnh)
6. Nhân trung, viền môi & khóe miệng (loại trừ ria mép/chân râu)
7. Cằm & đường xương hàm 2 bên
8. Vành tai / dái tai & vùng cổ

LƯU Ý CHỐNG NHẦM: Không chấm vào con ngươi mắt, lỗ mũi, sợi tóc, chấm chân râu hay bóng tối. Chỉ chấm đúng tâm nốt ruồi thật (đốm tròn nhỏ đậm hơn da xung quanh).

TRÌNH BÀY BẰNG TIẾNG VIỆT ẤM ÁP, ĐẦY ĐỦ 4 MỤC:
**1. 📍 Danh sách các nốt ruồi quan sát thấy trên khuôn mặt:** (Đánh số #1, #2, #3... KHỚP 100% với mảng tọa độ bên dưới. Ghi rõ vị trí thực tế trên ảnh, VD: "Trong chân mày (bên trái ảnh)", "Dưới đuôi mắt (bên phải ảnh)", "Gò má gần tai (bên trái ảnh)"... và màu đen/nâu hay son).
**2. ✨ Luận giải Nhân tướng học từng nốt ruồi (cho ${genderLabel}):** (Luận giải ngắn gọn, rõ ràng theo đúng từng số #1, #2, #3... về tính cách, tài vận, sự nghiệp, tình duyên).
**3. 🌟 Nhận xét tổng quan ngũ quan & khí sắc:** (1–2 câu khen ngợi nét hài hòa trên gương mặt).
**4. 💡 Lời khuyên tích cực:** (Ngắn gọn, nhẹ nhàng — nhắc kết quả mang tính văn hóa giải trí tham khảo).

BẮT BUỘC — TỌA ĐỘ CHÍNH XÁC HỆ 0–1000 Ở DÒNG CUỐI CÙNG:
Sau mục 4, xuất đúng 1 dòng thẻ JSON dùng hệ tọa độ chuẩn Gemini Vision "point":[y, x] (số nguyên 0..1000, y là chiều dọc từ mép TRÊN=0 đến mép DƯỚI=1000, x là chiều ngang từ mép TRÁI=0 đến mép PHẢI=1000):
[[MOLES_JSON:[{"num":1,"label":"Tên vị trí ngắn","point":[482,315],"color":"black","omen":"good","spotId":"le-duong","summary":"Ý nghĩa ngắn gọn 1 câu"}]]]
Quy tắc trong MOLES_JSON:
- "point": [y, x] (số nguyên từ 0 đến 1000) phải đặt CHÍNH XÁC ĐÚNG TÂM từng nốt ruồi nhìn thấy trên ảnh (kể cả nốt nhỏ 1–2mm)!
- Liệt kê ĐẦY ĐỦ tất cả nốt ruồi thật nhìn thấy (tối đa 20 nốt, KHÔNG cắt bớt chỉ còn 2–3 nốt nếu trên mặt có nhiều hơn!).
- "color": "red" (nốt ruồi son) hoặc "black" (đen/nâu).
- "omen": "good" hoặc "neutral".
- "spotId": 1 mã gần nhất trong ["giua-tran","an-duong","chan-may-trai","chan-may-phai","thai-duong","duoi-mat","le-duong","song-mui","dau-mui","canh-mui","go-ma-trai","go-ma-phai","nhan-trung","moi-tren","khoe-mieng","cam","tai","co"] hoặc "".`;

  const userPrompt = extraNote
    ? `Hãy quét kỹ toàn bộ 8 vùng khuôn mặt trong ảnh (không bỏ sót cả nốt ruồi nhỏ), chấm chính xác tọa độ point:[y,x] (0..1000) và luận giải đầy đủ giúp tôi (${genderLabel}). Ghi chú thêm: ${extraNote}`
    : `Hãy quét kỹ toàn bộ 8 vùng khuôn mặt trong ảnh (không bỏ sót cả nốt ruồi nhỏ 1-2mm), chấm chính xác tọa độ point:[y,x] (0..1000) và luận giải đầy đủ giúp tôi (${genderLabel}).`;

  const opts = {
    systemInstruction,
    contents: [
      {
        role: 'user',
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Jpeg } },
          { text: userPrompt }
        ]
      }
    ],
    temperature: 0.25,
    thinkingLevel: 'MEDIUM',
    timeoutMs: 32000
  };

  const stripTag = (s) => String(s || '').replace(/\[\[MOLES_JSON:[\s\S]*$/i, '').trim();

  const rawReply = typeof onDelta === 'function'
    ? await callGeminiApiStreaming(cfg, opts, (partial) => onDelta(stripTag(partial)))
    : await callGeminiApi(cfg, opts);

  let detectedMoles = [];
  const tagMatch = String(rawReply || '').match(/\[\[MOLES_JSON:(\[[\s\S]*?\])\]\]/i);
  if (tagMatch && tagMatch[1]) {
    try {
      const parsed = JSON.parse(tagMatch[1]);
      if (Array.isArray(parsed)) {
        detectedMoles = parsed
          .map((item, idx) => {
            let x;
            let y;
            if (Array.isArray(item?.point) && item.point.length >= 2) {
              // Native Gemini Vision [y, x] in 0..1000 (or 0..100)
              const py = Number(item.point[0]);
              const px = Number(item.point[1]);
              if (Number.isFinite(px) && Number.isFinite(py)) {
                y = py > 100 ? py / 10 : py;
                x = px > 100 ? px / 10 : px;
              }
            } else {
              x = Number(item?.x);
              y = Number(item?.y);
              if (x > 100 && x <= 1000) x = x / 10;
              if (y > 100 && y <= 1000) y = y / 10;
            }
            if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
            x = Math.max(2, Math.min(98, x));
            y = Math.max(2, Math.min(98, y));
            return {
              num: Number(item?.num) || (idx + 1),
              label: String(item?.label || `Vị trí #${idx + 1}`).trim().slice(0, 80),
              x,
              y,
              color: item?.color === 'red' ? 'red' : 'black',
              omen: item?.omen === 'neutral' ? 'neutral' : 'good',
              spotId: String(item?.spotId || '').trim(),
              summary: String(item?.summary || '').trim().slice(0, 220),
              source: 'ai'
            };
          })
          .filter(Boolean)
          .slice(0, 20);
      }
    } catch (_e) { /* ignore malformed JSON tag */ }
  }

  const cleanText = String(rawReply || '').replace(/\[\[MOLES_JSON:[\s\S]*?\]\]/gi, '').trim();
  return {
    text: cleanText || stripTag(rawReply),
    moles: detectedMoles
  };
}

/**
 * Multimodal Gemini Vision AI: High-detail forensic Vietnamese/East Asian Palmistry
 * Accepts either 1 image (base64 string) or 2 images ([originalHighRes, creaseEnhancedMap])
 * to inspect exact crease geometry: breaks ("đứt mạch"), overlaps ("nối gối"), forks, islands, mounts.
 */
export async function analyzePalmLinesWithGemini(cfg, palmImageOrPair, hand = 'left', gender = 'male', extraNote = '', state = {}, onDelta = null) {
  const imgs = (Array.isArray(palmImageOrPair) ? palmImageOrPair : [palmImageOrPair]).filter(Boolean).slice(0, 2);
  if (imgs.length === 0) throw new Error('Chưa có ảnh lòng bàn tay để phân tích.');

  const genderLabel = gender === 'female' ? 'Nữ giới' : 'Nam giới';
  const handLabel = hand === 'right' ? 'Bàn tay PHẢI' : 'Bàn tay TRÁI';
  const birthYear = state?.auspiciousPrefs?.birthYear;
  const ageStr = birthYear ? `Năm sinh tham khảo: ${birthYear} (Tuổi ${getYearCanChi(Number(birthYear))}).` : '';
  const dualHint = imgs.length > 1
    ? 'Bạn nhận được 2 ảnh của CÙNG 1 bàn tay: Ảnh 1 là ảnh màu gốc độ phân giải cao; Ảnh 2 là bản lọc tăng tương phản nổi đường vân giúp soi rõ các vết ĐỨT MẠCH, ĐỨT ĐOẠN, NỐI GỐI, NHÁNH RẼ, ĐƯỜNG CẮT NGANG và CÙ LAO mảnh nhất.'
    : 'Hãy phóng to quan sát thật kỹ từng đường vân mảnh trên ảnh lòng bàn tay này.';

  const systemInstruction = `Bạn là bậc thầy Thủ Tướng Học (Xem Chỉ Tay) cổ truyền Việt Nam & Á Đông kết hợp quan sát hình thái thực tế chuẩn xác.
Người dùng chọn: ${handLabel} (${genderLabel}). ${ageStr}
${dualHint}

NGUYÊN TẮC QUAN SÁT THỰC TẾ — CẤM NÓI CHUNG CHUNG / CẤM TÔ HỒNG:
1. KIỂM TRA TAY THẬT TRONG ẢNH: Nhìn vị trí ngón cái (bên trái hay bên phải khung hình khi xòe lòng bàn tay hướng camera) để xác nhận đúng đây là Tay Trái hay Tay Phải. Nếu người dùng bấm nhầm nút chọn tay, nhắc nhẹ ngay ở đầu bài để họ biết.
2. SOI TỪNG ĐƯỜNG THẬT TRƯỚC KHI LUẬN: Với MỖI đường chỉ tay, BẮT BUỘC phải **mô tả đúng hình thái thực tế nhìn thấy trong ảnh** rồi mới giải nghĩa:
   - Đường đó **sâu hay nông, liền mạch hay BỊ ĐỨT MẠCH / ĐỨT ĐOẠN / ĐỨT RỒI NỐI GỐI (chồng nhau)**?
   - Nếu CÓ **ĐỨT MẠCH / NGẮT QUÃNG / MỜ HẲN / CHỒNG GỐI**: PHẢI CHỈ ĐÍCH DANH **đường nào bị đứt**, **đứt ở đoạn nào** (đầu đường = tiền vận <30 tuổi; giữa đường = trung vận 30–50 tuổi; cuối đường = hậu vận >50 tuổi), **khoảng hở rộng hay hẹp**, có **đường song song/nhánh nối đỡ** hay không, và ý nghĩa thực tế của vết đứt đó (thay đổi bước ngoặt, chuyển hướng công việc, biến cố sức khỏe/tâm lý cần chú ý, cách hóa giải chủ động — nói thẳng, trung thực, sâu sắc nhưng văn minh, KHÔNG hù dọa mê tín).
   - Quan sát rõ **gốc Sinh Đạo & Trí Đạo có chập nhau hay tách rời**, **đường Vận Mệnh (chạy dọc giữa lòng bàn tay)** có thẳng hay đứt khúc/chuyển hướng, có **nhánh rẽ / đuôi cá / đường cắt ngang / cù lao (đảo) / chữ M / chữ Nhất / tam giác tài lộc** hay không.
3. Nếu phần nào trên ảnh bị bóng/lóa hoặc quá mờ không nhìn rõ, nói thẳng "đoạn này hơi mờ/chưa rõ" — TUYỆT ĐỐI KHÔNG bịa đặt chi tiết không có trên ảnh.

TRÌNH BÀY CHI TIẾT, CHUYÊN SÂU THEO 7 MỤC MẠCH LẠC:
**1. 🔍 Tổng quan bàn tay & Điểm đặc biệt nổi bật nhất trên ảnh:**
- Xác nhận Tay trái/phải, hình dáng lòng bàn tay & sắc da, và liệt kê ngay các dấu hiệu đặc trưng nhất đập vào mắt (đặc biệt chỉ rõ những đường nào đang **đứt mạch / nối gối / giao cắt mạnh**).

**2. ❤️ Đường Sinh Đạo (Sức khỏe, Thể lực & Mốc biến động):**
- *Quan sát thực tế:* Điểm khởi đầu (chập hay tách Trí Đạo), độ rộng vòng cung ôm gò Kim Tinh, độ sâu, **soi kỹ xem có đứt mạch / đứt đoạn / nối gối / đường cắt ngang / đường hộ mệnh song song hay không** và ở khoảng độ tuổi nào.
- *Luận giải chi tiết:* Thể chất, sức bền, lưu ý sức khỏe & các bước ngoặt lớn theo từng giai đoạn.

**3. 🧠 Đường Trí Đạo (Tư duy, Quyết định & Bản lĩnh):**
- *Quan sát thực tế:* Độ dài, độ sâu, chạy thẳng hay dốc xuống gò Thái Âm, **có đứt mạch, chuyển hướng, đảo hay chẻ nhánh cuối đường (đuôi cá) hay không**.
- *Luận giải chi tiết:* Phong cách tư duy, thế mạnh nghề nghiệp, cách xử lý áp lực & thời điểm dễ thay đổi định hướng.

**4. 💞 Đường Tâm Đạo & Hôn Nhân (Cảm xúc & Gia đạo):**
- *Quan sát thực tế:* Chạy tới dưới ngón trỏ hay ngón giữa, cong hay thẳng, **có đứt đoạn, dây xích, cù lao hay nhánh rẽ lên/xuống hay không**.
- *Luận giải chi tiết:* Tính cách trong tình cảm, sự chung thủy, gia đạo và điểm cần dung hòa.

**5. 🚀 Đường Vận Mệnh (Sự nghiệp) & Tài Lộc (Thái Dương – Thủy Tinh):**
- *Quan sát thực tế:* Soi rất kỹ đường thẳng đứng chạy từ cổ tay/giữa lòng bàn tay lên ngón giữa (đường Sự nghiệp/Vận Mệnh) và các đường mảnh dưới ngón áp út/ngón út: bắt đầu từ đâu, **có đứt khúc / đổi trục / nối tiếp sang nhánh mới hay bị cắt ngang không**.
- *Luận giải chi tiết:* Con đường tự lập, các mốc chuyển việc/mở rộng làm ăn (nếu đứt rồi nối lệch thường báo hiệu đổi nghề/lập nghiệp giai đoạn mới), khả năng tụ tài.

**6. ⛰️ Các Gò Bàn Tay & Vân Đặc Biệt:**
- Nhận xét các gò nổi rõ (Kim Tinh, Mộc Tinh, Thái Âm, Thái Dương, Thủy Tinh) và vân đặc biệt nếu thấy thật (chữ M, tam giác tài lộc, nhánh hướng lên, vân cản trở...).

**7. 💡 Tổng kết & Lời khuyên thực tế dành riêng cho bàn tay này:**
- Tóm gọn 3 điểm mạnh cần phát huy và 2–3 lời khuyên cụ thể, thực tế để giữ sức khỏe, vượt qua nhẹ nhàng các mốc đứt mạch/chuyển vận. Cuối bài nhắc nhẹ kết quả mang tính văn hóa Thủ tướng học tham khảo.`;

  const userPrompt = extraNote
    ? `Hãy soi thật kỹ từng đường vân (đặc biệt các đoạn đứt mạch, đứt đoạn, nối gối, nhánh rẽ nếu có) trên ảnh ${handLabel} (${genderLabel}) và luận giải thật chi tiết, khớp đúng với bàn tay thật giúp tôi. Ghi chú thêm của tôi: ${extraNote}`
    : `Hãy soi thật kỹ từng đường vân (đặc biệt kiểm tra kỹ xem đường nào bị đứt mạch, đứt đoạn, nối gối, chẻ nhánh hay giao cắt) trên ảnh ${handLabel} (${genderLabel}) và luận giải thật chi tiết, khớp đúng với bàn tay thật giúp tôi.`;

  const parts = imgs.map((b64) => ({ inlineData: { mimeType: 'image/jpeg', data: b64 } }));
  parts.push({ text: userPrompt });

  const opts = {
    systemInstruction,
    contents: [{ role: 'user', parts }],
    temperature: 0.25,
    thinkingLevel: 'MEDIUM',
    timeoutMs: 42000
  };

  return typeof onDelta === 'function'
    ? callGeminiApiStreaming(cfg, opts, onDelta)
    : callGeminiApi(cfg, opts);
}

/**
 * Multimodal Gemini Vision AI: Read & interpret a photographed Vietnamese Temple Fortune Slip
 * (Quẻ xăm đình chùa — Quan Âm, Tả Quân, Linh Xăm Hán-Nôm/Việt) OR a Tử Vi Horoscope sheet (Lá số Tử Vi 12 cung)
 * from 1 or 2 high-res images (front & back).
 */
export async function analyzeFortuneOrHoroscopeWithGemini(cfg, base64Images = [], meta = {}, state = {}, now = new Date(), onDelta = null) {
  const imgs = (Array.isArray(base64Images) ? base64Images : [base64Images]).filter(Boolean).slice(0, 2);
  if (imgs.length === 0) {
    throw new Error('Chưa có ảnh tờ quẻ / lá số Tử Vi để phân tích.');
  }

  const todaySolar = { day: now.getDate(), month: now.getMonth() + 1, year: now.getFullYear() };
  const todayLunar = convertSolar2Lunar(todaySolar.day, todaySolar.month, todaySolar.year, TIMEZONE_VN);
  const yearCanChiNow = getYearCanChi(todayLunar.year);
  const genderLabel = meta.gender === 'female' ? 'Nữ giới' : 'Nam giới';
  const birthYear = String(meta.birthYear || state?.auspiciousPrefs?.birthYear || '').trim();
  const ageStr = birthYear && Number(birthYear) >= 1920
    ? `Năm sinh người xem: ${birthYear} (Tuổi ${getYearCanChi(Number(birthYear))}).`
    : '';
  const typeHint = meta.docType && meta.docType !== 'auto'
    ? `Loại giấy người dùng chọn: ${meta.docTypeLabel || meta.docType}.`
    : 'Hãy tự nhận diện xem ảnh là Quẻ xăm đình chùa (chữ Hán-Nôm/Việt), Lá số Tử Vi 12 cung, hay Quẻ Kinh Dịch / Bát Tự.';
  const focusHint = meta.focusTopicLabel ? `Phương diện người dùng đang quan tâm / cầu xin nhất: ${meta.focusTopicLabel}.` : '';
  const extraHint = meta.extraNote ? `Ghi chú / câu hỏi riêng của người dùng: "${meta.extraNote}".` : '';

  const systemInstruction = `Bạn là học giả am hiểu sâu sắc văn hóa tâm linh Việt Nam, Hán-Nôm cổ truyền, Quẻ Xăm Đình Chùa (Xăm Quan Âm, Linh Xăm, Quẻ Tả Quân, Quẻ Thành Hoàng...) và khoa Tử Vi Đẩu Số (12 cung, Chính tinh, Phụ tinh, Tam hợp, Đại vận, Tiểu vận).
Ngữ cảnh hiện tại: Năm ${todaySolar.year} DL — năm Âm lịch ${yearCanChiNow} (hôm nay ${pad2(todaySolar.day)}/${pad2(todaySolar.month)}/${todaySolar.year} DL, tức ${todayLunar.day}/${todayLunar.month}/${todayLunar.year} ÂL).
Thông tin người xin quẻ / chủ lá số: ${genderLabel}. ${ageStr}
${typeHint}
${focusHint}
${extraHint}

NHIỆM VỤ BẮT BUỘC:
Đọc thật kỹ TỪNG DÒNG CHỮ, SỐ QUẺ, BÀI THƠ (kể cả chữ Hán, chữ Nôm, Hán-Việt, thơ lục bát) HOẶC CÁC CUNG & SAO trên ảnh tờ giấy người dùng gửi (${imgs.length} ảnh).
- Nếu ảnh quá mờ, bị mất chữ hoặc không phải tờ quẻ/lá số, hãy nói thật rõ ràng và gợi ý chụp lại phẳng, đủ sáng — TUYỆT ĐỐI KHÔNG bịa đặt nội dung không có trên ảnh!
- Luận giải bằng tiếng Việt trang trọng, ấm áp, dễ hiểu, khách quan, tích cực (TUYỆT ĐỐI không hù dọa mê tín) theo đúng 4 mục mạch lạc:

**1. 📄 Nhận diện & Đọc lại nội dung tờ giấy:**
- Nêu rõ đây là **Quẻ xăm gì / Số mấy / Hạng quẻ** (Thượng Thượng, Thượng Cát, Trung Bình, Hạ Hạ...) HOẶC **Lá số Tử Vi** (Mệnh – Cục – Thân – các Chính tinh nổi bật tại Mệnh/Tài/Quan/Phu Thê/Phúc Đức đọc được trên ảnh).
- Nếu có bài thơ chữ Hán / Hán-Việt trên tờ quẻ: chép lại vắn tắt và **dịch nghĩa sang tiếng Việt hiện đại** sát ý, dễ hiểu.

**2. 🌟 Đánh giá tổng quan (Thời vận & Cát/Hung):**
- Tổng kết xu hướng tốt/cần lưu ý của quẻ hoặc lá số trong năm ${yearCanChiNow} (${todaySolar.year}), liên hệ hài hòa với tuổi người xem (nếu có).

**3. 🔍 Luận giải chi tiết từng phương diện:**
- 💼 **Công danh & Sự nghiệp:** ...
- 💰 **Tài lộc & Làm ăn:** ...
- 💞 **Tình duyên & Gia đạo:** ...
- 🏥 **Sức khỏe & Xuất hành / Bình an:** ...
*(Phân tích kỹ hơn, trả lời thẳng trọng tâm vào mục người dùng đang cầu xin nhất!)*

**4. 💡 Lời khuyên hành động & Cách đón cát – hóa giải tích cực:**
- Đưa ra 2–3 lời khuyên thực tế, nhẹ nhàng, nhân văn để phát huy điểm tốt (nếu quẻ Cát) hoặc bình tĩnh hóa giải, giữ an tâm, phòng tránh rủi ro (nếu quẻ Trung/Hạ). Cuối bài nhắc nhẹ kết quả mang tính văn hóa tâm linh tham khảo.`;

  const parts = imgs.map((b64) => ({ inlineData: { mimeType: 'image/jpeg', data: b64 } }));
  parts.push({
    text: meta.extraNote
      ? `Hãy đọc kỹ chữ trên ảnh tờ giấy này và luận giải chi tiết giúp tôi (${genderLabel}). Câu hỏi thêm: ${meta.extraNote}`
      : `Hãy đọc kỹ toàn bộ nội dung trên ảnh tờ giấy quẻ / lá số Tử Vi này và luận giải chi tiết, dễ hiểu giúp tôi (${genderLabel}).`
  });

  const opts = {
    systemInstruction,
    contents: [{ role: 'user', parts }],
    temperature: 0.35,
    thinkingLevel: 'MEDIUM',
    timeoutMs: 36000
  };

  return typeof onDelta === 'function'
    ? callGeminiApiStreaming(cfg, opts, onDelta)
    : callGeminiApi(cfg, opts);
}

/**
 * Shared high-level Gemini 4 / 3.8 Turbo caller (Text + Multimodal Vision) for all Super-App modules
 * (Tử Vi, Phong thủy không gian, Sim/Biển số, Tuổi hợp, Tarot/Thần số học, Kinh Dịch/Xăm, Thu chi Bill, Đơn thuốc, Thực đơn).
 */
export async function askGeminiGeneral(cfg, params = {}, onDelta = null) {
  const {
    systemInstruction = '',
    userPrompt = '',
    images = [],
    temperature = 0.4,
    thinkingLevel = 'LOW',
    timeoutMs = 26000,
    responseMimeType = ''
  } = params;

  const parts = [];
  for (const b64 of (Array.isArray(images) ? images : []).filter(Boolean).slice(0, 2)) {
    parts.push({ inlineData: { mimeType: 'image/jpeg', data: b64 } });
  }
  parts.push({ text: String(userPrompt || '').trim() });

  const opts = {
    systemInstruction,
    contents: [{ role: 'user', parts }],
    temperature,
    thinkingLevel,
    timeoutMs,
    responseMimeType
  };

  return typeof onDelta === 'function'
    ? callGeminiApiStreaming(cfg, opts, onDelta)
    : callGeminiApi(cfg, opts);
}
