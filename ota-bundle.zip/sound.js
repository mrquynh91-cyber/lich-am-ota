/**
 * Web Audio API sound synthesizer (zero external dependencies)
 * - playWaterPourSound(): Realistic water pouring into a glass (rising cavity resonance + bubble droplets)
 * - playReminderChime(): Warm pleasant bell chime for date/time reminders
 */

let sharedCtx = null;

function getAudioContext() {
  const AudioCtx = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!sharedCtx || sharedCtx.state === 'closed') {
    sharedCtx = new AudioCtx();
  }
  return sharedCtx;
}

/**
 * Synthesize realistic water pouring into a cup/glass (~2.5s)
 */
export async function playWaterPourSound(volume = 0.85) {
  const ctx = getAudioContext();
  if (ctx.state === 'suspended') {
    await ctx.resume();
  }

  const now = ctx.currentTime;
  const duration = 2.45;
  const sampleRate = ctx.sampleRate;

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.001, now);
  masterGain.gain.linearRampToValueAtTime(volume, now + 0.16);
  masterGain.gain.setValueAtTime(volume, now + duration - 0.35);
  masterGain.gain.exponentialRampToValueAtTime(0.001, now + duration);
  masterGain.connect(ctx.destination);

  // 1. Continuous liquid stream (filtered pink-ish noise with rising glass-fill resonance)
  const bufferSize = Math.floor(sampleRate * duration);
  const noiseBuffer = ctx.createBuffer(1, bufferSize, sampleRate);
  const data = noiseBuffer.getChannelData(0);
  let b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    b0 = 0.997 * b0 + white * 0.029;
    b1 = 0.985 * b1 + white * 0.032;
    b2 = 0.950 * b2 + white * 0.048;
    data[i] = (b0 + b1 + b2 + white * 0.18) * 1.4;
  }

  const streamSrc = ctx.createBufferSource();
  streamSrc.buffer = noiseBuffer;

  // Main resonant cavity filter — rises in frequency as the glass fills!
  const cavityFilter = ctx.createBiquadFilter();
  cavityFilter.type = 'bandpass';
  cavityFilter.Q.setValueAtTime(3.2, now);
  cavityFilter.frequency.setValueAtTime(420, now);
  cavityFilter.frequency.exponentialRampToValueAtTime(760, now + duration * 0.55);
  cavityFilter.frequency.exponentialRampToValueAtTime(1450, now + duration);

  // Secondary splash/trickle high-frequency sheen
  const splashFilter = ctx.createBiquadFilter();
  splashFilter.type = 'highpass';
  splashFilter.frequency.setValueAtTime(1600, now);

  const streamGain = ctx.createGain();
  streamGain.gain.setValueAtTime(0.55, now);

  const splashGain = ctx.createGain();
  splashGain.gain.setValueAtTime(0.16, now);

  streamSrc.connect(cavityFilter);
  cavityFilter.connect(streamGain);
  streamGain.connect(masterGain);

  streamSrc.connect(splashFilter);
  splashFilter.connect(splashGain);
  splashGain.connect(masterGain);

  streamSrc.start(now);
  streamSrc.stop(now + duration);

  // 2. Randomized rising-pitch water bubbles / glugs along the pour
  const bubbleCount = 34;
  for (let i = 0; i < bubbleCount; i++) {
    const progress = i / bubbleCount;
    const t = now + 0.06 + progress * (duration - 0.28) + (Math.random() - 0.5) * 0.04;
    if (t < now || t > now + duration - 0.08) continue;

    // Bubble pitch rises gradually as the glass fills
    const baseFreq = 320 + progress * 680 + Math.random() * 260;
    const endFreq = baseFreq * (1.45 + Math.random() * 0.45);
    const bDur = 0.045 + Math.random() * 0.045;

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(endFreq, t + bDur);

    const bGain = ctx.createGain();
    const peak = 0.08 + Math.random() * 0.11;
    bGain.gain.setValueAtTime(0.0001, t);
    bGain.gain.linearRampToValueAtTime(peak, t + bDur * 0.25);
    bGain.gain.exponentialRampToValueAtTime(0.0001, t + bDur);

    osc.connect(bGain);
    bGain.connect(masterGain);

    osc.start(t);
    osc.stop(t + bDur + 0.01);
  }

  // 3. Final gentle droplet "plop" at the end
  const dropTime = now + duration - 0.12;
  const dropOsc = ctx.createOscillator();
  dropOsc.type = 'sine';
  dropOsc.frequency.setValueAtTime(920, dropTime);
  dropOsc.frequency.exponentialRampToValueAtTime(1680, dropTime + 0.075);

  const dropGain = ctx.createGain();
  dropGain.gain.setValueAtTime(0.0001, dropTime);
  dropGain.gain.linearRampToValueAtTime(0.18, dropTime + 0.015);
  dropGain.gain.exponentialRampToValueAtTime(0.0001, dropTime + 0.085);

  dropOsc.connect(dropGain);
  dropGain.connect(masterGain);
  dropOsc.start(dropTime);
  dropOsc.stop(dropTime + 0.09);

  return new Promise((resolve) => setTimeout(resolve, Math.ceil((duration + 0.15) * 1000)));
}

/**
 * Pleasant warm bell chime for scheduled date/time reminders (~1.4s)
 */
export async function playReminderChime(volume = 0.65) {
  const ctx = getAudioContext();
  if (ctx.state === 'suspended') {
    await ctx.resume();
  }

  const now = ctx.currentTime;
  const notes = [
    { freq: 587.33, start: 0.0, dur: 0.55 },  // D5
    { freq: 880.00, start: 0.18, dur: 0.65 }, // A5
    { freq: 1174.66, start: 0.36, dur: 0.9 }  // D6
  ];

  for (const n of notes) {
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(n.freq, now + n.start);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, now + n.start);
    g.gain.linearRampToValueAtTime(volume * 0.4, now + n.start + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + n.start + n.dur);

    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now + n.start);
    osc.stop(now + n.start + n.dur + 0.02);
  }

  return new Promise((resolve) => setTimeout(resolve, 1400));
}
