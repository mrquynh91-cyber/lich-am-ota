/**
 * Vietnamese Lunar Calendar Engine (GMT+7)
 * Based on the astronomical algorithms by Ho Ngoc Duc / Jean Meeus.
 */

export const TIMEZONE_VN = 7.0;
const PI = Math.PI;

export const CAN = [
  'Giáp', 'Ất', 'Bính', 'Đinh', 'Mậu',
  'Kỷ', 'Canh', 'Tân', 'Nhâm', 'Quý'
];

export const CHI = [
  'Tý', 'Sửu', 'Dần', 'Mão', 'Thìn', 'Tỵ',
  'Ngọ', 'Mùi', 'Thân', 'Dậu', 'Tuất', 'Hợi'
];

export const CON_GIAP = [
  'Chuột', 'Trâu', 'Hổ', 'Mèo', 'Rồng', 'Rắn',
  'Ngựa', 'Dê', 'Khỉ', 'Gà', 'Chó', 'Lợn'
];

export const THU_VN = [
  'Chủ Nhật', 'Thứ Hai', 'Thứ Ba', 'Thứ Tư',
  'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy'
];

export const LUNAR_MONTH_NAMES = [
  '', 'Giêng', 'Hai', 'Ba', 'Tư', 'Năm', 'Sáu',
  'Bảy', 'Tám', 'Chín', 'Mười', 'Một', 'Chạp'
];

// Giờ Hoàng Đạo indices (0 = Tý, 1 = Sửu, ..., 11 = Hợi) keyed by Chi of the day (0..11)
const HOANG_DAO_HOURS = [
  [0, 1, 3, 6, 8, 9],     // Tý, Ngọ
  [2, 3, 5, 8, 10, 11],   // Sửu, Mùi
  [0, 1, 4, 5, 7, 10],    // Dần, Thân
  [0, 2, 3, 6, 7, 9],     // Mão, Dậu
  [2, 4, 5, 8, 9, 11],    // Thìn, Tuất
  [1, 4, 6, 7, 10, 11]    // Tỵ, Hợi
];

const HOUR_RANGES = [
  '23-1h', '1-3h', '3-5h', '5-7h', '7-9h', '9-11h',
  '11-13h', '13-15h', '15-17h', '17-19h', '19-21h', '21-23h'
];

function INT(d) {
  return Math.floor(d);
}

/**
 * Compute the (integral) Julian day number of day dd/mm/yyyy
 */
export function jdFromDate(dd, mm, yy) {
  const a = INT((14 - mm) / 12);
  const y = yy + 4800 - a;
  const m = mm + 12 * a - 3;
  let jd = dd + INT((153 * m + 2) / 5) + 365 * y + INT(y / 4) - INT(y / 100) + INT(y / 400) - 32045;
  if (jd < 2299161) {
    jd = dd + INT((153 * m + 2) / 5) + 365 * y + INT(y / 4) - 32083;
  }
  return jd;
}

/**
 * Convert a Julian day number to day/month/year
 */
export function jdToDate(jd) {
  let a, b, c;
  if (jd > 2299160) {
    a = jd + 32044;
    b = INT((4 * a + 3) / 146097);
    c = a - INT((b * 146097) / 4);
  } else {
    b = 0;
    c = jd + 32082;
  }
  const d = INT((4 * c + 3) / 1461);
  const e = c - INT((1461 * d) / 4);
  const m = INT((5 * e + 2) / 153);
  const day = e - INT((153 * m + 2) / 5) + 1;
  const month = m + 3 - 12 * INT(m / 10);
  const year = b * 100 + d - 4800 + INT(m / 10);
  return { day, month, year };
}

/**
 * Compute the time of the k-th new moon after the new moon of 1/1/1900 13:52 UCT
 */
function newMoon(k) {
  const T = k / 1236.85;
  const T2 = T * T;
  const T3 = T2 * T;
  const dr = PI / 180;
  let Jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3;
  Jd1 = Jd1 + 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * dr);
  const M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
  const Mpr = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
  const F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
  let C1 = (0.1734 - 0.000393 * T) * Math.sin(M * dr) + 0.0021 * Math.sin(2 * dr * M);
  C1 = C1 - 0.4068 * Math.sin(Mpr * dr) + 0.0161 * Math.sin(dr * 2 * Mpr);
  C1 = C1 - 0.0004 * Math.sin(dr * 3 * Mpr);
  C1 = C1 + 0.0104 * Math.sin(dr * 2 * F) - 0.0051 * Math.sin(dr * (M + Mpr));
  C1 = C1 - 0.0074 * Math.sin(dr * (M - Mpr)) + 0.0004 * Math.sin(dr * (2 * F + M));
  C1 = C1 - 0.0004 * Math.sin(dr * (2 * F - M)) - 0.0006 * Math.sin(dr * (2 * F + Mpr));
  C1 = C1 + 0.0010 * Math.sin(dr * (2 * F - Mpr)) + 0.0005 * Math.sin(dr * (2 * Mpr + M));
  let deltat;
  if (T < -11) {
    deltat = 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3;
  } else {
    deltat = -0.000278 + 0.000265 * T + 0.000262 * T2;
  }
  return Jd1 + C1 - deltat;
}

/**
 * Compute the longitude of the sun at any Julian day number
 */
function sunLongitude(jdn) {
  const T = (jdn - 2451545.0) / 36525;
  const T2 = T * T;
  const dr = PI / 180;
  const M = 357.52910 + 35999.05030 * T - 0.0001559 * T2 - 0.00000048 * T * T2;
  const L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2;
  let DL = (1.914600 - 0.004817 * T - 0.000014 * T2) * Math.sin(dr * M);
  DL = DL + (0.019993 - 0.000101 * T) * Math.sin(dr * 2 * M) + 0.000290 * Math.sin(dr * 3 * M);
  let L = (L0 + DL) * dr;
  L = L - PI * 2 * INT(L / (PI * 2));
  return L;
}

function getSunLongitude(dayNumber, timeZone = TIMEZONE_VN) {
  return INT((sunLongitude(dayNumber - 0.5 - timeZone / 24.0) / PI) * 6);
}

function getNewMoonDay(k, timeZone = TIMEZONE_VN) {
  return INT(newMoon(k) + 0.5 + timeZone / 24.0);
}

function getLunarMonth11(yy, timeZone = TIMEZONE_VN) {
  const off = jdFromDate(31, 12, yy) - 2415021;
  const k = INT(off / 29.530588853);
  let nm = getNewMoonDay(k, timeZone);
  const sunLong = getSunLongitude(nm, timeZone);
  if (sunLong >= 9) {
    nm = getNewMoonDay(k - 1, timeZone);
  }
  return nm;
}

function getLeapMonthOffset(a11, timeZone = TIMEZONE_VN) {
  const k = INT((a11 - 2415021.076998695) / 29.530588853 + 0.5);
  let last = 0;
  let i = 1;
  let arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone);
  do {
    last = arc;
    i++;
    arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone);
  } while (arc !== last && i < 14);
  return i - 1;
}

/**
 * Convert solar date (dd/mm/yy) to Vietnamese lunar date
 */
export function convertSolar2Lunar(dd, mm, yy, timeZone = TIMEZONE_VN) {
  const dayNumber = jdFromDate(dd, mm, yy);
  const k = INT((dayNumber - 2415021.076998695) / 29.530588853);
  let monthStart = getNewMoonDay(k + 1, timeZone);
  if (monthStart > dayNumber) {
    monthStart = getNewMoonDay(k, timeZone);
  }
  let a11 = getLunarMonth11(yy, timeZone);
  let b11 = a11;
  let lunarYear;
  if (a11 >= monthStart) {
    lunarYear = yy;
    a11 = getLunarMonth11(yy - 1, timeZone);
  } else {
    lunarYear = yy + 1;
    b11 = getLunarMonth11(yy + 1, timeZone);
  }
  const lunarDay = dayNumber - monthStart + 1;
  const diff = INT((monthStart - a11) / 29);
  let lunarLeap = 0;
  let lunarMonth = diff + 11;
  if (b11 - a11 > 365) {
    const leapMonthDiff = getLeapMonthOffset(a11, timeZone);
    if (diff >= leapMonthDiff) {
      lunarMonth = diff + 10;
      if (diff === leapMonthDiff) {
        lunarLeap = 1;
      }
    }
  }
  if (lunarMonth > 12) {
    lunarMonth = lunarMonth - 12;
  }
  if (lunarMonth >= 11 && diff < 4) {
    lunarYear -= 1;
  }

  // Check if current lunar month has 29 or 30 days
  let nextMonthStart = getNewMoonDay(k + 1, timeZone);
  if (nextMonthStart <= dayNumber) {
    nextMonthStart = getNewMoonDay(k + 2, timeZone);
  }
  const monthLength = nextMonthStart - monthStart;

  return {
    day: lunarDay,
    month: lunarMonth,
    year: lunarYear,
    leap: lunarLeap === 1,
    monthLength,
    jd: dayNumber
  };
}

/**
 * Convert Vietnamese lunar date to solar date
 */
export function convertLunar2Solar(lunarDay, lunarMonth, lunarYear, lunarLeap = false, timeZone = TIMEZONE_VN) {
  let a11, b11;
  if (lunarMonth < 11) {
    a11 = getLunarMonth11(lunarYear - 1, timeZone);
    b11 = getLunarMonth11(lunarYear, timeZone);
  } else {
    a11 = getLunarMonth11(lunarYear, timeZone);
    b11 = getLunarMonth11(lunarYear + 1, timeZone);
  }
  const k = INT(0.5 + (a11 - 2415021.076998695) / 29.530588853);
  let off = lunarMonth - 11;
  if (off < 0) {
    off += 12;
  }
  if (b11 - a11 > 365) {
    const leapOff = getLeapMonthOffset(a11, timeZone);
    let leapMonth = leapOff - 2;
    if (leapMonth <= 0) {
      leapMonth += 12;
    }
    if (lunarLeap && lunarMonth !== leapMonth) {
      return null;
    } else if (lunarLeap || off >= leapOff) {
      off += 1;
    }
  } else if (lunarLeap) {
    return null;
  }
  const monthStart = getNewMoonDay(k + off, timeZone);
  const nextMonthStart = getNewMoonDay(k + off + 1, timeZone);
  const maxDay = nextMonthStart - monthStart;
  if (lunarDay < 1 || lunarDay > maxDay) {
    return null;
  }
  return jdToDate(monthStart + lunarDay - 1);
}

/**
 * Get the last day of Lunar Year (29 or 30 Tết / Tất Niên) as a solar date
 */
export function getTetEveSolarDate(lunarYear, timeZone = TIMEZONE_VN) {
  const tetNext = convertLunar2Solar(1, 1, lunarYear + 1, false, timeZone);
  const jdTetNext = jdFromDate(tetNext.day, tetNext.month, tetNext.year);
  const eveSolar = jdToDate(jdTetNext - 1);
  const eveLunar = convertSolar2Lunar(eveSolar.day, eveSolar.month, eveSolar.year, timeZone);
  return { solar: eveSolar, lunarDay: eveLunar.day };
}

/**
 * Get Can Chi of Lunar Year
 */
export function getYearCanChi(lunarYear) {
  const can = CAN[(lunarYear + 6) % 10];
  const chi = CHI[(lunarYear + 8) % 12];
  return `${can} ${chi}`;
}

/**
 * Get Can Chi of Lunar Month
 */
export function getMonthCanChi(lunarMonth, lunarYear) {
  const can = CAN[(lunarYear * 12 + lunarMonth + 3) % 10];
  const chi = CHI[(lunarMonth + 1) % 12];
  return `${can} ${chi}`;
}

/**
 * Get Can Chi of a Solar Day (via Julian Day Number)
 */
export function getDayCanChi(jd) {
  const canIndex = (jd + 9) % 10;
  const chiIndex = (jd + 1) % 12;
  const can = CAN[canIndex];
  const chi = CHI[chiIndex];
  return { name: `${can} ${chi}`, canIndex, chiIndex };
}

/**
 * Get Giờ Hoàng Đạo list for a given Julian Day Number
 */
export function getHoangDaoHours(jd) {
  const chiIndex = (jd + 1) % 12;
  const indices = HOANG_DAO_HOURS[chiIndex % 6];
  return indices.map((idx) => `${CHI[idx]} (${HOUR_RANGES[idx]})`);
}

/**
 * Get detailed 12 hours of the day split into Hoàng Đạo and Hắc Đạo
 */
export function getHoursDetail(jd) {
  const { canIndex, chiIndex } = getDayCanChi(jd);
  const goodSet = new Set(HOANG_DAO_HOURS[chiIndex % 6]);
  const tyCanStart = (canIndex % 5) * 2;
  const hoangDao = [];
  const hacDao = [];

  for (let i = 0; i < 12; i++) {
    const hourCan = CAN[(tyCanStart + i) % 10];
    const item = {
      chi: CHI[i],
      canChi: `${hourCan} ${CHI[i]}`,
      range: HOUR_RANGES[i],
      isGood: goodSet.has(i)
    };
    if (item.isGood) hoangDao.push(item);
    else hacDao.push(item);
  }
  return { hoangDao, hacDao, firstHourCanChi: `${CAN[tyCanStart]} Tý` };
}

const TIET_KHI = [
  'Xuân Phân', 'Thanh Minh', 'Cốc Vũ', 'Lập Hạ', 'Tiểu Mãn', 'Mang Chủng',
  'Hạ Chí', 'Tiểu Thử', 'Đại Thử', 'Lập Thu', 'Xử Thử', 'Bạch Lộ',
  'Thu Phân', 'Hàn Lộ', 'Sương Giáng', 'Lập Đông', 'Tiểu Tuyết', 'Đại Tuyết',
  'Đông Chí', 'Tiểu Hàn', 'Đại Hàn', 'Lập Xuân', 'Vũ Thủy', 'Kinh Trập'
];

/**
 * Get current Solar Term (Tiết Khí) for a Julian Day Number
 */
export function getTietKhi(jd, timeZone = TIMEZONE_VN) {
  const idx = INT((sunLongitude(jd + 0.5 - timeZone / 24.0) / PI) * 12) % 24;
  return TIET_KHI[idx];
}

const DAY_STARS = [
  { name: 'Thanh Long', isGood: true, desc: 'Rất tốt cho xuất hành, cưới hỏi, ký kết' },
  { name: 'Minh Đường', isGood: true, desc: 'Thuận lợi gặp gỡ quý nhân, thăng chức, cầu tài' },
  { name: 'Thiên Hình', isGood: false, desc: 'Ngày Hắc Đạo, nên thận trọng trong tranh chấp, kiện tụng' },
  { name: 'Chu Tước', isGood: false, desc: 'Ngày Hắc Đạo, tránh khẩu thiệt, tranh cãi' },
  { name: 'Kim Quỹ', isGood: true, desc: 'Tốt cho cưới hỏi, giao dịch tài chính, khai trương' },
  { name: 'Kim Đường', isGood: true, desc: 'Cát tinh chiếu mệnh, mọi việc hanh thông' },
  { name: 'Bạch Hổ', isGood: false, desc: 'Ngày Hắc Đạo, hạn chế khởi công, động thổ lớn' },
  { name: 'Ngọc Đường', isGood: true, desc: 'Tốt cho học hành, thi cử, xây dựng, khai trương' },
  { name: 'Thiên Lao', isGood: false, desc: 'Ngày Hắc Đạo, dễ gặp trở ngại với việc trọng đại' },
  { name: 'Nguyên Vũ', isGood: false, desc: 'Ngày Hắc Đạo, nên cẩn trọng giấy tờ, tài sản' },
  { name: 'Tư Mệnh', isGood: true, desc: 'Tốt cho cúng tế, cầu phúc, khởi sự bình an' },
  { name: 'Câu Trần', isGood: false, desc: 'Ngày Hắc Đạo, hạn chế di chuyển xa, cưới hỏi' }
];

/**
 * Get Hoàng Đạo / Hắc Đạo status for a date
 */
export function getDayHoangDao(lunarMonth, jd) {
  const { chiIndex } = getDayCanChi(jd);
  const startChi = ((lunarMonth - 1) % 6) * 2;
  const starIdx = (chiIndex - startChi + 12) % 12;
  const star = DAY_STARS[starIdx];
  return {
    type: star.isGood ? 'Hoàng Đạo' : 'Hắc Đạo',
    isGood: star.isGood,
    starName: star.name,
    desc: star.desc
  };
}

const THAP_NHI_TRUC = [
  { name: 'Trực Kiến', good: 'Xuất hành, nhậm chức, khai trương nhỏ', bad: 'Động thổ, đào giếng, an táng' },
  { name: 'Trực Trừ', good: 'Cúng tế, chữa bệnh, dọn dẹp, giải trừ', bad: 'Ký kết lớn, xuất vốn đầu tư' },
  { name: 'Trực Mãn', good: 'Cúng tế, cưới hỏi, mở kho, nhập trạch', bad: 'Kiện tụng, uống thuốc mới' },
  { name: 'Trực Bình', good: 'Sửa đường, tu sửa nhà cửa, giao dịch thường', bad: 'Khởi công lớn, trồng cây' },
  { name: 'Trực Định', good: 'Ký hợp đồng, cưới hỏi, giao dịch, nhập học', bad: 'Kiện tụng, xuất hành xa' },
  { name: 'Trực Chấp', good: 'Xây dựng, tu tạo, tuyển dụng, lập kế hoạch', bad: 'Dời nhà, xuất hành xa, mở kho' },
  { name: 'Trực Phá', good: 'Phá dỡ cũ, chữa bệnh, sửa chữa nhỏ', bad: 'Cưới hỏi, khai trương, ký kết' },
  { name: 'Trực Nguy', good: 'Cúng tế, lễ bái, cầu an', bad: 'Leo cao, đi sông nước, khởi công lớn' },
  { name: 'Trực Thành', good: 'Khai trương, nhập học, cưới hỏi, ký kết', bad: 'Kiện tụng, tranh chấp' },
  { name: 'Trực Thu', good: 'Thu hoạch, thu nợ, nhập kho, giao dịch', bad: 'An táng, xuất hành xa' },
  { name: 'Trực Khai', good: 'Khai trương, xuất hành, động thổ, cưới hỏi', bad: 'An táng, tranh cãi' },
  { name: 'Trực Bế', good: 'Đắp đê, xây tường, lấp hố, tu dưỡng', bad: 'Khai trương, xuất hành, nhậm chức' }
];

export function getDayTruc(lunarMonth, jd) {
  const { chiIndex } = getDayCanChi(jd);
  const monthChiIndex = (lunarMonth + 1) % 12;
  const idx = (chiIndex - monthChiIndex + 12) % 12;
  return THAP_NHI_TRUC[idx];
}

const NAP_AM = [
  'Hải Trung Kim (Vàng trong biển)', 'Lư Trung Hỏa (Lửa trong lò)',
  'Đại Lâm Mộc (Cây rừng lớn)', 'Lộ Bàng Thổ (Đất ven đường)',
  'Kiếm Phong Kim (Vàng mũi kiếm)', 'Sơn Đầu Hỏa (Lửa đầu núi)',
  'Giản Hạ Thủy (Nước khe suối)', 'Thành Đầu Thổ (Đất đầu thành)',
  'Bạch Lạp Kim (Vàng sáp ong)', 'Dương Liễu Mộc (Gỗ cây liễu)',
  'Tuyền Trung Thủy (Nước trong suối)', 'Ốc Thượng Thổ (Đất mái nhà)',
  'Tích Lịch Hỏa (Lửa sấm sét)', 'Tùng Bách Mộc (Gỗ tùng bách)',
  'Trường Lưu Thủy (Nước chảy dài)', 'Sa Trung Kim (Vàng trong cát)',
  'Sơn Hạ Hỏa (Lửa dưới núi)', 'Bình Địa Mộc (Cây đồng bằng)',
  'Bích Thượng Thổ (Đất trên vách)', 'Kim Bạch Kim (Vàng pha bạc)',
  'Phú Đăng Hỏa (Lửa đèn to)', 'Thiên Hà Thủy (Nước sông trời)',
  'Đại Trạch Thổ (Đất nền nhà)', 'Thoa Xuyến Kim (Vàng trang sức)',
  'Tang Đố Mộc (Gỗ cây dâu)', 'Đại Khê Thủy (Nước khe lớn)',
  'Sa Trung Thổ (Đất pha cát)', 'Thiên Thượng Hỏa (Lửa trên trời)',
  'Thạch Lựu Mộc (Gỗ cây lựu)', 'Đại Hải Thủy (Nước biển lớn)'
];

export function getDayNapAm(jd) {
  const sexagenary = ((jd + 49) % 60 + 60) % 60;
  return NAP_AM[Math.floor(sexagenary / 2)];
}

const HUONG_XUAT_HANH = [
  { hyThan: 'Đông Bắc', taiThan: 'Đông Nam' }, // Giáp
  { hyThan: 'Tây Bắc', taiThan: 'Đông Nam' },  // Ất
  { hyThan: 'Tây Nam', taiThan: 'Chính Đông' },// Bính
  { hyThan: 'Chính Nam', taiThan: 'Chính Đông' },// Đinh
  { hyThan: 'Đông Nam', taiThan: 'Chính Bắc' },// Mậu
  { hyThan: 'Đông Bắc', taiThan: 'Chính Nam' },// Kỷ
  { hyThan: 'Tây Bắc', taiThan: 'Tây Nam' },   // Canh
  { hyThan: 'Tây Nam', taiThan: 'Tây Nam' },   // Tân
  { hyThan: 'Chính Nam', taiThan: 'Chính Tây' },// Nhâm
  { hyThan: 'Đông Nam', taiThan: 'Tây Bắc' }   // Quý
];

export function getXuatHanh(jd) {
  const { canIndex } = getDayCanChi(jd);
  return HUONG_XUAT_HANH[canIndex];
}

export function getTuoiHopXung(jd) {
  const { chiIndex } = getDayCanChi(jd);
  const xungIdx = (chiIndex + 6) % 12;
  const tamHop1 = (chiIndex + 4) % 12;
  const tamHop2 = (chiIndex + 8) % 12;
  return {
    xung: `${CHI[xungIdx]} (${CON_GIAP[xungIdx]})`,
    hop: `${CHI[tamHop1]} (${CON_GIAP[tamHop1]}), ${CHI[tamHop2]} (${CON_GIAP[tamHop2]})`
  };
}

/**
 * Nhị Thập Bát Tú (28 Stars) — aligned via (jd + 11) % 28
 */
const NHI_THAP_BAT_TU = [
  { name: 'Giác (Mộc Giao)', isGood: true, good: 'Cưới hỏi, xuất hành, xây dựng, thi cử, nhậm chức', bad: 'Chôn cất, sửa mộ' },
  { name: 'Cang (Kim Long)', isGood: false, good: 'Cắt may áo mới, thu dọn', bad: 'Cưới hỏi, động thổ, xuất hành đường thủy, kiện tụng' },
  { name: 'Đê (Thổ Lạc)', isGood: false, good: 'Tế tự, sửa chữa nhỏ', bad: 'Khởi công, cưới hỏi, xuất hành đường thủy, nhập trạch' },
  { name: 'Phòng (Nhật Thố)', isGood: true, good: 'Khởi công, động thổ, cưới hỏi, nhập trạch, xuất hành', bad: 'Kiện tụng, tranh chấp' },
  { name: 'Tâm (Nguyệt Hồ)', isGood: false, good: 'Tế tự, cầu an', bad: 'Khởi tạo, cưới hỏi, động thổ, xuất hành lớn' },
  { name: 'Vĩ (Hỏa Hổ)', isGood: true, good: 'Khởi công, xây dựng, cưới hỏi, mở cửa hàng, thủy lợi', bad: 'Đóng tàu, đi thuyền lớn' },
  { name: 'Cơ (Thủy Báo)', isGood: true, good: 'Khai trương, xuất hành, động thổ, thu tài, sửa nhà', bad: 'Cưới hỏi, kiện tụng' },
  { name: 'Đẩu (Mộc Giải)', isGood: true, good: 'Xây dựng, đào ao, khai trương, cưới hỏi, cắt may', bad: 'Đi xa đường sông biển' },
  { name: 'Ngưu (Kim Ngưu)', isGood: false, good: 'Đi thuyền, giao dịch nhỏ', bad: 'Khởi công xây dựng, cưới hỏi, động thổ' },
  { name: 'Nữ (Thổ Bức)', isGood: false, good: 'Cắt may, học nghề', bad: 'Khởi công, cưới hỏi, kiện tụng, an táng' },
  { name: 'Hư (Nhật Thử)', isGood: false, good: 'Tế tự, dọn dẹp', bad: 'Khởi công, cưới hỏi, khai trương, mở kho' },
  { name: 'Nguy (Nguyệt Yến)', isGood: false, good: 'Chôn cất, san lấp nhỏ', bad: 'Xây dựng, lợp mái, leo cao, đi đường thủy' },
  { name: 'Thất (Hỏa Trư)', isGood: true, good: 'Khởi công, động thổ, cưới hỏi, khai trương, xuất hành', bad: 'Tranh chấp, kiện tụng' },
  { name: 'Bích (Thủy Du)', isGood: true, good: 'Khởi tạo, cưới hỏi, nhập trạch, khai trương, chôn cất', bad: 'Xuất hành về hướng Nam' },
  { name: 'Khuê (Mộc Lang)', isGood: false, good: 'Học hành, thi cử, làm việc hành chính', bad: 'Động thổ, khởi công, khai trương, mở cửa hàng' },
  { name: 'Lâu (Kim Cẩu)', isGood: true, good: 'Khởi công, cưới hỏi, lập vườn, xây dựng, giao dịch', bad: 'Đóng giường, đi đường thủy' },
  { name: 'Vị (Thổ Trĩ)', isGood: true, good: 'Xây dựng, cưới hỏi, khai trương, chôn cất, công việc lớn', bad: 'Xuất hành đường sông nước' },
  { name: 'Mão (Nhật Kê)', isGood: false, good: 'Sửa chữa nhỏ, dọn dẹp', bad: 'Khởi công, cưới hỏi, mở cửa, xuất hành' },
  { name: 'Tất (Nguyệt Ô)', isGood: true, good: 'Khởi công, động thổ, cưới hỏi, khai trương, chôn cất', bad: 'Đi thuyền xa' },
  { name: 'Chủy (Hỏa Hầu)', isGood: false, good: 'Tế tự, tu dưỡng', bad: 'Khởi công, cưới hỏi, nhập trạch, chôn cất' },
  { name: 'Sâm (Thủy Viên)', isGood: true, good: 'Khởi công, xây dựng, khai trương, xuất hành, nhập học', bad: 'Cưới hỏi, chôn cất' },
  { name: 'Tỉnh (Mộc Hãn)', isGood: true, good: 'Tế tự, khởi công, thủy lợi, trồng trọt, thi cử', bad: 'May mặc, chôn cất' },
  { name: 'Quỷ (Kim Dương)', isGood: false, good: 'Chôn cất, cúng tế', bad: 'Khởi công, cưới hỏi, xuất hành, khai trương' },
  { name: 'Liễu (Thổ Chương)', isGood: false, good: 'Cúng tế, dọn dẹp', bad: 'Khởi công, cưới hỏi, nhập trạch, mở cửa hàng' },
  { name: 'Tinh (Nhật Mã)', isGood: false, good: 'Xây dựng nhỏ, trồng cây', bad: 'Cưới hỏi, chôn cất, khai trương lớn' },
  { name: 'Trương (Nguyệt Lộc)', isGood: true, good: 'Khởi công, cưới hỏi, khai trương, nhập trạch, tế tự', bad: 'Sửa chữa mộ phần' },
  { name: 'Dực (Hỏa Xà)', isGood: false, good: 'Cắt may, học tập', bad: 'Cưới hỏi, khởi công lớn, chôn cất' },
  { name: 'Chẩn (Thủy Dẫn)', isGood: true, good: 'Khởi công, cưới hỏi, xuất hành, khai trương, mua xe', bad: 'Đi thuyền xa' }
];

export function getNhiThapBatTu(jd) {
  const idx = ((jd + 11) % 28 + 28) % 28;
  return NHI_THAP_BAT_TU[idx];
}

/**
 * Lịch Xuất Hành Lý Thuần Phong (6 Cung)
 */
const LY_THUAN_PHONG = [
  { name: 'Đại An', isGood: true, desc: 'Rất tốt — Mọi việc đều thuận lợi, cầu tài hướng Tây Nam, nhà cửa bình an.' },
  { name: 'Lưu Niên', isGood: false, desc: 'Chậm trễ — Mưu sự khó thành ngay, dễ bị trì hoãn, tránh kiện tụng tranh cãi.' },
  { name: 'Tốc Hỷ', isGood: true, desc: 'Tin vui — Niềm vui sắp tới, cầu tài hướng Nam, nên tiến hành vào buổi sáng.' },
  { name: 'Xích Khẩu', isGood: false, desc: 'Khẩu thiệt — Dễ sinh bất hòa, tranh cãi; nên giữ lời ăn tiếng nói hòa nhã.' },
  { name: 'Tiểu Cát', isGood: true, desc: 'Cát lành — Có quý nhân phù trợ, buôn bán có lời, đi xa gặp nhiều may mắn.' },
  { name: 'Không Vong', isGood: false, desc: 'Hao tổn — Việc dễ trắc trở, hao tài; cần cẩn trọng giấy tờ và tiền bạc.' }
];

const LTP_HOUR_PAIRS = [
  '23-1h & 11-13h (Tý / Ngọ)',
  '1-3h & 13-15h (Sửu / Mùi)',
  '3-5h & 15-17h (Dần / Thân)',
  '5-7h & 17-19h (Mão / Dậu)',
  '7-9h & 19-21h (Thìn / Tuất)',
  '9-11h & 21-23h (Tỵ / Hợi)'
];

export function getLyThuanPhong(lunarMonth, lunarDay) {
  const dayIdx = ((lunarMonth + lunarDay - 2) % 6 + 6) % 6;
  const dayCung = LY_THUAN_PHONG[dayIdx];
  const hourSlots = LTP_HOUR_PAIRS.map((label, slotIdx) => {
    const idx = ((dayIdx + slotIdx) % 6 + 6) % 6;
    const cung = LY_THUAN_PHONG[idx];
    return { label, name: cung.name, isGood: cung.isGood };
  });
  return { dayCung, hourSlots };
}

/**
 * Bành Tổ Bách Kỵ Nhật (10 Thiên Can + 12 Địa Chi)
 */
const BANH_TO_CAN = [
  'Giáp: Bất khai thương tài vật hao vong (Không nên mở kho, xuất tiền lớn).',
  'Ất: Bất tài thực thiên chu bất trưởng (Không nên gieo trồng cây giống mới).',
  'Bính: Bất tu táo tất kiến hỏa ương (Không nên sửa bếp, đề phòng hỏa hoạn).',
  'Đinh: Bất thế đầu đầu chủ sinh sang (Không nên cắt tóc, cạo đầu).',
  'Mậu: Bất thụ điền điền chủ bất tường (Không nên nhận đất, sang tên ruộng đất).',
  'Kỷ: Bất phá khoán nhị chủ tịnh vong (Không nên hủy bỏ hợp đồng, giấy tờ).',
  'Canh: Bất kinh lạc chức cơ hư trương (Không nên dệt vải, khởi đầu việc may mặc lớn).',
  'Tân: Bất hợp tương chủ nhân bất thường (Không nên làm mắm, trộn tương, ủ men).',
  'Nhâm: Bất ương thủy nan canh đê phòng (Không nên khơi mương, tháo nước, đắp đê).',
  'Quý: Bất từ tụng lý nhược địch cường (Không nên kiện tụng vì bất lợi về lý).'
];

const BANH_TO_CHI = [
  'Tý: Bất vấn bốc tự nhạ tai ương (Không nên bói toán, cầu đoán).',
  'Sửu: Bất quan đới chủ bất hoàn hương (Không nên nhận chức lớn, đội mũ miện).',
  'Dần: Bất tế tự quỷ thần bất thường (Không nên tế lễ cầu cúng lớn).',
  'Mão: Bất xuyên tỉnh thủy tuyền bất hương (Không nên đào giếng nước).',
  'Thìn: Bất khốc khấp tất chủ trọng tang (Không nên khóc lóc, bi ai).',
  'Tỵ: Bất viễn hành tài vật phục tàng (Không nên đi xa, dễ thất lạc đồ đạc).',
  'Ngọ: Bất thiêm cái thất chủ canh trương (Không nên lợp mái, thay mái nhà).',
  'Mùi: Bất phục dược độc khí nhập tràng (Không nên uống thuốc mới không rõ nguồn).',
  'Thân: Bất an sàng quỷ túy nhập phòng (Không nên kê giường ngủ mới).',
  'Dậu: Bất hội khách túy đảo cuồng hương (Không nên tụ tập tiệc tùng quá chén).',
  'Tuất: Bất cật khuyển tác quái thượng sàng (Không nên ăn thịt chó).',
  'Hợi: Bất giá thú tất chủ phân trương (Không nên cưới hỏi).'
];

export function getBanhToBachKy(jd) {
  const { canIndex, chiIndex } = getDayCanChi(jd);
  return {
    can: BANH_TO_CAN[canIndex],
    chi: BANH_TO_CHI[chiIndex]
  };
}

/**
 * Check traditional taboo days (Tam Nương, Nguyệt Kỵ, Dương Công Kỵ, Sát Chủ, Thọ Tử)
 * and auspicious/inauspicious stars (Cát Tinh / Hung Tinh)
 */
const DUONG_CONG_KY = new Set([
  '13-1', '11-2', '9-3', '7-4', '5-5', '3-6', '8-7', '29-7', '27-8', '25-9', '23-10', '21-11', '19-12'
]);
const SAT_CHU_CHI = [5, 0, 7, 3, 8, 10, 1, 11, 6, 9, 2, 4]; // Month 1..12 -> Chi index
const THO_TU_CHI = [10, 4, 11, 5, 0, 6, 1, 7, 2, 8, 3, 9];  // Month 1..12 -> Chi index

export function getTabooAndStars(lunarMonth, lunarDay, jd) {
  const { canIndex, chiIndex } = getDayCanChi(jd);
  const taboos = [];

  if ([3, 7, 13, 18, 22, 27].includes(lunarDay)) {
    taboos.push({ name: 'Ngày Tam Nương', desc: 'Kỵ khai trương, xuất hành, cưới hỏi, khởi công lớn.' });
  }
  if ([5, 14, 23].includes(lunarDay)) {
    taboos.push({ name: 'Ngày Nguyệt Kỵ', desc: '"Mùng năm, mười bốn, hai ba — Đi chơi cũng lỗ huống là đi buôn".' });
  }
  if (DUONG_CONG_KY.has(`${lunarDay}-${lunarMonth}`)) {
    taboos.push({ name: 'Dương Công Kỵ Nhật', desc: 'Ngày đại kỵ khởi sự lớn theo lịch cổ truyền.' });
  }
  if (SAT_CHU_CHI[(lunarMonth - 1) % 12] === chiIndex) {
    taboos.push({ name: 'Ngày Sát Chủ', desc: 'Tránh động thổ, xây nhà, cưới hỏi, mua bán tài sản lớn.' });
  }
  if (THO_TU_CHI[(lunarMonth - 1) % 12] === chiIndex) {
    taboos.push({ name: 'Ngày Thọ Tử', desc: 'Tránh làm việc trọng đại, ký kết lớn, xuất hành xa.' });
  }

  // Selected authentic Cát Tinh / Hung Tinh by Lunar Month & Day Can/Chi
  const goodStars = [];
  const badStars = [];

  // Thiên Đức (by lunar month -> Can/Chi match)
  const thienDucCan = [3, -1, 8, 7, -1, 0, 9, -1, 2, 1, -1, 6];
  if (thienDucCan[(lunarMonth - 1) % 12] === canIndex) goodStars.push('Thiên Đức (Tốt mọi việc, hóa giải hung)');

  // Thiên Đức Hợp
  const thienDucHop = [8, -1, 3, 2, -1, 5, 4, -1, 7, 6, -1, 1];
  if (thienDucHop[(lunarMonth - 1) % 12] === canIndex) goodStars.push('Thiên Đức Hợp (Rất tốt cho cưới hỏi, khởi công)');

  // Nguyệt Đức (by lunar month -> Can)
  const nguyetDucCan = [2, 0, 8, 6, 2, 0, 8, 6, 2, 0, 8, 6];
  if (nguyetDucCan[(lunarMonth - 1) % 12] === canIndex) goodStars.push('Nguyệt Đức (Cát lành, tốt mọi việc)');

  // Nguyệt Đức Hợp
  const nguyetDucHop = [7, 5, 3, 1, 7, 5, 3, 1, 7, 5, 3, 1];
  if (nguyetDucHop[(lunarMonth - 1) % 12] === canIndex) goodStars.push('Nguyệt Đức Hợp (Thuận lợi giao dịch, hỷ sự)');

  // Thiên Hỷ (Month 1=Tuất(10), 2=Hợi(11)...)
  if ((lunarMonth + 9) % 12 === chiIndex) goodStars.push('Thiên Hỷ (Tốt cho cưới hỏi, đính hôn, hỷ sự)');

  // Sinh Khí (Month 1=Tý(0), 2=Sửu(1)...)
  if ((lunarMonth - 1) % 12 === chiIndex) goodStars.push('Sinh Khí (Tốt xây dựng, trồng trọt, khởi sự)');

  // Thiên Tài (Month 1=Thìn(4), 2=Ngọ(6)...)
  if (((lunarMonth - 1) * 2 + 4) % 12 === chiIndex) goodStars.push('Thiên Tài (Tốt cầu tài, khai trương)');

  // Địa Tài (Month 1=Tỵ(5), 2=Mùi(7)...)
  if (((lunarMonth - 1) * 2 + 5) % 12 === chiIndex) goodStars.push('Địa Tài (Tốt giao dịch, kinh doanh)');

  // Ngũ Phú (Month 1=Hợi(11), 2=Dần(2), 3=Tỵ(5), 4=Thân(8)...)
  if (((lunarMonth - 1) * 3 + 11) % 12 === chiIndex) goodStars.push('Ngũ Phú (Tốt mở kho, nhập trạch, cầu tài)');

  // Giải Thần (Month 1,2=Thân(8); 3,4=Tuất(10); 5,6=Tý(0); 7,8=Dần(2); 9,10=Thìn(4); 11,12=Ngọ(6))
  if ((Math.floor((lunarMonth - 1) / 2) * 2 + 8) % 12 === chiIndex) goodStars.push('Giải Thần (Hóa giải sao xấu, tốt cúng tế)');

  // Phổ Hộ (Month 1=Thân(8), 2=Dậu(9)...)
  if ((lunarMonth + 7) % 12 === chiIndex) goodStars.push('Phổ Hộ (Tốt cho xuất hành, cầu phúc)');

  // Mẫu Thương (Spring: Hợi/Tý, Summer: Dần/Mão, Autumn: Thìn/Tuất/Sửu/Mùi, Winter: Thân/Dậu)
  const season = Math.floor((lunarMonth - 1) / 3);
  const mauThuong = [[11, 0], [2, 3], [4, 10, 1, 7], [8, 9]];
  if (mauThuong[season].includes(chiIndex)) goodStars.push('Mẫu Thương (Tốt cầu tài, khai trương, xuất hành)');

  // Nguyệt Phá (clashes with month Chi)
  const monthChiIdx = (lunarMonth + 1) % 12;
  if ((monthChiIdx + 6) % 12 === chiIndex) badStars.push('Nguyệt Phá / Đại Hao (Kỵ xây dựng, cưới hỏi, đầu tư lớn)');

  // Tiểu Hao (Month 1=Mùi(7), 2=Thân(8)...)
  if ((lunarMonth + 6) % 12 === chiIndex) badStars.push('Tiểu Hao (Kỵ xuất tiền lớn, kinh doanh mạo hiểm)');

  // Tiểu Hồng Sa (Month 1,4,7,10 = Tỵ(5); 2,5,8,11 = Dậu(9); 3,6,9,12 = Sửu(1))
  const thsMap = [5, 9, 1];
  if (thsMap[(lunarMonth - 1) % 3] === chiIndex) badStars.push('Tiểu Hồng Sa (Nên thận trọng việc lớn)');

  // Thiên Cương (Month 1=Tỵ(5), 2=Tý(0), 3=Mùi(7)...)
  const thienCuong = [5, 0, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10];
  if (thienCuong[(lunarMonth - 1) % 12] === chiIndex) badStars.push('Thiên Cương (Kỵ xuất hành, khởi tạo)');

  // Trùng Tang (Month 1=Giáp, 2=Ất, 3=Mậu, 4=Bính, 5=Đinh, 6=Kỷ, 7=Canh, 8=Tân, 9=Mậu, 10=Nhâm, 11=Quý, 12=Kỷ)
  const trungTangCan = [0, 1, 4, 2, 3, 5, 6, 7, 4, 8, 9, 5];
  if (trungTangCan[(lunarMonth - 1) % 12] === canIndex) badStars.push('Trùng Tang (Kỵ chôn cất, cưới hỏi, khởi công)');

  // Cô Thần / Quả Tú
  const coThan = [10, 11, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  if (coThan[(lunarMonth - 1) % 12] === chiIndex) badStars.push('Cô Thần (Không tốt cho cưới hỏi)');

  // Hoang Vu (Spring: Tỵ/Dậu/Sửu, Summer: Thân/Tý/Thìn, Autumn: Hợi/Mão/Mùi, Winter: Dần/Ngọ/Tuất)
  const hoangVu = [[5, 9, 1], [8, 0, 4], [11, 3, 7], [2, 6, 10]];
  if (hoangVu[season].includes(chiIndex)) badStars.push('Hoang Vu (Kỵ khai trương, nhập trạch, cưới hỏi)');

  if (goodStars.length === 0) {
    goodStars.push('Ích Hậu / Tục Thế (Ổn định công việc thường nhật)');
  }
  if (badStars.length === 0 && taboos.length === 0) {
    badStars.push('Không có hung tinh lớn chiếu ngày');
  }

  return { taboos, goodStars, badStars };
}

/**
 * Hạc Thần (inauspicious departure direction by 60-day cycle)
 */
export function getHacThan(jd) {
  const idx = ((jd + 49) % 60 + 60) % 60;
  // Quý Tỵ (29) -> Mậu Thân (44): 16 days in Heaven (no earthly clash)
  if (idx >= 29 && idx <= 44) return 'Lên trời (Không kỵ hướng nào trên mặt đất)';
  if (idx >= 45 && idx <= 50) return 'Đông Bắc (nên tránh xuất hành hướng này)';
  if (idx >= 51 && idx <= 56) return 'Chính Đông (nên tránh xuất hành hướng này)';
  if (idx >= 57 || idx <= 2) return 'Đông Nam (nên tránh xuất hành hướng này)';
  if (idx >= 3 && idx <= 8) return 'Chính Nam (nên tránh xuất hành hướng này)';
  if (idx >= 9 && idx <= 14) return 'Tây Nam (nên tránh xuất hành hướng này)';
  if (idx >= 15 && idx <= 20) return 'Chính Tây (nên tránh xuất hành hướng này)';
  if (idx >= 21 && idx <= 25) return 'Tây Bắc (nên tránh xuất hành hướng này)';
  return 'Chính Bắc (nên tránh xuất hành hướng này)';
}

/**
 * Detailed Can-Chi & Ngũ Hành analysis of the day (like lichngaytot.com)
 */
const CAN_ELEMENT = ['Mộc', 'Mộc', 'Hỏa', 'Hỏa', 'Thổ', 'Thổ', 'Kim', 'Kim', 'Thủy', 'Thủy'];
const CHI_ELEMENT = ['Thủy', 'Thổ', 'Mộc', 'Mộc', 'Thổ', 'Hỏa', 'Hỏa', 'Thổ', 'Kim', 'Kim', 'Thổ', 'Thủy'];
const SINH_MAP = { Kim: 'Thủy', Thủy: 'Mộc', Mộc: 'Hỏa', Hỏa: 'Thổ', Thổ: 'Kim' };
const KHAC_MAP = { Kim: 'Mộc', Mộc: 'Thổ', Thổ: 'Thủy', Thủy: 'Hỏa', Hỏa: 'Kim' };

export function getDayNguHanhDetail(jd) {
  const { canIndex, chiIndex } = getDayCanChi(jd);
  const canEl = CAN_ELEMENT[canIndex];
  const chiEl = CHI_ELEMENT[chiIndex];
  const canYinYang = canIndex % 2 === 0 ? 'Dương' : 'Âm';
  const chiYinYang = chiIndex % 2 === 0 ? 'Dương' : 'Âm';

  let relation = '';
  let relationLevel = 'medium';
  if (canEl === chiEl) {
    relation = `Can Chi đồng hành (${canEl}) — Ngày bình hòa, ổn định.`;
    relationLevel = 'good';
  } else if (SINH_MAP[canEl] === chiEl) {
    relation = `Can (${canEl}) sinh Chi (${chiEl}) — Ngày Bảo Nhật (Đại Cát, rất thuận lợi).`;
    relationLevel = 'good';
  } else if (SINH_MAP[chiEl] === canEl) {
    relation = `Chi (${chiEl}) sinh Can (${canEl}) — Ngày Nghĩa Nhật (Cát lành, có quý nhân).`;
    relationLevel = 'good';
  } else if (KHAC_MAP[canEl] === chiEl) {
    relation = `Can (${canEl}) khắc Chi (${chiEl}) — Ngày Chế Nhật (Trung bình, cần kiên trì).`;
    relationLevel = 'medium';
  } else {
    relation = `Chi (${chiEl}) khắc Can (${canEl}) — Ngày Phạt Nhật (Nên thận trọng việc lớn).`;
    relationLevel = 'bad';
  }

  const napAmFull = getDayNapAm(jd);
  const napAmEl = ['Kim', 'Mộc', 'Thủy', 'Hỏa', 'Thổ'].find((el) => napAmFull.includes(el)) || canEl;
  const hopMenh = `${SINH_MAP[napAmEl]}, ${napAmEl}`;
  const khacMenh = KHAC_MAP[napAmEl];

  return {
    canDesc: `${CAN[canIndex]} (${canYinYang} ${canEl})`,
    chiDesc: `${CHI[chiIndex]} (${chiYinYang} ${chiEl})`,
    relation,
    relationLevel,
    napAmEl,
    hopMenh,
    khacMenh
  };
}

/**
 * Detailed Age Relationships (exact Can-Chi clashing ages + Lục Hợp, Tam Hợp, Tương Hại, Tứ Hành Xung)
 */
const LUC_HOP_IDX = [1, 0, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2];
const TUONG_HAI_IDX = [7, 6, 5, 4, 3, 2, 1, 0, 11, 10, 9, 8];
const TUONG_PHA_IDX = [9, 4, 11, 6, 1, 8, 3, 10, 5, 0, 7, 2];
const TU_HANH_XUNG_GROUPS = [
  ['Tý', 'Ngọ', 'Mão', 'Dậu'],
  ['Dần', 'Thân', 'Tỵ', 'Hợi'],
  ['Thìn', 'Tuất', 'Sửu', 'Mùi']
];

export function getDetailedAgeRelations(jd) {
  const { canIndex, chiIndex } = getDayCanChi(jd);
  const xungChiIdx = (chiIndex + 6) % 12;
  const tamHop1 = (chiIndex + 4) % 12;
  const tamHop2 = (chiIndex + 8) % 12;
  const lucHopIdx = LUC_HOP_IDX[chiIndex];
  const haiIdx = TUONG_HAI_IDX[chiIndex];
  const phaIdx = TUONG_PHA_IDX[chiIndex];

  // Specific clashing Can-Chi ages: opposing Chi paired with clashing Cans ((canIndex + 4)%10, (canIndex + 6)%10)
  // Ensure same polarity (even Can + even Chi, odd Can + odd Chi)
  const xungCans = [(canIndex + 4) % 10, (canIndex + 6) % 10, (canIndex + 2) % 10].filter(
    (c, idx, arr) => c % 2 === xungChiIdx % 2 && arr.indexOf(c) === idx
  );
  const exactXungAges = xungCans.slice(0, 3).map((c) => {
    // Find a recent representative birth year (1960..2019) for this Can-Chi
    let sampleYear = '';
    for (let y = 2015; y >= 1955; y--) {
      if ((y + 6) % 10 === c && (y + 8) % 12 === xungChiIdx) {
        sampleYear = ` (${y})`;
        break;
      }
    }
    return `${CAN[c]} ${CHI[xungChiIdx]}${sampleYear}`;
  });

  const tuHanhXung = TU_HANH_XUNG_GROUPS.find((g) => g.includes(CHI[chiIndex]))?.join(' – ') || '';

  return {
    exactXung: exactXungAges.join(', '),
    lucHop: `${CHI[lucHopIdx]} (${CON_GIAP[lucHopIdx]})`,
    tamHop: `${CHI[tamHop1]} (${CON_GIAP[tamHop1]}), ${CHI[tamHop2]} (${CON_GIAP[tamHop2]})`,
    tuongHai: `${CHI[haiIdx]} (${CON_GIAP[haiIdx]})`,
    tuongPha: `${CHI[phaIdx]} (${CON_GIAP[phaIdx]})`,
    tuHanhXung
  };
}

/**
 * Ngày Xuất Hành theo Khổng Minh (based on lunar month group & lunar day)
 */
const KHONG_MINH_DAYS = [
  { name: 'Đường Phong', isGood: true, desc: 'Rất tốt — Xuất hành thuận lợi, cầu tài được như ý, gặp quý nhân.' },
  { name: 'Kim Thổ', isGood: false, desc: 'Xấu — Ra đi dễ gặp trắc trở, cầu tài khó thành, nên hoãn việc lớn.' },
  { name: 'Kim Dương', isGood: true, desc: 'Tốt — Có quý nhân phù trợ, tài lộc hanh thông, thưa kiện có lý.' },
  { name: 'Thuần Dương', isGood: true, desc: 'Rất tốt — Xuất hành đi hay về đều cát lợi, cầu tài đắc lợi.' },
  { name: 'Đạo Tặc', isGood: false, desc: 'Xấu — Đề phòng mất mát tài sản, giấy tờ, tránh giao dịch rủi ro.' },
  { name: 'Thiên Đạo', isGood: false, desc: 'Trung bình — Xuất hành cầu tài tốn kém, cần tính toán kỹ.' },
  { name: 'Thiên Môn', isGood: true, desc: 'Rất tốt — Làm mọi việc đều thuận buồm xuôi gió, cầu gì được nấy.' },
  { name: 'Thiên Đường', isGood: true, desc: 'Tốt — Xuất hành gặp nhiều may mắn, quý nhân giúp đỡ.' },
  { name: 'Thiên Tài', isGood: true, desc: 'Tốt — Rất tốt cho cầu tài, khai trương, giao dịch kinh doanh.' },
  { name: 'Thiên Tặc', isGood: false, desc: 'Xấu — Không nên đi xa, dễ gặp trở ngại ngoài ý muốn.' },
  { name: 'Thiên Dương', isGood: true, desc: 'Tốt — Xuất hành thuận lợi, cầu tài dễ thành, gặp người tốt.' },
  { name: 'Thiên Thương', isGood: true, desc: 'Khá tốt — Gặp gỡ cấp trên, đối tác thuận lợi, tránh tranh cãi.' },
  { name: 'Thanh Long Đầu', isGood: true, desc: 'Rất tốt — Xuất hành sớm gặp vận may lớn, cầu tài thắng lợi.' },
  { name: 'Thanh Long Kiếp', isGood: true, desc: 'Tốt — Đi 4 phương 8 hướng đều bình an, trăm sự như ý.' },
  { name: 'Chu Tước', isGood: false, desc: 'Xấu — Tránh tranh chấp, kiện tụng, giữ hòa khí khi thương lượng.' },
  { name: 'Bạch Hổ Đầu', isGood: true, desc: 'Khá tốt — Mọi việc tiến triển thuận lợi, nhất là việc kinh doanh.' },
  { name: 'Bạch Hổ Kiếp', isGood: true, desc: 'Tốt — Xuất hành hướng Nam hoặc Bắc đều gặp may mắn.' },
  { name: 'Huyền Vũ', isGood: false, desc: 'Xấu — Tránh cãi vã, đi xa cần cẩn trọng sức khỏe và hành lý.' }
];

export function getKhongMinhXuatHanh(lunarMonth, lunarDay) {
  // Traditional 3-group cycle by lunar month (1/4/7/10, 2/5/8/11, 3/6/9/12)
  const groupOffset = ((lunarMonth - 1) % 3) * 6;
  const idx = (groupOffset + (lunarDay - 1)) % KHONG_MINH_DAYS.length;
  return KHONG_MINH_DAYS[idx];
}

/**
 * Vị trí Thai Thần trong ngày (theo Thiên Can & Địa Chi ngày)
 */
const THAI_THAN_CAN = [
  'Chiếm môn (Cửa chính)', 'Chiếm ma (Cối xay / nhà bếp)', 'Chiếm trù táo (Bếp nấu)',
  'Chiếm thương khố (Kho chứa đồ)', 'Chiếm phòng sàng (Phòng ngủ / giường)',
  'Chiếm môn (Cửa ra vào)', 'Chiếm ma (Bếp / đồ gia dụng)', 'Chiếm trù táo (Bếp núc)',
  'Chiếm thương khố (Tủ / kho)', 'Chiếm phòng sàng (Giường ngủ)'
];
const THAI_THAN_DIR = [
  'ngoài hướng Đông Nam', 'ngoài hướng Đông Nam', 'ngoài hướng Chính Nam', 'ngoài hướng Chính Nam',
  'ngoài hướng Tây Nam', 'ngoài hướng Tây Nam', 'ngoài hướng Chính Tây', 'ngoài hướng Tây Bắc',
  'ngoài hướng Chính Bắc', 'ngoài hướng Đông Bắc', 'ngoài hướng Đông Bắc', 'ngoài hướng Chính Đông'
];

export function getThaiThan(jd) {
  const { canIndex, chiIndex } = getDayCanChi(jd);
  return `${THAI_THAN_CAN[canIndex]} — ${THAI_THAN_DIR[chiIndex]} (Phụ nữ mang thai hạn chế sửa chữa, đục đẽo, xê dịch đồ vật tại vị trí này).`;
}

/**
 * 10-Task Verdict Checklist (like lichngaytot.com's "Việc nên làm / Không nên làm")
 */
const DAY_TASKS_CHECKLIST = [
  { name: 'Cưới hỏi', goodTruc: ['Trực Thành', 'Trực Định', 'Trực Mãn', 'Trực Khai', 'Trực Bình'], badTruc: ['Trực Phá', 'Trực Bế', 'Trực Nguy', 'Trực Trừ'] },
  { name: 'Khai trương', goodTruc: ['Trực Khai', 'Trực Thành', 'Trực Mãn', 'Trực Định'], badTruc: ['Trực Phá', 'Trực Bế', 'Trực Nguy'] },
  { name: 'Xuất hành', goodTruc: ['Trực Kiến', 'Trực Khai', 'Trực Thành', 'Trực Mãn', 'Trực Trừ'], badTruc: ['Trực Phá', 'Trực Bế', 'Trực Thu'] },
  { name: 'Động thổ / Xây nhà', goodTruc: ['Trực Thành', 'Trực Khai', 'Trực Định', 'Trực Mãn', 'Trực Chấp'], badTruc: ['Trực Kiến', 'Trực Phá', 'Trực Nguy'] },
  { name: 'Nhập trạch', goodTruc: ['Trực Mãn', 'Trực Thành', 'Trực Định', 'Trực Khai'], badTruc: ['Trực Phá', 'Trực Chấp', 'Trực Bế', 'Trực Nguy'] },
  { name: 'Ký hợp đồng', goodTruc: ['Trực Định', 'Trực Thành', 'Trực Khai', 'Trực Mãn', 'Trực Thu'], badTruc: ['Trực Phá', 'Trực Nguy', 'Trực Bế'] },
  { name: 'Mua xe / Nhà', goodTruc: ['Trực Thành', 'Trực Mãn', 'Trực Định', 'Trực Khai', 'Trực Thu'], badTruc: ['Trực Phá', 'Trực Nguy', 'Trực Bế'] },
  { name: 'Cúng tế / Cầu phúc', goodTruc: ['Trực Trừ', 'Trực Mãn', 'Trực Định', 'Trực Thành', 'Trực Nguy', 'Trực Kiến'], badTruc: ['Trực Phá'] },
  { name: 'Nhậm chức / Học hành', goodTruc: ['Trực Kiến', 'Trực Thành', 'Trực Khai', 'Trực Định'], badTruc: ['Trực Phá', 'Trực Bế'] },
  { name: 'An táng / Sang cát', goodTruc: ['Trực Trừ', 'Trực Mãn', 'Trực Định', 'Trực Thành', 'Trực Nguy'], badTruc: ['Trực Kiến', 'Trực Phá', 'Trực Khai'] }
];

export function getDailyTaskVerdicts(lunarMonth, lunarDay, jd) {
  const hoangDao = getDayHoangDao(lunarMonth, jd);
  const truc = getDayTruc(lunarMonth, jd);
  const batTu = getNhiThapBatTu(jd);
  const { taboos } = getTabooAndStars(lunarMonth, lunarDay, jd);

  return DAY_TASKS_CHECKLIST.map((task) => {
    let score = 50;
    if (hoangDao.isGood) score += 20; else score -= 12;
    if (batTu.isGood) score += 12; else score -= 10;
    if (task.goodTruc.includes(truc.name)) score += 22;
    else if (task.badTruc.includes(truc.name)) score -= 24;
    if (taboos.length > 0 && task.name !== 'Cúng tế / Cầu phúc') score -= 18;

    if (score >= 76) return { name: task.name, level: 'excellent', label: 'Rất tốt' };
    if (score >= 58) return { name: task.name, level: 'good', label: 'Khá tốt' };
    if (score >= 42) return { name: task.name, level: 'medium', label: 'Trung bình' };
    return { name: task.name, level: 'bad', label: 'Nên tránh' };
  });
}

/**
 * Moon Phase from Lunar Day (1..30)
 */
export function getMoonPhase(lunarDay) {
  if (lunarDay === 1) return { icon: '🌑', name: 'Trăng mới (Ngày Sóc)' };
  if (lunarDay <= 6) return { icon: '🌒', name: 'Trăng lưỡi liềm đầu tháng' };
  if (lunarDay <= 8) return { icon: '🌓', name: 'Trăng bán nguyệt đầu tháng' };
  if (lunarDay <= 14) return { icon: '🌔', name: 'Trăng khuyết dần tròn' };
  if (lunarDay <= 16) return { icon: '🌕', name: 'Trăng tròn (Ngày Rằm / Vọng)' };
  if (lunarDay <= 21) return { icon: '🌖', name: 'Trăng khuyết cuối tháng' };
  if (lunarDay <= 23) return { icon: '🌗', name: 'Trăng bán nguyệt cuối tháng' };
  return { icon: '🌘', name: 'Trăng tàn cuối tháng' };
}

/**
 * Western Zodiac sign for solar day/month
 */
export function getZodiacSign(dd, mm) {
  const signs = [
    [1, 19, '♑ Ma Kết'], [2, 18, '♒ Bảo Bình'], [3, 20, '♓ Song Ngư'],
    [4, 19, '♈ Bạch Dương'], [5, 20, '♉ Kim Ngưu'], [6, 21, '♊ Song Tử'],
    [7, 22, '♋ Cự Giải'], [8, 22, '♌ Sư Tử'], [9, 22, '♍ Xử Nữ'],
    [10, 23, '♎ Thiên Bình'], [11, 22, '♏ Bọ Cạp'], [12, 21, '♐ Nhân Mã'],
    [12, 31, '♑ Ma Kết']
  ];
  for (const [m, d, label] of signs) {
    if (mm < m || (mm === m && dd <= d)) return label;
  }
  return '♑ Ma Kết';
}

const DAILY_QUOTES = [
  'Có công mài sắt, có ngày nên kim.',
  'Uống nước nhớ nguồn, ăn quả nhớ kẻ trồng cây.',
  'Một cây làm chẳng nên non, ba cây chụm lại nên hòn núi cao.',
  'Đi một ngày đàng, học một sàng khôn.',
  'Tốt gỗ hơn tốt nước sơn.',
  'Lửa thử vàng, gian nan thử sức.',
  'Kiến tha lâu cũng đầy tổ.',
  'Thuận vợ thuận chồng tát biển Đông cũng cạn.',
  'Lời nói chẳng mất tiền mua, lựa lời mà nói cho vừa lòng nhau.',
  'Cây ngay không sợ chết đứng.',
  'Chớ thấy sóng cả mà ngã tay chèo.',
  'Bầu ơi thương lấy bí cùng, tuy rằng khác giống nhưng chung một giàn.',
  'Ở hiền gặp lành, ăn ở có đức mặc sức mà ăn.',
  'Học ăn, học nói, học gói, học mở.',
  'Thời gian là vàng bạc — biết quý hôm nay là gieo mầm cho ngày mai.',
  'Tâm an vạn sự an, lòng tĩnh trăm việc thuận.',
  'Kính trên nhường dưới, gia đạo hưng long.',
  'Chậm mà chắc còn hơn nhanh mà vội.',
  'Gieo nhân nào gặt quả nấy, làm việc thiện ắt gặp phúc lành.',
  'Đoàn kết là sức mạnh, chia sẻ là niềm vui.',
  'Sức khỏe là vốn quý nhất của đời người — đừng quên nghỉ ngơi và uống đủ nước.',
  'Thất bại là mẹ thành công, kiên trì là chìa khóa mở mọi cánh cửa.',
  'Lùi một bước biển rộng trời cao, nhường một câu gia hòa vạn sự hưng.',
  'Mỗi buổi sáng là một khởi đầu mới đầy cơ hội tốt lành.'
];

export function getDailyQuote(jd) {
  return DAILY_QUOTES[((jd % DAILY_QUOTES.length) + DAILY_QUOTES.length) % DAILY_QUOTES.length];
}

/**
 * 24 Tiết Khí seasonal health & nutrition guidance (Dưỡng sinh theo Tiết khí)
 */
const TIET_KHI_HEALTH = {
  'Lập Xuân': 'Khí xuân mới khởi — ngủ dậy sớm, vận động nhẹ kéo giãn gân cốt, nên ăn rau xanh tươi (hẹ, giá đỗ, rau mùi) để dưỡng gan.',
  'Vũ Thủy': 'Ẩm ướt mưa xuân — giữ ấm vùng lưng & bàn chân, hạn chế đồ sống lạnh, nên uống trà gừng nhẹ, ăn cháo kê, táo đỏ kiện tỳ.',
  'Kinh Trập': 'Khí dương vượng dần — dễ khô họng, nên ăn lê hấp, mật ong, rau xanh thanh mát, giữ tinh thần thư thái tránh nóng giận.',
  'Xuân Phân': 'Âm dương cân bằng — duy trì giờ ngủ đều đặn, kết hợp rau củ thanh đạm với đạm dễ tiêu, đi bộ ngoài trời hít thở sâu.',
  'Thanh Minh': 'Trời ấm dễ dị ứng phấn hoa — nên ăn rau chân vịt, măng tươi, trà hoa cúc thanh gan, hạn chế đồ cay nóng nhiều dầu mỡ.',
  'Cốc Vũ': 'Độ ẩm tăng cao — phòng cảm ẩm & đau khớp bằng gừng, ý dĩ, đậu đỏ; tập thể dục vừa sức ra mồ hôi nhẹ.',
  'Lập Hạ': 'Bắt đầu vào hè — ưu tiên dưỡng tâm, ngủ trưa 20–30 phút, ăn đậu xanh, mướp đắng, dưa leo và uống đủ nước mỗi ngày.',
  'Tiểu Mãn': 'Nắng ẩm xen kẽ — dễ mệt mỏi, nên ăn đồ thanh đạm giải nhiệt như bí đao, rau má, hạt sen; tránh thức khuya.',
  'Mang Chủng': 'Trời oi nóng — uống nước đều cả ngày (kể cả khi chưa khát), ăn canh chua nhẹ, trái cây mọng nước, tránh tắm nước lạnh ngay khi đi nắng về.',
  'Hạ Chí': 'Ngày dài nhất năm — tránh nắng gắt 11h–15h, bổ sung nước điện giải tự nhiên (nước dừa, chanh muối), ăn nhẹ bữa tối.',
  'Tiểu Thử': 'Nắng nóng cao điểm — giữ phòng thoáng mát, ăn chè đậu xanh, canh bí đao, mướp hương; ngủ trưa để dưỡng thần.',
  'Đại Thử': 'Nóng nhất trong năm — tăng cường uống nước, ăn canh mát bổ khí (hạt sen, ngó sen, dưa hấu), hạn chế đồ chiên rán.',
  'Lập Thu': 'Nắng hanh đầu thu — phổi dễ khô, nên ăn lê, ngân nhĩ, mật ong, hạt sen; hạn chế ăn quá cay.',
  'Xử Thử': 'Chênh lệch nhiệt độ sáng tối — dễ bị cảm lạnh nhẹ, tối ngủ đắp chăn mỏng, nên ăn cháo loãng ấm bụng, uống trà hoa cúc.',
  'Bạch Lộ': 'Sương sớm bắt đầu lạnh — giữ ấm cổ họng & bụng khi sáng sớm, ăn khoai lang, củ sen, táo đỏ nhuận phế.',
  'Thu Phân': 'Trời khô mát — dưỡng âm nhuận táo bằng mè đen, hạt óc chó, lê, mật ong; tập hít thở sâu buổi sáng.',
  'Hàn Lộ': 'Khí lạnh rõ hơn — giữ ấm bàn chân (ngâm chân nước ấm trước khi ngủ), ăn canh nóng, tránh uống nước đá lạnh.',
  'Sương Giáng': 'Giao mùa sang đông — bồi bổ tỳ vị với bí đỏ, khoai từ, thịt nạc hầm, hạt dẻ; mặc áo khoác mỏng khi ra đường sớm.',
  'Lập Đông': 'Bắt đầu mùa đông — ngủ sớm hơn một chút, tăng thực phẩm ấm bổ thận như canh gừng, gà hầm, đậu đen, rau củ màu sẫm.',
  'Tiểu Tuyết': 'Trời chuyển lạnh khô — giữ ấm cổ, vai gáy & bàn chân; uống nước ấm, nên ăn thực phẩm bổ thận như mè đen, đậu đen, canh gừng ấm.',
  'Đại Tuyết': 'Lạnh sâu — chú ý giữ ấm đầu và chân khi ra ngoài sáng sớm; ăn đồ nóng sốt (cháo ấm, súp, củ cải trắng, thịt hầm), vận động làm ấm cơ thể.',
  'Đông Chí': 'Đêm dài nhất năm, dương khí bắt đầu sinh — thời điểm vàng để bồi bổ nhẹ nhàng, giữ ấm, ngủ đủ giấc và hạn chế làm việc quá sức.',
  'Tiểu Hàn': 'Rét đậm đầu năm — ăn bữa sáng nóng đủ năng lượng, bổ sung gừng, tỏi, táo đỏ, hạt sen; khởi động kỹ trước khi tập thể dục.',
  'Đại Hàn': 'Lạnh nhất trong năm — giữ ấm đường hô hấp, uống trà gừng mật ong ấm, ăn canh nóng giàu dinh dưỡng, chuẩn bị sức khỏe đón Tết.'
};

export function getTietKhiHealthTip(tietKhiName) {
  return TIET_KHI_HEALTH[tietKhiName] || 'Giữ nếp sinh hoạt điều độ, uống đủ nước và vận động nhẹ mỗi ngày để cơ thể khỏe mạnh.';
}

/**
 * Simple Biorhythm (Nhịp sinh học: Thể chất 23d, Cảm xúc 28d, Trí tuệ 33d) based on birthYear (or birthDate)
 */
export function getBiorhythmForDate(birthYearOrDate, dd, mm, yy) {
  if (!birthYearOrDate) return null;
  let birthJd = null;
  if (typeof birthYearOrDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(birthYearOrDate)) {
    const [by, bm, bd] = birthYearOrDate.split('-').map(Number);
    birthJd = jdFromDate(bd, bm, by);
  } else {
    const by = Number(birthYearOrDate);
    if (!Number.isFinite(by) || by < 1920 || by > 2050) return null;
    birthJd = jdFromDate(1, 1, by);
  }
  const targetJd = jdFromDate(dd, mm, yy);
  const daysAlive = targetJd - birthJd;
  if (daysAlive < 0) return null;

  const pct = (period) => Math.round(((Math.sin((2 * Math.PI * daysAlive) / period) + 1) / 2) * 100);
  const physical = pct(23);
  const emotional = pct(28);
  const intellectual = pct(33);
  const avg = Math.round((physical + emotional + intellectual) / 3);
  return { physical, emotional, intellectual, avg };
}

/**
 * Compute exact days / weeks / working days between two YYYY-MM-DD solar dates
 */
export function computeDateDiff(fromDateKey, toDateKey) {
  const m1 = /^(\d{4})-(\d{2})-(\d{2})$/.exec(fromDateKey || '');
  const m2 = /^(\d{4})-(\d{2})-(\d{2})$/.exec(toDateKey || '');
  if (!m1 || !m2) return null;
  const d1 = new Date(Number(m1[1]), Number(m1[2]) - 1, Number(m1[3]));
  const d2 = new Date(Number(m2[1]), Number(m2[2]) - 1, Number(m2[3]));
  const signedDays = Math.round((d2 - d1) / 86400000);
  const absDays = Math.abs(signedDays);
  const weeks = Math.floor(absDays / 7);
  const remDays = absDays % 7;
  const approxMonths = (absDays / 30.4375).toFixed(1);

  // Count weekdays (Mon-Fri)
  const start = d1 <= d2 ? d1 : d2;
  const end = d1 <= d2 ? d2 : d1;
  let workDays = 0;
  if (absDays <= 4000) {
    const cur = new Date(start.getTime());
    while (cur < end) {
      const dow = cur.getDay();
      if (dow !== 0 && dow !== 6) workDays++;
      cur.setDate(cur.getDate() + 1);
    }
  } else {
    workDays = Math.round((absDays * 5) / 7);
  }

  return { signedDays, absDays, weeks, remDays, approxMonths, workDays };
}

/**
 * Compile complete Vietnamese almanac details for a solar date
 */
export function getFullDayDetails(dd, mm, yy, timeZone = TIMEZONE_VN) {
  const lunar = convertSolar2Lunar(dd, mm, yy, timeZone);
  const jd = lunar.jd;
  const jsDate = new Date(yy, mm - 1, dd);
  const startOfYear = new Date(yy, 0, 1);
  const endOfYear = new Date(yy, 11, 31);
  const dayOfYear = Math.floor((jsDate - startOfYear) / 86400000) + 1;
  const totalDaysInYear = Math.floor((endOfYear - startOfYear) / 86400000) + 1;
  const weekOfYear = Math.ceil((dayOfYear + startOfYear.getDay()) / 7);

  const yearChiIdx = (lunar.year + 8) % 12;
  const dayCanChi = getDayCanChi(jd);
  const hours = getHoursDetail(jd);

  return {
    solar: {
      day: dd,
      month: mm,
      year: yy,
      weekday: THU_VN[jsDate.getDay()],
      dayOfYear,
      daysRemaining: totalDaysInYear - dayOfYear,
      weekOfYear,
      zodiac: getZodiacSign(dd, mm)
    },
    lunar,
    lunarFormatted: formatLunarDateFull(lunar),
    moonPhase: getMoonPhase(lunar.day),
    canChi: {
      year: getYearCanChi(lunar.year),
      yearAnimal: CON_GIAP[yearChiIdx],
      month: getMonthCanChi(lunar.month, lunar.year),
      day: dayCanChi.name,
      hourStart: hours.firstHourCanChi
    },
    napAm: getDayNapAm(jd),
    nguHanhDetail: getDayNguHanhDetail(jd),
    tietKhi: getTietKhi(jd, timeZone),
    tietKhiHealth: getTietKhiHealthTip(getTietKhi(jd, timeZone)),
    hoangDaoDay: getDayHoangDao(lunar.month, jd),
    truc: getDayTruc(lunar.month, jd),
    hours,
    xuatHanh: { ...getXuatHanh(jd), hacThan: getHacThan(jd) },
    tuoiHopXung: getTuoiHopXung(jd),
    ageRelations: getDetailedAgeRelations(jd),
    batTu: getNhiThapBatTu(jd),
    lyThuanPhong: getLyThuanPhong(lunar.month, lunar.day),
    khongMinh: getKhongMinhXuatHanh(lunar.month, lunar.day),
    thaiThan: getThaiThan(jd),
    taskVerdicts: getDailyTaskVerdicts(lunar.month, lunar.day, jd),
    banhTo: getBanhToBachKy(jd),
    tabooAndStars: getTabooAndStars(lunar.month, lunar.day, jd),
    dailyQuote: getDailyQuote(jd)
  };
}

/**
 * Format Lunar Day in Vietnamese (e.g., "Mùng 1", "Rằm", "23")
 */
export function formatLunarDayShort(day, month, leap = false) {
  if (day === 1) {
    return `1/${month}${leap ? 'N' : ''}`;
  }
  return `${day}`;
}

export function formatLunarDateFull(lunar) {
  const dayLabel = lunar.day <= 10 ? `Mùng ${lunar.day}` : lunar.day === 15 ? 'Rằm (15)' : `Ngày ${lunar.day}`;
  const monthLabel = `tháng ${LUNAR_MONTH_NAMES[lunar.month] || lunar.month}${lunar.leap ? ' (Nhuận)' : ''}`;
  return `${dayLabel} ${monthLabel}`;
}
