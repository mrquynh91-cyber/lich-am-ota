/**
 * Super-App Module Group 2 (v3.0.0 — PC + OPPO Find X9):
 *  1. AI Chấm điểm Phong thủy không gian (AI Camera — bàn làm việc, phòng ngủ, bàn thờ, phòng khách, bếp)
 *  2. Thần số học Pythagoras & Rút bài Tarot AI (22 lá Ẩn Chính Xuôi/Ngược)
 *  3. Gieo quẻ Kinh Dịch (64 Quẻ) & Xin xăm Quan Âm (100 Quẻ) — Hỗ trợ Lắc điện thoại!
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import { compressImageSourceToBase64 } from './moles.js';
import { getBirthProfile } from './auspicious.js';
import { getCungPhi } from './tuvi-compat.js';
import { isGeminiConfigured, askGeminiGeneral, getLastGeminiMeta } from './gemini-ai.js';
import { shareToZaloQuick } from './zalo.js';
import { openSmartCamera, attachCameraControlBar, removeCameraControlBar } from './camera-helper.js';

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function fmtMd(raw) {
  return escHtml(raw)
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*([^*\n]+)\*(?=$|[\s,.;:!?])/g, '$1<em>$2</em>')
    .replace(/^\s*---\s*$/gm, '<hr style="border:none;border-top:1px solid #E5E7EB;margin:6px 0;" />')
    .replace(/^\s*[\*\-]\s+/gm, '• ');
}

/* ==================== 1. AI CHẤM ĐIỂM PHONG THỦY KHÔNG GIAN (AI CAMERA) ==================== */

const SPACE_TYPES = [
  { id: 'desk', label: '💻 Bàn làm việc' },
  { id: 'bedroom', label: '🛏️ Phòng ngủ' },
  { id: 'altar', label: '🏮 Bàn thờ gia tiên / Thần Tài' },
  { id: 'living', label: '🛋️ Phòng khách' },
  { id: 'kitchen', label: '🍳 Phòng bếp' },
  { id: 'door', label: '🚪 Cửa chính / Mặt tiền' }
];

const COMPASS_DIRS = [
  { name: 'Bắc', short: 'B', deg: 0 },
  { name: 'Đông Bắc', short: 'ĐB', deg: 45 },
  { name: 'Đông', short: 'Đ', deg: 90 },
  { name: 'Đông Nam', short: 'ĐN', deg: 135 },
  { name: 'Nam', short: 'N', deg: 180 },
  { name: 'Tây Nam', short: 'TN', deg: 225 },
  { name: 'Tây', short: 'T', deg: 270 },
  { name: 'Tây Bắc', short: 'TB', deg: 315 }
];

// Classical Bát Trạch Star Lookup: Kua Name -> { Direction: [StarName, isGood, shortDesc] }
const BAT_TRACH_MAP = {
  'Khảm': {
    'Đông Nam': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Đông': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Nam': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Bắc': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Tây': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Đông Bắc': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Tây Bắc': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Tây Nam': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  },
  'Ly': {
    'Đông': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Đông Nam': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Bắc': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Nam': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Đông Bắc': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Tây': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Tây Nam': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Tây Bắc': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  },
  'Chấn': {
    'Nam': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Bắc': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Đông Nam': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Đông': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Tây Nam': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Tây Bắc': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Đông Bắc': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Tây': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  },
  'Tốn': {
    'Bắc': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Nam': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Đông': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Đông Nam': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Tây Bắc': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Tây Nam': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Tây': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Đông Bắc': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  },
  'Càn': {
    'Tây': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Đông Bắc': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Tây Nam': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Tây Bắc': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Đông Nam': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Đông': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Bắc': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Nam': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  },
  'Khôn': {
    'Đông Bắc': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Tây': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Tây Bắc': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Tây Nam': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Đông': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Đông Nam': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Nam': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Bắc': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  },
  'Cấn': {
    'Tây Nam': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Tây Bắc': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Tây': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Đông Bắc': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Nam': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Bắc': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Đông': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Đông Nam': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  },
  'Đoài': {
    'Tây Bắc': ['Sinh Khí', true, 'Đại Cát • Tài lộc, thăng tiến'],
    'Tây Nam': ['Thiên Y', true, 'Cát • Sức khỏe, quý nhân'],
    'Đông Bắc': ['Diên Niên', true, 'Cát • Hòa thuận, bền vững'],
    'Tây': ['Phục Vị', true, 'Tiểu Cát • Bình an, tập trung'],
    'Bắc': ['Họa Hại', false, 'Tiểu Hung • Dễ thị phi nhỏ'],
    'Nam': ['Ngũ Quỷ', false, 'Hung • Hao tài, bất hòa'],
    'Đông Nam': ['Lục Sát', false, 'Hung • Rối rắm, tiểu nhân'],
    'Đông': ['Tuyệt Mệnh', false, 'Đại Hung • Cần hóa giải']
  }
};

function headingToDirObj(deg) {
  const norm = ((Math.round(deg) % 360) + 360) % 360;
  const idx = Math.floor(((norm + 22.5) % 360) / 45);
  return { deg: norm, ...COMPASS_DIRS[idx] };
}

function buildCompassSvgHtml(kuaName) {
  const map = BAT_TRACH_MAP[kuaName] || null;
  const cx = 110, cy = 110, rOut = 98, rIn = 40;
  const polar = (r, deg) => {
    const rad = ((deg - 90) * Math.PI) / 180;
    return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)];
  };

  const wedges = COMPASS_DIRS.map((d) => {
    const a1 = d.deg - 22.5, a2 = d.deg + 22.5;
    const [x1, y1] = polar(rOut, a1);
    const [x2, y2] = polar(rOut, a2);
    const [x3, y3] = polar(rIn, a2);
    const [x4, y4] = polar(rIn, a1);
    const info = map?.[d.name];
    const fill = info ? (info[1] ? '#DCFCE7' : '#FEE2E2') : '#F8FAFC';
    const stroke = info ? (info[1] ? '#10B981' : '#EF4444') : '#CBD5E1';
    const txtCol = info ? (info[1] ? '#065F46' : '#991B1B') : '#334155';
    const [lx, ly] = polar(78, d.deg);
    const [sx, sy] = polar(58, d.deg);
    const starShort = info ? info[0] : '';
    return `
      <path d="M${x1.toFixed(1)},${y1.toFixed(1)} A${rOut},${rOut} 0 0,1 ${x2.toFixed(1)},${y2.toFixed(1)} L${x3.toFixed(1)},${y3.toFixed(1)} A${rIn},${rIn} 0 0,0 ${x4.toFixed(1)},${y4.toFixed(1)} Z" fill="${fill}" stroke="${stroke}" stroke-width="1" />
      <text x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="11" font-weight="800" fill="${txtCol}" transform="rotate(${d.deg} ${lx.toFixed(1)} ${ly.toFixed(1)})">${d.short}</text>
      ${starShort ? `<text x="${sx.toFixed(1)}" y="${sy.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="7.5" font-weight="700" fill="${txtCol}" transform="rotate(${d.deg} ${sx.toFixed(1)} ${sy.toFixed(1)})">${starShort}</text>` : ''}
    `;
  }).join('');

  // Degree ticks every 15°
  let ticks = '';
  for (let a = 0; a < 360; a += 15) {
    const major = a % 45 === 0;
    const [x1, y1] = polar(rOut, a);
    const [x2, y2] = polar(rOut - (major ? 7 : 4), a);
    ticks += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#475569" stroke-width="${major ? 1.5 : 0.8}" />`;
  }

  return `
    <svg viewBox="0 0 220 220" width="210" height="210" class="fs-compass-svg">
      <circle cx="110" cy="110" r="106" fill="#0F172A" stroke="#D97706" stroke-width="3" />
      <g class="fs-compass-rotor">
        ${wedges}
        ${ticks}
        <circle cx="110" cy="110" r="${rIn}" fill="#FFFBEB" stroke="#D97706" stroke-width="1.8" />
        <text x="110" y="106" text-anchor="middle" font-size="11" font-weight="900" fill="#991B1B">${kuaName ? `Cung ${kuaName}` : 'Bát Trạch'}</text>
        <text x="110" y="121" text-anchor="middle" font-size="9" font-weight="700" fill="#78350F">La Bàn VN</text>
      </g>
      <!-- Fixed red aiming arrow at 12 o'clock -->
      <polygon points="110,4 103,20 117,20" fill="#EF4444" stroke="#FFFFFF" stroke-width="1.5" />
      <line x1="110" y1="20" x2="110" y2="34" stroke="#EF4444" stroke-width="2" />
    </svg>
  `;
}

export function mountFengShuiSpaceModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { isMobile = false, getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onSendTelegram = null } = opts;
  const defYear = String(getState()?.auspiciousPrefs?.birthYear || '');

  let spaceType = 'desk';
  let gender = 'male';
  let activeStream = null;
  let activeFacing = 'environment';
  let capturedBase64 = '';
  let lastPlain = '';
  let busy = false;

  // Live Feng Shui Compass state
  let compassOpen = false;
  let compassListening = false;
  let compassHeading = 0; // 0..359
  let lockedHeadingText = '';
  let webCompassHandler = null;
  let hasLiveSensorSignal = false;

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-teal">
        <div>
          <h2 class="sf-hero-title">🏠 AI Chấm Điểm Phong Thủy Không Gian</h2>
          <div class="sf-hero-sub">Tích hợp Quét La Bàn Bát Trạch trực tiếp + AI Camera soi lỗi bố trí, chấm điểm /100 &amp; gợi ý cây xanh, vật phẩm hợp mệnh.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-fs-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <div class="sf-field">
          <label>Chọn không gian cần soi phong thủy:</label>
          <div class="sf-pills" id="fs-space-pills">
            ${SPACE_TYPES.map((s, i) => `<button type="button" class="sf-pill${i === 0 ? ' active' : ''}" data-sp="${s.id}">${s.label}</button>`).join('')}
          </div>
        </div>

        <div class="sf-grid-3">
          <div class="sf-field">
            <label for="fs-year">Năm sinh gia chủ</label>
            <input id="fs-year" type="number" min="1920" max="2045" placeholder="VD: 1991" value="${escHtml(defYear)}" />
          </div>
          <div class="sf-field">
            <label for="fs-gender">Giới tính</label>
            <select id="fs-gender"><option value="male">👨 Nam</option><option value="female">👩 Nữ</option></select>
          </div>
          <div class="sf-field">
            <label for="fs-dir">Hướng (tùy chọn)</label>
            <select id="fs-dir">
              <option value="">Chưa rõ hướng</option>
              <option value="Đông">Đông</option><option value="Tây">Tây</option>
              <option value="Nam">Nam</option><option value="Bắc">Bắc</option>
              <option value="Đông Nam">Đông Nam</option><option value="Đông Bắc">Đông Bắc</option>
              <option value="Tây Nam">Tây Nam</option><option value="Tây Bắc">Tây Bắc</option>
            </select>
          </div>
        </div>
        <div id="fs-kua-banner" class="sf-kv-item hidden" style="margin-bottom:8px;background:#F0FDFA;border-color:#99F6E4;"></div>

        <!-- Integrated Live Bát Trạch Compass Bar & Panel -->
        <div class="sf-btn-row" style="margin-bottom:8px;">
          <button type="button" id="btn-fs-compass-toggle" class="sf-btn emerald" style="flex:1;">🧭 Quét La Bàn Phong Thủy</button>
          <span id="fs-locked-dir-badge" class="sf-badge info hidden"></span>
        </div>

        <div id="fs-compass-panel" class="fs-compass-panel hidden">
          <div style="font-size:11.5px;font-weight:700;color:#0F766E;text-align:center;margin-bottom:6px;" id="fs-compass-hint">
            🧭 Hướng đỉnh điện thoại về phía bàn/cửa/bàn thờ — Vùng <strong>Xanh = Hướng Tốt</strong>, <strong>Đỏ = Hướng Xấu</strong> theo tuổi!
          </div>
          <div id="fs-compass-dial-wrap" class="fs-compass-dial-wrap"></div>
          <div class="fs-compass-readout">
            <div id="fs-compass-deg" class="fs-compass-deg">0° — Bắc</div>
            <div id="fs-compass-verdict" class="fs-compass-verdict"></div>
          </div>
          <div style="margin:6px 0 8px;">
            <input id="fs-compass-slider" type="range" min="0" max="359" value="0" style="width:100%;accent-color:#0D9488;" title="Kéo xoay thử góc La Bàn (0°–359°)" />
          </div>
          <div class="sf-btn-row" style="justify-content:center;">
            <button type="button" id="btn-fs-compass-lock" class="sf-btn primary">📌 Chốt hướng này vào AI</button>
            <button type="button" id="btn-fs-compass-close" class="sf-btn">Đóng La Bàn</button>
          </div>
        </div>

        <div class="mole-stage" id="fs-stage" style="border-color:#0D9488;position:relative;">
          <video id="fs-video" class="mole-media hidden" autoplay playsinline muted></video>
          <img id="fs-preview" class="mole-photo-img hidden" alt="Ảnh không gian phong thủy" />
          <div id="fs-cam-hud" class="fs-cam-hud hidden">🧭 0° Bắc</div>
          <div id="fs-empty" class="mole-placeholder">
            <div style="font-size:38px;margin-bottom:4px;">🏠🧭</div>
            <div>Bấm <strong>📷 Chụp góc phòng</strong> (kèm La Bàn trực tiếp) hoặc <strong>📁 Tải ảnh không gian</strong> để AI soi lỗi phong thủy ngay</div>
          </div>
        </div>

        <div class="sf-btn-row" style="margin-bottom:8px;">
          <button type="button" id="btn-fs-cam" class="sf-btn primary">📷 Chụp ảnh &amp; Quét hướng</button>
          <button type="button" id="btn-fs-snap" class="sf-btn ai hidden">✨ Chụp &amp; Soi ngay</button>
          <button type="button" id="btn-fs-stop" class="sf-btn hidden">Tắt cam</button>
          <label class="sf-btn" style="cursor:pointer;">
            📁 Tải ảnh lên
            <input id="fs-file" type="file" accept="image/*" class="hidden" />
          </label>
          <input id="fs-cam-fb" type="file" accept="image/*" capture="environment" class="hidden" />
          <button type="button" id="btn-fs-run" class="sf-btn ai hidden">✨ Chấm điểm lại bằng AI</button>
        </div>

        <div class="sf-field" style="margin-bottom:0;">
          <input id="fs-note" type="text" placeholder="Ghi chú thêm (VD: sau lưng là cửa sổ, bên phải có gương, muốn đặt thêm cây...)" maxlength="180" />
        </div>
        <div id="fs-status" class="sf-status"></div>
      </div>

      <div id="fs-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong id="fs-ai-title">✨ Kết quả Chấm điểm Phong thủy không gian</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-fs-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-fs-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-fs-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div id="fs-ai-body" class="dream-result-body"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  const videoEl = q('#fs-video');
  const prevEl = q('#fs-preview');
  const emptyEl = q('#fs-empty');

  const getCurrentKua = () => {
    const y = Number(q('#fs-year').value || 0);
    gender = q('#fs-gender').value || 'male';
    return (y >= 1920 && y <= 2045) ? getCungPhi(y, gender) : null;
  };

  const renderCompassDial = () => {
    const kua = getCurrentKua();
    const wrap = q('#fs-compass-dial-wrap');
    if (wrap) wrap.innerHTML = buildCompassSvgHtml(kua?.name || '');
    applyCompassHeadingUi(compassHeading);
  };

  const applyCompassHeadingUi = (deg) => {
    const info = headingToDirObj(deg);
    compassHeading = info.deg;
    const rotor = q('.fs-compass-rotor');
    if (rotor) {
      rotor.setAttribute('transform', `rotate(${-info.deg} 110 110)`);
    }
    const slider = q('#fs-compass-slider');
    if (slider && document.activeElement !== slider) slider.value = String(info.deg);

    const kua = getCurrentKua();
    const bt = kua?.name ? BAT_TRACH_MAP[kua.name]?.[info.name] : null;

    const degEl = q('#fs-compass-deg');
    if (degEl) degEl.textContent = `${info.deg}° — Hướng ${info.name}`;

    const verdEl = q('#fs-compass-verdict');
    if (verdEl) {
      if (bt) {
        verdEl.innerHTML = `<span class="sf-badge ${bt[1] ? 'good' : 'bad'}">${bt[1] ? '✅ HƯỚNG TỐT' : '⚠️ HƯỚNG XẤU'} • ${bt[0]}</span> <span style="font-size:11.5px;color:#475569;">${bt[2]}</span>`;
      } else {
        verdEl.innerHTML = '<span style="font-size:11.5px;color:#64748B;">Nhập Năm sinh gia chủ ở trên để La Bàn tự chấm cung Tốt/Xấu Bát Trạch!</span>';
      }
    }

    const hud = q('#fs-cam-hud');
    if (hud) {
      hud.textContent = bt
        ? `🧭 ${info.deg}° ${info.name} • ${bt[1] ? '✅' : '⚠️'} ${bt[0]}`
        : `🧭 ${info.deg}° ${info.name}`;
      hud.classList.toggle('good', Boolean(bt?.[1]));
      hud.classList.toggle('bad', Boolean(bt && !bt[1]));
    }
  };

  const startCompassSensor = () => {
    if (compassListening) return;
    compassListening = true;
    hasLiveSensorSignal = false;

    // 1. Native Android Hardware Magnetometer/RotationVector bridge (OPPO Find X9 APK)
    if (typeof window !== 'undefined' && window.AndroidBridge && typeof window.AndroidBridge.startCompass === 'function') {
      window.__onNativeCompassHeading = (deg) => {
        if (!compassListening) return;
        hasLiveSensorSignal = true;
        applyCompassHeadingUi(Number(deg) || 0);
      };
      try { window.AndroidBridge.startCompass(); } catch (_e) {}
    }

    // 2. Standard Web DeviceOrientationAbsolute / DeviceOrientation fallback
    const onOrient = (ev) => {
      if (!compassListening) return;
      let heading = null;
      if (typeof ev.webkitCompassHeading === 'number' && !Number.isNaN(ev.webkitCompassHeading)) {
        heading = ev.webkitCompassHeading;
      } else if (ev.alpha !== null && typeof ev.alpha === 'number') {
        heading = (360 - ev.alpha) % 360;
      }
      if (heading !== null && !hasLiveSensorSignal) {
        applyCompassHeadingUi(heading);
      }
    };
    webCompassHandler = onOrient;
    if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
      DeviceOrientationEvent.requestPermission().then((r) => {
        if (r === 'granted') {
          window.addEventListener('deviceorientationabsolute', onOrient, true);
          window.addEventListener('deviceorientation', onOrient, true);
        }
      }).catch(() => {});
    } else {
      window.addEventListener('deviceorientationabsolute', onOrient, true);
      window.addEventListener('deviceorientation', onOrient, true);
    }
  };

  const stopCompassSensor = () => {
    if (!compassListening) return;
    compassListening = false;
    if (typeof window !== 'undefined' && window.AndroidBridge && typeof window.AndroidBridge.stopCompass === 'function') {
      try { window.AndroidBridge.stopCompass(); } catch (_e) {}
    }
    if (webCompassHandler) {
      window.removeEventListener('deviceorientationabsolute', webCompassHandler, true);
      window.removeEventListener('deviceorientation', webCompassHandler, true);
      webCompassHandler = null;
    }
  };

  const lockCurrentCompassDirection = (silent = false) => {
    const info = headingToDirObj(compassHeading);
    const kua = getCurrentKua();
    const bt = kua?.name ? BAT_TRACH_MAP[kua.name]?.[info.name] : null;
    q('#fs-dir').value = info.name;
    lockedHeadingText = `${info.name} (${info.deg}°${bt ? ` — Cung ${bt[0]}: ${bt[1] ? 'Hướng Tốt' : 'Hướng Xấu'}` : ''})`;
    const badge = q('#fs-locked-dir-badge');
    if (badge) {
      badge.classList.remove('hidden');
      badge.className = `sf-badge ${bt ? (bt[1] ? 'good' : 'bad') : 'info'}`;
      badge.textContent = `🧭 Đã chốt: ${info.deg}° ${info.name}${bt ? ` (${bt[0]})` : ''}`;
    }
    if (!silent) {
      q('#fs-status').className = 'sf-status';
      q('#fs-status').textContent = `🧭 Đã chốt hướng La Bàn: ${lockedHeadingText} — AI sẽ phân tích chuẩn theo hướng này!`;
    }
  };

  const updateKuaBanner = () => {
    const y = Number(q('#fs-year').value || 0);
    gender = q('#fs-gender').value || 'male';
    const box = q('#fs-kua-banner');
    if (y >= 1920 && y <= 2045) {
      const prof = getBirthProfile(y);
      const kua = getCungPhi(y, gender);
      box.classList.remove('hidden');
      box.innerHTML = `🧭 <strong>${prof?.canChi}</strong> • Mệnh <strong>${prof?.napAmName} (${prof?.element})</strong> • Cung <strong>${kua?.name} (${kua?.group})</strong><br/>✨ Hướng tốt: <strong>${kua?.goodDirs}</strong>`;
    } else {
      box.classList.add('hidden');
    }
    renderCompassDial();
  };
  updateKuaBanner();
  q('#fs-year')?.addEventListener('input', updateKuaBanner);
  q('#fs-gender')?.addEventListener('change', updateKuaBanner);
  q('#fs-dir')?.addEventListener('change', (e) => {
    const val = e.target.value;
    if (!val) {
      lockedHeadingText = '';
      q('#fs-locked-dir-badge')?.classList.add('hidden');
    } else {
      const d = COMPASS_DIRS.find((x) => x.name === val);
      if (d) {
        compassHeading = d.deg;
        applyCompassHeadingUi(d.deg);
      }
      lockedHeadingText = val;
    }
  });

  q('#btn-fs-compass-toggle')?.addEventListener('click', () => {
    compassOpen = !compassOpen;
    q('#fs-compass-panel')?.classList.toggle('hidden', !compassOpen);
    q('#btn-fs-compass-toggle').textContent = compassOpen ? '🧭 Đang quét La Bàn (Ẩn)' : '🧭 Quét La Bàn Phong Thủy';
    if (compassOpen) {
      renderCompassDial();
      startCompassSensor();
    } else if (!activeStream) {
      stopCompassSensor();
    }
  });

  q('#btn-fs-compass-close')?.addEventListener('click', () => {
    compassOpen = false;
    q('#fs-compass-panel')?.classList.add('hidden');
    q('#btn-fs-compass-toggle').textContent = '🧭 Quét La Bàn Phong Thủy';
    if (!activeStream) stopCompassSensor();
  });

  q('#btn-fs-compass-lock')?.addEventListener('click', () => {
    lockCurrentCompassDirection(false);
  });

  q('#fs-compass-slider')?.addEventListener('input', (e) => {
    applyCompassHeadingUi(Number(e.target.value) || 0);
  });

  const stopCamera = () => {
    if (activeStream) {
      activeStream.getTracks().forEach((t) => { try { t.stop(); } catch (_e) {} });
      activeStream = null;
    }
    if (videoEl) { videoEl.srcObject = null; videoEl.classList.add('hidden'); }
    removeCameraControlBar(q('#fs-stage'));
    q('#fs-cam-hud')?.classList.add('hidden');
    q('#btn-fs-snap')?.classList.add('hidden');
    q('#btn-fs-stop')?.classList.add('hidden');
    q('#btn-fs-cam')?.classList.remove('hidden');
    if (!compassOpen) stopCompassSensor();
    if (!capturedBase64) emptyEl?.classList.remove('hidden');
    else prevEl?.classList.remove('hidden');
  };

  const runAiScan = async () => {
    if (!capturedBase64 || busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#fs-status').className = 'sf-status err';
      q('#fs-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-fs-cfg">Nhập Key</button>';
      q('#btn-fs-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-fs-run').disabled = true;
    q('#fs-status').className = 'sf-status';
    q('#fs-status').textContent = '✨ Gemini Vision AI đang soi bố cục, hướng La Bàn Bát Trạch & chấm điểm phong thủy...';
    q('#fs-ai-card').classList.remove('hidden');
    q('#fs-ai-body').innerHTML = '✨ Đang quan sát không gian & đối chiếu hướng La Bàn...';
    try {
      const spLabel = SPACE_TYPES.find((s) => s.id === spaceType)?.label || 'Không gian sống';
      const y = Number(q('#fs-year').value || 0);
      const prof = y ? getBirthProfile(y) : null;
      const kua = y ? getCungPhi(y, gender) : null;
      const dir = lockedHeadingText || q('#fs-dir').value;
      const note = q('#fs-note').value.trim();

      const prompt = `Quan sát kỹ bức ảnh "${spLabel}" này.
${prof ? `Gia chủ: ${gender === 'female' ? 'Nữ' : 'Nam'} sinh năm ${y} (${prof.canChi}), Mệnh ${prof.napAmName} (Hành ${prof.element}), Cung ${kua?.name} (${kua?.group}), hướng tốt: ${kua?.goodDirs}.` : ''}
${dir ? `🧭 Hướng đo trực tiếp bằng La Bàn Phong Thủy: ${dir}. (Hãy đánh giá kỹ mức độ hợp/khắc Bát Trạch của hướng này với gia chủ và cách hóa giải cụ thể nếu phạm hướng xấu!)` : ''}
${note ? `Ghi chú thêm: ${note}` : ''}

Hãy chấm điểm phong thủy không gian kết hợp thiết kế khoa học hiện đại (ánh sáng, thông gió, công thái học) bằng tiếng Việt ấm áp, thực tế theo 5 mục:
**1. 🏆 Điểm Phong Thủy Tổng Quan:** (Chấm cụ thể X/100 điểm kèm đánh giá nhanh hướng La Bàn${dir ? ` ${dir}` : ''}).
**2. ✅ Điểm tốt đang có trong ảnh:** (Khen rõ những chi tiết thực tế nhìn thấy trong ảnh).
**3. ⚠️ Các lỗi phong thủy / hướng & bố trí cần khắc phục:** (Chỉ rõ lỗi thật thấy trong ảnh như gương chiếu giường, bàn quay lưng cửa, dây điện rối, thiếu sáng, vị trí đồ thờ/bếp... — không bịa đặt nếu ảnh không có).
**4. 🌿 Gợi ý cây xanh, màu sắc & vật phẩm hợp mệnh${prof ? ` (${prof.element})` : ''}:** (2–3 gợi ý dễ mua, đẹp mắt).
**5. 💡 3 bước chỉnh sửa / hóa giải đơn giản làm được ngay hôm nay:**`;

      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là chuyên gia Phong thủy Bát Trạch kết hợp kiến trúc sư nội thất hiện đại, tư vấn thực tế, dễ làm, không mê tín.',
        userPrompt: prompt,
        images: [capturedBase64],
        temperature: 0.4,
        thinkingLevel: 'MEDIUM',
        timeoutMs: 30000
      }, (p) => { if (p) q('#fs-ai-body').innerHTML = fmtMd(p); });
      const meta = getLastGeminiMeta();
      lastPlain = `🏠 Chấm điểm Phong thủy ${spLabel}${dir ? ` (${dir})` : ''}\n\n${ans}`;
      q('#fs-ai-title').textContent = `✨ Kết quả Phong thủy${meta?.model ? ` (${meta.model} • ${(meta.ms / 1000).toFixed(1)}s)` : ''}`;
      q('#fs-ai-body').innerHTML = fmtMd(ans);
      q('#fs-status').textContent = '✅ Đã chấm điểm phong thủy & phân tích hướng La Bàn xong!';
    } catch (err) {
      q('#fs-status').className = 'sf-status err';
      q('#fs-status').textContent = `⚠️ ${err?.message || 'Lỗi phân tích ảnh'}`;
    } finally {
      busy = false;
      q('#btn-fs-run').disabled = false;
    }
  };

  const acceptSource = (src, fromLiveCamera = false) => {
    if (fromLiveCamera && (hasLiveSensorSignal || compassOpen)) {
      lockCurrentCompassDirection(true);
    }
    const { dataUrl, base64 } = compressImageSourceToBase64(src, 1100, 0.88, false);
    capturedBase64 = base64;
    stopCamera();
    prevEl.src = dataUrl;
    prevEl.classList.remove('hidden');
    emptyEl.classList.add('hidden');
    q('#btn-fs-run').classList.remove('hidden');
    runAiScan();
  };

  const handleFile = (f) => {
    if (!f) return;
    const img = new Image();
    const u = URL.createObjectURL(f);
    img.onload = () => { URL.revokeObjectURL(u); acceptSource(img, false); };
    img.onerror = () => { URL.revokeObjectURL(u); q('#fs-status').textContent = '⚠️ Không đọc được ảnh.'; };
    img.src = u;
  };

  q('#btn-fs-back')?.addEventListener('click', () => { stopCamera(); stopCompassSensor(); onBack(); });
  q('#fs-space-pills')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-pill');
    if (!b) return;
    spaceType = b.dataset.sp || 'desk';
    q('#fs-space-pills').querySelectorAll('.sf-pill').forEach((x) => x.classList.toggle('active', x === b));
  });
  const startFsCamera = async (preferredDeviceId = null) => {
    if (!navigator.mediaDevices?.getUserMedia) {
      if (isMobile) q('#fs-cam-fb')?.click();
      else q('#fs-status').textContent = '⚠️ Hãy bấm "📁 Tải ảnh lên" hoặc mở toàn trang để dùng Camera.';
      return;
    }
    try {
      stopCamera();
      const ctrl = await openSmartCamera(activeFacing, { preferredDeviceId });
      activeStream = ctrl.stream;
      videoEl.srcObject = ctrl.stream;
      videoEl.classList.remove('hidden');
      try { await videoEl.play(); } catch (_e) {}
      prevEl.classList.add('hidden');
      emptyEl.classList.add('hidden');
      q('#fs-cam-hud')?.classList.remove('hidden');
      q('#btn-fs-snap').classList.remove('hidden');
      q('#btn-fs-stop').classList.remove('hidden');
      q('#btn-fs-cam').classList.add('hidden');
      startCompassSensor();
      attachCameraControlBar(q('#fs-stage'), ctrl, {
        onSwitchRearLens: (devId) => startFsCamera(devId),
        onOpenNativeCamera: isMobile ? () => { stopCamera(); q('#fs-cam-fb')?.click(); } : null
      });
    } catch (_e) {
      if (isMobile) q('#fs-cam-fb')?.click();
      else q('#fs-status').textContent = '⚠️ Không mở được Camera — hãy dùng "📁 Tải ảnh lên".';
    }
  };
  q('#btn-fs-cam')?.addEventListener('click', () => startFsCamera(null));
  q('#btn-fs-stop')?.addEventListener('click', stopCamera);
  q('#btn-fs-snap')?.addEventListener('click', () => { if (videoEl?.videoWidth) acceptSource(videoEl, true); });
  q('#fs-file')?.addEventListener('change', (e) => { handleFile(e.target.files?.[0]); e.target.value = ''; });
  q('#fs-cam-fb')?.addEventListener('change', (e) => { handleFile(e.target.files?.[0]); e.target.value = ''; });
  q('#btn-fs-run')?.addEventListener('click', runAiScan);
  q('#btn-fs-copy')?.addEventListener('click', async () => { if (lastPlain) { try { await navigator.clipboard.writeText(lastPlain); } catch (_e) {} q('#fs-status').textContent = '✓ Đã sao chép!'; } });
  q('#btn-fs-zalo')?.addEventListener('click', () => { if (lastPlain) shareToZaloQuick(lastPlain); });
  q('#btn-fs-tg')?.addEventListener('click', (e) => { if (lastPlain && onSendTelegram) onSendTelegram(escHtml(lastPlain), e.currentTarget); });

  return { stopCamera: () => { stopCamera(); stopCompassSensor(); } };
}

/* ==================== 2. THẦN SỐ HỌC PYTHAGORAS & RÚT BÀI TAROT AI ==================== */

const LIFE_PATH_INFO = {
  2: ['Người Hòa Giải & Trực Giác', 'Nhạy cảm, khéo léo, giàu tình cảm và có khả năng kết nối con người tuyệt vời.'],
  3: ['Người Truyền Cảm Hứng & Sáng Tạo', 'Hoạt ngôn, lạc quan, óc thẩm mỹ tốt và luôn mang lại năng lượng tích cực.'],
  4: ['Người Kiến Tạo & Kỷ Luật', 'Thực tế, chắc chắn, đáng tin cậy và xây dựng sự nghiệp bền vững từ gốc.'],
  5: ['Người Tự Do & Khám Phá', 'Linh hoạt, yêu trải nghiệm mới, giỏi giao tiếp và thích ứng nhanh với thay đổi.'],
  6: ['Người Yêu Thương & Trách Nhiệm', 'Ấm áp, hướng về gia đình, giàu lòng nhân ái và có gu thẩm mỹ tinh tế.'],
  7: ['Người Tri Thức & Chiêm Nghiệm', 'Sâu sắc, thích nghiên cứu bản chất vấn đề, trực giác mạnh và độc lập.'],
  8: ['Người Điều Hành & Thịnh Vượng', 'Bản lĩnh, tư duy tài chính và quản trị xuất sắc, dễ tạo dựng thành tựu lớn.'],
  9: ['Người Nhân Đạo & Lý Tưởng', 'Rộng lượng, có tầm nhìn cộng đồng, luôn sẵn sàng cống hiến và sẻ chia.'],
  10: ['Người Tiên Phong & Tự Chủ', 'Độc lập, quyết đoán, có tố chất dẫn đầu và khả năng xoay chuyển tình thế.'],
  11: ['Bậc Thầy Trực Giác (Master 11)', 'Nhạy bén tâm linh, giàu cảm hứng và có sức lan tỏa tinh thần mạnh mẽ.'],
  22: ['Kiến Trúc Sư Vĩ Đại (Master 22)', 'Kết hợp giữa tầm nhìn lớn và năng lực thực thi phi thường để biến ước mơ thành thật.'],
  33: ['Bậc Thầy Chữa Lành (Master 33)', 'Trái tim nhân ái sâu rộng, dẫn dắt và nâng đỡ mọi người bằng tình yêu thương.']
};

const TAROT_MAJOR = [
  { id: 0, name: 'The Fool (Chàng Khờ)', ico: '🃏', up: 'Khởi đầu mới đầy tự do, niềm tin và cơ hội bất ngờ.', rev: 'Chậm lại để tính toán rủi ro, tránh vội vàng.' },
  { id: 1, name: 'The Magician (Nhà Ảo Thuật)', ico: '🪄', up: 'Đủ nguồn lực & kỹ năng để biến ý tưởng thành hiện thực.', rev: 'Tránh phân tán năng lượng, hãy tập trung 1 mục tiêu.' },
  { id: 2, name: 'The High Priestess (Nữ Tư Tế)', ico: '🌙', up: 'Hãy tin vào trực giác và quan sát kỹ trước khi hành động.', rev: 'Đừng bỏ qua tín hiệu bên trong, cần lắng nghe lòng mình.' },
  { id: 3, name: 'The Empress (Nữ Hoàng)', ico: '👑', up: 'Trù phú, sáng tạo, tình cảm đong đầy và tài lộc nảy nở.', rev: 'Dành thời gian chăm sóc bản thân nhiều hơn.' },
  { id: 4, name: 'The Emperor (Hoàng Đế)', ico: '🏛️', up: 'Ổn định, kỷ luật, quyền lực và nền tảng vững chắc.', rev: 'Bớt cứng nhắc, linh hoạt hơn trong quản lý & giao tiếp.' },
  { id: 5, name: 'The Hierophant (Giáo Hoàng)', ico: '📜', up: 'Học hỏi từ người có kinh nghiệm, đi theo con đường chính đạo.', rev: 'Dám thử cách làm mới sáng tạo ngoài khuôn mẫu cũ.' },
  { id: 6, name: 'The Lovers (Tình Nhân)', ico: '💞', up: 'Sự hòa hợp sâu sắc, lựa chọn đúng đắn theo tiếng gọi con tim.', rev: 'Cần cân bằng lại kỳ vọng và trao đổi thẳng thắn.' },
  { id: 7, name: 'The Chariot (Cỗ Xe)', ico: '🛞', up: 'Quyết tâm cao độ sẽ mang lại chiến thắng và bứt phá nhanh.', rev: 'Kiểm soát cảm xúc để giữ vững tay lái.' },
  { id: 8, name: 'Strength (Sức Mạnh)', ico: '🦁', up: 'Nội lực mềm dẻo, lòng kiên nhẫn chiến thắng mọi trở ngại.', rev: 'Tin tưởng hơn vào giá trị và khả năng của chính mình.' },
  { id: 9, name: 'The Hermit (Ẩn Sĩ)', ico: '🕯️', up: 'Khoảng lặng quý giá để nhìn sâu, tìm ra câu trả lời sáng suốt.', rev: 'Đừng tự cô lập quá lâu, hãy chia sẻ với người tin cậy.' },
  { id: 10, name: 'Wheel of Fortune (Bánh Xe Vận Mệnh)', ico: '☸️', up: 'Bước ngoặt may mắn đang đến, thời vận xoay chuyển tích cực!', rev: 'Giai đoạn chuyển giao — kiên nhẫn chờ sóng lặng.' },
  { id: 11, name: 'Justice (Công Lý)', ico: '⚖️', up: 'Minh bạch, công bằng, gieo nhân tốt gặt quả xứng đáng.', rev: 'Rà soát kỹ giấy tờ, hợp đồng và giữ sự khách quan.' },
  { id: 12, name: 'The Hanged Man (Người Treo Ngược)', ico: '⏳', up: 'Thay đổi góc nhìn sẽ thấy lối mở hoàn toàn mới.', rev: 'Đã đến lúc dừng chần chừ và đưa ra quyết định.' },
  { id: 13, name: 'Death (Chuyển Hóa)', ico: '🦋', up: 'Khép lại chương cũ để đón nhận sự tái sinh tươi mới hơn.', rev: 'Mạnh dạn buông bỏ thói quen cũ không còn phù hợp.' },
  { id: 14, name: 'Temperance (Chừng Mực)', ico: '🏺', up: 'Cân bằng, hài hòa, kiên nhẫn sẽ tạo nên kết quả bền lâu.', rev: 'Tránh cực đoan, điều chỉnh lại nhịp sống điều độ.' },
  { id: 15, name: 'The Devil (Ràng Buộc)', ico: '⛓️', up: 'Tham vọng mạnh mẽ — cần tỉnh táo trước cám dỗ ngắn hạn.', rev: 'Tín hiệu giải thoát khỏi áp lực hoặc thói quen xấu!' },
  { id: 16, name: 'The Tower (Tòa Tháp)', ico: '⚡', up: 'Thay đổi đột ngột giúp phơi bày sự thật và xây nền mới chắc hơn.', rev: 'Chủ động điều chỉnh sớm để tránh biến động bất ngờ.' },
  { id: 17, name: 'The Star (Ngôi Sao)', ico: '⭐', up: 'Hy vọng sáng rực, chữa lành, bình an và quý nhân dẫn lối!', rev: 'Giữ vững niềm tin, ánh sáng vẫn ở ngay phía trước.' },
  { id: 18, name: 'The Moon (Mặt Trăng)', ico: '🌕', up: 'Trực giác nhạy bén — hãy kiểm chứng thông tin rõ ràng trước khi chốt.', rev: 'Sương mù dần tan, sự thật đang trở nên sáng tỏ.' },
  { id: 19, name: 'The Sun (Mặt Trời)', ico: '☀️', up: 'Đại cát! Niềm vui, thành công rực rỡ, minh bạch và tràn đầy sinh lực!', rev: 'Thành công vẫn đến nhưng cần thêm chút kiên nhẫn.' },
  { id: 20, name: 'Judgement (Phán Xét)', ico: '🎺', up: 'Thời khắc thức tỉnh, thăng cấp và bước sang trang mới rực rỡ.', rev: 'Tha thứ cho sai sót cũ để tự tin tiến lên.' },
  { id: 21, name: 'The World (Thế Giới)', ico: '🌍', up: 'Hoàn thành viên mãn, gặt hái thành quả trọn vẹn & mở tầm nhìn rộng!', rev: 'Chỉ còn 1 bước cuối nữa là về đích — đừng bỏ dở.' }
];

function reduceNum(n, keepMaster = true) {
  let v = Number(n) || 0;
  while (v > 9) {
    if (keepMaster && (v === 11 || v === 22 || v === 33)) break;
    v = String(v).split('').reduce((a, b) => a + Number(b), 0);
  }
  return v;
}

function calcNumerology(fullName, d, m, y) {
  const digits = `${d}${m}${y}`.replace(/\D/g, '').split('').map(Number);
  const lpSum = digits.reduce((a, b) => a + b, 0);
  let lifePath = lpSum;
  while (lifePath > 11 && lifePath !== 22 && lifePath !== 33) {
    lifePath = String(lifePath).split('').reduce((a, b) => a + Number(b), 0);
  }
  if (lifePath === 1) lifePath = 10;

  const curYear = new Date().getFullYear();
  const personalYear = reduceNum(reduceNum(d, false) + reduceNum(m, false) + reduceNum(curYear, false), false);

  const clean = String(fullName || '')
    .toUpperCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/Đ/g, 'D')
    .replace(/[^A-Z]/g, '');
  const pyth = (ch) => ((ch.charCodeAt(0) - 65) % 9) + 1;
  const vowels = new Set(['A', 'E', 'I', 'O', 'U']);
  let exprSum = 0, soulSum = 0, persSum = 0;
  for (const ch of clean) {
    const val = pyth(ch);
    exprSum += val;
    if (vowels.has(ch)) soulSum += val;
    else persSum += val;
  }
  return {
    lifePath,
    personalYear,
    expression: clean ? reduceNum(exprSum, true) : null,
    soul: clean ? reduceNum(soulSum, true) : null,
    personality: clean ? reduceNum(persSum, true) : null,
    info: LIFE_PATH_INFO[lifePath] || LIFE_PATH_INFO[reduceNum(lifePath, false)] || ['Độc đáo & Tiềm năng', 'Bạn mang nguồn năng lượng cân bằng và giàu tiềm năng phát triển.']
  };
}

export function mountTarotNumerologyModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onSendTelegram = null } = opts;
  const defYear = Number(getState()?.auspiciousPrefs?.birthYear) || 1995;

  let tab = 'tarot';
  let spread = 3;
  let drawn = [];
  let lastNum = null;
  let lastAi = '';
  let busy = false;

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-indigo">
        <div>
          <h2 class="sf-hero-title">🔮 Thần Số Học &amp; Rút Bài Tarot AI</h2>
          <div class="sf-hero-sub">Khám phá Con số Đường đời, Năm cá nhân Pythagoras &amp; rút bài Tarot 1 lá / 3 lá hỏi đáp nhanh cùng AI.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-tn-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <div class="sf-seg" id="tn-seg">
          <button type="button" class="sf-seg-btn active" data-t="tarot">🃏 Rút bài Tarot AI</button>
          <button type="button" class="sf-seg-btn" data-t="numerology">🔢 Thần số học</button>
        </div>

        <div id="tn-pane-tarot">
          <div class="sf-field">
            <label for="tarot-q">Câu hỏi bạn muốn hỏi bài Tarot:</label>
            <input id="tarot-q" type="text" placeholder="VD: Công việc tháng này có thuận lợi không? Tình cảm sắp tới ra sao?" maxlength="200" />
          </div>
          <div class="sf-pills" id="tarot-spread-pills">
            <button type="button" class="sf-pill" data-sp="1">🃏 1 Lá (Hỏi nhanh)</button>
            <button type="button" class="sf-pill active" data-sp="3">✨ 3 Lá (Quá khứ – Hiện tại – Tương lai)</button>
          </div>
          <div class="sf-btn-row">
            <button type="button" id="btn-tarot-draw" class="sf-btn primary" style="flex:1;">🎴 Xào &amp; Rút bài</button>
            <button type="button" id="btn-tarot-ai" class="sf-btn ai hidden" style="flex:1;">✨ AI Giải bài Tarot</button>
          </div>
          <div id="tarot-board" class="tarot-cards-row"></div>
          <div id="tarot-offline-box" class="sf-kv-list"></div>
        </div>

        <div id="tn-pane-num" class="hidden">
          <div class="sf-field">
            <label for="num-name">Họ và tên đầy đủ (để tính Sứ mệnh &amp; Linh hồn)</label>
            <input id="num-name" type="text" placeholder="VD: Nguyễn Minh Anh" maxlength="80" />
          </div>
          <div class="sf-grid-3">
            <div class="sf-field"><label for="num-d">Ngày sinh</label><input id="num-d" type="number" min="1" max="31" value="15" /></div>
            <div class="sf-field"><label for="num-m">Tháng</label><input id="num-m" type="number" min="1" max="12" value="8" /></div>
            <div class="sf-field"><label for="num-y">Năm sinh</label><input id="num-y" type="number" min="1920" max="2045" value="${defYear}" /></div>
          </div>
          <div class="sf-btn-row">
            <button type="button" id="btn-num-calc" class="sf-btn primary" style="flex:1;">🔢 Tính chỉ số ngay</button>
            <button type="button" id="btn-num-ai" class="sf-btn ai" style="flex:1;">✨ AI Luận giải sâu</button>
          </div>
          <div id="num-result" style="margin-top:10px;"></div>
        </div>

        <div id="tn-status" class="sf-status"></div>
      </div>

      <div id="tn-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong id="tn-ai-title">✨ Luận giải từ Gemini AI</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-tn-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-tn-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-tn-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div id="tn-ai-body" class="dream-result-body"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  q('#btn-tn-back')?.addEventListener('click', onBack);
  q('#tn-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    tab = b.dataset.t || 'tarot';
    q('#tn-seg').querySelectorAll('.sf-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
    q('#tn-pane-tarot').classList.toggle('hidden', tab !== 'tarot');
    q('#tn-pane-num').classList.toggle('hidden', tab !== 'numerology');
    q('#tn-status').textContent = '';
  });

  // Tarot logic
  q('#tarot-spread-pills')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-pill');
    if (!b) return;
    spread = Number(b.dataset.sp) || 3;
    q('#tarot-spread-pills').querySelectorAll('.sf-pill').forEach((x) => x.classList.toggle('active', x === b));
  });

  const renderTarotBoard = () => {
    const board = q('#tarot-board');
    const offBox = q('#tarot-offline-box');
    board.innerHTML = '';
    offBox.innerHTML = '';
    const posLabels = spread === 1 ? ['Thông điệp cốt lõi'] : ['1. Quá khứ / Gốc rễ', '2. Hiện tại', '3. Xu hướng Tương lai'];
    drawn.forEach((item, idx) => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = `tarot-card${item.revealed ? ' revealed' : ''}${item.revealed && item.reversed ? ' reversed' : ''}`;
      card.innerHTML = item.revealed
        ? `<div class="tarot-pos">${posLabels[idx] || ''}</div><div class="tarot-ico">${item.card.ico}</div><div class="tarot-name">${escHtml(item.card.name)}</div><div class="tarot-ori">${item.reversed ? 'Ngược (Reversed)' : 'Xuôi (Upright)'}</div>`
        : `<div class="tarot-pos">${posLabels[idx] || ''}</div><div style="font-size:30px;">✨</div><div style="font-size:11.5px;font-weight:700;">Chạm để lật lá ${idx + 1}</div>`;
      card.addEventListener('click', () => {
        item.revealed = true;
        renderTarotBoard();
      });
      board.appendChild(card);

      if (item.revealed) {
        const kv = document.createElement('div');
        kv.className = 'sf-kv-item';
        kv.innerHTML = `<strong>${posLabels[idx]} — ${item.card.ico} ${escHtml(item.card.name)} (${item.reversed ? 'Ngược' : 'Xuôi'}):</strong> ${escHtml(item.reversed ? item.card.rev : item.card.up)}`;
        offBox.appendChild(kv);
      }
    });
    const allRev = drawn.length > 0 && drawn.every((x) => x.revealed);
    q('#btn-tarot-ai').classList.toggle('hidden', !allRev);
  };

  q('#btn-tarot-draw')?.addEventListener('click', () => {
    const pool = [...TAROT_MAJOR].sort(() => Math.random() - 0.5);
    drawn = pool.slice(0, spread).map((card) => ({ card, reversed: Math.random() < 0.28, revealed: false }));
    renderTarotBoard();
    q('#tn-status').className = 'sf-status';
    q('#tn-status').textContent = '✨ Hãy tập trung nghĩ về câu hỏi rồi chạm vào từng lá bài để lật mở!';
  });

  q('#btn-tarot-ai')?.addEventListener('click', async () => {
    if (busy || drawn.length === 0) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#tn-status').className = 'sf-status err';
      q('#tn-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-tn-cfg">Nhập Key</button>';
      q('#btn-tn-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-tarot-ai').disabled = true;
    q('#tn-status').textContent = '✨ Gemini AI đang kết nối các lá bài Tarot để trả lời câu hỏi của bạn...';
    q('#tn-ai-card').classList.remove('hidden');
    q('#tn-ai-body').innerHTML = '✨ Đang giải bài Tarot...';
    try {
      const qTxt = q('#tarot-q').value.trim() || 'Thông điệp tổng quan cho giai đoạn hiện tại của tôi';
      const posLabels = spread === 1 ? ['Thông điệp cốt lõi'] : ['Quá khứ / Nguyên nhân', 'Hiện tại', 'Xu hướng Tương lai'];
      const cardsDesc = drawn.map((d, i) => `- ${posLabels[i]}: ${d.card.name} (${d.reversed ? 'Ngược' : 'Xuôi'})`).join('\n');
      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là chuyên gia Tarot & tâm lý học hiện đại, giải bài sâu sắc, ấm áp, tích cực, truyền động lực.',
        userPrompt: `Câu hỏi của người rút bài: "${qTxt}".\nCác lá bài đã rút:\n${cardsDesc}\n\nHãy giải bài Tarot bám sát câu hỏi trên theo 3 mục gọn gàng: 1. Ý nghĩa từng lá bài gắn với câu hỏi; 2. Bức tranh tổng thể & câu trả lời trực diện; 3. Lời khuyên hành động tích cực.`,
        temperature: 0.55
      }, (p) => { if (p) q('#tn-ai-body').innerHTML = fmtMd(p); });
      lastAi = `🃏 Trải bài Tarot: ${qTxt}\n${cardsDesc}\n\n${ans}`;
      q('#tn-ai-title').textContent = '✨ Luận giải Bài Tarot AI';
      q('#tn-ai-body').innerHTML = fmtMd(ans);
      q('#tn-status').textContent = '✅ Đã giải xong bài Tarot!';
    } catch (err) {
      q('#tn-status').className = 'sf-status err';
      q('#tn-status').textContent = `⚠️ ${err?.message || 'Lỗi AI'}`;
    } finally {
      busy = false;
      q('#btn-tarot-ai').disabled = false;
    }
  });

  // Numerology logic
  const runNum = () => {
    const name = q('#num-name').value.trim();
    const d = Math.max(1, Math.min(31, Number(q('#num-d').value) || 15));
    const m = Math.max(1, Math.min(12, Number(q('#num-m').value) || 8));
    const y = Math.max(1920, Math.min(2045, Number(q('#num-y').value) || 1995));
    const r = calcNumerology(name, d, m, y);
    lastNum = { name, d, m, y, ...r };
    q('#num-result').innerHTML = `
      <div class="sf-score-banner">
        <div class="sf-score-circle good"><span class="sf-score-num">${r.lifePath}</span><span class="sf-score-sub">Chủ đạo</span></div>
        <div>
          <div style="font-weight:800;font-size:13.5px;color:#4C1D95;">Số Đường Đời ${r.lifePath}: ${escHtml(r.info[0])}</div>
          <div style="font-size:12px;color:#374151;margin-top:2px;">${escHtml(r.info[1])}</div>
        </div>
      </div>
      <div class="sf-grid-3">
        <div class="exp-kpi bal"><div class="exp-kpi-lbl">Năm cá nhân ${new Date().getFullYear()}</div><div class="exp-kpi-val">Số ${r.personalYear}</div></div>
        <div class="exp-kpi inc"><div class="exp-kpi-lbl">Số Sứ mệnh</div><div class="exp-kpi-val">${r.expression ? `Số ${r.expression}` : 'Nhập tên'}</div></div>
        <div class="exp-kpi"><div class="exp-kpi-lbl">Số Linh hồn</div><div class="exp-kpi-val">${r.soul ? `Số ${r.soul}` : 'Nhập tên'}</div></div>
      </div>
    `;
    return lastNum;
  };
  q('#btn-num-calc')?.addEventListener('click', runNum);
  q('#btn-num-ai')?.addEventListener('click', async () => {
    const r = runNum();
    if (!r || busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#tn-status').className = 'sf-status err';
      q('#tn-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-tn-cfg2">Nhập Key</button>';
      q('#btn-tn-cfg2')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-num-ai').disabled = true;
    q('#tn-status').textContent = '✨ Gemini AI đang luận giải bản đồ Thần số học của bạn...';
    q('#tn-ai-card').classList.remove('hidden');
    q('#tn-ai-body').innerHTML = '✨ Đang luận giải...';
    try {
      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là chuyên gia Thần số học Pythagoras ứng dụng hiện đại, rõ ràng, thực tế, tích cực.',
        userPrompt: `Luận giải Thần số học cho ${r.name || 'người dùng'} sinh ngày ${r.d}/${r.m}/${r.y}: Con số Chủ đạo ${r.lifePath} (${r.info[0]}), Năm cá nhân ${new Date().getFullYear()} là số ${r.personalYear}${r.expression ? `, Sứ mệnh ${r.expression}, Linh hồn ${r.soul}, Nhân cách ${r.personality}` : ''}. Trình bày 4 mục ngắn: 1. Điểm mạnh & nghề nghiệp hợp; 2. Điều cần cân bằng; 3. Trọng tâm Năm cá nhân ${new Date().getFullYear()} (Số ${r.personalYear}); 4. Lời khuyên phát triển bản thân.`,
        temperature: 0.45
      }, (p) => { if (p) q('#tn-ai-body').innerHTML = fmtMd(p); });
      lastAi = `🔢 Thần số học — Số Chủ Đạo ${r.lifePath} • Năm cá nhân ${r.personalYear}\n\n${ans}`;
      q('#tn-ai-title').textContent = `✨ Luận giải Thần số học (Số ${r.lifePath})`;
      q('#tn-ai-body').innerHTML = fmtMd(ans);
      q('#tn-status').textContent = '✅ Đã luận giải xong!';
    } catch (err) {
      q('#tn-status').className = 'sf-status err';
      q('#tn-status').textContent = `⚠️ ${err?.message || 'Lỗi AI'}`;
    } finally {
      busy = false;
      q('#btn-num-ai').disabled = false;
    }
  });

  q('#btn-tn-copy')?.addEventListener('click', async () => { if (lastAi) { try { await navigator.clipboard.writeText(lastAi); } catch (_e) {} q('#tn-status').textContent = '✓ Đã sao chép!'; } });
  q('#btn-tn-zalo')?.addEventListener('click', () => { if (lastAi) shareToZaloQuick(lastAi); });
  q('#btn-tn-tg')?.addEventListener('click', (e) => { if (lastAi && onSendTelegram) onSendTelegram(escHtml(lastAi), e.currentTarget); });
  runNum();
}

/* ==================== 3. GIEO QUẺ KINH DỊCH (64 QUẺ) & XIN XĂM QUAN ÂM (LẮC MÁY!) ==================== */

const TRIGRAMS = [
  { bits: '111', name: 'Càn', nat: 'Thiên (Trời)' },
  { bits: '110', name: 'Đoài', nat: 'Trạch (Đầm)' },
  { bits: '101', name: 'Ly', nat: 'Hỏa (Lửa)' },
  { bits: '100', name: 'Chấn', nat: 'Lôi (Sấm)' },
  { bits: '011', name: 'Tốn', nat: 'Phong (Gió)' },
  { bits: '010', name: 'Khảm', nat: 'Thủy (Nước)' },
  { bits: '001', name: 'Cấn', nat: 'Sơn (Núi)' },
  { bits: '000', name: 'Khôn', nat: 'Địa (Đất)' }
];

// 8x8 King Wen 64 Hexagrams (index: upper*8 + lower using TRIGRAMS order above)
const HEX_64 = [
  ['Thuần Càn', 'Đại Cát', 'Sáng tạo mạnh mẽ, tự cường bất tức, thuận lợi khởi sự lớn.'],
  ['Thiên Trạch Lý', 'Cát', 'Đi trên nền vững bằng lễ nghĩa và sự cẩn trọng sẽ thành công.'],
  ['Thiên Hỏa Đồng Nhân', 'Đại Cát', 'Đồng tâm hiệp lực, hợp tác rộng mở, dễ gặp quý nhân.'],
  ['Thiên Lôi Vô Vọng', 'Cát', 'Chân thành ngay thẳng thì mọi việc thuận tự nhiên, tránh mưu cầu sai.'],
  ['Thiên Phong Cấu', 'Trung', 'Gặp gỡ bất ngờ — chọn lọc cơ hội kỹ, không nên vội tin ngay.'],
  ['Thiên Thủy Tụng', 'Cẩn trọng', 'Tránh tranh cãi kiện tụng, lấy hòa giải làm đầu.'],
  ['Thiên Sơn Độn', 'Trung', 'Tạm lùi một bước để bảo toàn lực lượng và chờ thời cơ tốt hơn.'],
  ['Thiên Địa Bĩ', 'Cẩn trọng', 'Bế tắc tạm thời — kiên trì tích lũy nội lực, hết bĩ tới thái.'],
  ['Trạch Thiên Quải', 'Cát', 'Quyết đoán giải quyết dứt điểm tồn đọng, ánh sáng đang tới.'],
  ['Thuần Đoài', 'Đại Cát', 'Vui vẻ hòa nhã, giao tiếp thuận lợi, đàm phán dễ thành.'],
  ['Trạch Hỏa Cách', 'Cát', 'Đổi mới đúng thời điểm sẽ tạo bước ngoặt tích cực rõ rệt.'],
  ['Trạch Lôi Tùy', 'Cát', 'Thuận theo thời thế linh hoạt, biết lắng nghe sẽ có quý nhân giúp.'],
  ['Trạch Phong Đại Quá', 'Trung', 'Áp lực lớn — cần phân bổ sức lực hợp lý, đừng ôm đồm một mình.'],
  ['Trạch Thủy Khốn', 'Cẩn trọng', 'Thử thách ý chí — giữ bình tĩnh, nhờ người có kinh nghiệm cố vấn.'],
  ['Trạch Sơn Hàm', 'Đại Cát', 'Cảm ứng chân thành — cực tốt cho tình duyên, ký kết, hợp tác!'],
  ['Trạch Địa Tụy', 'Đại Cát', 'Tụ hội nhân tài và tài lộc, làm việc tập thể rất vượng.'],
  ['Hỏa Thiên Đại Hữu', 'Đại Cát', 'Phú quý sung túc, công danh tài lộc rộng mở rực rỡ!'],
  ['Hỏa Trạch Khuê', 'Trung', 'Khác biệt quan điểm — tôn trọng lẫn nhau sẽ tìm được điểm chung.'],
  ['Thuần Ly', 'Cát', 'Sáng suốt minh bạch, bám vững nguyên tắc sẽ tỏa sáng.'],
  ['Hỏa Lôi Phệ Hạp', 'Trung', 'Tháo gỡ nút thắt bằng sự công minh và dứt khoát.'],
  ['Hỏa Phong Đỉnh', 'Đại Cát', 'Vững như kiềng ba chân — lập nghiệp, thăng chức, tụ tài rất tốt!'],
  ['Hỏa Thủy Vị Tế', 'Trung', 'Sắp về đích — cẩn trọng khâu cuối cùng để thành công trọn vẹn.'],
  ['Hỏa Sơn Lữ', 'Trung', 'Hợp đi xa, công tác, du lịch — giữ khiêm nhường nơi đất khách.'],
  ['Hỏa Địa Tấn', 'Đại Cát', 'Mặt trời lên cao — thăng tiến mạnh mẽ, được cấp trên trọng dụng!'],
  ['Lôi Thiên Đại Tráng', 'Cát', 'Khí thế mạnh mẽ — kết hợp bản lĩnh với sự điềm tĩnh sẽ đại thắng.'],
  ['Lôi Trạch Quy Muội', 'Trung', 'Chuyện tình cảm/hợp tác cần đi từng bước chắc chắn, tránh nóng vội.'],
  ['Lôi Hỏa Phong', 'Đại Cát', 'Phong phú hưng thịnh, thành quả rực rỡ — nhớ giữ tâm bình an.'],
  ['Thuần Chấn', 'Cát', 'Biến động tạo cơ hội mới — giữ vững tinh thần sẽ vượt lên nhanh.'],
  ['Lôi Phong Hằng', 'Đại Cát', 'Kiên trì bền bỉ — công việc và tình cảm ngày càng vững chắc!'],
  ['Lôi Thủy Giải', 'Đại Cát', 'Mọi vướng mắc, lo âu được tháo gỡ nhẹ nhàng, mưa tan trời sáng!'],
  ['Lôi Sơn Tiểu Quá', 'Trung', 'Làm việc nhỏ chắc chắn trước, tránh tham lớn đốt cháy giai đoạn.'],
  ['Lôi Địa Dự', 'Đại Cát', 'Chuẩn bị chu đáo sẽ đón niềm vui và cơ hội thuận lợi lớn!'],
  ['Phong Thiên Tiểu Súc', 'Trung', 'Tích lũy từng bước nhỏ, thời cơ lớn đang dần hình thành.'],
  ['Phong Trạch Trung Phu', 'Đại Cát', 'Chữ tín và lòng chân thành giúp chinh phục mọi đối tác!'],
  ['Phong Hỏa Gia Nhân', 'Đại Cát', 'Gia đạo hòa thuận, hậu phương vững chắc giúp sự nghiệp hưng vượng!'],
  ['Phong Lôi Ích', 'Đại Cát', 'Tăng ích tài lộc và phúc phần — rất hợp đầu tư, mở rộng, cho đi!'],
  ['Thuần Tốn', 'Cát', 'Mềm dẻo khéo léo như gió xuân, thuận lợi thương lượng & đối ngoại.'],
  ['Phong Thủy Hoán', 'Cát', 'Xua tan bế tắc, khởi hành đi xa hoặc thay đổi môi trường rất tốt.'],
  ['Phong Sơn Tiệm', 'Đại Cát', 'Tiến từng bước vững chắc như chim hồng bay cao — thành công bền lâu!'],
  ['Phong Địa Quan', 'Cát', 'Quan sát kỹ bức tranh toàn cảnh trước khi ra quyết định quan trọng.'],
  ['Thủy Thiên Nhu', 'Cát', 'Chờ thời cơ chín muồi trong an nhiên, mọi sự rồi sẽ thông suốt.'],
  ['Thủy Trạch Tiết', 'Cát', 'Biết tiết chế chi tiêu và kỷ luật giúp tài chính vững vàng.'],
  ['Thủy Hỏa Ký Tế', 'Đại Cát', 'Mọi việc đã vào guồng hoàn hảo — tiếp tục giữ cẩn trọng để bền lâu!'],
  ['Thủy Lôi Truân', 'Trung', 'Vạn sự khởi đầu nan — kiên nhẫn vượt giai đoạn đầu sẽ có quý nhân giúp.'],
  ['Thủy Phong Tỉnh', 'Cát', 'Như giếng nước mát — trau dồi chuyên môn sẽ có nguồn thu bền vững.'],
  ['Thuần Khảm', 'Cẩn trọng', 'Gặp sóng gió cần giữ tâm tĩnh và làm đúng nguyên tắc để vượt qua.'],
  ['Thủy Sơn Kiển', 'Cẩn trọng', 'Tạm dừng xem lại hướng đi, tìm người hiểu việc tham vấn.'],
  ['Thủy Địa Tỷ', 'Đại Cát', 'Thân thiện gắn kết — cực tốt cho kết giao, chọn cộng sự & đội nhóm!'],
  ['Sơn Thiên Đại Súc', 'Đại Cát', 'Tích trữ năng lực và tài chính dồi dào, sẵn sàng cho bước tiến lớn!'],
  ['Sơn Trạch Tổn', 'Trung', 'Bớt cái không cần thiết để tập trung vào điều cốt lõi sẽ sinh lời.'],
  ['Sơn Hỏa Bí', 'Cát', 'Chú trọng hình ảnh, trình bày chỉn chu kết hợp thực chất sẽ ghi điểm lớn.'],
  ['Sơn Lôi Di', 'Cát', 'Chú ý lời ăn tiếng nói và bồi dưỡng sức khỏe, tinh thần.'],
  ['Sơn Phong Cổ', 'Trung', 'Dọn dẹp, chấn chỉnh lại những việc cũ tồn đọng để khởi sắc mới.'],
  ['Sơn Thủy Mông', 'Trung', 'Học hỏi thêm kiến thức từ người đi trước sẽ mở sáng con đường.'],
  ['Thuần Cấn', 'Trung', 'Biết dừng đúng lúc, giữ sự tĩnh tại để nhìn rõ việc cần làm.'],
  ['Sơn Địa Bác', 'Cẩn trọng', 'Phòng ngừa hao hụt, giữ chắc nền tảng, không mạo hiểm ngắn hạn.'],
  ['Địa Thiên Thái', 'Đại Cát', 'Thiên địa giao hòa — vận trình cực kỳ hanh thông, cát tường như ý!'],
  ['Địa Trạch Lâm', 'Đại Cát', 'Quý nhân lâm môn, cơ hội đang tới gần — mạnh dạn nắm bắt!'],
  ['Địa Hỏa Minh Di', 'Cẩn trọng', 'Tạm ẩn mình giữ sức, tránh phô trương, chờ lúc sáng tỏ hơn.'],
  ['Địa Lôi Phục', 'Đại Cát', 'Khởi sắc trở lại sau thời gian trầm lắng — vận may đang quay về!'],
  ['Địa Phong Thăng', 'Đại Cát', 'Thăng tiến vững vàng từng nấc thang, công danh sự nghiệp rộng mở!'],
  ['Địa Thủy Sư', 'Cát', 'Cần kế hoạch bài bản, kỷ luật và người dẫn dắt sáng suốt sẽ thắng.'],
  ['Địa Sơn Khiêm', 'Đại Cát', 'Khiêm tốn nhún nhường là đức tính mang lại phúc lộc trọn vẹn nhất!'],
  ['Thuần Khôn', 'Đại Cát', 'Bao dung, kiên nhẫn và bền bỉ — đất dày chở vạn vật, hậu vận an lành!']
];

const XAM_GRADES = ['Thượng Thượng (Đại Cát)', 'Thượng Cát', 'Trung Cát', 'Trung Bình', 'Trung Hạ', 'Hạ Hạ (Cẩn Trọng)'];
const XAM_POEMS = [
  'Hoa mai nở rộ giữa trời xuân, quý nhân phương xa tới kết thân.',
  'Gió thuận buồm xuôi qua biển lớn, công danh tài lộc vẹn đôi phần.',
  'Trăng sáng mây tan đường rộng mở, kiên tâm bền chí ắt nên công.',
  'Ngọc ẩn trong đá chờ tay thợ, chậm mà chắc chắn phúc về đông.',
  'Sông sâu nước lặng thuyền đi khéo, giữ dạ an hòa mọi việc thông.',
  'Hết cơn mưa hạ trời quang đãng, tích đức hành thiện hóa cát tường.'
];

export function mountIChingXamModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onSendTelegram = null } = opts;

  let mode = 'iching'; // 'iching' | 'xam'
  let shakeEnabled = false;
  let lastShakeAt = 0;
  let lastOutcome = null;
  let lastAi = '';
  let busy = false;

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-amber">
        <div>
          <h2 class="sf-hero-title">🎲 Gieo Quẻ Kinh Dịch &amp; Xin Xăm Quan Âm</h2>
          <div class="sf-hero-sub">Lắc điện thoại hoặc bấm gieo quẻ hằng ngày, xin xăm đầu năm &amp; AI giải quẻ bám sát đúng câu hỏi của bạn.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-ic-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <div class="sf-seg" id="ic-seg">
          <button type="button" class="sf-seg-btn active" data-m="iching">☯️ Gieo Quẻ Kinh Dịch</button>
          <button type="button" class="sf-seg-btn" data-m="xam">🏮 Xin Xăm Quan Âm</button>
        </div>

        <div class="sf-field">
          <label for="ic-question">Câu hỏi cụ thể bạn đang muốn xin quẻ:</label>
          <input id="ic-question" type="text" placeholder="VD: Hôm nay ký hợp đồng có thuận lợi không? Dự định mở quán tháng tới ra sao?" maxlength="200" />
        </div>

        <div class="sf-btn-row" style="margin-bottom:8px;">
          <button type="button" id="btn-ic-cast" class="sf-btn primary" style="flex:1;">🎲 Gieo 3 đồng xu (6 hào)</button>
          <button type="button" id="btn-ic-shake" class="sf-btn" title="Bật cảm biến lắc điện thoại để gieo quẻ / lắc ống xăm">📳 Lắc máy: Tắt</button>
        </div>

        <div id="ic-visual" class="iching-box">
          <div id="ic-anim-ico" style="font-size:40px;">☯️</div>
          <div style="font-size:12px;color:#78350F;text-align:center;">Thành tâm nghĩ đến câu hỏi của bạn, sau đó bấm <strong>Gieo quẻ</strong> (hoặc bật <strong>📳 Lắc máy</strong> và lắc điện thoại!).</div>
        </div>

        <div class="sf-btn-row">
          <button type="button" id="btn-ic-ai" class="sf-btn ai full hidden">✨ AI Giải Quẻ bám sát câu hỏi của tôi</button>
        </div>
        <div id="ic-status" class="sf-status"></div>
      </div>

      <div id="ic-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong id="ic-ai-title">✨ Luận giải Quẻ từ Gemini AI</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-ic-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-ic-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-ic-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div id="ic-ai-body" class="dream-result-body"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);

  const renderHexLines = (lines) => {
    // lines[0] is bottom hào 1, lines[5] is top hào 6 -> display top to bottom
    return [...lines].reverse().map((v) => {
      const isYang = v === 7 || v === 9;
      const isMov = v === 6 || v === 9;
      return `<div class="iching-line ${isYang ? 'yang' : 'yin'}${isMov ? ' moving' : ''}">${isYang ? '<span class="iching-bar"></span>' : '<span class="iching-bar"></span><span class="iching-bar"></span>'}</div>`;
    }).join('');
  };

  const lookupHex = (bits6) => {
    const lowBits = bits6.slice(0, 3);
    const upBits = bits6.slice(3, 6);
    const lIdx = TRIGRAMS.findIndex((t) => t.bits === lowBits);
    const uIdx = TRIGRAMS.findIndex((t) => t.bits === upBits);
    const h = HEX_64[uIdx * 8 + lIdx] || HEX_64[0];
    return { name: h[0], grade: h[1], meaning: h[2], upper: TRIGRAMS[uIdx], lower: TRIGRAMS[lIdx] };
  };

  const castNow = () => {
    try { navigator.vibrate?.([40, 30, 50]); } catch (_e) {}
    const vis = q('#ic-visual');
    vis.classList.remove('sf-shaking');
    void vis.offsetWidth;
    vis.classList.add('sf-shaking');

    if (mode === 'iching') {
      // 3-coin authentic probabilities: 6 (1/8 old yin), 7 (3/8 young yang), 8 (3/8 young yin), 9 (1/8 old yang)
      const vals = [6, 7, 7, 7, 8, 8, 8, 9];
      const lines = Array.from({ length: 6 }, () => vals[Math.floor(Math.random() * vals.length)]);
      const mainBits = lines.map((v) => (v === 7 || v === 9 ? '1' : '0')).join('');
      const changedLines = lines.map((v) => (v === 9 ? 8 : v === 6 ? 7 : v));
      const changedBits = changedLines.map((v) => (v === 7 || v === 9 ? '1' : '0')).join('');
      const movingNums = lines.map((v, i) => (v === 6 || v === 9 ? i + 1 : null)).filter(Boolean);

      const mainHex = lookupHex(mainBits);
      const changedHex = movingNums.length > 0 ? lookupHex(changedBits) : null;
      lastOutcome = { mode: 'iching', lines, mainHex, changedHex, movingNums };

      vis.innerHTML = `
        <div class="iching-hex-pair">
          <div class="iching-hex">
            <div style="font-size:11px;font-weight:800;color:#991B1B;">Quẻ Chính</div>
            ${renderHexLines(lines)}
            <strong style="font-size:13px;color:#7F1D1D;">${mainHex.name}</strong>
            <span class="sf-badge ${mainHex.grade.includes('Cát') ? 'good' : mainHex.grade === 'Trung' ? 'warn' : 'bad'}">${mainHex.grade}</span>
          </div>
          ${changedHex ? `
            <div style="font-size:20px;font-weight:900;color:#D97706;">→</div>
            <div class="iching-hex">
              <div style="font-size:11px;font-weight:800;color:#B45309;">Quẻ Biến (Động hào ${movingNums.join(', ')})</div>
              ${renderHexLines(changedLines)}
              <strong style="font-size:13px;color:#78350F;">${changedHex.name}</strong>
              <span class="sf-badge ${changedHex.grade.includes('Cát') ? 'good' : 'warn'}">${changedHex.grade}</span>
            </div>
          ` : ''}
        </div>
        <div style="font-size:12px;color:#374151;text-align:center;margin-top:4px;">${escHtml(mainHex.meaning)}</div>
      `;
    } else {
      const num = Math.floor(Math.random() * 100) + 1;
      const gIdx = num % 10 <= 1 ? 0 : num % 10 <= 3 ? 1 : num % 10 <= 5 ? 2 : num % 10 <= 7 ? 3 : num % 10 === 8 ? 4 : 5;
      const grade = XAM_GRADES[gIdx];
      const poem = XAM_POEMS[num % XAM_POEMS.length];
      lastOutcome = { mode: 'xam', num, grade, poem };

      vis.innerHTML = `
        <div style="font-size:38px;">🏮</div>
        <div style="font-size:18px;font-weight:900;color:#991B1B;">Xăm Quan Âm Số ${num}</div>
        <span class="sf-badge ${gIdx <= 2 ? 'good' : gIdx === 3 ? 'warn' : 'bad'}">${grade}</span>
        <div style="font-size:12.5px;font-style:italic;color:#78350F;text-align:center;margin-top:4px;">"${poem}"</div>
      `;
    }
    q('#btn-ic-ai').classList.remove('hidden');
    q('#ic-status').className = 'sf-status';
    q('#ic-status').textContent = '✨ Đã gieo xong! Bấm "✨ AI Giải Quẻ bám sát câu hỏi" để nhận luận giải riêng.';
  };

  const onMotion = (ev) => {
    if (!shakeEnabled) return;
    const acc = ev.accelerationIncludingGravity || ev.acceleration;
    if (!acc) return;
    const mag = Math.abs(acc.x || 0) + Math.abs(acc.y || 0) + Math.abs(acc.z || 0);
    if (mag > 28 && Date.now() - lastShakeAt > 1800) {
      lastShakeAt = Date.now();
      castNow();
    }
  };

  const stopShake = () => {
    shakeEnabled = false;
    window.removeEventListener('devicemotion', onMotion);
    if (q('#btn-ic-shake')) q('#btn-ic-shake').textContent = '📳 Lắc máy: Tắt';
  };

  q('#btn-ic-back')?.addEventListener('click', () => { stopShake(); onBack(); });
  q('#ic-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    mode = b.dataset.m || 'iching';
    q('#ic-seg').querySelectorAll('.sf-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
    q('#btn-ic-cast').textContent = mode === 'iching' ? '🎲 Gieo 3 đồng xu (6 hào)' : '🏮 Lắc ống Xăm Quan Âm';
  });
  q('#btn-ic-cast')?.addEventListener('click', castNow);
  q('#btn-ic-shake')?.addEventListener('click', async () => {
    if (shakeEnabled) { stopShake(); return; }
    if (typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') {
      try { await DeviceMotionEvent.requestPermission(); } catch (_e) {}
    }
    shakeEnabled = true;
    window.addEventListener('devicemotion', onMotion);
    q('#btn-ic-shake').textContent = '📳 Lắc máy: Đang bật!';
    q('#ic-status').textContent = '📳 Hãy cầm điện thoại lắc nhẹ để gieo quẻ / lắc ống xăm!';
  });

  q('#btn-ic-ai')?.addEventListener('click', async () => {
    if (busy || !lastOutcome) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#ic-status').className = 'sf-status err';
      q('#ic-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-ic-cfg">Nhập Key</button>';
      q('#btn-ic-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    busy = true;
    q('#btn-ic-ai').disabled = true;
    q('#ic-status').textContent = '✨ Gemini AI đang giải quẻ bám sát đúng câu hỏi của bạn...';
    q('#ic-ai-card').classList.remove('hidden');
    q('#ic-ai-body').innerHTML = '✨ Đang giải quẻ...';
    try {
      const qTxt = q('#ic-question').value.trim() || 'Vận trình và lời khuyên cho tôi trong ngày hôm nay';
      const desc = lastOutcome.mode === 'iching'
        ? `Gieo quẻ Kinh Dịch được Quẻ Chính: ${lastOutcome.mainHex.name} (${lastOutcome.mainHex.grade}, Thượng ${lastOutcome.mainHex.upper.name} - Hạ ${lastOutcome.mainHex.lower.name})${lastOutcome.changedHex ? `, động hào ${lastOutcome.movingNums.join(', ')} biến sang Quẻ Biến: ${lastOutcome.changedHex.name} (${lastOutcome.changedHex.grade})` : ' (không hào động)'}.`
        : `Xin Xăm Quan Âm được Quẻ Số ${lastOutcome.num} — Hạng: ${lastOutcome.grade}.`;
      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là học giả Kinh Dịch & Văn hóa tâm linh Việt Nam, giải quẻ trực diện, bám sát đúng câu hỏi người dùng, lời khuyên thực tế và tích cực.',
        userPrompt: `Người dùng hỏi: "${qTxt}".\nKết quả gieo quẻ: ${desc}\n\nHãy giải quẻ bám sát đúng câu hỏi trên theo 4 mục rõ ràng: 1. Tóm tắt ý tượng quẻ; 2. Câu trả lời trực diện cho vấn đề đang hỏi (nên tiến hay nên thủ); 3. Diễn biến sắp tới; 4. Lời khuyên hành động cụ thể.`,
        temperature: 0.45
      }, (p) => { if (p) q('#ic-ai-body').innerHTML = fmtMd(p); });
      lastAi = `🎲 Giải quẻ (${qTxt})\n${desc}\n\n${ans}`;
      q('#ic-ai-body').innerHTML = fmtMd(ans);
      q('#ic-status').textContent = '✅ Đã giải quẻ xong!';
    } catch (err) {
      q('#ic-status').className = 'sf-status err';
      q('#ic-status').textContent = `⚠️ ${err?.message || 'Lỗi AI'}`;
    } finally {
      busy = false;
      q('#btn-ic-ai').disabled = false;
    }
  });

  q('#btn-ic-copy')?.addEventListener('click', async () => { if (lastAi) { try { await navigator.clipboard.writeText(lastAi); } catch (_e) {} q('#ic-status').textContent = '✓ Đã sao chép!'; } });
  q('#btn-ic-zalo')?.addEventListener('click', () => { if (lastAi) shareToZaloQuick(lastAi); });
  q('#btn-ic-tg')?.addEventListener('click', (e) => { if (lastAi && onSendTelegram) onSendTelegram(escHtml(lastAi), e.currentTarget); });

  return { stopShake };
}
