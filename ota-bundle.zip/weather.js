/**
 * High-Accuracy Live Weather + 24h Hourly + 14-Day Forecast + Air Quality (AQI, PM2.5) + UV Index
 * Primary Model: ECMWF IFS 0.25° (European Centre — same gold-standard model used by Windy & Apple Weather)
 * Enriched with Open-Meteo multi-model rain probability, UV index, 24h hourly strip & Vietnam commune/district search!
 */

export const DEFAULT_WEATHER_PREFS = {
  cityId: 'hanoi',
  customLat: null,
  customLon: null,
  customName: ''
};

// Đầy đủ 63 tỉnh / thành phố Việt Nam (sắp xếp ưu tiên các thành phố lớn trước, sau đó theo bảng chữ cái)
export const VN_CITIES = [
  { id: 'hanoi', name: 'Hà Nội', lat: 21.0285, lon: 105.8542 },
  { id: 'hcm', name: 'TP. Hồ Chí Minh', lat: 10.8231, lon: 106.6297 },
  { id: 'danang', name: 'Đà Nẵng', lat: 16.0544, lon: 108.2022 },
  { id: 'haiphong', name: 'Hải Phòng', lat: 20.8449, lon: 106.6881 },
  { id: 'cantho', name: 'Cần Thơ', lat: 10.0452, lon: 105.7469 },
  { id: 'thaibinh', name: 'Thái Bình', lat: 20.4463, lon: 106.3366 },
  { id: 'thaithuy', name: 'Thái Thụy (Thái Bình)', lat: 20.5285, lon: 106.5655 },
  { id: 'angiang', name: 'An Giang (Long Xuyên)', lat: 10.3864, lon: 105.4352 },
  { id: 'vungtau', name: 'Bà Rịa - Vũng Tàu', lat: 10.346, lon: 107.0843 },
  { id: 'bacgiang', name: 'Bắc Giang', lat: 21.2731, lon: 106.1946 },
  { id: 'backan', name: 'Bắc Kạn', lat: 22.147, lon: 105.8348 },
  { id: 'baclieu', name: 'Bạc Liêu', lat: 9.294, lon: 105.7216 },
  { id: 'bacninh', name: 'Bắc Ninh', lat: 21.1861, lon: 106.0763 },
  { id: 'bentre', name: 'Bến Tre', lat: 10.2434, lon: 106.3756 },
  { id: 'quynhon', name: 'Bình Định (Quy Nhơn)', lat: 13.782, lon: 109.2197 },
  { id: 'binhduong', name: 'Bình Dương (Thủ Dầu Một)', lat: 10.9804, lon: 106.6519 },
  { id: 'binhphuoc', name: 'Bình Phước (Đồng Xoài)', lat: 11.535, lon: 106.8832 },
  { id: 'binhthuan', name: 'Bình Thuận (Phan Thiết)', lat: 10.9289, lon: 108.1021 },
  { id: 'camau', name: 'Cà Mau', lat: 9.1768, lon: 105.1524 },
  { id: 'caobang', name: 'Cao Bằng', lat: 22.6667, lon: 106.25 },
  { id: 'bmt', name: 'Đắk Lắk (Buôn Ma Thuột)', lat: 12.6667, lon: 108.05 },
  { id: 'daknong', name: 'Đắk Nông (Gia Nghĩa)', lat: 12.0033, lon: 107.6876 },
  { id: 'dienbien', name: 'Điện Biên', lat: 21.386, lon: 103.023 },
  { id: 'bienhoa', name: 'Đồng Nai (Biên Hòa)', lat: 10.946, lon: 106.8235 },
  { id: 'dongthap', name: 'Đồng Tháp (Cao Lãnh)', lat: 10.4592, lon: 105.6325 },
  { id: 'gialai', name: 'Gia Lai (Pleiku)', lat: 13.9833, lon: 108.0 },
  { id: 'hagiang', name: 'Hà Giang', lat: 22.8233, lon: 104.9836 },
  { id: 'hanam', name: 'Hà Nam (Phủ Lý)', lat: 20.5453, lon: 105.9122 },
  { id: 'hatinh', name: 'Hà Tĩnh', lat: 18.3428, lon: 105.9057 },
  { id: 'haiduong', name: 'Hải Dương', lat: 20.9373, lon: 106.3146 },
  { id: 'haugiang', name: 'Hậu Giang (Vị Thanh)', lat: 9.7845, lon: 105.4701 },
  { id: 'hoabinh', name: 'Hòa Bình', lat: 20.8172, lon: 105.3376 },
  { id: 'hungyen', name: 'Hưng Yên', lat: 20.6464, lon: 106.0511 },
  { id: 'nhatrang', name: 'Khánh Hòa (Nha Trang)', lat: 12.2388, lon: 109.1967 },
  { id: 'kiengiang', name: 'Kiên Giang (Rạch Giá)', lat: 10.0125, lon: 105.0809 },
  { id: 'phuquoc', name: 'Phú Quốc (Kiên Giang)', lat: 10.2899, lon: 103.984 },
  { id: 'kontum', name: 'Kon Tum', lat: 14.3545, lon: 108.0076 },
  { id: 'laichau', name: 'Lai Châu', lat: 22.3964, lon: 103.4582 },
  { id: 'dalat', name: 'Lâm Đồng (Đà Lạt)', lat: 11.9404, lon: 108.4583 },
  { id: 'langson', name: 'Lạng Sơn', lat: 21.8537, lon: 106.7615 },
  { id: 'laocai', name: 'Lào Cai', lat: 22.4856, lon: 103.9707 },
  { id: 'sapa', name: 'Sa Pa (Lào Cai)', lat: 22.3364, lon: 103.8438 },
  { id: 'longan', name: 'Long An (Tân An)', lat: 10.5359, lon: 106.4137 },
  { id: 'namdinh', name: 'Nam Định', lat: 20.4388, lon: 106.1621 },
  { id: 'vinh', name: 'Nghệ An (Vinh)', lat: 18.6796, lon: 105.6813 },
  { id: 'ninhbinh', name: 'Ninh Bình', lat: 20.2506, lon: 105.9745 },
  { id: 'ninhthuan', name: 'Ninh Thuận (Phan Rang)', lat: 11.5643, lon: 108.9886 },
  { id: 'phutho', name: 'Phú Thọ (Việt Trì)', lat: 21.3227, lon: 105.402 },
  { id: 'phuyen', name: 'Phú Yên (Tuy Hòa)', lat: 13.0955, lon: 109.3209 },
  { id: 'quangbinh', name: 'Quảng Bình (Đồng Hới)', lat: 17.4689, lon: 106.6223 },
  { id: 'quangnam', name: 'Quảng Nam (Tam Kỳ)', lat: 15.5736, lon: 108.474 },
  { id: 'quangngai', name: 'Quảng Ngãi', lat: 15.1205, lon: 108.7923 },
  { id: 'halong', name: 'Quảng Ninh (Hạ Long)', lat: 20.9517, lon: 107.0748 },
  { id: 'quangtri', name: 'Quảng Trị (Đông Hà)', lat: 16.8163, lon: 107.1003 },
  { id: 'soctrang', name: 'Sóc Trăng', lat: 9.6037, lon: 105.98 },
  { id: 'sonla', name: 'Sơn La', lat: 21.3256, lon: 103.9188 },
  { id: 'tayninh', name: 'Tây Ninh', lat: 11.31, lon: 106.0983 },
  { id: 'thainguyen', name: 'Thái Nguyên', lat: 21.5942, lon: 105.8482 },
  { id: 'thanhhoa', name: 'Thanh Hóa', lat: 19.8067, lon: 105.7852 },
  { id: 'hue', name: 'Thừa Thiên Huế', lat: 16.4637, lon: 107.5909 },
  { id: 'tiengiang', name: 'Tiền Giang (Mỹ Tho)', lat: 10.36, lon: 106.36 },
  { id: 'travinh', name: 'Trà Vinh', lat: 9.9347, lon: 106.3453 },
  { id: 'tuyenquang', name: 'Tuyên Quang', lat: 21.8236, lon: 105.2142 },
  { id: 'vinhlong', name: 'Vĩnh Long', lat: 10.2537, lon: 105.9722 },
  { id: 'vinhphuc', name: 'Vĩnh Phúc (Vĩnh Yên)', lat: 21.3089, lon: 105.6049 },
  { id: 'yenbai', name: 'Yên Bái', lat: 21.7229, lon: 104.9113 }
];

export function mapWmoWeather(code) {
  const c = Number(code);
  if (c === 0) return { icon: '☀️', label: 'Trời quang, nắng đẹp' };
  if (c === 1) return { icon: '🌤️', label: 'Ít mây, nắng nhẹ' };
  if (c === 2) return { icon: '⛅', label: 'Có mây' };
  if (c === 3) return { icon: '☁️', label: 'Nhiều mây, âm u' };
  if (c === 45 || c === 48) return { icon: '🌫️', label: 'Có sương mù' };
  if (c === 51 || c === 53 || c === 55) return { icon: '🌦️', label: 'Mưa phùn nhẹ' };
  if (c === 56 || c === 57) return { icon: '🌧️', label: 'Mưa phùn lạnh' };
  if (c === 61) return { icon: '🌦️', label: 'Mưa nhỏ' };
  if (c === 63) return { icon: '🌧️', label: 'Mưa vừa' };
  if (c === 65) return { icon: '🌧️', label: 'Mưa to' };
  if (c === 66 || c === 67) return { icon: '🌧️', label: 'Mưa lạnh' };
  if (c === 71 || c === 73 || c === 75 || c === 77) return { icon: '❄️', label: 'Tuyết / Băng giá' };
  if (c === 80 || c === 81) return { icon: '🌦️', label: 'Mưa rào rải rác' };
  if (c === 82) return { icon: '🌧️', label: 'Mưa rào nặng hạt' };
  if (c === 95) return { icon: '⛈️', label: 'Mưa dông, có sấm sét' };
  if (c === 96 || c === 99) return { icon: '⛈️', label: 'Dông mạnh, đề phòng mưa đá' };
  return { icon: '⛅', label: 'Nhiều mây' };
}

export function describeAqi(usAqi) {
  const v = Number(usAqi);
  if (!Number.isFinite(v) || v <= 0) return { label: '—', level: 'good' };
  if (v <= 50) return { label: 'Tốt', level: 'good' };
  if (v <= 100) return { label: 'Trung bình', level: 'medium' };
  if (v <= 150) return { label: 'Kém (nhạy cảm)', level: 'warn' };
  if (v <= 200) return { label: 'Xấu', level: 'bad' };
  return { label: 'Rất xấu', level: 'bad' };
}

export function describeUv(uv) {
  const v = Number(uv);
  if (!Number.isFinite(v)) return { label: '—', level: 'good' };
  if (v < 3) return { label: 'Thấp', level: 'good' };
  if (v < 6) return { label: 'Trung bình', level: 'medium' };
  if (v < 8) return { label: 'Cao', level: 'warn' };
  if (v < 11) return { label: 'Rất cao', level: 'bad' };
  return { label: 'Cực cao', level: 'bad' };
}

export function resolveWeatherLocation(prefs = DEFAULT_WEATHER_PREFS) {
  if ((prefs?.cityId === 'gps' || prefs?.cityId === 'custom') && Number.isFinite(Number(prefs.customLat)) && Number.isFinite(Number(prefs.customLon))) {
    return {
      id: prefs.cityId,
      name: prefs.customName || (prefs.cityId === 'gps' ? 'Vị trí GPS' : 'Địa điểm đã chọn'),
      lat: Number(prefs.customLat),
      lon: Number(prefs.customLon)
    };
  }
  return VN_CITIES.find((c) => c.id === prefs?.cityId) || VN_CITIES[0];
}

const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes
const CACHE_STORAGE_KEY = 'lich_am_vn_weather_cache_v3';

function readCachedWeather(locKey) {
  try {
    const raw = localStorage.getItem(CACHE_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.locKey === locKey && Date.now() - parsed.fetchedAt < CACHE_TTL_MS) {
      return parsed.payload;
    }
  } catch (_e) {}
  return null;
}

function writeCachedWeather(locKey, payload) {
  try {
    localStorage.setItem(
      CACHE_STORAGE_KEY,
      JSON.stringify({ locKey, fetchedAt: Date.now(), payload })
    );
  } catch (_e) {}
}

/**
 * Search any Vietnamese commune / district / town / province down to exact coordinates
 * Uses Open-Meteo Geocoding API (fast, free, zero key) + Nominatim fallback
 */
export async function searchVietnamLocations(query) {
  const q = String(query || '').trim();
  if (q.length < 2) return [];
  const results = [];
  const seen = new Set();

  const pushItem = (name, subtitle, lat, lon) => {
    const k = `${Number(lat).toFixed(2)}_${Number(lon).toFixed(2)}`;
    if (seen.has(k) || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lon))) return;
    seen.add(k);
    results.push({
      name: String(name || '').trim(),
      subtitle: String(subtitle || '').trim(),
      label: subtitle && !String(name).toLowerCase().includes(String(subtitle).toLowerCase())
        ? `${name}, ${subtitle}`
        : String(name || '').trim(),
      lat: Number(lat),
      lon: Number(lon)
    });
  };

  try {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=8&language=vi&countryCode=VN&format=json`;
    const r = await fetch(url, { cache: 'no-store' });
    if (r.ok) {
      const data = await r.json();
      for (const it of (data?.results || [])) {
        const sub = [it.admin2, it.admin1].filter((x) => x && x !== it.name).join(', ');
        pushItem(it.name, sub, it.latitude, it.longitude);
      }
    }
  } catch (_e) {}

  if (results.length < 3) {
    try {
      const nUrl = `https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(q + ', Việt Nam')}&countrycodes=vn&limit=6&accept-language=vi`;
      const r2 = await fetch(nUrl, { cache: 'no-store' });
      if (r2.ok) {
        const arr = await r2.json();
        for (const it of (Array.isArray(arr) ? arr : [])) {
          const parts = String(it.display_name || '').split(',').map((s) => s.trim()).filter(Boolean);
          const nm = it.name || parts[0] || q;
          const sub = parts.slice(1, 3).join(', ');
          pushItem(nm, sub, it.lat, it.lon);
        }
      }
    } catch (_e) {}
  }
  return results.slice(0, 8);
}

/**
 * Reverse geocode GPS coordinates to a real Vietnamese district / province name
 */
export async function reverseGeocodeVietnam(lat, lon) {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&accept-language=vi`;
    const r = await fetch(url, { cache: 'no-store' });
    if (r.ok) {
      const data = await r.json();
      const a = data?.address || {};
      const district = a.county || a.city_district || a.town || a.village || a.suburb || a.city || '';
      const province = a.state || a.province || a.locality || '';
      const clean = [district, province]
        .map((s) => String(s || '').replace(/^Tỉnh\s+|^Thành phố\s+/i, '').trim())
        .filter((s, idx, arr) => s && arr.indexOf(s) === idx)
        .join(', ');
      if (clean) return clean;
    }
  } catch (_e) {}
  // Nearest known city fallback
  let nearest = null;
  let bestDist = Infinity;
  for (const c of VN_CITIES) {
    const d = Math.hypot(c.lat - lat, c.lon - lon);
    if (d < bestDist) { bestDist = d; nearest = c; }
  }
  if (nearest && bestDist < 0.35) return nearest.name;
  return `GPS (${Number(lat).toFixed(2)}°N, ${Number(lon).toFixed(2)}°E)`;
}

/**
 * Fetch High-Accuracy Weather:
 * - Primary: ECMWF IFS 0.25° (European Centre — gold standard for Vietnam & coastal Northern Delta)
 * - Supplement: Open-Meteo multi-model best_match (rain probability %, UV index, 24h hourly timeline, days 11-16)
 * - Air Quality: Open-Meteo CAMS (US AQI, PM2.5)
 */
export async function fetchWeatherForecast(prefs = DEFAULT_WEATHER_PREFS, forceRefresh = false) {
  const loc = resolveWeatherLocation(prefs);
  const locKey = `${loc.id}_${loc.lat.toFixed(3)}_${loc.lon.toFixed(3)}`;

  if (!forceRefresh) {
    const cached = readCachedWeather(locKey);
    if (cached) return cached;
  }

  const ecmwfUrl =
    `https://api.open-meteo.com/v1/forecast` +
    `?latitude=${encodeURIComponent(loc.lat)}` +
    `&longitude=${encodeURIComponent(loc.lon)}` +
    `&models=ecmwf_ifs025` +
    `&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum` +
    `&timezone=Asia%2FBangkok&forecast_days=10`;

  const bestUrl =
    `https://api.open-meteo.com/v1/forecast` +
    `?latitude=${encodeURIComponent(loc.lat)}` +
    `&longitude=${encodeURIComponent(loc.lon)}` +
    `&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation` +
    `&hourly=temperature_2m,precipitation_probability,precipitation,weather_code` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,uv_index_max` +
    `&timezone=Asia%2FBangkok&forecast_days=16`;

  const aqiUrl =
    `https://air-quality-api.open-meteo.com/v1/air-quality` +
    `?latitude=${encodeURIComponent(loc.lat)}` +
    `&longitude=${encodeURIComponent(loc.lon)}` +
    `&current=us_aqi,pm2_5,uv_index` +
    `&timezone=Asia%2FBangkok`;

  const [ecmwfResp, bestResp, aqiResp] = await Promise.all([
    fetch(ecmwfUrl).catch(() => null),
    fetch(bestUrl).catch(() => null),
    fetch(aqiUrl).catch(() => null)
  ]);

  const ecmwfJson = ecmwfResp && ecmwfResp.ok ? await ecmwfResp.json().catch(() => null) : null;
  const bestJson = bestResp && bestResp.ok ? await bestResp.json().catch(() => null) : null;
  if (!ecmwfJson && !bestJson) {
    throw new Error(`HTTP ${bestResp?.status || ecmwfResp?.status || 'Lỗi mạng'}`);
  }
  const aqiJson = aqiResp && aqiResp.ok ? await aqiResp.json().catch(() => null) : null;

  const useEcmwf = Boolean(ecmwfJson?.current && Number.isFinite(Number(ecmwfJson.current.temperature_2m)));
  const curRaw = useEcmwf ? ecmwfJson.current : (bestJson?.current || {});
  const curFallback = bestJson?.current || {};
  const curCode = curRaw.weather_code ?? curFallback.weather_code;
  const curInfo = mapWmoWeather(curCode);

  const aqiCur = aqiJson?.current || {};
  const aqiVal = Number.isFinite(Number(aqiCur.us_aqi)) ? Math.round(Number(aqiCur.us_aqi)) : null;
  const pm25Val = Number.isFinite(Number(aqiCur.pm2_5)) ? Math.round(Number(aqiCur.pm2_5) * 10) / 10 : null;
  const uvCurVal = Number.isFinite(Number(aqiCur.uv_index)) ? Math.round(Number(aqiCur.uv_index) * 10) / 10 : null;

  const current = {
    temp: Math.round(Number(curRaw.temperature_2m ?? curFallback.temperature_2m ?? 0)),
    feelsLike: Math.round(Number(curRaw.apparent_temperature ?? curFallback.apparent_temperature ?? curRaw.temperature_2m ?? 0)),
    humidity: Math.round(Number(curRaw.relative_humidity_2m ?? curFallback.relative_humidity_2m ?? 0)),
    wind: Math.round(Number(curRaw.wind_speed_10m ?? curFallback.wind_speed_10m ?? 0)),
    precipMm: Math.round(Number(curRaw.precipitation ?? curFallback.precipitation ?? 0) * 10) / 10,
    icon: curInfo.icon,
    label: curInfo.label,
    aqi: aqiVal,
    aqiInfo: describeAqi(aqiVal),
    pm25: pm25Val,
    uv: uvCurVal,
    uvInfo: describeUv(uvCurVal)
  };

  // Index ECMWF daily by date for higher precision on days 1-10
  const ecmwfDailyMap = {};
  if (ecmwfJson?.daily && Array.isArray(ecmwfJson.daily.time)) {
    const ed = ecmwfJson.daily;
    for (let i = 0; i < ed.time.length; i++) {
      ecmwfDailyMap[ed.time[i]] = {
        code: ed.weather_code?.[i],
        tMin: ed.temperature_2m_min?.[i],
        tMax: ed.temperature_2m_max?.[i],
        precipSum: ed.precipitation_sum?.[i]
      };
    }
  }

  const dailyByDate = {};
  const d = bestJson?.daily || ecmwfJson?.daily || {};
  const times = Array.isArray(d.time) ? d.time : [];
  for (let i = 0; i < times.length; i++) {
    const dateKey = times[i];
    const ec = ecmwfDailyMap[dateKey];
    const code = (ec && ec.code !== null && ec.code !== undefined) ? ec.code : d.weather_code?.[i];
    const info = mapWmoWeather(code);
    const tMinRaw = (ec && Number.isFinite(Number(ec.tMin))) ? ec.tMin : d.temperature_2m_min?.[i];
    const tMaxRaw = (ec && Number.isFinite(Number(ec.tMax))) ? ec.tMax : d.temperature_2m_max?.[i];
    const precipMmRaw = (ec && Number.isFinite(Number(ec.precipSum))) ? ec.precipSum : d.precipitation_sum?.[i];
    const uvMax = Number.isFinite(Number(d.uv_index_max?.[i]))
      ? Math.round(Number(d.uv_index_max[i]) * 10) / 10
      : null;
    dailyByDate[dateKey] = {
      icon: info.icon,
      label: info.label,
      tMin: Math.round(Number(tMinRaw ?? 0)),
      tMax: Math.round(Number(tMaxRaw ?? 0)),
      rainProb: Math.round(Number(d.precipitation_probability_max?.[i] ?? 0)),
      rainMm: Number.isFinite(Number(precipMmRaw)) ? Math.round(Number(precipMmRaw) * 10) / 10 : 0,
      uvMax,
      uvInfo: describeUv(uvMax)
    };
  }

  // Extract next 24 hours in 3-hour steps (6-8 slots) for crisp hourly glance
  const hourlyNext = [];
  const h = bestJson?.hourly;
  if (h && Array.isArray(h.time)) {
    const now = new Date();
    const curHourKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}T${String(now.getHours()).padStart(2, '0')}:00`;
    let startIdx = h.time.findIndex((t) => t >= curHourKey);
    if (startIdx < 0) startIdx = 0;
    for (let step = 0; step < 8; step++) {
      const idx = startIdx + step * 3;
      if (idx >= h.time.length) break;
      const tStr = String(h.time[idx]);
      const hh = tStr.slice(11, 13);
      const info = mapWmoWeather(h.weather_code?.[idx]);
      hourlyNext.push({
        timeLabel: `${hh}h`,
        icon: info.icon,
        temp: Math.round(Number(h.temperature_2m?.[idx] ?? 0)),
        rainProb: Math.round(Number(h.precipitation_probability?.[idx] ?? 0))
      });
    }
  }

  const payload = {
    locationName: loc.name,
    lat: loc.lat,
    lon: loc.lon,
    sourceLabel: useEcmwf ? 'ECMWF Châu Âu' : 'Open-Meteo',
    fetchedAt: Date.now(),
    current,
    dailyByDate,
    hourlyNext
  };

  writeCachedWeather(locKey, payload);
  return payload;
}

/**
 * Generate smart contextual lifestyle & reminder tips based on Weather + AQI + UV + Scheduled Reminders
 */
export function getSmartWeatherAdvice(dayWx, currentWx, isToday = false, dayReminders = []) {
  const tips = [];
  const activeRems = (dayReminders || []).filter((r) => !r.done);
  const firstRem = activeRems[0] || null;

  if (dayWx) {
    if (dayWx.rainProb >= 50 || dayWx.rainMm >= 3) {
      if (firstRem) {
        tips.push({
          level: 'warn',
          text: `☔ Có lịch "${firstRem.title}" (${firstRem.time}) & khả năng mưa ${dayWx.rainProb}%${dayWx.rainMm > 0 ? ` (~${dayWx.rainMm}mm)` : ''} — Nhớ mang áo mưa / ô và đi sớm!`
        });
      } else {
        tips.push({
          level: 'warn',
          text: `☔ Khả năng mưa ${dayWx.rainProb}%${dayWx.rainMm > 0 ? ` (~${dayWx.rainMm}mm)` : ''} (${dayWx.label.toLowerCase()}) — Nhớ mang theo ô / áo mưa khi ra ngoài.`
        });
      }
    } else if (dayWx.rainProb >= 30 && firstRem) {
      tips.push({
        level: 'info',
        text: `🌦️ Có lịch "${firstRem.title}" (${firstRem.time}), xác suất mưa ${dayWx.rainProb}% — Nên mang sẵn chiếc ô nhỏ.`
      });
    }

    if (dayWx.tMin <= 17) {
      tips.push({
        level: 'info',
        text: `🧥 Trời lạnh (${dayWx.tMin}°C) — Giữ ấm cổ & bàn chân khi ra ngoài sáng sớm hoặc tối muộn.`
      });
    } else if (dayWx.tMax >= 35) {
      tips.push({
        level: 'warn',
        text: `🥤 Trời nắng nóng (${dayWx.tMax}°C) — Uống thêm nước, hạn chế hoạt động ngoài trời buổi trưa.`
      });
    }

    if (dayWx.uvMax !== null && dayWx.uvMax >= 7) {
      tips.push({
        level: 'warn',
        text: `🕶️ Tia UV cao (${dayWx.uvMax} — ${dayWx.uvInfo.label}) — Dùng kem chống nắng, mũ & kính râm khi ra đường.`
      });
    }
  }

  if (isToday && currentWx && currentWx.aqi !== null && currentWx.aqi >= 101) {
    tips.push({
      level: 'bad',
      text: `😷 Không khí ${currentWx.aqiInfo.label.toLowerCase()} (AQI ${currentWx.aqi}${currentWx.pm25 !== null ? `, PM2.5: ${currentWx.pm25}` : ''}) — Nên đeo khẩu trang lọc bụi mịn khi di chuyển.`
    });
  }

  if (tips.length === 0 && dayWx) {
    tips.push({
      level: 'good',
      text: firstRem
        ? `🌤️ Thời tiết thuận lợi (${dayWx.tMin}°–${dayWx.tMax}°C) cho lịch "${firstRem.title}" lúc ${firstRem.time}!`
        : `🌤️ Thời tiết khá dễ chịu (${dayWx.tMin}°–${dayWx.tMax}°C, mưa ${dayWx.rainProb}%) — Thuận lợi cho các hoạt động trong ngày.`
    });
  }

  return tips;
}

/**
 * Request REAL high-accuracy GPS position:
 * - On Android APK (OPPO Find X9): uses native LocationManager via AndroidBridge.requestNativeGps()
 *   with automatic runtime permission prompt so it gets true GPS coordinates (never Hanoi ISP fallback!).
 * - On Web / Chrome Extension: uses navigator.geolocation with high accuracy + fallback.
 */
export function requestGpsPosition() {
  return new Promise((resolve, reject) => {
    if (typeof window !== 'undefined' && window.AndroidBridge && typeof window.AndroidBridge.requestNativeGps === 'function') {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        reject(new Error('Quá thời gian lấy tín hiệu GPS. Hãy bật Vị trí (GPS) trên điện thoại hoặc dùng ô 🔍 Tìm xã/huyện!'));
      }, 16000);

      window.__onNativeGpsResult = (res) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (res && res.ok && Number.isFinite(Number(res.lat)) && Number.isFinite(Number(res.lon))) {
          resolve({ lat: Number(res.lat), lon: Number(res.lon), accuracy: Number(res.accuracy || 0) });
        } else {
          reject(new Error(res?.error || 'Không lấy được vị trí GPS. Hãy bật Vị trí trên điện thoại hoặc dùng nút 🔍 Tìm xã/huyện!'));
        }
      };

      try {
        window.AndroidBridge.requestNativeGps();
      } catch (e) {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          reject(new Error(e?.message || 'Lỗi gọi GPS Android'));
        }
      }
      return;
    }

    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      reject(new Error('Thiết bị không hỗ trợ định vị GPS — hãy dùng ô 🔍 Tìm xã/huyện!'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude, accuracy: pos.coords.accuracy }),
      () => {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude, accuracy: pos.coords.accuracy }),
          (err) => reject(new Error(err?.message || 'Không lấy được vị trí GPS — hãy dùng ô 🔍 Tìm xã/huyện!')),
          { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
        );
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  });
}
