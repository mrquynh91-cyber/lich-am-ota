/**
 * Free Live Weather + 16-Day Daily Forecast + Air Quality (AQI, PM2.5) + UV Index Engine
 * Powered by Open-Meteo (zero API key required) + Smart Weather-to-Reminder Advice.
 */

export const DEFAULT_WEATHER_PREFS = {
  cityId: 'hanoi',
  customLat: null,
  customLon: null,
  customName: ''
};

export const VN_CITIES = [
  { id: 'hanoi', name: 'Hà Nội', lat: 21.0285, lon: 105.8542 },
  { id: 'hcm', name: 'TP. Hồ Chí Minh', lat: 10.8231, lon: 106.6297 },
  { id: 'danang', name: 'Đà Nẵng', lat: 16.0544, lon: 108.2022 },
  { id: 'haiphong', name: 'Hải Phòng', lat: 20.8449, lon: 106.6881 },
  { id: 'cantho', name: 'Cần Thơ', lat: 10.0452, lon: 105.7469 },
  { id: 'hue', name: 'Huế', lat: 16.4637, lon: 107.5909 },
  { id: 'nhatrang', name: 'Nha Trang', lat: 12.2388, lon: 109.1967 },
  { id: 'dalat', name: 'Đà Lạt', lat: 11.9404, lon: 108.4583 },
  { id: 'vungtau', name: 'Vũng Tàu', lat: 10.346, lon: 107.0843 },
  { id: 'halong', name: 'Hạ Long', lat: 20.9517, lon: 107.0748 },
  { id: 'bacninh', name: 'Bắc Ninh', lat: 21.1861, lon: 106.0763 },
  { id: 'vinh', name: 'Vinh (Nghệ An)', lat: 18.6796, lon: 105.6813 },
  { id: 'thanhhoa', name: 'Thanh Hóa', lat: 19.8067, lon: 105.7852 },
  { id: 'quynhon', name: 'Quy Nhơn', lat: 13.782, lon: 109.2197 },
  { id: 'phuquoc', name: 'Phú Quốc', lat: 10.2899, lon: 103.984 },
  { id: 'sapa', name: 'Sa Pa (Lào Cai)', lat: 22.3364, lon: 103.8438 },
  { id: 'thainguyen', name: 'Thái Nguyên', lat: 21.5942, lon: 105.8482 },
  { id: 'namdinh', name: 'Nam Định', lat: 20.4388, lon: 106.1621 },
  { id: 'bienhoa', name: 'Biên Hòa', lat: 10.946, lon: 106.8235 },
  { id: 'bmt', name: 'Buôn Ma Thuột', lat: 12.6667, lon: 108.05 }
];

export function mapWmoWeather(code) {
  const c = Number(code);
  if (c === 0) return { icon: '☀️', label: 'Trời quang, nắng đẹp' };
  if (c === 1) return { icon: '🌤️', label: 'Ít mây, nắng nhẹ' };
  if (c === 2) return { icon: '⛅', label: 'Có mây' };
  if (c === 3) return { icon: '☁️', label: 'Nhiều mây, âm u' };
  if (c === 45 || c === 48) return { icon: '🌫️', label: 'Có sương mù' };
  if (c === 51 || c === 53 || c === 55) return { icon: '🌦️', label: 'Mưa phùn nhẹ' };
  if (c === 56 || c === 57) return { icon: '🌧️', label: 'Mưa phùn lạnh' };
  if (c === 61) return { icon: '🌦️', label: 'Mưa nhỏ' };
  if (c === 63) return { icon: '🌧️', label: 'Mưa vừa' };
  if (c === 65) return { icon: '🌧️', label: 'Mưa to' };
  if (c === 66 || c === 67) return { icon: '🌧️', label: 'Mưa lạnh' };
  if (c === 71 || c === 73 || c === 75 || c === 77) return { icon: '❄️', label: 'Tuyết / Băng giá' };
  if (c === 80 || c === 81) return { icon: '🌦️', label: 'Mưa rào rải rác' };
  if (c === 82) return { icon: '🌧️', label: 'Mưa rào nặng hạt' };
  if (c === 95) return { icon: '⛈️', label: 'Mưa dông, có sấm sét' };
  if (c === 96 || c === 99) return { icon: '⛈️', label: 'Dông mạnh, đề phòng mưa đá' };
  return { icon: '⛅', label: 'Nhiều mây' };
}

export function describeAqi(usAqi) {
  const v = Number(usAqi);
  if (!Number.isFinite(v) || v <= 0) return { label: '—', level: 'good' };
  if (v <= 50) return { label: 'Tốt', level: 'good' };
  if (v <= 100) return { label: 'Trung bình', level: 'medium' };
  if (v <= 150) return { label: 'Kém (nhạy cảm)', level: 'warn' };
  if (v <= 200) return { label: 'Xấu', level: 'bad' };
  return { label: 'Rất xấu', level: 'bad' };
}

export function describeUv(uv) {
  const v = Number(uv);
  if (!Number.isFinite(v)) return { label: '—', level: 'good' };
  if (v < 3) return { label: 'Thấp', level: 'good' };
  if (v < 6) return { label: 'Trung bình', level: 'medium' };
  if (v < 8) return { label: 'Cao', level: 'warn' };
  if (v < 11) return { label: 'Rất cao', level: 'bad' };
  return { label: 'Cực cao', level: 'bad' };
}

export function resolveWeatherLocation(prefs = DEFAULT_WEATHER_PREFS) {
  if (prefs?.cityId === 'gps' && Number.isFinite(prefs.customLat) && Number.isFinite(prefs.customLon)) {
    return {
      id: 'gps',
      name: prefs.customName || 'Vị trí hiện tại (GPS)',
      lat: prefs.customLat,
      lon: prefs.customLon
    };
  }
  return VN_CITIES.find((c) => c.id === prefs?.cityId) || VN_CITIES[0];
}

const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes
const CACHE_STORAGE_KEY = 'lich_am_vn_weather_cache_v2';

function readCachedWeather(locKey) {
  try {
    const raw = localStorage.getItem(CACHE_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.locKey === locKey && Date.now() - parsed.fetchedAt < CACHE_TTL_MS) {
      return parsed.payload;
    }
  } catch (_e) {}
  return null;
}

function writeCachedWeather(locKey, payload) {
  try {
    localStorage.setItem(
      CACHE_STORAGE_KEY,
      JSON.stringify({ locKey, fetchedAt: Date.now(), payload })
    );
  } catch (_e) {}
}

/**
 * Fetch current weather + 16-day forecast + Air Quality (US AQI, PM2.5) + UV index
 */
export async function fetchWeatherForecast(prefs = DEFAULT_WEATHER_PREFS, forceRefresh = false) {
  const loc = resolveWeatherLocation(prefs);
  const locKey = `${loc.id}_${loc.lat.toFixed(2)}_${loc.lon.toFixed(2)}`;

  if (!forceRefresh) {
    const cached = readCachedWeather(locKey);
    if (cached) return cached;
  }

  const forecastUrl =
    `https://api.open-meteo.com/v1/forecast` +
    `?latitude=${encodeURIComponent(loc.lat)}` +
    `&longitude=${encodeURIComponent(loc.lon)}` +
    `&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max` +
    `&timezone=Asia%2FBangkok&forecast_days=16`;

  const aqiUrl =
    `https://air-quality-api.open-meteo.com/v1/air-quality` +
    `?latitude=${encodeURIComponent(loc.lat)}` +
    `&longitude=${encodeURIComponent(loc.lon)}` +
    `&current=us_aqi,pm2_5,uv_index` +
    `&timezone=Asia%2FBangkok`;

  const [wxResp, aqiResp] = await Promise.all([
    fetch(forecastUrl),
    fetch(aqiUrl).catch(() => null)
  ]);

  if (!wxResp.ok) {
    throw new Error(`HTTP ${wxResp.status}`);
  }
  const json = await wxResp.json();
  const aqiJson = aqiResp && aqiResp.ok ? await aqiResp.json().catch(() => null) : null;

  const curRaw = json.current || {};
  const curInfo = mapWmoWeather(curRaw.weather_code);
  const aqiCur = aqiJson?.current || {};
  const aqiVal = Number.isFinite(Number(aqiCur.us_aqi)) ? Math.round(Number(aqiCur.us_aqi)) : null;
  const pm25Val = Number.isFinite(Number(aqiCur.pm2_5)) ? Math.round(Number(aqiCur.pm2_5) * 10) / 10 : null;
  const uvCurVal = Number.isFinite(Number(aqiCur.uv_index)) ? Math.round(Number(aqiCur.uv_index) * 10) / 10 : null;

  const current = {
    temp: Math.round(Number(curRaw.temperature_2m ?? 0)),
    feelsLike: Math.round(Number(curRaw.apparent_temperature ?? curRaw.temperature_2m ?? 0)),
    humidity: Math.round(Number(curRaw.relative_humidity_2m ?? 0)),
    wind: Math.round(Number(curRaw.wind_speed_10m ?? 0)),
    icon: curInfo.icon,
    label: curInfo.label,
    aqi: aqiVal,
    aqiInfo: describeAqi(aqiVal),
    pm25: pm25Val,
    uv: uvCurVal,
    uvInfo: describeUv(uvCurVal)
  };

  const dailyByDate = {};
  const d = json.daily || {};
  const times = Array.isArray(d.time) ? d.time : [];
  for (let i = 0; i < times.length; i++) {
    const dateKey = times[i];
    const info = mapWmoWeather(d.weather_code?.[i]);
    const uvMax = Number.isFinite(Number(d.uv_index_max?.[i]))
      ? Math.round(Number(d.uv_index_max[i]) * 10) / 10
      : null;
    dailyByDate[dateKey] = {
      icon: info.icon,
      label: info.label,
      tMin: Math.round(Number(d.temperature_2m_min?.[i] ?? 0)),
      tMax: Math.round(Number(d.temperature_2m_max?.[i] ?? 0)),
      rainProb: Math.round(Number(d.precipitation_probability_max?.[i] ?? 0)),
      uvMax,
      uvInfo: describeUv(uvMax)
    };
  }

  const payload = {
    locationName: loc.name,
    fetchedAt: Date.now(),
    current,
    dailyByDate
  };

  writeCachedWeather(locKey, payload);
  return payload;
}

/**
 * Generate smart contextual lifestyle & reminder tips based on Weather + AQI + UV + Scheduled Reminders
 */
export function getSmartWeatherAdvice(dayWx, currentWx, isToday = false, dayReminders = []) {
  const tips = [];
  const activeRems = (dayReminders || []).filter((r) => !r.done);
  const firstRem = activeRems[0] || null;

  if (dayWx) {
    if (dayWx.rainProb >= 50) {
      if (firstRem) {
        tips.push({
          level: 'warn',
          text: `☔ Có lịch "${firstRem.title}" (${firstRem.time}) & khả năng mưa ${dayWx.rainProb}% — Nhớ mang áo mưa / ô và đi sớm tránh kẹt xe!`
        });
      } else {
        tips.push({
          level: 'warn',
          text: `☔ Khả năng mưa ${dayWx.rainProb}% (${dayWx.label.toLowerCase()}) — Nhớ mang theo ô / áo mưa khi ra ngoài.`
        });
      }
    } else if (dayWx.rainProb >= 30 && firstRem) {
      tips.push({
        level: 'info',
        text: `🌦️ Có lịch "${firstRem.title}" (${firstRem.time}), xác suất mưa ${dayWx.rainProb}% — Nên mang sẵn chiếc ô nhỏ.`
      });
    }

    if (dayWx.tMin <= 17) {
      tips.push({
        level: 'info',
        text: `🧥 Trời lạnh (${dayWx.tMin}°C) — Giữ ấm cổ & bàn chân khi ra ngoài sáng sớm hoặc tối muộn.`
      });
    } else if (dayWx.tMax >= 35) {
      tips.push({
        level: 'warn',
        text: `🥤 Trời nắng nóng (${dayWx.tMax}°C) — Uống thêm nước, hạn chế hoạt động ngoài trời buổi trưa.`
      });
    }

    if (dayWx.uvMax !== null && dayWx.uvMax >= 7) {
      tips.push({
        level: 'warn',
        text: `🕶️ Tia UV cao (${dayWx.uvMax} — ${dayWx.uvInfo.label}) — Dùng kem chống nắng, mũ & kính râm khi ra đường.`
      });
    }
  }

  if (isToday && currentWx && currentWx.aqi !== null && currentWx.aqi >= 101) {
    tips.push({
      level: 'bad',
      text: `😷 Không khí ${currentWx.aqiInfo.label.toLowerCase()} (AQI ${currentWx.aqi}${currentWx.pm25 !== null ? `, PM2.5: ${currentWx.pm25}` : ''}) — Nên đeo khẩu trang lọc bụi mịn khi di chuyển.`
    });
  }

  if (tips.length === 0 && dayWx) {
    tips.push({
      level: 'good',
      text: firstRem
        ? `🌤️ Thời tiết thuận lợi (${dayWx.tMin}°–${dayWx.tMax}°C) cho lịch "${firstRem.title}" lúc ${firstRem.time}!`
        : `🌤️ Thời tiết khá dễ chịu (${dayWx.tMin}°–${dayWx.tMax}°C, mưa ${dayWx.rainProb}%) — Thuận lợi cho các hoạt động trong ngày.`
    });
  }

  return tips;
}

export function requestGpsPosition() {
  return new Promise((resolve, reject) => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      reject(new Error('Thiết bị không hỗ trợ định vị GPS.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
      (err) => reject(new Error(err?.message || 'Không lấy được vị trí GPS.')),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 600000 }
    );
  });
}
