/**
 * Super-App Module Group 3 (v3.0.0 — PC + OPPO Find X9):
 *  1. Ghi chép Thu Chi AI — Giọng nói & Quét Bill / Hóa đơn (AI Scan)
 *  2. Nhắc uống thuốc & Lưu đơn thuốc (+ AI Đọc đơn thuốc + Đồng bộ báo thức Nhắc nhở!)
 *  3. Hôm nay ăn gì? — AI Gợi ý thực đơn theo Thời tiết, Tủ lạnh & Tự động gợi ý Chay Mùng 1/Rằm
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import { convertSolar2Lunar, TIMEZONE_VN } from './lunar.js';
import { pad2, formatDateKey } from './reminders.js';
import { compressImageSourceToBase64 } from './moles.js';
import { isGeminiConfigured, askGeminiGeneral } from './gemini-ai.js';
import { shareToZaloQuick } from './zalo.js';
import { mountDietGuideModule, DIET_CONDITIONS } from './diet-guide.js';

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function fmtMd(raw) {
  return escHtml(raw)
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*([^*\n]+)\*(?=$|[\s,.;:!?])/g, '$1<em>$2</em>')
    .replace(/^\s*---\s*$/gm, '<hr style="border:none;border-top:1px solid #E5E7EB;margin:6px 0;" />')
    .replace(/^\s*[\*\-]\s+/gm, '• ');
}
function fmtVnd(n) {
  return `${Math.round(Number(n) || 0).toLocaleString('vi-VN')}đ`;
}
function todayIso() {
  const d = new Date();
  return formatDateKey(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

/* ==================== 1. GHI CHÉP THU CHI AI (GIỌNG NÓI & QUÉT BILL) ==================== */

const EXP_LS_KEY = 'lich_am_expense_book_v1';
const EXP_OWNER_LS_KEY = 'lich_am_expense_owner_v1';
const LOAN_LS_KEY = 'lich_am_loan_book_v1';
const EXP_CATS = [
  '🍜 Ăn uống', '⛽ Di chuyển', '🛒 Mua sắm', '💡 Hóa đơn',
  '🏥 Y tế', '🎁 Hiếu hỷ / Quà', '🏠 Nhà cửa', '💼 Lương / Thu nhập', '🏪 Kinh doanh / Bán hàng', '🤝 Vay / Trả nợ', '📌 Khác'
];

function loadExpenses() {
  try {
    const a = JSON.parse(localStorage.getItem(EXP_LS_KEY) || '[]');
    return Array.isArray(a) ? a : [];
  } catch (_e) { return []; }
}
function saveExpenses(arr) {
  try { localStorage.setItem(EXP_LS_KEY, JSON.stringify((arr || []).slice(0, 500))); } catch (_e) {}
}
function loadLoans() {
  try {
    const a = JSON.parse(localStorage.getItem(LOAN_LS_KEY) || '[]');
    return Array.isArray(a) ? a : [];
  } catch (_e) { return []; }
}
function saveLoans(arr) {
  try { localStorage.setItem(LOAN_LS_KEY, JSON.stringify((arr || []).slice(0, 400))); } catch (_e) {}
}
function parseVietnameseQuickLoan(raw) {
  const txt = String(raw || '').trim();
  if (!txt) return null;
  const low = txt.toLowerCase();
  const isLend = /(?:cho\s+.+?\s*(?:vay|mượn|muon)|cho\s+vay|cho\s+mượn|cho\s+muon|ứng\s+cho|ung\s+cho)/i.test(low);
  const type = isLend ? 'lend' : 'borrow';

  let amount = 0;
  const mTr = txt.match(/(\d+(?:[.,]\d+)?)\s*(?:triệu|trieu|tr|củ|cu)\b/i);
  const mK = txt.match(/(\d+(?:[.,]\d+)?)\s*(?:k|nghìn|nghin|ngàn|ngan|ng)\b/i);
  const mRaw = txt.match(/(\d{1,3}(?:[.,]\d{3})+|\d{5,10})\s*(?:đ|d|vnd|vnđ)?/i);
  if (mTr) amount = Math.round(parseFloat(mTr[1].replace(',', '.')) * 1000000);
  else if (mK) amount = Math.round(parseFloat(mK[1].replace(',', '.')) * 1000);
  else if (mRaw) amount = Number(mRaw[1].replace(/[.,]/g, ''));
  if (!amount || amount <= 0) return null;

  // Extract optional due date (e.g. "hẹn 30/12", "trả 15/01/2027")
  let dueDate = '';
  const mDue = txt.match(/(?:hẹn|hen|trả|tra|hạn|han)\s*(?:ngày|ngay)?\s*(\d{1,2})\s*[\/.\-]\s*(\d{1,2})(?:\s*[\/.\-]\s*(\d{2,4}))?/i);
  if (mDue) {
    const d = Number(mDue[1]);
    const m = Number(mDue[2]);
    let y = mDue[3] ? Number(mDue[3]) : new Date().getFullYear();
    if (y < 100) y += 2000;
    if (m >= 1 && m <= 12 && d >= 1 && d <= 31) dueDate = `${y}-${pad2(m)}-${pad2(d)}`;
  }

  // Extract person name
  let person = '';
  const mP1 = txt.match(/cho\s+([^0-9,.;]+?)\s+(?:vay|mượn|muon)/i);
  const mP2 = txt.match(/(?:đi\s+vay|vay|mượn|muon|nợ|no)\s+(?:của\s+)?([^0-9,.;]+?)(?:\s+\d|$)/i);
  if (mP1 && mP1[1]) person = mP1[1].trim();
  else if (mP2 && mP2[1]) person = mP2[1].trim();
  person = person.replace(/\b(?:tiền|tien|số|so|khoản|khoan)\b/gi, '').trim();
  if (!person) person = isLend ? 'Người vay' : 'Người cho vay';
  person = person.charAt(0).toUpperCase() + person.slice(1);

  return {
    id: `loan-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    type,
    person: person.slice(0, 80),
    phone: '',
    amount,
    paidAmount: 0,
    date: todayIso(),
    dueDate,
    interest: '',
    note: txt.slice(0, 140),
    settled: false,
    settledDate: '',
    payments: []
  };
}
function diffDaysFromToday(isoDate) {
  if (!isoDate || !/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) return null;
  const [y, m, d] = isoDate.split('-').map(Number);
  const t = new Date();
  const todayMid = new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime();
  const targetMid = new Date(y, m - 1, d).getTime();
  return Math.round((targetMid - todayMid) / 86400000);
}
function fmtDateVnShort(isoDate) {
  if (!isoDate || !/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) return isoDate || '';
  const [y, m, d] = isoDate.split('-');
  return `${d}/${m}/${y}`;
}
function addMonthsIso(isoDate, monthsToAdd) {
  const m = String(isoDate || todayIso()).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return todayIso();
  const y0 = Number(m[1]);
  const mo0 = Number(m[2]) - 1;
  const d0 = Number(m[3]);
  const totalMo = y0 * 12 + mo0 + monthsToAdd;
  const y = Math.floor(totalMo / 12);
  const mo = totalMo % 12;
  const maxDay = new Date(y, mo + 1, 0).getDate();
  return `${y}-${pad2(mo + 1)}-${pad2(Math.min(d0, maxDay))}`;
}
function parseVnNumberStrict(str) {
  const s = String(str || '').trim();
  if (!s) return 0;
  // Handle Excel numbers like 1.000.000.000 or 10,000,000 or 1.6ty or 20tr
  const low = s.toLowerCase();
  const mTy = low.match(/(\d+(?:[.,]\d+)?)\s*(?:tỷ|ty|tỉ|ti)\b/);
  if (mTy) return Math.round(parseFloat(mTy[1].replace(',', '.')) * 1000000000);
  const mTr = low.match(/(\d+(?:[.,]\d+)?)\s*(?:triệu|trieu|tr|củ|cu)\b/);
  if (mTr) return Math.round(parseFloat(mTr[1].replace(',', '.')) * 1000000);
  const mK = low.match(/(\d+(?:[.,]\d+)?)\s*(?:k|nghìn|nghin|ngàn|ngan)\b/);
  if (mK) return Math.round(parseFloat(mK[1].replace(',', '.')) * 1000);
  const clean = s.replace(/[₫đ\s]/gi, '').replace(/vn[dđ]/gi, '');
  if (/^\d+(?:[.,]\d{3})+$/.test(clean)) return Number(clean.replace(/[.,]/g, '')) || 0;
  const num = Number(clean.replace(/,/g, '.'));
  return Number.isFinite(num) ? Math.round(Math.abs(num)) : 0;
}
function recalcDecliningLoan(loan) {
  const startPrincipal = Math.max(0, Math.round(Number(loan.amount) || 0));
  const defaultRate = Number(loan.annualRate) || 0;
  const rows = Array.isArray(loan.schedule) ? loan.schedule : [];
  let running = startPrincipal;
  let totalPrincipalPaid = 0;
  let totalTopUp = 0;
  let totalInterestExact = 0;

  const computedRows = [];
  const years = [];
  let curYear = null;

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const yearIdx = Math.floor(i / 12) + 1;
    const monthInYear = (i % 12) + 1;
    const rate = r.annualRate !== undefined && r.annualRate !== '' ? Number(r.annualRate) : defaultRate;
    const opening = running;
    const exactInt = opening * (rate / 100) / 12;
    const roundedInt = Math.round(exactInt);
    const paid = Math.max(0, Math.round(Number(r.principalPaid) || 0));
    const topUp = Math.max(0, Math.round(Number(r.topUp) || 0));
    const closing = Math.max(0, opening - paid + topUp);

    running = closing;
    totalPrincipalPaid += paid;
    totalTopUp += topUp;
    totalInterestExact += exactInt;

    const item = {
      idx: i,
      id: r.id || `m-${i + 1}`,
      yearIdx,
      monthInYear,
      date: (r.customDate && r.date) ? r.date : addMonthsIso(loan.date || todayIso(), i + 1),
      annualRate: rate,
      opening,
      interestExact: exactInt,
      interest: roundedInt,
      principalPaid: paid,
      topUp,
      closing,
      actualDate: String(r.actualDate || '').trim(),
      note: String(r.note || '').trim()
    };
    computedRows.push(item);

    if (!curYear || curYear.yearIdx !== yearIdx) {
      curYear = { yearIdx, rows: [], interestExactSum: 0, principalSum: 0, topUpSum: 0, endBalance: closing };
      years.push(curYear);
    }
    curYear.rows.push(item);
    curYear.interestExactSum += exactInt;
    curYear.principalSum += paid;
    curYear.topUpSum += topUp;
    curYear.endBalance = closing;
  }

  const paidYearsSet = new Set(Array.isArray(loan.paidInterestYears) ? loan.paidInterestYears.map(Number) : []);
  let paidInterestSum = 0;
  let unpaidInterestSum = 0;
  years.forEach((y) => {
    y.interestTotal = Math.round(y.interestExactSum);
    y.isInterestPaid = paidYearsSet.has(y.yearIdx);
    if (y.isInterestPaid) paidInterestSum += y.interestTotal;
    else unpaidInterestSum += y.interestTotal;
  });

  // Forecast remaining months if paying minMonthlyPrincipal (or 20tr fallback)
  const minStep = Math.max(0, Math.round(Number(loan.minMonthlyPrincipal) || 0));
  let forecastMonths = 0;
  let forecastInterest = 0;
  let forecastEndDate = '';
  if (!loan.settled && running > 0 && minStep > 0) {
    let simBal = running;
    const simRate = computedRows.length > 0 ? computedRows[computedRows.length - 1].annualRate : defaultRate;
    const lastDate = computedRows.length > 0 ? computedRows[computedRows.length - 1].date : (loan.date || todayIso());
    while (simBal > 0 && forecastMonths < 600) {
      forecastMonths++;
      forecastInterest += simBal * (simRate / 100) / 12;
      simBal = Math.max(0, simBal - minStep);
    }
    forecastEndDate = addMonthsIso(lastDate, forecastMonths);
  }

  return {
    rows: computedRows,
    years,
    startPrincipal,
    totalTopUp,
    totalPrincipalPaid,
    currentBalance: loan.settled ? 0 : running,
    totalInterest: Math.round(totalInterestExact),
    paidInterest: paidInterestSum,
    unpaidInterest: unpaidInterestSum,
    forecastMonths,
    forecastInterest: Math.round(forecastInterest),
    forecastEndDate
  };
}
function getLoanRemainingBalance(loan) {
  if (!loan || loan.settled) return 0;
  if (loan.calcMode === 'declining') {
    return recalcDecliningLoan(loan).currentBalance;
  }
  return Math.max(0, (Number(loan.amount) || 0) - (Number(loan.paidAmount) || 0));
}
function parsePastedLoanSchedule(rawText, defaultRate = 7) {
  const lines = String(rawText || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const parsed = [];
  for (const line of lines) {
    const cols = line.split('\t').map((c) => c.trim());
    if (cols.length < 2) continue;
    // Skip header or yellow subtotal rows
    const lowLine = line.toLowerCase();
    if (lowLine.includes('tổng cộng') || lowLine.includes('gốc tháng trước') || lowLine.includes('góp hàng tháng')) continue;
    // Detect date column (usually col 0 or col 1: e.g. 4/6/2024)
    let dateColIdx = -1;
    let isoDate = '';
    for (let i = 0; i < Math.min(cols.length, 3); i++) {
      const mD = cols[i].match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})$/);
      if (mD) {
        const d = Number(mD[1]);
        const mo = Number(mD[2]);
        let y = Number(mD[3]);
        if (y < 100) y += 2000;
        if (mo >= 1 && mo <= 12 && d >= 1 && d <= 31) {
          dateColIdx = i;
          isoDate = `${y}-${pad2(mo)}-${pad2(d)}`;
          break;
        }
      }
    }
    if (!isoDate) continue; // Skip yellow yearly summary rows without a period date

    // Match spreadsheet layout: [Thang, Ngay, LaiSuatThang, Lai, GocTruoc, GopHangThang, GocConLai, GhiChu?, NgayThucTra?]
    // Also handle shorter pasted format: [Ngay, GopHangThang, GhiChu?]
    let rate = defaultRate;
    let opening = 0;
    let paid = 0;
    let closing = 0;
    let topUp = 0;
    let note = '';
    let actualDate = '';

    const after = cols.slice(dateColIdx + 1);
    if (after.length >= 5) {
      // Full Excel format from screenshot: [0: rate, 1: interest, 2: opening, 3: paid, 4: closing, 5?: note, 6?: actualDate]
      const rateRaw = parseFloat(after[0].replace(',', '.'));
      if (Number.isFinite(rateRaw) && rateRaw > 0) {
        rate = rateRaw < 0.1 ? Math.round(rateRaw * 12 * 10000) / 100 : rateRaw;
      }
      opening = parseVnNumberStrict(after[2]);
      paid = parseVnNumberStrict(after[3]);
      closing = parseVnNumberStrict(after[4]);
      if (opening > 0 && closing > Math.max(0, opening - paid) + 1000) {
        topUp = closing - Math.max(0, opening - paid);
      }
      if (after[5]) note = after[5].slice(0, 120);
      if (after[6]) actualDate = after[6].slice(0, 40);
      // Skip initial balance row (like 4/5/2024 with empty opening & paid, only closing = 1.000.000.000)
      if (opening === 0 && paid === 0 && closing > 0) continue;
    } else {
      // Compact format: [Ngay, TraGoc, VayThem?, GhiChu?]
      paid = parseVnNumberStrict(after[0]);
      if (after[1]) {
        const maybeNum = parseVnNumberStrict(after[1]);
        if (/^\d[\d.,\s]*(?:tr|k|tỷ|ty|đ)?$/i.test(after[1]) && maybeNum > 0) topUp = maybeNum;
        else note = after[1].slice(0, 120);
      }
      if (after[2]) note = after[2].slice(0, 120);
    }

    parsed.push({
      id: `m-imp-${Date.now()}-${parsed.length}`,
      date: isoDate,
      annualRate: rate,
      principalPaid: paid,
      topUp,
      actualDate,
      note
    });
  }
  return parsed;
}
function loadExpenseOwner() {
  try { return String(localStorage.getItem(EXP_OWNER_LS_KEY) || '').trim(); } catch (_e) { return ''; }
}
function saveExpenseOwner(v) {
  try { localStorage.setItem(EXP_OWNER_LS_KEY, String(v || '').trim().slice(0, 120)); } catch (_e) {}
}

function parseAiAmount(val) {
  if (typeof val === 'number' && Number.isFinite(val)) return Math.round(Math.abs(val));
  const raw = String(val || '').trim();
  if (!raw) return 0;
  const mTr = raw.match(/(\d+(?:[.,]\d+)?)\s*(?:triệu|trieu|tr|củ|cu)\b/i);
  if (mTr) return Math.round(parseFloat(mTr[1].replace(',', '.')) * 1000000);
  const mK = raw.match(/(\d+(?:[.,]\d+)?)\s*(?:k|nghìn|nghin|ngàn|ngan)\b/i);
  if (mK) return Math.round(parseFloat(mK[1].replace(',', '.')) * 1000);
  // Strip currency/signs/spaces, handle 26,300,000 or 26.300.000 or 26300000.00
  const cleaned = raw.replace(/[+\-₫đ\s]/gi, '').replace(/vn[dđ]/gi, '');
  if (/^\d+(?:[.,]\d{3})+$/.test(cleaned)) {
    return Number(cleaned.replace(/[.,]/g, '')) || 0;
  }
  if (/^\d+[.,]\d{1,2}$/.test(cleaned)) {
    return Math.round(parseFloat(cleaned.replace(',', '.'))) || 0;
  }
  const digits = cleaned.replace(/[^\d]/g, '');
  return digits ? Number(digits) || 0 : 0;
}

function parseAiDate(val) {
  const s = String(val || '').trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const mDmy = s.match(/(\d{1,2})\s*[\/.\-]\s*(\d{1,2})\s*[\/.\-]\s*(\d{2,4})/);
  if (mDmy) {
    const d = Number(mDmy[1]);
    const m = Number(mDmy[2]);
    let y = Number(mDmy[3]);
    if (y < 100) y += 2000;
    if (m >= 1 && m <= 12 && d >= 1 && d <= 31 && y >= 2000 && y <= 2100) {
      return `${y}-${pad2(m)}-${pad2(d)}`;
    }
  }
  const mVn = s.match(/ngày\s*(\d{1,2})\s*tháng\s*(\d{1,2})\s*năm\s*(\d{2,4})/i);
  if (mVn) {
    const d = Number(mVn[1]);
    const m = Number(mVn[2]);
    let y = Number(mVn[3]);
    if (y < 100) y += 2000;
    if (m >= 1 && m <= 12 && d >= 1 && d <= 31) return `${y}-${pad2(m)}-${pad2(d)}`;
  }
  return todayIso();
}

function extractAiJsonItems(raw) {
  const txt = String(raw || '').replace(/```(?:json)?/gi, '').replace(/```/g, '').trim();
  const candidates = [txt];
  const mObj = txt.match(/\{[\s\S]*\}/);
  if (mObj) candidates.push(mObj[0]);
  const mArr = txt.match(/\[[\s\S]*\]/);
  if (mArr) candidates.push(mArr[0]);
  for (const c of candidates) {
    try {
      const parsed = JSON.parse(c);
      if (Array.isArray(parsed)) return parsed;
      if (Array.isArray(parsed?.items)) return parsed.items;
      if (Array.isArray(parsed?.transactions)) return parsed.transactions;
      if (parsed && typeof parsed === 'object' && (parsed.amount !== undefined || parsed.total !== undefined)) {
        return [parsed];
      }
    } catch (_e) {}
  }
  return [];
}

function parseVietnameseQuickTx(raw) {
  const txt = String(raw || '').trim();
  if (!txt) return null;
  const low = txt.toLowerCase();
  const isIncome = /(?:lương|luong|thưởng|thuong|nhận tiền|nhan tien|bán hàng|ban hang|thu nhập|thu nhap|lãi|lai|hoàn tiền|hoan tien|khách ck|khach ck|khách chuyển|khach chuyen|thu tiền|thu tien)/i.test(low);

  // Match Vietnamese money: 35k, 1.5tr, 250 nghìn, 500000đ, 120.000
  let amount = 0;
  const mTr = txt.match(/(\d+(?:[.,]\d+)?)\s*(?:triệu|trieu|tr|củ|cu)\b/i);
  const mK = txt.match(/(\d+(?:[.,]\d+)?)\s*(?:k|nghìn|nghin|ngàn|ngan|ng)\b/i);
  const mRaw = txt.match(/(\d{1,3}(?:[.,]\d{3})+|\d{4,9})\s*(?:đ|d|vnd|vnđ)?/i);

  if (mTr) amount = Math.round(parseFloat(mTr[1].replace(',', '.')) * 1000000);
  else if (mK) amount = Math.round(parseFloat(mK[1].replace(',', '.')) * 1000);
  else if (mRaw) amount = Number(mRaw[1].replace(/[.,]/g, ''));
  if (!amount || amount <= 0) return null;

  let cat = isIncome ? '💼 Lương / Thu nhập' : '📌 Khác';
  if (!isIncome) {
    if (/(?:ăn|an|phở|pho|cơm|com|bún|bun|cafe|cà phê|trà|tra|nhậu|nhau|uống|uong|bánh|banh|sáng|trưa|tối)/i.test(low)) cat = '🍜 Ăn uống';
    else if (/(?:xăng|xang|grab|taxi|xe|gửi xe|gui xe|vé|ve|bay|cầu đường)/i.test(low)) cat = '⛽ Di chuyển';
    else if (/(?:điện|dien|nước|nuoc|mạng|mang|internet|wifi|cước|cuoc|thẻ|the)/i.test(low)) cat = '💡 Hóa đơn';
    else if (/(?:thuốc|thuoc|khám|kham|bệnh|benh|viện|vien)/i.test(low)) cat = '🏥 Y tế';
    else if (/(?:mua|siêu thị|sieu thi|chợ|cho|quần|áo|giày|shopee|lazada)/i.test(low)) cat = '🛒 Mua sắm';
    else if (/(?:cưới|cuoi|mừng|mung|biếu|bieu|quà|qua|giỗ|gio|cúng|cung)/i.test(low)) cat = '🎁 Hiếu hỷ / Quà';
    else if (/(?:nhà|nha|thuê|thue|phòng|phong|sửa|sua)/i.test(low)) cat = '🏠 Nhà cửa';
  }

  return {
    id: `tx-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    type: isIncome ? 'income' : 'expense',
    amount,
    category: cat,
    title: txt.slice(0, 90),
    date: todayIso()
  };
}

export function mountExpenseAiModule(mountEl, opts = {}) {
  if (!mountEl) return null;
  const { getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onFinanceChange = null } = opts;

  let txs = loadExpenses();
  let loans = loadLoans();
  const buildSigMap = (arr) => {
    const m = new Map();
    for (const it of Array.isArray(arr) ? arr : []) {
      if (it && it.id) m.set(it.id, JSON.stringify({ ...it, updatedAt: 0 }));
    }
    return m;
  };
  let prevExpSigs = buildSigMap(txs);
  let prevLoanSigs = buildSigMap(loans);

  const saveExpenses = (arr) => {
    const list = (Array.isArray(arr) ? arr : []).slice(0, 500);
    const now = Date.now();
    const curIds = new Set();
    for (const it of list) {
      if (!it || !it.id) continue;
      curIds.add(it.id);
      const sig = JSON.stringify({ ...it, updatedAt: 0 });
      if (!it.updatedAt || prevExpSigs.get(it.id) !== sig) {
        it.updatedAt = now;
        prevExpSigs.set(it.id, sig);
      }
    }
    const deletedIds = [];
    for (const oldId of Array.from(prevExpSigs.keys())) {
      if (!curIds.has(oldId)) {
        deletedIds.push(oldId);
        prevExpSigs.delete(oldId);
      }
    }
    try { localStorage.setItem(EXP_LS_KEY, JSON.stringify(list)); } catch (_e) {}
    onFinanceChange?.('expenseBook', list, deletedIds);
  };

  const saveLoans = (arr) => {
    const list = (Array.isArray(arr) ? arr : []).slice(0, 400);
    const now = Date.now();
    const curIds = new Set();
    for (const it of list) {
      if (!it || !it.id) continue;
      curIds.add(it.id);
      const sig = JSON.stringify({ ...it, updatedAt: 0 });
      if (!it.updatedAt || prevLoanSigs.get(it.id) !== sig) {
        it.updatedAt = now;
        prevLoanSigs.set(it.id, sig);
      }
    }
    const deletedIds = [];
    for (const oldId of Array.from(prevLoanSigs.keys())) {
      if (!curIds.has(oldId)) {
        deletedIds.push(oldId);
        prevLoanSigs.delete(oldId);
      }
    }
    try { localStorage.setItem(LOAN_LS_KEY, JSON.stringify(list)); } catch (_e) {}
    onFinanceChange?.('loanBook', list, deletedIds);
  };
  let activePane = 'cashbook'; // 'cashbook' | 'loans'
  let filterMonth = todayIso().slice(0, 7); // YYYY-MM (or 'all')
  let showAllMonths = false;
  let filterType = 'all';
  let editingTxId = null;
  let loanFilter = 'open'; // 'all' | 'lend' | 'borrow' | 'open' | 'settled'
  let loanSearch = '';
  let editingLoanId = null;
  let payingLoanId = null;
  let expandedSchedLoanId = null;
  let userCollapsedSched = false;
  let editingSchedRowKey = null; // `${loanId}::${rowIdx}`
  let openPasteLoanId = null;
  let busy = false;
  let webRec = null;
  let loanWebRec = null;
  let ownerName = loadExpenseOwner();

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-emerald">
        <div>
          <h2 class="sf-hero-title">💰 Sổ Quỹ Thu Chi &amp; Vay Mượn AI</h2>
          <div class="sf-hero-sub">Quét Bill ngân hàng, ảnh chat Zalo/Messenger, ghi thu chi &amp; theo dõi sổ Cho Vay / Đi Vay tiện lợi.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-exp-back">← Thêm</button>
      </div>

      <div class="exp-main-tabs" id="exp-main-tabs" role="tablist">
        <button type="button" class="exp-main-tab active" data-pane="cashbook" role="tab">💰 Sổ Thu Chi</button>
        <button type="button" class="exp-main-tab" data-pane="loans" role="tab">🤝 Vay &amp; Cho Vay <span id="exp-loan-badge" class="exp-tab-badge hidden">0</span></button>
      </div>

      <!-- ==================== PANE 1: SỔ THU CHI ==================== -->
      <div id="exp-pane-cashbook">
      <div class="sf-card">
        <div class="sf-field">
          <label for="exp-quick-inp">🎙️ Nói hoặc gõ nhanh (VD: "Ăn sáng phở bò 45k", "Khách CK 13.4tr", "Nhận lương 20tr")</label>
          <div class="sf-btn-row" style="flex-wrap:nowrap;">
            <input id="exp-quick-inp" type="text" placeholder="Nhập hoặc bấm 🎙️ để nói..." style="flex:1;min-width:0;padding:8px 10px;border:1px solid #DFD5C5;border-radius:9px;font-size:13px;" />
            <button type="button" id="btn-exp-voice" class="sf-btn" title="Nói tiếng Việt">🎙️</button>
            <button type="button" id="btn-exp-add-quick" class="sf-btn emerald">+ Ghi</button>
          </div>
        </div>

        <div class="exp-action-stack">
          <label class="sf-btn ai full" style="cursor:pointer;justify-content:center;padding:10px 12px;font-size:13px;">
            📸 Quét Bill / Ảnh Chat CK (Chọn 1 hoặc nhiều ảnh)
            <input id="exp-bill-file" type="file" accept="image/*" multiple class="hidden" />
          </label>
          <div class="exp-action-grid2">
            <button type="button" id="btn-exp-ai-parse" class="sf-btn" style="justify-content:center;">✨ AI tách câu</button>
            <button type="button" id="btn-exp-manual-toggle" class="sf-btn" style="justify-content:center;">✏️ Nhập chi tiết</button>
          </div>
        </div>

        <div class="exp-owner-bar">
          <span style="font-weight:700;color:#475569;white-space:nowrap;" title="Giúp AI nhận ra tài khoản/tên shop của bạn để phân biệt Thu (nhận tiền) vs Chi (chuyển tiền) chính xác hơn">👤 Tên/TK tôi:</span>
          <input id="exp-owner-inp" type="text" value="${escHtml(ownerName)}" placeholder="Tùy chọn (VD: NGUYEN VAN A, Ten Shop...)" maxlength="100" />
        </div>

        <div id="exp-manual-box" class="hidden" style="background:#FAF6F0;border:1px solid #EAE0D2;border-radius:10px;padding:9px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
            <strong id="exp-manual-heading" style="font-size:12.5px;color:#7C2D12;">✏️ Nhập giao dịch chi tiết</strong>
            <button type="button" id="btn-exp-m-cancel" class="exp-mini-btn">✕ Đóng</button>
          </div>
          <div class="sf-grid-2">
            <div class="sf-field"><label for="exp-m-type">Loại</label><select id="exp-m-type"><option value="expense">💸 Chi tiêu</option><option value="income">💵 Thu nhập</option></select></div>
            <div class="sf-field"><label for="exp-m-amt">Số tiền (VNĐ)</label><input id="exp-m-amt" type="number" min="0" placeholder="VD: 50000" /></div>
          </div>
          <div class="sf-grid-2">
            <div class="sf-field"><label for="exp-m-cat">Danh mục</label><select id="exp-m-cat">${EXP_CATS.map((c) => `<option value="${c}">${c}</option>`).join('')}</select></div>
            <div class="sf-field"><label for="exp-m-date">Ngày</label><input id="exp-m-date" type="date" value="${todayIso()}" /></div>
          </div>
          <div class="sf-field"><label for="exp-m-title">Ghi chú</label><input id="exp-m-title" type="text" placeholder="Nội dung khoản thu/chi..." maxlength="120" /></div>
          <button type="button" id="btn-exp-m-save" class="sf-btn primary full">💾 Lưu khoản này</button>
        </div>

        <div id="exp-status" class="sf-status"></div>
        <div id="exp-scan-banner" class="exp-scan-banner hidden"></div>
      </div>

      <div class="sf-card">
        <div class="sf-btn-row" style="justify-content:space-between;align-items:center;margin-bottom:8px;gap:6px;flex-wrap:wrap;">
          <strong style="font-size:13.5px;color:#065F46;">📊 Thống kê</strong>
          <div style="display:flex;align-items:center;gap:5px;">
            <button type="button" id="btn-exp-scope-all" class="exp-mini-btn" title="Xem toàn bộ các tháng">Tất cả tháng</button>
            <input id="exp-month-pick" type="month" value="${filterMonth}" style="padding:4px 7px;border:1px solid #DFD5C5;border-radius:8px;font-size:12px;font-weight:700;" />
          </div>
        </div>
        <div id="exp-kpi-grid" class="exp-summary-grid"></div>
        <div id="exp-cat-bars" style="margin-bottom:8px;"></div>
        <div class="sf-btn-row">
          <button type="button" id="btn-exp-ai-review" class="sf-btn ai" style="flex:1;">✨ AI Nhận xét chi tiêu</button>
          <button type="button" id="btn-exp-csv" class="sf-btn">⬇️ Xuất CSV</button>
        </div>
      </div>

      <div id="exp-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head"><strong>✨ AI Phân tích &amp; Gợi ý tiết kiệm</strong></div>
        <div id="exp-ai-body" class="dream-result-body"></div>
      </div>

      <div class="sf-card">
        <div class="sf-seg" id="exp-filter-seg">
          <button type="button" class="sf-seg-btn active" data-f="all">Tất cả</button>
          <button type="button" class="sf-seg-btn" data-f="expense">💸 Chi</button>
          <button type="button" class="sf-seg-btn" data-f="income">💵 Thu</button>
        </div>
        <div style="font-size:11px;color:#6B7280;margin:-2px 0 8px;text-align:center;">💡 Chạm <strong>⇄ Thu/Chi</strong> để đổi nhanh loại giao dịch hoặc <strong>✏️</strong> để sửa</div>
        <div id="exp-list" class="sf-kv-list"></div>
      </div>
      </div>

      <!-- ==================== PANE 2: SỔ CHO VAY / ĐI VAY ==================== -->
      <div id="exp-pane-loans" class="hidden">
        <div class="sf-card">
          <div class="sf-btn-row" style="justify-content:space-between;align-items:center;margin-bottom:8px;gap:6px;">
            <strong style="font-size:13.5px;color:#065F46;">🤝 Tổng quan Vay &amp; Cho Vay</strong>
            <button type="button" id="btn-loan-csv" class="exp-mini-btn">⬇️ Xuất CSV</button>
          </div>
          <div id="loan-kpi-grid" class="exp-summary-grid"></div>
          <div id="loan-kpi-sub" style="font-size:11.5px;color:#475569;text-align:center;"></div>
        </div>

        <div class="sf-card">
          <div class="sf-field">
            <label for="loan-quick-inp">🎙️ Ghi nhanh khoản vay (VD: "Cho anh Minh vay 5tr hẹn 30/12", "Mượn cô Lan 2 triệu")</label>
            <div class="sf-btn-row" style="flex-wrap:nowrap;">
              <input id="loan-quick-inp" type="text" placeholder="Nhập nhanh hoặc bấm 🎙️ để nói..." style="flex:1;min-width:0;padding:8px 10px;border:1px solid #DFD5C5;border-radius:9px;font-size:13px;" />
              <button type="button" id="btn-loan-voice" class="sf-btn" title="Nói tiếng Việt">🎙️</button>
              <button type="button" id="btn-loan-add-quick" class="sf-btn emerald">+ Ghi</button>
            </div>
          </div>

          <div class="exp-action-grid2" style="margin-bottom:6px;">
            <button type="button" id="btn-loan-form-toggle" class="sf-btn primary" style="justify-content:center;">➕ Vay đơn giản</button>
            <button type="button" id="btn-loan-declining-toggle" class="sf-btn emerald" style="justify-content:center;">📊 Vay lãi giảm dần</button>
          </div>

          <div id="loan-form-box" class="hidden" style="background:#FAF6F0;border:1px solid #EAE0D2;border-radius:10px;padding:9px;margin-top:6px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
              <strong id="loan-form-heading" style="font-size:12.5px;color:#7C2D12;">🤝 Thêm khoản Cho vay / Đi vay</strong>
              <button type="button" id="btn-loan-form-cancel" class="exp-mini-btn">✕ Đóng</button>
            </div>
            <div class="sf-field">
              <label for="loan-f-mode">Cách tính lãi &amp; trả góp</label>
              <select id="loan-f-mode">
                <option value="simple">🤝 Vay đơn giản (trả 1 lần / trả từng phần không bảng lãi)</option>
                <option value="declining">📊 Vay trả góp lãi giảm dần theo tháng (như bảng Excel: lãi %/năm tụt theo dư nợ, gom trả lãi cuối năm)</option>
              </select>
            </div>
            <div class="sf-grid-2">
              <div class="sf-field">
                <label for="loan-f-type">Loại giao dịch</label>
                <select id="loan-f-type">
                  <option value="lend">📤 Cho vay (Người khác nợ mình)</option>
                  <option value="borrow">📥 Đi vay / Mượn (Mình nợ người khác)</option>
                </select>
              </div>
              <div class="sf-field">
                <label for="loan-f-amount">Số tiền gốc ban đầu (gõ được 1.6 tỷ, 100tr...)</label>
                <input id="loan-f-amount" type="text" inputmode="decimal" placeholder="VD: 1.6 tỷ hoặc 1600000000" />
                <div id="loan-f-amount-preview" style="font-size:11px;font-weight:700;color:#047857;margin-top:2px;"></div>
              </div>
            </div>
            <div class="loan-quick-chips" style="margin-bottom:8px;">
              <button type="button" class="exp-mini-btn loan-amt-chip" data-add="1000000">+1tr</button>
              <button type="button" class="exp-mini-btn loan-amt-chip" data-add="10000000">+10tr</button>
              <button type="button" class="exp-mini-btn loan-amt-chip" data-add="100000000">+100tr</button>
              <button type="button" class="exp-mini-btn loan-amt-chip" data-add="500000000">+500tr</button>
              <button type="button" class="exp-mini-btn loan-amt-chip" data-add="1000000000">+1 tỷ</button>
              <button type="button" class="exp-mini-btn" id="btn-loan-amt-clear">✕ Xóa số</button>
            </div>

            <div id="loan-declining-fields" class="loan-declining-box hidden">
              <div style="font-size:11.5px;font-weight:800;color:#92400E;margin-bottom:6px;">📊 Lãi giảm dần theo dư nợ thực tế từng tháng (trả gốc linh hoạt mỗi tháng, đủ 1 năm trả lãi)</div>
              <div class="sf-grid-2">
                <div class="sf-field">
                  <label for="loan-f-rate">Lãi suất (%/năm)</label>
                  <input id="loan-f-rate" type="number" step="0.1" min="0" max="100" value="7" placeholder="VD: 7" />
                </div>
                <div class="sf-field">
                  <label for="loan-f-min-principal">Gợi ý trả gốc/tháng (tùy chọn — không bắt buộc)</label>
                  <input id="loan-f-min-principal" type="text" inputmode="decimal" value="" placeholder="Để trống nếu trả linh hoạt" />
                </div>
              </div>
              <div class="loan-quick-chips" style="margin-bottom:7px;">
                <button type="button" class="exp-mini-btn loan-min-chip" data-val="">Linh hoạt (không cố định)</button>
                <button type="button" class="exp-mini-btn loan-min-chip" data-val="10000000">10tr/T</button>
                <button type="button" class="exp-mini-btn loan-min-chip" data-val="20000000">20tr/T</button>
                <button type="button" class="exp-mini-btn loan-min-chip" data-val="50000000">50tr/T</button>
              </div>
              <div class="sf-grid-2">
                <div class="sf-field">
                  <label for="loan-f-int-cycle">Kỳ thanh toán lãi</label>
                  <select id="loan-f-int-cycle">
                    <option value="yearly">📅 1 năm trả lãi 1 lần (Gom 12 tháng cuối năm)</option>
                    <option value="monthly">🗓 Trả lãi hàng tháng</option>
                  </select>
                </div>
                <div class="sf-field" id="loan-init-months-wrap">
                  <label for="loan-f-init-months">Khởi tạo bảng tháng</label>
                  <select id="loan-f-init-months">
                    <option value="12_blank">Tạo sẵn 12 tháng Năm 1 (tự nhập số trả gốc từng tháng)</option>
                    <option value="0">Để trống (dùng khi dán lịch sử từ Excel)</option>
                    <option value="12_fixed">Tạo sẵn 12 tháng điền mức gợi ý</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="sf-grid-2">
              <div class="sf-field">
                <label for="loan-f-person">Tên người vay / chủ nợ *</label>
                <input id="loan-f-person" type="text" placeholder="VD: Người thân, Anh Minh..." maxlength="80" />
              </div>
              <div class="sf-field">
                <label for="loan-f-phone">SĐT liên hệ (tùy chọn)</label>
                <input id="loan-f-phone" type="tel" placeholder="VD: 0912345678" maxlength="20" />
              </div>
            </div>
            <div class="sf-grid-2">
              <div class="sf-field">
                <label for="loan-f-date">Ngày bắt đầu vay (chốt ngày hàng tháng)</label>
                <input id="loan-f-date" type="date" value="${todayIso()}" />
              </div>
              <div class="sf-field">
                <label for="loan-f-due">Hạn trả cuối (tùy chọn)</label>
                <input id="loan-f-due" type="date" />
              </div>
            </div>
            <div class="sf-grid-2">
              <div class="sf-field" id="loan-simple-int-wrap">
                <label for="loan-f-interest">Lãi suất / Hình thức (tùy chọn)</label>
                <input id="loan-f-interest" type="text" placeholder="VD: Không lãi, 7%/năm..." maxlength="50" />
              </div>
              <div class="sf-field">
                <label for="loan-f-note">Ghi chú / Điều khoản lãi</label>
                <input id="loan-f-note" type="text" placeholder="VD: Sau 5/2026 nếu LS bank > 7% tính theo bank..." maxlength="180" />
              </div>
            </div>
            <label id="loan-sync-row" style="display:flex;align-items:center;gap:6px;font-size:12px;color:#334155;margin:2px 0 8px;cursor:pointer;">
              <input type="checkbox" id="loan-f-sync-cash" />
              <span>💰 Đồng thời ghi khoản này vào Sổ Thu Chi</span>
            </label>
            <button type="button" id="btn-loan-f-save" class="sf-btn emerald full" style="justify-content:center;">💾 Lưu khoản vay / mượn</button>
          </div>

          <div id="loan-status" class="sf-status"></div>
        </div>

        <div class="sf-card">
          <div class="sf-seg" id="loan-filter-seg">
            <button type="button" class="sf-seg-btn active" data-lf="open">⏳ Đang mở</button>
            <button type="button" class="sf-seg-btn" data-lf="lend">📤 Cho vay</button>
            <button type="button" class="sf-seg-btn" data-lf="borrow">📥 Đi vay</button>
            <button type="button" class="sf-seg-btn" data-lf="settled">✅ Đã xong</button>
            <button type="button" class="sf-seg-btn" data-lf="all">Tất cả</button>
          </div>
          <input id="loan-search-inp" type="text" placeholder="🔍 Tìm theo tên người, SĐT hoặc ghi chú..." style="width:100%;padding:7px 10px;border:1px solid #DFD5C5;border-radius:9px;font-size:12.5px;margin-bottom:8px;" />
          <div id="loan-list" class="sf-kv-list"></div>
        </div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  const setStatus = (m, err = false) => {
    q('#exp-status').className = err ? 'sf-status err' : 'sf-status';
    q('#exp-status').textContent = m || '';
  };

  const openEditTx = (tx) => {
    editingTxId = tx ? tx.id : null;
    q('#exp-manual-heading').textContent = tx ? '✏️ Sửa giao dịch' : '✏️ Nhập giao dịch chi tiết';
    q('#btn-exp-m-save').textContent = tx ? '💾 Cập nhật giao dịch' : '💾 Lưu khoản này';
    q('#exp-m-type').value = tx?.type === 'income' ? 'income' : 'expense';
    q('#exp-m-amt').value = tx ? String(tx.amount || '') : '';
    q('#exp-m-cat').value = tx && EXP_CATS.includes(tx.category) ? tx.category : EXP_CATS[0];
    q('#exp-m-date').value = tx?.date || todayIso();
    q('#exp-m-title').value = tx?.title || '';
    q('#exp-manual-box').classList.remove('hidden');
    q('#exp-manual-box').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  };

  const flipTxType = (txId) => {
    const target = txs.find((x) => x.id === txId);
    if (!target) return;
    target.type = target.type === 'income' ? 'expense' : 'income';
    if (target.type === 'income' && target.category === '📌 Khác') target.category = '💼 Lương / Thu nhập';
    saveExpenses(txs);
    setStatus(`⇄ Đã đổi "${target.title.slice(0, 40)}" thành ${target.type === 'income' ? '💵 THU' : '💸 CHI'} (${fmtVnd(target.amount)})!`);
    renderAll();
  };

  const renderScanBanner = (addedList, switchedMonthNote = '') => {
    const box = q('#exp-scan-banner');
    if (!box) return;
    if (!addedList || addedList.length === 0) {
      box.classList.add('hidden');
      box.innerHTML = '';
      return;
    }
    box.classList.remove('hidden');
    box.innerHTML = `
      <div style="font-weight:800;">✅ AI đã ghi ${addedList.length} giao dịch${switchedMonthNote ? ` (${escHtml(switchedMonthNote)})` : ''}:</div>
      ${addedList.map((it) => `
        <div class="exp-scan-item-row" data-scan-id="${escHtml(it.id)}">
          <span style="min-width:0;flex:1;">
            <strong>${it.type === 'income' ? '💵 THU' : '💸 CHI'} ${it.type === 'income' ? '+' : '-'}${fmtVnd(it.amount)}</strong>
            • ${escHtml(it.title)} <span style="opacity:0.8;">(${escHtml(it.date)})</span>
          </span>
          <span style="display:flex;gap:4px;">
            <button type="button" class="exp-mini-btn ${it.type === 'income' ? 'flip-exp' : 'flip-inc'}" data-banner-flip="${escHtml(it.id)}">⇄ Đổi sang ${it.type === 'income' ? 'Chi' : 'Thu'}</button>
            <button type="button" class="exp-mini-btn" data-banner-edit="${escHtml(it.id)}">✏️ Sửa</button>
          </span>
        </div>
      `).join('')}
    `;
    box.querySelectorAll('[data-banner-flip]').forEach((b) => {
      b.addEventListener('click', () => {
        const id = b.dataset.bannerFlip;
        flipTxType(id);
        const updated = addedList.map((x) => txs.find((t) => t.id === x.id) || x);
        renderScanBanner(updated, switchedMonthNote);
      });
    });
    box.querySelectorAll('[data-banner-edit]').forEach((b) => {
      b.addEventListener('click', () => {
        const found = txs.find((t) => t.id === b.dataset.bannerEdit);
        if (found) openEditTx(found);
      });
    });
  };

  const renderAll = () => {
    const scopeBtn = q('#btn-exp-scope-all');
    if (scopeBtn) {
      scopeBtn.classList.toggle('flip-inc', showAllMonths);
      scopeBtn.textContent = showAllMonths ? '✓ Đang xem tất cả' : 'Tất cả tháng';
    }
    const monthTxs = showAllMonths ? txs : txs.filter((t) => String(t.date || '').startsWith(filterMonth));
    const totalInc = monthTxs.filter((t) => t.type === 'income').reduce((a, b) => a + (Number(b.amount) || 0), 0);
    const totalExp = monthTxs.filter((t) => t.type === 'expense').reduce((a, b) => a + (Number(b.amount) || 0), 0);
    const bal = totalInc - totalExp;

    q('#exp-kpi-grid').innerHTML = `
      <div class="exp-kpi inc"><div class="exp-kpi-lbl">Tổng Thu</div><div class="exp-kpi-val" title="${fmtVnd(totalInc)}">${fmtVnd(totalInc)}</div></div>
      <div class="exp-kpi exp"><div class="exp-kpi-lbl">Tổng Chi</div><div class="exp-kpi-val" title="${fmtVnd(totalExp)}">${fmtVnd(totalExp)}</div></div>
      <div class="exp-kpi bal"><div class="exp-kpi-lbl">Số Dư</div><div class="exp-kpi-val" title="${fmtVnd(bal)}">${fmtVnd(bal)}</div></div>
    `;

    // Category breakdown bars (expenses)
    const byCat = {};
    for (const t of monthTxs.filter((x) => x.type === 'expense')) {
      byCat[t.category] = (byCat[t.category] || 0) + (Number(t.amount) || 0);
    }
    const entries = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
    q('#exp-cat-bars').innerHTML = entries.length > 0
      ? entries.slice(0, 6).map(([cat, val]) => {
        const pct = totalExp > 0 ? Math.round((val / totalExp) * 100) : 0;
        return `<div class="exp-cat-bar-row"><div class="exp-cat-bar-top"><span>${escHtml(cat)}</span><span>${fmtVnd(val)} (${pct}%)</span></div><div class="exp-cat-track"><div class="exp-cat-fill" style="width:${pct}%;"></div></div></div>`;
      }).join('')
      : '<div style="font-size:12px;color:#6B7280;text-align:center;">Chưa có khoản chi nào trong khoảng thời gian này.</div>';

    const list = monthTxs
      .filter((t) => filterType === 'all' || t.type === filterType)
      .sort((a, b) => String(b.date).localeCompare(String(a.date)) || b.id.localeCompare(a.id));

    const box = q('#exp-list');
    box.innerHTML = '';
    if (list.length === 0) {
      const otherCount = showAllMonths ? 0 : txs.length;
      box.innerHTML = `<div style="font-size:12px;color:#6B7280;text-align:center;padding:8px;">Chưa có giao dịch nào${!showAllMonths ? ` trong tháng ${escHtml(filterMonth)}` : ''}.${otherCount > 0 ? ` (Có ${otherCount} giao dịch ở tháng khác — bấm "Tất cả tháng" để xem!)` : ' Hãy nói "Ăn sáng 35k" hoặc quét ảnh Bill ở trên!'}</div>`;
      return;
    }
    list.slice(0, 80).forEach((t) => {
      const row = document.createElement('div');
      row.className = 'exp-tx-row';
      const isInc = t.type === 'income';
      row.innerHTML = `
        <div style="min-width:0;flex:1;">
          <div style="font-size:12.5px;font-weight:700;color:#1F2937;word-break:break-word;">${escHtml(t.title)}</div>
          <div style="font-size:11px;color:#6B7280;margin-top:2px;">${escHtml(t.category)} • ${escHtml(t.date)}</div>
        </div>
        <div class="exp-tx-right">
          <button type="button" class="exp-tx-amt ${isInc ? 'inc' : 'exp'}" data-act="flip" title="Chạm để đổi nhanh Thu ↔ Chi">${isInc ? '+' : '-'}${fmtVnd(t.amount)}</button>
          <div class="exp-tx-tools">
            <button type="button" class="exp-mini-btn ${isInc ? 'flip-inc' : 'flip-exp'}" data-act="flip" title="Đổi Thu ↔ Chi">⇄ ${isInc ? 'Thu' : 'Chi'}</button>
            <button type="button" class="exp-mini-btn" data-act="edit" title="Sửa giao dịch">✏️</button>
            <button type="button" class="exp-mini-btn" data-act="del" title="Xóa">🗑</button>
          </div>
        </div>
      `;
      row.querySelectorAll('[data-act="flip"]').forEach((el) => {
        el.addEventListener('click', () => flipTxType(t.id));
      });
      row.querySelector('[data-act="edit"]')?.addEventListener('click', () => openEditTx(t));
      row.querySelector('[data-act="del"]')?.addEventListener('click', () => {
        txs = txs.filter((x) => x.id !== t.id);
        saveExpenses(txs);
        renderAll();
      });
      box.appendChild(row);
    });
  };

  q('#btn-exp-back')?.addEventListener('click', onBack);
  q('#exp-owner-inp')?.addEventListener('change', (e) => {
    ownerName = e.target.value.trim();
    saveExpenseOwner(ownerName);
    if (ownerName) setStatus(`✅ Đã lưu tên/TK "${ownerName}" để AI phân biệt Thu/Chi chính xác hơn!`);
  });
  q('#exp-month-pick')?.addEventListener('change', (e) => {
    showAllMonths = false;
    filterMonth = e.target.value || todayIso().slice(0, 7);
    renderAll();
  });
  q('#btn-exp-scope-all')?.addEventListener('click', () => {
    showAllMonths = !showAllMonths;
    renderAll();
  });
  q('#exp-filter-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    filterType = b.dataset.f || 'all';
    q('#exp-filter-seg').querySelectorAll('.sf-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
    renderAll();
  });

  q('#btn-exp-add-quick')?.addEventListener('click', () => {
    const parsed = parseVietnameseQuickTx(q('#exp-quick-inp').value);
    if (!parsed) {
      setStatus('Chưa thấy số tiền rõ (VD: "Ăn sáng 35k" hoặc "Khách CK 13.4tr"). Bạn có thể bấm "✨ AI tách câu"!', true);
      return;
    }
    txs.unshift(parsed);
    saveExpenses(txs);
    q('#exp-quick-inp').value = '';
    setStatus(`✅ Đã ghi ${parsed.type === 'income' ? '💵 Thu' : '💸 Chi'} ${fmtVnd(parsed.amount)} (${parsed.category})!`);
    renderScanBanner([parsed]);
    renderAll();
  });

  q('#btn-exp-manual-toggle')?.addEventListener('click', () => {
    const box = q('#exp-manual-box');
    if (box.classList.contains('hidden')) openEditTx(null);
    else { editingTxId = null; box.classList.add('hidden'); }
  });
  q('#btn-exp-m-cancel')?.addEventListener('click', () => {
    editingTxId = null;
    q('#exp-manual-box').classList.add('hidden');
  });
  q('#btn-exp-m-save')?.addEventListener('click', () => {
    const amt = Number(q('#exp-m-amt').value || 0);
    if (amt <= 0) { setStatus('Hãy nhập số tiền lớn hơn 0.', true); return; }
    const nextDate = q('#exp-m-date').value || todayIso();
    const payload = {
      type: q('#exp-m-type').value || 'expense',
      amount: Math.round(amt),
      category: q('#exp-m-cat').value || '📌 Khác',
      date: nextDate,
      title: q('#exp-m-title').value.trim() || q('#exp-m-cat').value
    };
    if (editingTxId) {
      const idx = txs.findIndex((x) => x.id === editingTxId);
      if (idx >= 0) txs[idx] = { ...txs[idx], ...payload };
      editingTxId = null;
      setStatus(`✅ Đã cập nhật giao dịch ${fmtVnd(payload.amount)}!`);
    } else {
      txs.unshift({ id: `tx-${Date.now()}`, ...payload });
      setStatus(`✅ Đã lưu ${payload.type === 'income' ? '💵 Thu' : '💸 Chi'} ${fmtVnd(payload.amount)}!`);
    }
    saveExpenses(txs);
    if (!showAllMonths && !nextDate.startsWith(filterMonth)) {
      filterMonth = nextDate.slice(0, 7);
      if (q('#exp-month-pick')) q('#exp-month-pick').value = filterMonth;
    }
    q('#exp-m-amt').value = '';
    q('#exp-m-title').value = '';
    q('#exp-manual-box').classList.add('hidden');
    renderAll();
  });

  // Voice input (Universal Android Native inline + Web Speech 3.5s auto-stop)
  q('#btn-exp-voice')?.addEventListener('click', () => {
    const vBtn = q('#btn-exp-voice');
    const finishExpVoice = (spText) => {
      const val = String(spText || q('#exp-quick-inp')?.value || '').trim();
      if (val && q('#exp-quick-inp')) q('#exp-quick-inp').value = val;
      const parsed = parseVietnameseQuickTx(val);
      if (parsed) {
        txs.unshift(parsed);
        saveExpenses(txs);
        if (q('#exp-quick-inp')) q('#exp-quick-inp').value = '';
        setStatus(`🎙️ Đã tự ghi ${parsed.type === 'income' ? '💵 Thu' : '💸 Chi'} ${fmtVnd(parsed.amount)} (${parsed.category})!`);
        renderScanBanner([parsed]);
        renderAll();
      }
    };
    if (typeof window.__toggleUnifiedVoice === 'function') {
      window.__toggleUnifiedVoice({
        btnEl: vBtn,
        silenceMs: 3500,
        onStart: () => setStatus('🎙️ Đang nghe... Nói VD: "Ăn trưa 55 nghìn" (ngừng 3.5 giây tự lưu)'),
        onInterim: (sp) => { if (q('#exp-quick-inp')) q('#exp-quick-inp').value = sp; },
        onFinal: finishExpVoice,
        onError: (msg) => { if (msg) setStatus(msg, true); }
      });
      return;
    }
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) { setStatus('⚠️ Thiết bị chưa hỗ trợ Micro trực tiếp tại đây — hãy gõ nhanh VD: "Cà phê 35k".', true); return; }
    if (webRec) { try { webRec.stop(); } catch (_e) {} return; }
    const rec = new SpeechRec();
    webRec = rec;
    rec.lang = 'vi-VN';
    rec.interimResults = true;
    rec.continuous = true;
    let silT = null;
    rec.onstart = () => { vBtn.textContent = '🔴'; setStatus('🎙️ Đang nghe... Ngừng 3.5 giây tự lưu'); };
    rec.onresult = (ev) => {
      const sp = Array.from(ev.results).map((r) => r[0].transcript).join(' ').trim();
      if (sp) {
        q('#exp-quick-inp').value = sp;
        if (silT) clearTimeout(silT);
        silT = setTimeout(() => { try { rec.stop(); } catch (_e) {} }, 3500);
      }
    };
    rec.onerror = () => { if (silT) clearTimeout(silT); webRec = null; vBtn.textContent = '🎙️'; };
    rec.onend = () => {
      if (silT) clearTimeout(silT);
      webRec = null;
      vBtn.textContent = '🎙️';
      finishExpVoice(q('#exp-quick-inp')?.value);
    };
    try { rec.start(); } catch (_e) { webRec = null; }
  });

  const buildExpenseSystemInstruction = () => {
    const owner = (q('#exp-owner-inp')?.value || ownerName || '').trim();
    const ownerRule = owner
      ? `\n- TÊN / TÀI KHOẢN / CỬA HÀNG CỦA TÔI (chủ máy): "${owner}". Nếu người NHẬN / tài khoản thụ hưởng trùng tên tôi → chắc chắn "income" (THU). Nếu người CHUYỂN / từ tài khoản / người mua hàng trùng tên tôi → chắc chắn "expense" (CHI).`
      : '';
    return `Bạn là chuyên gia Kế toán AI đọc hóa đơn, bill ngân hàng và ảnh chụp màn hình chat Zalo/Messenger/Telegram tại Việt Nam.
Trích xuất giao dịch thu chi VNĐ thành JSON chuẩn (CHỈ trả JSON hợp lệ, KHÔNG bọc chữ giải thích):
{"items":[{"type":"expense"|"income","amount":13400000,"category":"1 trong: ${EXP_CATS.join(', ')}","title":"Mô tả ngắn rõ tên người/mặt hàng","date":"YYYY-MM-DD (đọc đúng ngày trên bill/hóa đơn, nếu hoàn toàn không có ngày mới dùng ${todayIso()})"}]}

QUY TẮC BẮT BUỘC PHÂN BIỆT "income" (THU) vs "expense" (CHI/TIÊU):
1. ẢNH CHỤP MÀN HÌNH CHAT (Zalo, Messenger, Telegram, WhatsApp, SMS):
   - Nhìn VỊ TRÍ BONG BÓNG CHAT:
     + Bong bóng nằm BÊN TRÁI (có avatar người đối diện, căn trái) = NGƯỜI KHÁC / KHÁCH HÀNG gửi cho TÔI.
       => Nếu ảnh bill chuyển khoản ngân hàng ("Thanh toán thành công", "Giao dịch thành công", MB Bank, Sacombank, Vietcombank, Techcombank, BIDV, VPBank, TPBank...) nằm trong bong bóng BÊN TRÁI → NGƯỜI TA ĐÃ CHUYỂN TIỀN CHO TÔI ⇒ BẮT BUỘC ghi "type": "income" (THU)! KHÔNG ĐƯỢC nhầm thành "expense" chỉ vì bên trong ảnh bill ghi chữ "Thanh toán thành công"!
       => Nếu ngay dưới/trên có tin nhắn của TÔI ở bên phải kiểu "Dạ", "Đã nhận", "Chờ tt làm hóa đơn" hoặc file phiếu xuất kho/bán hàng → càng chắc chắn 100% là "income" (THU)!
     + Bong bóng nằm BÊN PHẢI (tin nhắn của TÔI gửi đi, căn phải, thường màu xanh/tím hoặc có dấu đã gửi/đã xem) = TÔI gửi cho người ta.
       => Nếu TÔI gửi ảnh bill chuyển khoản ở BÊN PHẢI → TÔI đã chuyển tiền đi ⇒ ghi "type": "expense" (CHI).
   - Nếu là tin nhắn chữ báo giá/xuất hàng (VD: "Xuất 20c Dell Latitude ... Giá 5.6tr"): tính đúng tổng tiền (20 * 5.600.000 = 112.000.000). Nếu người bán ở bên trái báo xuất cho mình và mình bên phải nhắn "oki / múc" → mình là người mua ⇒ "expense". Nếu mình xuất bán cho khách → "income".
2. ẢNH CHỤP TRỰC TIẾP APP NGÂN HÀNG (toàn màn hình app bank, KHÔNG nằm trong khung chat):
   - Có dấu TRỪ (-) trước số tiền (VD: - 990,000 VND) hoặc màn hình "Chuyển tiền thành công / Thanh toán thành công" từ tài khoản của mình → "expense" (CHI).
   - Có dấu CỘNG (+) trước số tiền (VD: + 13,400,000 VND) hoặc "Nhận tiền / Tiền vào / Hoàn tiền" → "income" (THU).
3. HÓA ĐƠN GIẤY / HÓA ĐƠN BÁN LẺ VIẾT TAY / HÓA ĐƠN SIÊU THỊ:
   - Đọc kỹ số lượng × đơn giá và dòng CỘNG / Tổng thanh toán (đối chiếu cả số viết bằng chữ nếu có) để lấy đúng số nguyên VNĐ.
   - Đọc ĐÚNG ngày tháng năm ghi trên hóa đơn (VD: "Ngày 25 tháng 11 năm 2026" → "2026-11-25"; "23/08/2026" → "2026-08-23").
   - Hóa đơn mua hàng/ăn uống/mua sắm là "expense" (CHI).${ownerRule}
4. "amount" LUÔN là SỐ NGUYÊN VNĐ không dấu chấm phẩy (VD: 26300000, KHÔNG viết "26.300.000đ"). Nếu trong ảnh có nhiều giao dịch rõ ràng thì tách nhiều phần tử trong "items".`;
  };

  // AI Parse text OR Bill image(s)
  const parseWithGemini = async (textOrPrompt, images = [], batchLabel = '') => {
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#exp-status').className = 'sf-status err';
      q('#exp-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-exp-cfg">Nhập Key</button>';
      q('#btn-exp-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return [];
    }
    setStatus(images.length
      ? `📸 ${batchLabel ? batchLabel + ' ' : ''}Gemini Vision đang đọc bill & phân biệt Thu/Chi...`
      : '✨ Gemini AI đang tách khoản thu chi...');

    const runCall = async (useJsonMime) => askGeminiGeneral(st.geminiSettings, {
      systemInstruction: buildExpenseSystemInstruction(),
      userPrompt: textOrPrompt,
      images,
      temperature: 0.1,
      responseMimeType: useJsonMime ? 'application/json' : undefined,
      timeoutMs: 38000
    });

    let raw = '';
    try {
      raw = await runCall(true);
    } catch (_firstErr) {
      raw = await runCall(false);
    }
    let items = extractAiJsonItems(raw);
    if (items.length === 0) {
      // Retry once without strict JSON mime in case model truncated or refused schema
      try {
        const retryRaw = await runCall(false);
        items = extractAiJsonItems(retryRaw);
      } catch (_e) {}
    }

    const addedList = [];
    for (const it of items) {
      const amt = parseAiAmount(it?.amount ?? it?.total ?? it?.money);
      if (amt <= 0) continue;
      const rawType = String(it?.type || '').toLowerCase();
      const isInc = rawType === 'income' || rawType === 'thu' || rawType === 'in';
      const catRaw = String(it?.category || '').trim();
      const matchedCat = EXP_CATS.find((c) => c === catRaw || c.toLowerCase().includes(catRaw.toLowerCase()));
      const txObj = {
        id: `tx-ai-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        type: isInc ? 'income' : 'expense',
        amount: amt,
        category: matchedCat || (isInc ? '💼 Lương / Thu nhập' : '📌 Khác'),
        title: String(it?.title || it?.note || it?.description || 'Giao dịch AI').trim().slice(0, 110),
        date: parseAiDate(it?.date)
      };
      txs.unshift(txObj);
      addedList.push(txObj);
    }
    return addedList;
  };

  q('#btn-exp-ai-parse')?.addEventListener('click', async () => {
    if (busy) return;
    const val = q('#exp-quick-inp').value.trim();
    if (!val) { setStatus('Hãy nhập 1 câu mô tả thu/chi trước nhé!', true); return; }
    busy = true;
    try {
      const addedList = await parseWithGemini(`Tách các khoản thu chi trong câu sau (chú ý phân biệt tôi chi/chuyển đi = expense, người ta chuyển cho tôi / thu bán hàng = income): "${val}"`);
      if (addedList.length > 0) {
        saveExpenses(txs);
        q('#exp-quick-inp').value = '';
        let switchedNote = '';
        const firstM = addedList[0].date.slice(0, 7);
        if (!showAllMonths && firstM !== filterMonth) {
          filterMonth = firstM;
          if (q('#exp-month-pick')) q('#exp-month-pick').value = filterMonth;
          switchedNote = `chuyển sang tháng ${firstM}`;
        }
        setStatus(`✅ AI đã tự ghi nhận ${addedList.length} giao dịch vào sổ thu chi!`);
        renderScanBanner(addedList, switchedNote);
        renderAll();
      } else {
        setStatus('⚠️ AI chưa đọc thấy số tiền rõ ràng trong câu này.', true);
      }
    } catch (err) {
      setStatus(`⚠️ ${err?.message || 'Lỗi tách câu bằng AI'}`, true);
    } finally {
      busy = false;
    }
  });

  const readFileToBase64 = (file) => new Promise((resolve, reject) => {
    const img = new Image();
    const u = URL.createObjectURL(file);
    img.onload = () => {
      try {
        // Keep 1920px so embedded bank bills inside tall Zalo/Messenger chat screenshots stay sharp
        const { base64 } = compressImageSourceToBase64(img, 1920, 0.92, false);
        URL.revokeObjectURL(u);
        resolve(base64);
      } catch (err) {
        URL.revokeObjectURL(u);
        reject(err);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(u);
      reject(new Error('Không mở được ảnh này.'));
    };
    img.src = u;
  });

  q('#exp-bill-file')?.addEventListener('change', async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (files.length === 0 || busy) return;
    busy = true;
    renderScanBanner([]);
    const allAdded = [];
    let failedCount = 0;
    let lastErr = '';
    try {
      for (let i = 0; i < files.length; i++) {
        const label = files.length > 1 ? `[Ảnh ${i + 1}/${files.length}]` : '';
        try {
          const base64 = await readFileToBase64(files[i]);
          const added = await parseWithGemini(
            'Hãy quan sát thật kỹ toàn bộ ảnh này (đặc biệt xem đây là ảnh chụp màn hình chat Zalo/Messenger có bill nằm bên TRÁI hay bên PHẢI, hay ảnh chụp trực tiếp app ngân hàng, hay hóa đơn giấy). Trích xuất chính xác loại Thu (income) / Chi (expense), tổng tiền VNĐ, ngày giao dịch trên bill và tên người/nội dung.',
            [base64],
            label
          );
          if (added.length > 0) allAdded.push(...added);
          else failedCount++;
        } catch (err) {
          failedCount++;
          lastErr = err?.message || 'Lỗi đọc ảnh';
        }
      }
      if (allAdded.length > 0) {
        saveExpenses(txs);
        let switchedNote = '';
        const months = new Set(allAdded.map((x) => x.date.slice(0, 7)));
        if (months.size > 1) {
          showAllMonths = true;
          switchedNote = 'đã bật Tất cả tháng vì có nhiều tháng khác nhau';
        } else {
          const m = allAdded[0].date.slice(0, 7);
          if (!showAllMonths && m !== filterMonth) {
            filterMonth = m;
            if (q('#exp-month-pick')) q('#exp-month-pick').value = filterMonth;
            switchedNote = `đã chuyển sang tháng ${m.slice(5, 7)}/${m.slice(0, 4)}`;
          }
        }
        setStatus(`✅ AI đã quét & ghi nhận ${allAdded.length} giao dịch${failedCount > 0 ? ` (${failedCount} ảnh không có số tiền rõ)` : ''}!`);
        renderScanBanner(allAdded, switchedNote);
        renderAll();
      } else {
        setStatus(`⚠️ ${lastErr || 'AI chưa nhận diện được số tiền rõ ràng trên ảnh này. Hãy thử chụp gần bill hơn hoặc nhập tay!'}`, true);
      }
    } finally {
      busy = false;
    }
  });

  q('#btn-exp-ai-review')?.addEventListener('click', async () => {
    const monthTxs = showAllMonths ? txs : txs.filter((t) => String(t.date || '').startsWith(filterMonth));
    if (monthTxs.length === 0) { setStatus('Chưa có dữ liệu để AI nhận xét.', true); return; }
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) { onOpenGeminiSettings(); return; }
    q('#exp-ai-card').classList.remove('hidden');
    q('#exp-ai-body').innerHTML = '✨ Đang phân tích thói quen thu chi...';
    try {
      const summary = monthTxs.slice(0, 50).map((t) => `- ${t.date}: [${t.type === 'income' ? 'Thu' : 'Chi'}] ${fmtVnd(t.amount)} (${t.category}) ${t.title}`).join('\n');
      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là cố vấn tài chính cá nhân thực tế, gần gũi, gợi ý tiết kiệm dễ áp dụng.',
        userPrompt: `Phân tích sổ thu chi ${showAllMonths ? '(tất cả các tháng)' : `tháng ${filterMonth}`}:\n${summary}\n\nNêu ngắn gọn: 1. Nhận xét tỷ lệ Thu/Chi; 2. Danh mục tốn nhiều nhất; 3. 3 gợi ý tối ưu dòng tiền.`,
        temperature: 0.4
      }, (p) => { if (p) q('#exp-ai-body').innerHTML = fmtMd(p); });
      q('#exp-ai-body').innerHTML = fmtMd(ans);
    } catch (err) {
      q('#exp-ai-body').textContent = `⚠️ ${err?.message || 'Lỗi AI'}`;
    }
  });

  q('#btn-exp-csv')?.addEventListener('click', () => {
    const rows = [['Ngay', 'Loai', 'DanhMuc', 'SoTien', 'NoiDung'], ...txs.map((t) => [t.date, t.type, t.category, t.amount, `"${String(t.title || '').replace(/"/g, '""')}"`])];
    const blob = new Blob(['\uFEFF' + rows.map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `thu-chi-lich-am-${showAllMonths ? 'tat-ca' : filterMonth}.csv`;
    a.click();
    setStatus('✓ Đã xuất file CSV thu chi!');
  });

  /* ==================== TAB SỔ VAY MƯỢN (CHO VAY / ĐI VAY) ==================== */
  const setLoanStatus = (m, err = false) => {
    const el = q('#loan-status');
    if (!el) return;
    el.className = err ? 'sf-status err' : 'sf-status';
    el.textContent = m || '';
  };

  const switchExpPane = (pane) => {
    activePane = pane === 'loans' ? 'loans' : 'cashbook';
    q('#exp-pane-cashbook')?.classList.toggle('hidden', activePane !== 'cashbook');
    q('#exp-pane-loans')?.classList.toggle('hidden', activePane !== 'loans');
    q('#exp-main-tabs')?.querySelectorAll('.exp-main-tab').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.pane === activePane);
    });
    if (activePane === 'loans') renderLoans();
    else renderAll();
  };

  q('#exp-main-tabs')?.addEventListener('click', (e) => {
    const btn = e.target.closest('.exp-main-tab');
    if (!btn) return;
    switchExpPane(btn.dataset.pane);
  });

  const syncLoanModeUI = () => {
    const isDec = q('#loan-f-mode')?.value === 'declining';
    q('#loan-declining-fields')?.classList.toggle('hidden', !isDec);
    q('#loan-simple-int-wrap')?.classList.toggle('hidden', isDec);
    q('#loan-init-months-wrap')?.classList.toggle('hidden', Boolean(editingLoanId));
  };
  q('#loan-f-mode')?.addEventListener('change', syncLoanModeUI);

  const openLoanForm = (loan = null, defaultMode = 'simple', defaultType = null) => {
    editingLoanId = loan ? loan.id : null;
    const mode = loan ? (loan.calcMode === 'declining' ? 'declining' : 'simple') : defaultMode;
    q('#loan-form-heading').textContent = loan
      ? '✏️ Sửa khoản vay / mượn'
      : (mode === 'declining' ? '📊 Tạo khoản vay lãi giảm dần theo tháng' : '🤝 Thêm khoản Cho vay / Đi vay');
    q('#btn-loan-f-save').textContent = loan ? '💾 Cập nhật khoản này' : '💾 Lưu khoản vay / mượn';
    if (q('#loan-f-mode')) q('#loan-f-mode').value = mode;
    q('#loan-f-type').value = loan ? (loan.type === 'borrow' ? 'borrow' : 'lend') : (defaultType || (mode === 'declining' ? 'borrow' : 'lend'));
    q('#loan-f-amount').value = loan ? String(loan.amount || '') : '';
    if (q('#loan-f-rate')) q('#loan-f-rate').value = loan?.annualRate !== undefined ? String(loan.annualRate) : '7';
    if (q('#loan-f-min-principal')) q('#loan-f-min-principal').value = loan?.minMonthlyPrincipal ? String(loan.minMonthlyPrincipal) : '';
    if (q('#loan-f-int-cycle')) q('#loan-f-int-cycle').value = loan?.interestCycle || 'yearly';
    if (q('#loan-f-init-months')) q('#loan-f-init-months').value = '12_blank';
    if (q('#loan-f-amount-preview')) {
      const pAmt = parseVnNumberStrict(q('#loan-f-amount')?.value);
      q('#loan-f-amount-preview').textContent = pAmt > 0 ? `= ${fmtVnd(pAmt)}` : '';
    }
    q('#loan-f-person').value = loan?.person || '';
    q('#loan-f-phone').value = loan?.phone || '';
    q('#loan-f-date').value = loan?.date || todayIso();
    q('#loan-f-due').value = loan?.dueDate || '';
    q('#loan-f-interest').value = loan?.interest || '';
    q('#loan-f-note').value = loan?.note || '';
    if (q('#loan-f-sync-cash')) q('#loan-f-sync-cash').checked = false;
    q('#loan-sync-row')?.classList.toggle('hidden', Boolean(loan));
    syncLoanModeUI();
    q('#loan-form-box')?.classList.remove('hidden');
    q('#loan-form-box')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  };

  const pushLoanToCashbook = (txType, amount, title, dateStr) => {
    if (!amount || amount <= 0) return;
    txs.unshift({
      id: `tx-loan-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      type: txType,
      amount: Math.round(amount),
      category: '🤝 Vay / Trả nợ',
      title: String(title || 'Giao dịch vay mượn').slice(0, 110),
      date: dateStr || todayIso()
    });
    saveExpenses(txs);
  };

  const exportSingleLoanScheduleCsv = (loan) => {
    const calc = recalcDecliningLoan(loan);
    const rows = [
      ['Nam', 'Thang', 'Ngay', 'LaiSuatNam(%)', 'LaiSuatThang', 'LaiThang(VND)', 'GocThangTruoc', 'GopHangThang', 'VayThem', 'GocConLai', 'NgayThucTra', 'GhiChu']
    ];
    calc.years.forEach((yr) => {
      yr.rows.forEach((r) => {
        rows.push([
          yr.yearIdx,
          r.monthInYear,
          fmtDateVnShort(r.date),
          r.annualRate,
          (r.annualRate / 100 / 12).toFixed(8),
          r.interest,
          r.opening,
          r.principalPaid,
          r.topUp || 0,
          r.closing,
          `"${String(r.actualDate || '').replace(/"/g, '""')}"`,
          `"${String(r.note || '').replace(/"/g, '""')}"`
        ]);
      });
      rows.push([
        `TONG NAM ${yr.yearIdx}`,
        '',
        yr.isInterestPaid ? 'DA TRA LAI' : 'CHUA TRA LAI',
        '',
        '',
        yr.interestTotal,
        '',
        yr.principalSum,
        yr.topUpSum || 0,
        yr.endBalance,
        '',
        ''
      ]);
    });
    rows.push(['TONG CONG', '', '', '', '', calc.totalInterest, calc.startPrincipal, calc.totalPrincipalPaid, calc.totalTopUp, calc.currentBalance, '', '']);
    const blob = new Blob(['\uFEFF' + rows.map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `bang-lai-vay-${String(loan.person || 'vay').toLowerCase().replace(/[^a-z0-9]+/gi, '-')}-${todayIso()}.csv`;
    a.click();
    setLoanStatus(`✓ Đã xuất bảng lãi chi tiết (${calc.rows.length} kỳ) ra file Excel/CSV!`);
  };

  const renderLoans = () => {
    const openLoans = loans.filter((l) => !l.settled);
    const badge = q('#exp-loan-badge');
    if (badge) {
      badge.textContent = String(openLoans.length);
      badge.classList.toggle('hidden', openLoans.length === 0);
    }

    const totalLendRem = openLoans
      .filter((l) => l.type === 'lend')
      .reduce((acc, l) => acc + getLoanRemainingBalance(l), 0);
    const totalBorrowRem = openLoans
      .filter((l) => l.type === 'borrow')
      .reduce((acc, l) => acc + getLoanRemainingBalance(l), 0);
    const netLoan = totalLendRem - totalBorrowRem;

    const totalUnpaidInterest = openLoans
      .filter((l) => l.calcMode === 'declining')
      .reduce((acc, l) => acc + recalcDecliningLoan(l).unpaidInterest, 0);

    const overdueCount = openLoans.filter((l) => {
      const dd = diffDaysFromToday(l.dueDate);
      return dd !== null && dd < 0;
    }).length;

    const kpiGrid = q('#loan-kpi-grid');
    if (kpiGrid) {
      kpiGrid.innerHTML = `
        <div class="exp-kpi inc"><div class="exp-kpi-lbl">📤 Đang cho vay</div><div class="exp-kpi-val" title="${fmtVnd(totalLendRem)}">${fmtVnd(totalLendRem)}</div></div>
        <div class="exp-kpi exp"><div class="exp-kpi-lbl">📥 Đang đi vay</div><div class="exp-kpi-val" title="${fmtVnd(totalBorrowRem)}">${fmtVnd(totalBorrowRem)}</div></div>
        <div class="exp-kpi bal"><div class="exp-kpi-lbl">⚖️ Chênh lệch</div><div class="exp-kpi-val" title="${fmtVnd(netLoan)}">${netLoan >= 0 ? '+' : ''}${fmtVnd(netLoan)}</div></div>
      `;
    }
    const kpiSub = q('#loan-kpi-sub');
    if (kpiSub) {
      const settledCnt = loans.length - openLoans.length;
      const ovHtml = overdueCount > 0 ? ` • <strong style="color:#DC2626;">⚠️ ${overdueCount} quá hạn</strong>` : '';
      const intHtml = totalUnpaidInterest > 0 ? `<div style="margin-top:3px;color:#B45309;">💹 Lãi tích lũy chưa thanh toán (các khoản giảm dần): <strong>${fmtVnd(totalUnpaidInterest)}</strong></div>` : '';
      kpiSub.innerHTML = `⏳ <strong>${openLoans.length}</strong> khoản đang mở • ✅ <strong>${settledCnt}</strong> đã tất toán${ovHtml}${intHtml}`;
    }

    const term = loanSearch.trim().toLowerCase();
    const filtered = loans
      .filter((l) => {
        if (loanFilter === 'open' && l.settled) return false;
        if (loanFilter === 'settled' && !l.settled) return false;
        if (loanFilter === 'lend' && l.type !== 'lend') return false;
        if (loanFilter === 'borrow' && l.type !== 'borrow') return false;
        if (term) {
          const hay = `${l.person || ''} ${l.phone || ''} ${l.note || ''} ${l.interest || ''}`.toLowerCase();
          if (!hay.includes(term)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (Boolean(a.settled) !== Boolean(b.settled)) return a.settled ? 1 : -1;
        if (!a.settled && (a.dueDate || b.dueDate)) {
          if (a.dueDate && !b.dueDate) return -1;
          if (!a.dueDate && b.dueDate) return 1;
          const cmpDue = String(a.dueDate).localeCompare(String(b.dueDate));
          if (cmpDue !== 0) return cmpDue;
        }
        return String(b.date || '').localeCompare(String(a.date || '')) || String(b.id).localeCompare(String(a.id));
      });

    const listEl = q('#loan-list');
    if (!listEl) return;
    listEl.innerHTML = '';
    if (filtered.length === 0) {
      listEl.innerHTML = `<div style="font-size:12px;color:#6B7280;text-align:center;padding:10px;">${loans.length === 0 ? 'Chưa có khoản vay mượn nào. Bấm <strong>📊 Vay lãi giảm dần</strong> (cho khoản vay trả góp như 1,6 tỷ lãi 7%/năm) hoặc <strong>➕ Vay đơn giản</strong> ở trên!' : 'Không có khoản nào khớp bộ lọc hiện tại.'}</div>`;
      return;
    }

    // Auto-expand the first open declining-balance loan unless user manually collapsed it
    if (!expandedSchedLoanId && !userCollapsedSched) {
      const firstOpenDec = filtered.find((x) => x.calcMode === 'declining' && !x.settled);
      if (firstOpenDec) expandedSchedLoanId = firstOpenDec.id;
    }

    filtered.forEach((l) => {
      const isDeclining = l.calcMode === 'declining';
      const decCalc = isDeclining ? recalcDecliningLoan(l) : null;
      const total = isDeclining ? (decCalc.startPrincipal + decCalc.totalTopUp) : (Number(l.amount) || 0);
      const paid = isDeclining ? decCalc.totalPrincipalPaid : Math.min(total, Number(l.paidAmount) || 0);
      const rem = isDeclining ? decCalc.currentBalance : (l.settled ? 0 : Math.max(0, total - paid));
      const pct = total > 0 ? Math.min(100, Math.round((paid / total) * 100)) : 0;
      const isLend = l.type === 'lend';
      const dd = diffDaysFromToday(l.dueDate);

      let dueBadge = '';
      if (l.settled) {
        dueBadge = `<span class="loan-due-badge settled">✅ Đã tất toán${l.settledDate ? ` (${fmtDateVnShort(l.settledDate)})` : ''}</span>`;
      } else if (dd !== null) {
        if (dd < 0) dueBadge = `<span class="loan-due-badge overdue">⚠️ Quá hạn ${Math.abs(dd)} ngày (${fmtDateVnShort(l.dueDate)})</span>`;
        else if (dd === 0) dueBadge = `<span class="loan-due-badge today">⏰ Hạn trả hôm nay</span>`;
        else dueBadge = `<span class="loan-due-badge soon">📅 Hạn ${fmtDateVnShort(l.dueDate)} (còn ${dd} ngày)</span>`;
      }

      const card = document.createElement('div');
      card.className = `loan-item-card ${isLend ? 'is-lend' : 'is-borrow'}${l.settled ? ' is-settled' : ''}`;
      const payments = Array.isArray(l.payments) ? l.payments : [];
      const isSchedOpen = isDeclining && expandedSchedLoanId === l.id;

      // Build declining schedule panel HTML if expanded
      let schedHtml = '';
      if (isDeclining && isSchedOpen) {
        // Smart target: fill first blank month (principalPaid === 0 && !actualDate) if present, else append next month
        const blankRowIdx = decCalc.rows.findIndex((r) => r.principalPaid === 0 && !r.actualDate && r.topUp === 0);
        const targetRow = blankRowIdx >= 0 ? decCalc.rows[blankRowIdx] : null;
        const lastRow = decCalc.rows.length > 0 ? decCalc.rows[decCalc.rows.length - 1] : null;
        const nextIdx = targetRow ? (targetRow.idx + 1) : (decCalc.rows.length + 1);
        const nextYear = targetRow ? targetRow.yearIdx : (Math.floor(decCalc.rows.length / 12) + 1);
        const nextMonthInYear = targetRow ? targetRow.monthInYear : ((decCalc.rows.length % 12) + 1);
        const nextDate = targetRow ? targetRow.date : (lastRow ? addMonthsIso(lastRow.date, 1) : addMonthsIso(l.date || todayIso(), 1));
        const nextRate = targetRow ? targetRow.annualRate : (lastRow ? lastRow.annualRate : (Number(l.annualRate) || 7));
        const targetOpening = targetRow ? targetRow.opening : rem;
        const defaultPay = l.minMonthlyPrincipal > 0 ? Math.min(targetOpening, l.minMonthlyPrincipal) : 0;
        const previewInt = Math.round(targetOpening * (nextRate / 100) / 12);
        const previewRem = Math.max(0, targetOpening - defaultPay);
        const curYearObj = decCalc.years.length > 0 ? decCalc.years[decCalc.years.length - 1] : null;

        let tableRowsHtml = '';
        decCalc.years.forEach((yr) => {
          yr.rows.forEach((r) => {
            const rowKey = `${l.id}::${r.idx}`;
            const isEditingRow = editingSchedRowKey === rowKey;
            tableRowsHtml += `
              <tr class="${r.topUp > 0 ? 'is-topup' : ''}">
                <td><strong>N${yr.yearIdx}·T${r.monthInYear}</strong></td>
                <td>${escHtml(fmtDateVnShort(r.date))}</td>
                <td>${r.annualRate}%</td>
                <td style="color:#B45309;font-weight:700;">${fmtVnd(r.interest)}</td>
                <td>${fmtVnd(r.opening)}</td>
                <td>
                  <input type="text" inputmode="decimal" class="loan-inline-paid-inp ${r.principalPaid > 0 ? 'is-filled' : ''}" data-inline-paid="${r.idx}" value="${r.principalPaid > 0 ? r.principalPaid.toLocaleString('vi-VN') : ''}" placeholder="0 (VD: 100tr)" title="Nhập số tiền trả gốc tháng này (gõ được 100tr, 20tr, 10tr...) rồi bấm Enter" />
                  ${r.topUp > 0 ? `<div style="font-size:9.5px;color:#DC2626;text-align:right;">+${fmtVnd(r.topUp)} vay thêm</div>` : ''}
                </td>
                <td style="font-weight:800;">${fmtVnd(r.closing)}</td>
                <td>
                  <span style="font-size:10px;color:#64748B;">${escHtml(r.actualDate || '')}</span>
                  <button type="button" class="exp-mini-btn" data-sched-edit="${r.idx}" title="Sửa chi tiết kỳ này">✏️</button>
                </td>
              </tr>
            `;
            if (isEditingRow) {
              tableRowsHtml += `
                <tr class="loan-row-edit-tr">
                  <td colspan="8">
                    <div style="font-weight:800;color:#92400E;margin-bottom:5px;">✏️ Sửa Năm ${yr.yearIdx} • Tháng ${r.monthInYear} (tự động tính lại toàn bộ các tháng sau):</div>
                    <div class="loan-sched-add-grid">
                      <div><label>Ngày kỳ</label><input type="date" class="ed-r-date" value="${escHtml(r.date)}" /></div>
                      <div><label>Lãi suất (%/năm)</label><input type="number" step="0.1" class="ed-r-rate" value="${r.annualRate}" /></div>
                      <div><label>Trả gốc tháng này (gõ 100tr, 20tr...)</label><input type="text" inputmode="decimal" class="ed-r-paid" value="${r.principalPaid}" /></div>
                      <div><label>Vay thêm (nếu có)</label><input type="text" inputmode="decimal" class="ed-r-topup" value="${r.topUp || 0}" /></div>
                      <div><label>Ngày thực trả</label><input type="text" class="ed-r-actual" value="${escHtml(r.actualDate)}" placeholder="VD: 04/06/2026" /></div>
                      <div><label>Ghi chú</label><input type="text" class="ed-r-note" value="${escHtml(r.note)}" placeholder="Ghi chú..." /></div>
                    </div>
                    <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap;">
                      <button type="button" class="sf-btn emerald" data-sched-save="${r.idx}" style="padding:5px 10px;font-size:11.5px;">💾 Lưu &amp; Tính lại</button>
                      <button type="button" class="sf-btn" data-sched-cancel style="padding:5px 10px;font-size:11.5px;">Hủy</button>
                      <button type="button" class="exp-mini-btn flip-exp" data-sched-del="${r.idx}" style="margin-left:auto;">🗑 Xóa kỳ này</button>
                    </div>
                  </td>
                </tr>
              `;
            }
          });
          tableRowsHtml += `
            <tr class="loan-year-row ${yr.isInterestPaid ? 'is-paid' : ''}">
              <td colspan="3">🟡 TỔNG NĂM ${yr.yearIdx} (${yr.rows.length}T)</td>
              <td>${fmtVnd(yr.interestTotal)}</td>
              <td></td>
              <td>${fmtVnd(yr.principalSum)}</td>
              <td>${fmtVnd(yr.endBalance)}</td>
              <td>
                <button type="button" class="exp-mini-btn ${yr.isInterestPaid ? 'flip-inc' : ''}" data-toggle-year-int="${yr.yearIdx}">
                  ${yr.isInterestPaid ? '✅ Đã trả lãi' : '⬜ Đánh dấu trả lãi'}
                </button>
              </td>
            </tr>
          `;
        });

        schedHtml = `
          <div class="loan-sched-panel">
            <div class="loan-sched-kpi">
              <div class="loan-sched-kpi-box warn">
                <div class="loan-sched-kpi-lbl">Tổng lãi cộng dồn chưa trả (${decCalc.rows.length} kỳ)</div>
                <div class="loan-sched-kpi-val">${fmtVnd(decCalc.unpaidInterest)}</div>
              </div>
              <div class="loan-sched-kpi-box">
                <div class="loan-sched-kpi-lbl">Lãi 1 tháng tiếp theo (${nextRate}%)</div>
                <div class="loan-sched-kpi-val" style="color:#B45309;">${fmtVnd(Math.round(rem * (nextRate / 100) / 12))}</div>
              </div>
              <div class="loan-sched-kpi-box">
                <div class="loan-sched-kpi-lbl">Tổng gốc đã trả</div>
                <div class="loan-sched-kpi-val" style="color:#047857;">${fmtVnd(decCalc.totalPrincipalPaid)}</div>
              </div>
              <div class="loan-sched-kpi-box">
                <div class="loan-sched-kpi-lbl">${curYearObj ? `Cộng lãi Năm ${curYearObj.yearIdx} (${curYearObj.rows.length}/12T)` : 'Tổng lãi lũy kế'}</div>
                <div class="loan-sched-kpi-val">${fmtVnd(curYearObj ? curYearObj.interestTotal : decCalc.totalInterest)}</div>
              </div>
            </div>

            ${(!l.settled && decCalc.forecastMonths > 0) ? `
              <div class="loan-sched-forecast">
                🔮 <strong>Dự tính nếu góp đều ${fmtVnd(l.minMonthlyPrincipal)}/tháng:</strong> còn khoảng <strong>${decCalc.forecastMonths} tháng</strong> (hết nợ ~<strong>${escHtml(fmtDateVnShort(decCalc.forecastEndDate))}</strong>) • Lãi dự kiến phát sinh thêm: <strong>${fmtVnd(decCalc.forecastInterest)}</strong>.
              </div>
            ` : ''}

            ${!l.settled ? `
              <div class="loan-sched-add-box">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;flex-wrap:wrap;">
                  <strong style="font-size:12px;color:#065F46;">${targetRow ? `💵 Nhập trả gốc Kỳ ${nextIdx} (Năm ${nextYear} • Tháng ${nextMonthInYear})` : `➕ Ghi nhận Kỳ ${nextIdx} (Năm ${nextYear} • Tháng ${nextMonthInYear})`}</strong>
                  <span style="font-size:11px;color:#047857;font-weight:700;">Gốc tính lãi tháng này: ${fmtVnd(targetOpening)}</span>
                </div>
                <div class="loan-sched-add-grid">
                  <div>
                    <label>Trả gốc tháng này (gõ 100tr, 20tr, 10tr...)</label>
                    <input type="text" inputmode="decimal" class="ns-paid" value="${defaultPay > 0 ? defaultPay : ''}" placeholder="VD: 100tr hoặc 20tr" />
                  </div>
                  <div>
                    <label>Ngày kỳ hạn</label>
                    <input type="date" class="ns-date" value="${escHtml(nextDate)}" />
                  </div>
                  <div>
                    <label>Lãi suất (%/năm)</label>
                    <input type="number" step="0.1" class="ns-rate" value="${nextRate}" />
                  </div>
                  <div>
                    <label>Vay thêm (nếu có)</label>
                    <input type="text" inputmode="decimal" class="ns-topup" value="" placeholder="0 (VD: 500tr)" />
                  </div>
                  <div>
                    <label>Ngày thực trả</label>
                    <input type="text" class="ns-actual" value="${escHtml(fmtDateVnShort(todayIso()))}" placeholder="VD: 04/12/2026" />
                  </div>
                  <div>
                    <label>Ghi chú kỳ này</label>
                    <input type="text" class="ns-note" placeholder="VD: CK đợt 1..." maxlength="100" />
                  </div>
                </div>
                <div class="loan-quick-chips">
                  <button type="button" class="exp-mini-btn ns-chip" data-v="10000000">10tr</button>
                  <button type="button" class="exp-mini-btn ns-chip" data-v="20000000">20tr</button>
                  <button type="button" class="exp-mini-btn ns-chip" data-v="50000000">50tr</button>
                  <button type="button" class="exp-mini-btn ns-chip" data-v="100000000">100tr</button>
                  <button type="button" class="exp-mini-btn ns-chip" data-v="0">0đ (chỉ tính lãi)</button>
                  <button type="button" class="exp-mini-btn ns-chip flip-inc" data-v="${targetOpening}">Tất toán hết</button>
                </div>
                <div class="loan-sched-preview">💡 Lãi tháng này (${nextRate}% × ${fmtVnd(targetOpening)} / 12): <strong>${fmtVnd(previewInt)}</strong> → Gốc tháng sau còn: <strong>${fmtVnd(previewRem)}</strong></div>
                <label style="display:flex;align-items:center;gap:5px;font-size:11.5px;color:#166534;cursor:pointer;">
                  <input type="checkbox" class="ns-sync" />
                  <span>💰 Đồng thời ghi khoản trả gốc này vào Sổ Thu Chi</span>
                </label>
                <button type="button" class="sf-btn emerald full" data-act="sched-add" data-target-idx="${blankRowIdx}" style="justify-content:center;padding:7px 10px;font-size:12px;">✓ Lưu Kỳ Năm ${nextYear} • Tháng ${nextMonthInYear}</button>
              </div>
            ` : ''}

            <div style="font-size:11px;color:#0F766E;font-weight:700;">💡 Mẹo: Bạn có thể <strong>chạm nhập trực tiếp số tiền trả gốc (VD: 100tr, 20tr, 10tr)</strong> ngay trong cột <em>Trả gốc</em> của từng tháng bên dưới — gốc còn lại &amp; tiền lãi tháng sau tự động tụt ngay!</div>

            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:5px 8px;font-size:11.5px;">
              <strong style="color:#334155;">🗓 Ngày bắt đầu vay:</strong>
              <input type="date" class="loan-inline-start-date" value="${escHtml(l.date || todayIso())}" style="padding:3px 6px;border:1px solid #CBD5E1;border-radius:6px;font-size:11.5px;font-weight:700;background:#FFF;" />
              <span style="color:#64748B;font-size:10.5px;">(Đổi ngày này sẽ tự nhảy toàn bộ các tháng)</span>
            </div>

            <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
              ${!l.settled ? `<button type="button" class="exp-mini-btn flip-inc" data-act="gen-12">➕ Thêm 12 tháng (Năm tiếp theo)</button>` : ''}
              ${!l.settled ? `<button type="button" class="exp-mini-btn" data-act="add-1m">+ Thêm 1 tháng</button>` : ''}
              ${decCalc.rows.length > 0 ? `<button type="button" class="exp-mini-btn" data-act="realign-dates" title="Tự động đánh lại ngày các kỳ nối tiếp nhau theo Ngày bắt đầu vay">🗓 Đồng bộ ngày các kỳ</button>` : ''}
              <button type="button" class="exp-mini-btn" data-act="toggle-paste">📋 Dán từ Excel</button>
              <button type="button" class="exp-mini-btn" data-act="sched-csv">⬇️ Xuất Excel (.csv)</button>
            </div>

            ${openPasteLoanId === l.id ? `
              <div class="loan-paste-box">
                <div style="font-size:11.5px;font-weight:700;color:#334155;">📋 Copy các dòng từ Google Sheets / Excel rồi dán vào đây (tự nhận diện Ngày, Lãi suất, Góp hàng tháng &amp; tự tính cả khoản vay thêm!):</div>
                <textarea class="loan-paste-ta" placeholder="VD copy trực tiếp các dòng từ cột Tháng đến cột Ghi chú trong Google Sheets rồi Ctrl+V vào đây..."></textarea>
                <div style="display:flex;gap:6px;">
                  <button type="button" class="sf-btn primary" data-act="paste-import" style="flex:1;justify-content:center;padding:6px 8px;font-size:12px;">📥 Nhập vào bảng</button>
                  <button type="button" class="sf-btn" data-act="paste-cancel" style="padding:6px 10px;font-size:12px;">Đóng</button>
                </div>
              </div>
            ` : ''}

            ${decCalc.rows.length > 0 ? `
              <div class="loan-table-wrap">
                <table class="loan-sched-table">
                  <thead>
                    <tr>
                      <th>Kỳ</th>
                      <th>Ngày</th>
                      <th>Lãi %</th>
                      <th>Lãi tháng</th>
                      <th>Gốc trước</th>
                      <th>Trả gốc</th>
                      <th>Gốc còn lại</th>
                      <th>Thực trả</th>
                    </tr>
                  </thead>
                  <tbody>${tableRowsHtml}</tbody>
                </table>
              </div>
            ` : '<div style="font-size:11.5px;color:#64748B;text-align:center;padding:6px;">Chưa có kỳ nào trong bảng. Hãy bấm "✓ Ghi nhận kỳ Năm 1 • Tháng 1", "📋 Dán từ Excel" hoặc "⚡ Tạo nhanh 12 kỳ"!</div>'}
          </div>
        `;
      }

      card.innerHTML = `
        <div class="loan-item-top">
          <div style="min-width:0;flex:1;">
            <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;">
              <span class="loan-type-pill ${isLend ? 'lend' : 'borrow'}">${isLend ? '📤 CHO VAY' : '📥 ĐI VAY'}</span>
              ${isDeclining ? `<span class="loan-due-badge soon">📊 ${l.annualRate || 0}%/năm • Giảm dần</span>` : ''}
              <strong style="font-size:13.5px;color:#1F2937;">${escHtml(l.person)}</strong>
              ${l.phone ? `<a href="tel:${escHtml(l.phone)}" style="font-size:11px;color:#0284C7;text-decoration:none;font-weight:700;">📞 ${escHtml(l.phone)}</a>` : ''}
            </div>
            <div style="font-size:11px;color:#64748B;margin-top:3px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
              <span>🗓 Bắt đầu: ${escHtml(fmtDateVnShort(l.date))}</span>
              ${isDeclining ? `<span>• ${l.interestCycle === 'monthly' ? 'Trả lãi hàng tháng' : '1 năm trả lãi 1 lần'}</span>` : (l.interest ? `<span>• 💹 ${escHtml(l.interest)}</span>` : '')}
              ${isDeclining && l.minMonthlyPrincipal > 0 ? `<span>• Góp tối thiểu ${fmtVnd(l.minMonthlyPrincipal)}/T</span>` : ''}
              ${dueBadge}
            </div>
            ${isDeclining && decCalc.unpaidInterest > 0 ? `<div style="font-size:11px;color:#B45309;font-weight:700;margin-top:2px;">💹 Lãi chờ trả (${decCalc.rows.length} kỳ): ${fmtVnd(decCalc.unpaidInterest)}</div>` : ''}
            ${l.note ? `<div style="font-size:11.5px;color:#475569;margin-top:3px;word-break:break-word;">📝 ${escHtml(l.note)}</div>` : ''}
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <div style="font-size:10px;font-weight:700;color:#64748B;">${l.settled ? 'Tổng gốc' : (paid > 0 || isDeclining ? 'Gốc còn lại' : 'Số tiền')}</div>
            <div style="font-size:14px;font-weight:900;color:${l.settled ? '#64748B' : (isLend ? '#047857' : '#DC2626')};white-space:nowrap;">${fmtVnd(l.settled ? total : rem)}</div>
            ${(!l.settled && (paid > 0 || (isDeclining && decCalc.totalTopUp > 0))) ? `<div style="font-size:10px;color:#64748B;">Tổng gốc: ${fmtVnd(total)}</div>` : ''}
          </div>
        </div>

        ${(paid > 0 && !l.settled) ? `
          <div class="loan-progress-wrap">
            <div class="loan-progress-meta">
              <span>Đã ${isLend ? 'thu' : 'trả'} gốc: ${fmtVnd(paid)}</span>
              <span>${pct}%</span>
            </div>
            <div class="loan-progress-track"><div class="loan-progress-fill" style="width:${pct}%;"></div></div>
          </div>
        ` : ''}

        ${(!isDeclining && payments.length > 0) ? `
          <div class="loan-history-list">
            ${payments.slice(-5).map((p) => `<span class="loan-history-pill">${escHtml(fmtDateVnShort(p.date))}: +${fmtVnd(p.amount)}${p.note ? ` (${escHtml(p.note)})` : ''}</span>`).join('')}
          </div>
        ` : ''}

        ${(!isDeclining && payingLoanId === l.id && !l.settled) ? `
          <div class="loan-pay-box">
            <div style="font-size:11.5px;font-weight:800;color:#065F46;">💵 Ghi nhận ${isLend ? 'thu nợ 1 phần' : 'trả nợ 1 phần'} (còn ${fmtVnd(rem)}):</div>
            <div class="loan-pay-row">
              <input type="number" class="loan-pay-amt" min="1" max="${rem}" placeholder="Số tiền (VNĐ)" value="${rem}" />
              <input type="text" class="loan-pay-note" placeholder="Ghi chú (VD: CK đợt 1)" maxlength="80" />
            </div>
            <label style="display:flex;align-items:center;gap:5px;font-size:11.5px;color:#166534;cursor:pointer;">
              <input type="checkbox" class="loan-pay-sync" />
              <span>💰 Đồng thời ghi vào Sổ Thu Chi (${isLend ? 'Thu nợ' : 'Trả nợ'})</span>
            </label>
            <div style="display:flex;gap:6px;">
              <button type="button" class="sf-btn emerald" data-act="pay-confirm" style="flex:1;justify-content:center;padding:6px 8px;font-size:12px;">✓ Xác nhận</button>
              <button type="button" class="sf-btn" data-act="pay-cancel" style="padding:6px 10px;font-size:12px;">Hủy</button>
            </div>
          </div>
        ` : ''}

        ${(isDeclining && !isSchedOpen && !l.settled) ? `
          <button type="button" class="loan-cta-sched-btn" data-act="toggle-sched">💵 Nhập trả gốc tháng này &amp; Bảng cộng lãi (${decCalc.rows.length} kỳ)</button>
        ` : ''}

        ${schedHtml}

        <div class="loan-actions-bar">
          ${isDeclining ? `
            <button type="button" class="exp-mini-btn flip-inc" data-act="toggle-sched">${isSchedOpen ? '▲ Thu gọn bảng lãi' : `📊 Mở bảng lãi (${decCalc.rows.length} kỳ)`}</button>
          ` : ''}
          ${!l.settled ? `
            ${!isDeclining ? `<button type="button" class="exp-mini-btn flip-inc" data-act="pay-open">💵 ${isLend ? 'Thu 1 phần' : 'Trả 1 phần'}</button>` : ''}
            <button type="button" class="exp-mini-btn flip-inc" data-act="settle">✅ Tất toán</button>
          ` : `
            <button type="button" class="exp-mini-btn" data-act="reopen">↩️ Mở lại</button>
          `}
          <button type="button" class="exp-mini-btn" data-act="zalo" title="Gửi tóm tắt qua Zalo">💬 Zalo</button>
          <button type="button" class="exp-mini-btn" data-act="edit" title="Sửa">✏️ Sửa</button>
          <button type="button" class="exp-mini-btn" data-act="del" title="Xóa" style="margin-left:auto;">🗑</button>
        </div>
      `;

      // Wire declining schedule interactions
      if (isDeclining) {
        card.querySelectorAll('[data-act="toggle-sched"]').forEach((btn) => {
          btn.addEventListener('click', () => {
            if (isSchedOpen) {
              expandedSchedLoanId = null;
              userCollapsedSched = true;
            } else {
              expandedSchedLoanId = l.id;
              userCollapsedSched = false;
            }
            editingSchedRowKey = null;
            renderLoans();
          });
        });

        if (isSchedOpen) {
          const blankRowIdx = decCalc.rows.findIndex((r) => r.principalPaid === 0 && !r.actualDate && r.topUp === 0);
          const targetOpening = blankRowIdx >= 0 ? decCalc.rows[blankRowIdx].opening : rem;
          const paidInp = card.querySelector('.ns-paid');
          const rateInp = card.querySelector('.ns-rate');
          const topupInp = card.querySelector('.ns-topup');
          const prevEl = card.querySelector('.loan-sched-preview');
          const updatePreview = () => {
            if (!prevEl) return;
            const pVal = parseVnNumberStrict(paidInp?.value);
            const rVal = Number(rateInp?.value || 0);
            const tVal = parseVnNumberStrict(topupInp?.value);
            const mInt = Math.round(targetOpening * (rVal / 100) / 12);
            const nextRem = Math.max(0, targetOpening - pVal + tVal);
            prevEl.innerHTML = `💡 Lãi tháng này (${rVal}% × ${fmtVnd(targetOpening)} / 12): <strong>${fmtVnd(mInt)}</strong> → Gốc tháng sau còn: <strong>${fmtVnd(nextRem)}</strong>${tVal > 0 ? ` (đã cộng vay thêm +${fmtVnd(tVal)})` : ''}`;
          };
          paidInp?.addEventListener('input', updatePreview);
          rateInp?.addEventListener('input', updatePreview);
          topupInp?.addEventListener('input', updatePreview);
          card.querySelectorAll('.ns-chip').forEach((ch) => {
            ch.addEventListener('click', () => {
              if (paidInp) { paidInp.value = String(ch.dataset.v || 0); updatePreview(); }
            });
          });

          // Inline editable Trả gốc inputs right inside the table!
          card.querySelectorAll('.loan-inline-paid-inp').forEach((inp) => {
            inp.addEventListener('focus', () => { try { inp.select(); } catch (_e) {} });
            const commitInline = () => {
              const idx = Number(inp.dataset.inlinePaid);
              if (!Array.isArray(l.schedule) || !l.schedule[idx]) return;
              const nextVal = parseVnNumberStrict(inp.value);
              if (nextVal === (Number(l.schedule[idx].principalPaid) || 0)) {
                inp.value = nextVal > 0 ? nextVal.toLocaleString('vi-VN') : '';
                return;
              }
              l.schedule[idx].principalPaid = nextVal;
              if (nextVal > 0 && !l.schedule[idx].actualDate) {
                l.schedule[idx].actualDate = fmtDateVnShort(todayIso());
              }
              const afterCalc = recalcDecliningLoan(l);
              l.paidAmount = afterCalc.totalPrincipalPaid;
              if (afterCalc.currentBalance <= 0) {
                l.settled = true;
                l.settledDate = todayIso();
              }
              saveLoans(loans);
              const nextBal = afterCalc.rows[idx]?.closing ?? afterCalc.currentBalance;
              const nextMoInt = Math.round(nextBal * (l.schedule[idx].annualRate / 100) / 12);
              setLoanStatus(`✅ Kỳ ${idx + 1}: trả gốc ${fmtVnd(nextVal)} → Gốc còn ${fmtVnd(nextBal)} (lãi tháng sau tụt còn ${fmtVnd(nextMoInt)}/tháng)!`);
              renderLoans();
            };
            inp.addEventListener('change', commitInline);
            inp.addEventListener('keydown', (ev) => {
              if (ev.key === 'Enter') { ev.preventDefault(); inp.blur(); }
            });
          });

          card.querySelector('[data-act="sched-add"]')?.addEventListener('click', () => {
            const pVal = parseVnNumberStrict(paidInp?.value);
            const rVal = Number(rateInp?.value || l.annualRate || 0);
            const tVal = parseVnNumberStrict(topupInp?.value);
            const dVal = card.querySelector('.ns-date')?.value || todayIso();
            const actVal = String(card.querySelector('.ns-actual')?.value || '').trim();
            const noteVal = String(card.querySelector('.ns-note')?.value || '').trim();
            const syncCash = Boolean(card.querySelector('.ns-sync')?.checked);
            const targetIdx = Number(card.querySelector('[data-act="sched-add"]')?.dataset.targetIdx ?? -1);
            if (!Array.isArray(l.schedule)) l.schedule = [];
            const rowPayload = {
              id: (targetIdx >= 0 && l.schedule[targetIdx]?.id) ? l.schedule[targetIdx].id : `m-${Date.now()}`,
              date: dVal,
              annualRate: rVal,
              principalPaid: pVal,
              topUp: tVal,
              actualDate: actVal || fmtDateVnShort(todayIso()),
              note: noteVal
            };
            if (targetIdx >= 0 && l.schedule[targetIdx]) {
              l.schedule[targetIdx] = rowPayload;
            } else {
              l.schedule.push(rowPayload);
            }
            const savedNum = targetIdx >= 0 ? (targetIdx + 1) : l.schedule.length;
            const afterCalc = recalcDecliningLoan(l);
            l.paidAmount = afterCalc.totalPrincipalPaid;
            if (afterCalc.currentBalance <= 0) {
              l.settled = true;
              l.settledDate = todayIso();
            }
            saveLoans(loans);
            if (syncCash && pVal > 0) {
              pushLoanToCashbook(
                isLend ? 'income' : 'expense',
                pVal,
                `${isLend ? 'Thu gốc vay' : 'Trả gốc vay'}: ${l.person} (Kỳ ${savedNum})${noteVal ? ` — ${noteVal}` : ''}`,
                dVal
              );
            }
            setLoanStatus(`✅ Đã lưu Kỳ ${savedNum}: trả gốc ${fmtVnd(pVal)} • Gốc còn lại: ${fmtVnd(afterCalc.currentBalance)}!`);
            renderLoans();
          });

          card.querySelector('[data-act="toggle-paste"]')?.addEventListener('click', () => {
            openPasteLoanId = openPasteLoanId === l.id ? null : l.id;
            renderLoans();
          });
          card.querySelector('[data-act="paste-cancel"]')?.addEventListener('click', () => {
            openPasteLoanId = null;
            renderLoans();
          });
          card.querySelector('[data-act="paste-import"]')?.addEventListener('click', () => {
            const raw = card.querySelector('.loan-paste-ta')?.value || '';
            const imported = parsePastedLoanSchedule(raw, Number(l.annualRate) || 7);
            if (imported.length === 0) {
              setLoanStatus('⚠️ Chưa đọc được dòng hợp lệ. Hãy copy trực tiếp các dòng dữ liệu từ Google Sheets / Excel rồi dán vào nhé!', true);
              return;
            }
            if (!Array.isArray(l.schedule)) l.schedule = [];
            // If schedule only had blank template rows (all 0), replace them cleanly
            const allBlank = l.schedule.every((r) => !r.principalPaid && !r.topUp && !r.actualDate);
            if (allBlank) l.schedule = [...imported];
            else l.schedule.push(...imported);
            const afterCalc = recalcDecliningLoan(l);
            l.paidAmount = afterCalc.totalPrincipalPaid;
            openPasteLoanId = null;
            saveLoans(loans);
            setLoanStatus(`📥 Đã nhập thành công ${imported.length} kỳ từ Excel! Gốc còn lại hiện tại: ${fmtVnd(afterCalc.currentBalance)}.`);
            renderLoans();
          });

          const appendBlankMonths = (count) => {
            if (!Array.isArray(l.schedule)) l.schedule = [];
            const curCalc = recalcDecliningLoan(l);
            const lastR = curCalc.rows.length > 0 ? curCalc.rows[curCalc.rows.length - 1] : null;
            const baseDate = lastR ? lastR.date : (l.date || todayIso());
            const baseRate = lastR ? lastR.annualRate : (Number(l.annualRate) || 7);
            for (let k = 1; k <= count; k++) {
              l.schedule.push({
                id: `m-auto-${Date.now()}-${k}`,
                date: addMonthsIso(baseDate, k),
                annualRate: baseRate,
                principalPaid: 0,
                topUp: 0,
                actualDate: '',
                note: ''
              });
            }
            saveLoans(loans);
            setLoanStatus(`➕ Đã thêm ${count} tháng mới vào bảng — bạn chạm trực tiếp cột "Trả gốc" từng tháng để nhập số trả linh hoạt!`);
            renderLoans();
          };
          card.querySelector('.loan-inline-start-date')?.addEventListener('change', (ev) => {
            const newStart = ev.target.value;
            if (!newStart) return;
            l.date = newStart;
            if (Array.isArray(l.schedule)) {
              for (let i = 0; i < l.schedule.length; i++) {
                l.schedule[i].date = addMonthsIso(newStart, i + 1);
                l.schedule[i].customDate = false;
              }
            }
            saveLoans(loans);
            setLoanStatus(`🗓 Đã đổi ngày bắt đầu sang ${fmtDateVnShort(newStart)} — toàn bộ ${l.schedule?.length || 0} kỳ đã tự động nhảy ngày & tháng!`);
            renderLoans();
          });

          card.querySelector('[data-act="gen-12"]')?.addEventListener('click', () => appendBlankMonths(12));
          card.querySelector('[data-act="add-1m"]')?.addEventListener('click', () => appendBlankMonths(1));
          card.querySelector('[data-act="realign-dates"]')?.addEventListener('click', () => {
            if (!Array.isArray(l.schedule) || l.schedule.length === 0) return;
            const startD = l.date || todayIso();
            for (let i = 0; i < l.schedule.length; i++) {
              l.schedule[i].date = addMonthsIso(startD, i + 1);
              l.schedule[i].customDate = false;
            }
            saveLoans(loans);
            setLoanStatus(`🗓 Đã đồng bộ lại ngày cho ${l.schedule.length} kỳ nối tiếp từ ngày bắt đầu ${fmtDateVnShort(startD)}!`);
            renderLoans();
          });

          card.querySelector('[data-act="sched-csv"]')?.addEventListener('click', () => exportSingleLoanScheduleCsv(l));

          card.querySelectorAll('[data-sched-edit]').forEach((b) => {
            b.addEventListener('click', () => {
              const idx = Number(b.dataset.schedEdit);
              const k = `${l.id}::${idx}`;
              editingSchedRowKey = editingSchedRowKey === k ? null : k;
              renderLoans();
            });
          });
          card.querySelector('[data-sched-cancel]')?.addEventListener('click', () => {
            editingSchedRowKey = null;
            renderLoans();
          });
          card.querySelectorAll('[data-sched-save]').forEach((b) => {
            b.addEventListener('click', () => {
              const idx = Number(b.dataset.schedSave);
              const tr = b.closest('tr');
              if (!Array.isArray(l.schedule) || !l.schedule[idx] || !tr) return;
              const prevDate = decCalc.rows[idx]?.date || l.schedule[idx].date;
              const nextDate = tr.querySelector('.ed-r-date')?.value || prevDate;
              const dateChanged = Boolean(nextDate && nextDate !== prevDate);
              l.schedule[idx] = {
                ...l.schedule[idx],
                date: nextDate,
                customDate: dateChanged ? true : Boolean(l.schedule[idx].customDate),
                annualRate: Number(tr.querySelector('.ed-r-rate')?.value || l.annualRate || 0),
                principalPaid: parseVnNumberStrict(tr.querySelector('.ed-r-paid')?.value),
                topUp: parseVnNumberStrict(tr.querySelector('.ed-r-topup')?.value),
                actualDate: String(tr.querySelector('.ed-r-actual')?.value || '').trim(),
                note: String(tr.querySelector('.ed-r-note')?.value || '').trim()
              };
              // If period date changed, automatically cascade subsequent months (+1 month each)!
              if (dateChanged) {
                for (let j = idx + 1; j < l.schedule.length; j++) {
                  l.schedule[j].date = addMonthsIso(nextDate, j - idx);
                  l.schedule[j].customDate = true;
                }
              }
              editingSchedRowKey = null;
              const afterCalc = recalcDecliningLoan(l);
              l.paidAmount = afterCalc.totalPrincipalPaid;
              saveLoans(loans);
              setLoanStatus(nextDate !== prevDate
                ? `✅ Đã cập nhật Kỳ ${idx + 1} (${fmtDateVnShort(nextDate)}), tự động nhảy ngày các kỳ sau & tính lại bảng lãi!`
                : `✅ Đã cập nhật Kỳ ${idx + 1} và tự động tính lại toàn bộ bảng lãi!`);
              renderLoans();
            });
          });
          card.querySelectorAll('[data-sched-del]').forEach((b) => {
            b.addEventListener('click', () => {
              const idx = Number(b.dataset.schedDel);
              if (!Array.isArray(l.schedule)) return;
              l.schedule.splice(idx, 1);
              editingSchedRowKey = null;
              const afterCalc = recalcDecliningLoan(l);
              l.paidAmount = afterCalc.totalPrincipalPaid;
              saveLoans(loans);
              setLoanStatus('🗑 Đã xóa kỳ và tự động tính lại dư nợ các tháng sau.');
              renderLoans();
            });
          });
          card.querySelectorAll('[data-toggle-year-int]').forEach((b) => {
            b.addEventListener('click', () => {
              const yNum = Number(b.dataset.toggleYearInt);
              if (!Array.isArray(l.paidInterestYears)) l.paidInterestYears = [];
              const pos = l.paidInterestYears.indexOf(yNum);
              if (pos >= 0) {
                l.paidInterestYears.splice(pos, 1);
                setLoanStatus(`↩️ Đã chuyển lãi Năm ${yNum} về trạng thái chưa thanh toán.`);
              } else {
                l.paidInterestYears.push(yNum);
                const yrInfo = decCalc.years.find((y) => y.yearIdx === yNum);
                setLoanStatus(`✅ Đã đánh dấu thanh toán xong lãi Năm ${yNum}${yrInfo ? ` (${fmtVnd(yrInfo.interestTotal)})` : ''}!`);
              }
              saveLoans(loans);
              renderLoans();
            });
          });
        }
      }

      card.querySelector('[data-act="pay-open"]')?.addEventListener('click', () => {
        payingLoanId = payingLoanId === l.id ? null : l.id;
        renderLoans();
      });
      card.querySelector('[data-act="pay-cancel"]')?.addEventListener('click', () => {
        payingLoanId = null;
        renderLoans();
      });
      card.querySelector('[data-act="pay-confirm"]')?.addEventListener('click', () => {
        const payAmt = Math.round(Number(card.querySelector('.loan-pay-amt')?.value || 0));
        const payNote = String(card.querySelector('.loan-pay-note')?.value || '').trim();
        const syncCash = Boolean(card.querySelector('.loan-pay-sync')?.checked);
        if (payAmt <= 0) { setLoanStatus('Hãy nhập số tiền thanh toán lớn hơn 0.', true); return; }
        if (!Array.isArray(l.payments)) l.payments = [];
        l.payments.push({ date: todayIso(), amount: payAmt, note: payNote });
        l.paidAmount = Math.min(total, (Number(l.paidAmount) || 0) + payAmt);
        if (l.paidAmount >= total) {
          l.settled = true;
          l.settledDate = todayIso();
        }
        saveLoans(loans);
        if (syncCash) {
          pushLoanToCashbook(
            isLend ? 'income' : 'expense',
            payAmt,
            `${isLend ? 'Thu nợ' : 'Trả nợ'}: ${l.person}${payNote ? ` (${payNote})` : ''}`,
            todayIso()
          );
        }
        payingLoanId = null;
        setLoanStatus(l.settled
          ? `🎉 Đã tất toán xong khoản ${isLend ? 'cho vay' : 'đi vay'} với ${l.person}!`
          : `✅ Đã ghi nhận ${isLend ? 'thu' : 'trả'} ${fmtVnd(payAmt)} — ${l.person} còn ${fmtVnd(Math.max(0, total - l.paidAmount))}.`);
        renderLoans();
      });
      card.querySelector('[data-act="settle"]')?.addEventListener('click', () => {
        if (!isDeclining) {
          const left = Math.max(0, total - (Number(l.paidAmount) || 0));
          if (!Array.isArray(l.payments)) l.payments = [];
          if (left > 0) l.payments.push({ date: todayIso(), amount: left, note: 'Tất toán' });
          l.paidAmount = total;
        }
        l.settled = true;
        l.settledDate = todayIso();
        payingLoanId = null;
        saveLoans(loans);
        setLoanStatus(`✅ Đã tất toán khoản ${isLend ? 'cho vay' : 'đi vay'} với ${l.person}!`);
        renderLoans();
      });
      card.querySelector('[data-act="reopen"]')?.addEventListener('click', () => {
        l.settled = false;
        l.settledDate = '';
        if (!isDeclining && (Number(l.paidAmount) || 0) >= total) {
          l.paidAmount = Math.max(0, total - (l.payments?.[l.payments.length - 1]?.amount || total));
          if (Array.isArray(l.payments) && l.payments.length > 0 && l.payments[l.payments.length - 1].note === 'Tất toán') {
            l.payments.pop();
          }
        }
        saveLoans(loans);
        setLoanStatus(`↩️ Đã mở lại khoản với ${l.person}.`);
        renderLoans();
      });
      card.querySelector('[data-act="zalo"]')?.addEventListener('click', () => {
        const msg = [
          `🤝 THÔNG TIN KHOẢN ${isLend ? 'CHO VAY' : 'VAY MƯỢN'}`,
          `👤 Đối tác: ${l.person}`,
          `💵 Tổng gốc: ${fmtVnd(total)}`,
          paid > 0 ? `✅ Đã thanh toán gốc: ${fmtVnd(paid)}` : '',
          `💰 Gốc còn lại: ${fmtVnd(rem)}`,
          isDeclining ? `📊 Lãi suất: ${l.annualRate || 0}%/năm (giảm dần theo dư nợ)` : '',
          isDeclining && decCalc.unpaidInterest > 0 ? `💹 Lãi chưa thanh toán: ${fmtVnd(decCalc.unpaidInterest)}` : '',
          `🗓 Ngày bắt đầu: ${fmtDateVnShort(l.date)}`,
          l.dueDate ? `⏳ Hạn trả: ${fmtDateVnShort(l.dueDate)}` : '',
          l.note ? `📝 Ghi chú: ${l.note}` : ''
        ].filter(Boolean).join('\n');
        shareToZaloQuick(msg, `Sổ Vay Mượn - ${l.person}`);
        setLoanStatus('💬 Đã mở chia sẻ tóm tắt khoản vay sang Zalo!');
      });
      card.querySelector('[data-act="edit"]')?.addEventListener('click', () => openLoanForm(l));
      card.querySelector('[data-act="del"]')?.addEventListener('click', () => {
        loans = loans.filter((x) => x.id !== l.id);
        if (expandedSchedLoanId === l.id) expandedSchedLoanId = null;
        saveLoans(loans);
        setLoanStatus(`🗑 Đã xóa khoản với ${l.person}.`);
        renderLoans();
      });
      listEl.appendChild(card);
    });
  };

  q('#btn-loan-form-toggle')?.addEventListener('click', () => {
    const box = q('#loan-form-box');
    if (box.classList.contains('hidden') || q('#loan-f-mode')?.value !== 'simple') openLoanForm(null, 'simple', 'lend');
    else { editingLoanId = null; box.classList.add('hidden'); }
  });
  q('#btn-loan-declining-toggle')?.addEventListener('click', () => {
    const box = q('#loan-form-box');
    if (box.classList.contains('hidden') || q('#loan-f-mode')?.value !== 'declining') openLoanForm(null, 'declining', 'borrow');
    else { editingLoanId = null; box.classList.add('hidden'); }
  });
  q('#btn-loan-form-cancel')?.addEventListener('click', () => {
    editingLoanId = null;
    q('#loan-form-box')?.classList.add('hidden');
  });
  const refreshLoanAmtPreview = () => {
    const pv = q('#loan-f-amount-preview');
    if (!pv) return;
    const val = parseVnNumberStrict(q('#loan-f-amount')?.value);
    pv.textContent = val > 0 ? `= ${fmtVnd(val)}` : '';
  };
  q('#loan-f-amount')?.addEventListener('input', refreshLoanAmtPreview);
  mountEl.querySelectorAll('.loan-amt-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      const inp = q('#loan-f-amount');
      if (!inp) return;
      const cur = parseVnNumberStrict(inp.value);
      inp.value = String(cur + Number(chip.dataset.add || 0));
      refreshLoanAmtPreview();
    });
  });
  q('#btn-loan-amt-clear')?.addEventListener('click', () => {
    if (q('#loan-f-amount')) q('#loan-f-amount').value = '';
    refreshLoanAmtPreview();
  });
  mountEl.querySelectorAll('.loan-min-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      if (q('#loan-f-min-principal')) q('#loan-f-min-principal').value = String(chip.dataset.val || 0);
    });
  });

  q('#btn-loan-add-quick')?.addEventListener('click', () => {
    const parsed = parseVietnameseQuickLoan(q('#loan-quick-inp')?.value);
    if (!parsed) {
      setLoanStatus('Chưa thấy số tiền rõ (VD: "Cho anh Minh vay 5tr hẹn 30/12" hoặc "Mượn cô Lan 2 triệu").', true);
      return;
    }
    loans.unshift(parsed);
    saveLoans(loans);
    if (q('#loan-quick-inp')) q('#loan-quick-inp').value = '';
    setLoanStatus(`✅ Đã ghi ${parsed.type === 'lend' ? '📤 Cho vay' : '📥 Đi vay'} ${parsed.person} — ${fmtVnd(parsed.amount)}!`);
    renderLoans();
  });

  q('#btn-loan-voice')?.addEventListener('click', () => {
    const vBtn = q('#btn-loan-voice');
    const finishLoanVoice = (spText) => {
      const val = String(spText || q('#loan-quick-inp')?.value || '').trim();
      if (val && q('#loan-quick-inp')) q('#loan-quick-inp').value = val;
      const parsed = parseVietnameseQuickLoan(val);
      if (parsed) {
        loans.unshift(parsed);
        saveLoans(loans);
        if (q('#loan-quick-inp')) q('#loan-quick-inp').value = '';
        setLoanStatus(`🎙️ Đã tự ghi ${parsed.type === 'lend' ? '📤 Cho vay' : '📥 Đi vay'} ${parsed.person} — ${fmtVnd(parsed.amount)}!`);
        renderLoans();
      }
    };
    if (typeof window.__toggleUnifiedVoice === 'function') {
      window.__toggleUnifiedVoice({
        btnEl: vBtn,
        silenceMs: 3500,
        onStart: () => setLoanStatus('🎙️ Đang nghe... Nói VD: "Cho anh Minh vay 5 triệu" (ngừng 3.5 giây tự lưu)'),
        onInterim: (sp) => { if (q('#loan-quick-inp')) q('#loan-quick-inp').value = sp; },
        onFinal: finishLoanVoice,
        onError: (msg) => { if (msg) setLoanStatus(msg, true); }
      });
      return;
    }
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) { setLoanStatus('⚠️ Thiết bị chưa hỗ trợ Micro trực tiếp — hãy gõ nhanh VD: "Cho anh Minh vay 5tr".', true); return; }
    if (loanWebRec) { try { loanWebRec.stop(); } catch (_e) {} return; }
    const rec = new SpeechRec();
    loanWebRec = rec;
    rec.lang = 'vi-VN';
    rec.interimResults = true;
    rec.continuous = true;
    let silT = null;
    rec.onstart = () => { vBtn.textContent = '🔴'; setLoanStatus('🎙️ Đang nghe... Ngừng 3.5 giây tự lưu'); };
    rec.onresult = (ev) => {
      const sp = Array.from(ev.results).map((r) => r[0].transcript).join(' ').trim();
      if (sp && q('#loan-quick-inp')) {
        q('#loan-quick-inp').value = sp;
        if (silT) clearTimeout(silT);
        silT = setTimeout(() => { try { rec.stop(); } catch (_e) {} }, 3500);
      }
    };
    rec.onerror = () => { if (silT) clearTimeout(silT); loanWebRec = null; vBtn.textContent = '🎙️'; };
    rec.onend = () => {
      if (silT) clearTimeout(silT);
      loanWebRec = null;
      vBtn.textContent = '🎙️';
      finishLoanVoice(q('#loan-quick-inp')?.value);
    };
    try { rec.start(); } catch (_e) { loanWebRec = null; }
  });

  q('#btn-loan-f-save')?.addEventListener('click', () => {
    const calcMode = q('#loan-f-mode')?.value === 'declining' ? 'declining' : 'simple';
    const type = q('#loan-f-type')?.value === 'borrow' ? 'borrow' : 'lend';
    const amount = parseVnNumberStrict(q('#loan-f-amount')?.value);
    const person = String(q('#loan-f-person')?.value || '').trim();
    if (!person) { setLoanStatus('Hãy nhập tên người vay / chủ nợ nhé!', true); return; }
    if (amount <= 0) { setLoanStatus('Hãy nhập số tiền lớn hơn 0 (VD: 1.6 tỷ hoặc 1600000000).', true); return; }
    const annualRate = Math.max(0, Number(q('#loan-f-rate')?.value || 0));
    const minMonthlyPrincipal = parseVnNumberStrict(q('#loan-f-min-principal')?.value);
    const interestCycle = q('#loan-f-int-cycle')?.value === 'monthly' ? 'monthly' : 'yearly';
    const startDate = q('#loan-f-date')?.value || todayIso();

    const payload = {
      calcMode,
      type,
      amount,
      person: person.slice(0, 80),
      phone: String(q('#loan-f-phone')?.value || '').trim().slice(0, 20),
      date: startDate,
      dueDate: q('#loan-f-due')?.value || '',
      annualRate: calcMode === 'declining' ? annualRate : 0,
      minMonthlyPrincipal: calcMode === 'declining' ? minMonthlyPrincipal : 0,
      interestCycle,
      interest: calcMode === 'declining'
        ? `${annualRate}%/năm (giảm dần)`
        : String(q('#loan-f-interest')?.value || '').trim().slice(0, 50),
      note: String(q('#loan-f-note')?.value || '').trim().slice(0, 180)
    };

    if (editingLoanId) {
      const idx = loans.findIndex((x) => x.id === editingLoanId);
      if (idx >= 0) {
        const cur = loans[idx];
        const merged = {
          ...cur,
          ...payload,
          schedule: Array.isArray(cur.schedule) ? cur.schedule : [],
          paidInterestYears: Array.isArray(cur.paidInterestYears) ? cur.paidInterestYears : []
        };
        if (calcMode === 'declining') {
          // Always cascade period dates cleanly from startDate whenever editing/saving the loan
          if (startDate && merged.schedule.length > 0) {
            merged.schedule = merged.schedule.map((r, i) => ({
              ...r,
              date: addMonthsIso(startDate, i + 1),
              customDate: false
            }));
          }
          const c = recalcDecliningLoan(merged);
          merged.paidAmount = c.totalPrincipalPaid;
        } else {
          const nextPaid = Math.min(amount, Number(cur.paidAmount) || 0);
          merged.paidAmount = nextPaid;
          merged.settled = cur.settled && nextPaid >= amount;
        }
        loans[idx] = merged;
      }
      editingLoanId = null;
      setLoanStatus(`✅ Đã cập nhật khoản với ${payload.person}!`);
    } else {
      const initOpt = q('#loan-f-init-months')?.value || '12_blank';
      const schedule = [];
      if (calcMode === 'declining' && initOpt !== '0') {
        let bal = amount;
        for (let k = 1; k <= 12 && bal > 0; k++) {
          const p = (initOpt === '12_fixed' && minMonthlyPrincipal > 0) ? Math.min(bal, minMonthlyPrincipal) : 0;
          schedule.push({
            id: `m-init-${Date.now()}-${k}`,
            date: addMonthsIso(startDate, k),
            annualRate,
            principalPaid: p,
            topUp: 0,
            actualDate: '',
            note: ''
          });
          bal = Math.max(0, bal - p);
        }
      }
      const newLoan = {
        id: `loan-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        ...payload,
        paidAmount: schedule.reduce((s, r) => s + r.principalPaid, 0),
        settled: false,
        settledDate: '',
        payments: [],
        schedule,
        paidInterestYears: []
      };
      loans.unshift(newLoan);
      if (calcMode === 'declining') {
        expandedSchedLoanId = newLoan.id;
      }
      if (q('#loan-f-sync-cash')?.checked) {
        pushLoanToCashbook(
          type === 'lend' ? 'expense' : 'income',
          amount,
          `${type === 'lend' ? 'Cho vay' : 'Đi vay'}: ${payload.person}${payload.note ? ` (${payload.note})` : ''}`,
          startDate
        );
      }
      setLoanStatus(`✅ Đã lưu ${calcMode === 'declining' ? '📊 Khoản vay lãi giảm dần' : (type === 'lend' ? '📤 Cho vay' : '📥 Đi vay')} ${payload.person} (${fmtVnd(amount)})!`);
    }
    saveLoans(loans);
    q('#loan-form-box')?.classList.add('hidden');
    renderLoans();
  });

  q('#loan-filter-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    loanFilter = b.dataset.lf || 'open';
    q('#loan-filter-seg').querySelectorAll('.sf-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
    renderLoans();
  });

  q('#loan-search-inp')?.addEventListener('input', (e) => {
    loanSearch = e.target.value || '';
    renderLoans();
  });

  q('#btn-loan-csv')?.addEventListener('click', () => {
    if (loans.length === 0) { setLoanStatus('Chưa có khoản vay mượn nào để xuất CSV.', true); return; }
    const rows = [
      ['Loai', 'CheDo', 'DoiTac', 'SDT', 'TongGoc', 'DaTraGoc', 'GocConLai', 'LaiChuaTra', 'NgayVay', 'HanTra', 'LaiSuat', 'TrangThai', 'GhiChu'],
      ...loans.map((l) => {
        const isDec = l.calcMode === 'declining';
        const c = isDec ? recalcDecliningLoan(l) : null;
        const tot = isDec ? (c.startPrincipal + c.totalTopUp) : (l.amount || 0);
        const pd = isDec ? c.totalPrincipalPaid : (l.paidAmount || 0);
        const rem = getLoanRemainingBalance(l);
        const unpInt = isDec ? c.unpaidInterest : 0;
        return [
          l.type === 'lend' ? 'Cho vay' : 'Di vay',
          isDec ? 'Lai giam dan' : 'Don gian',
          `"${String(l.person || '').replace(/"/g, '""')}"`,
          l.phone || '',
          tot,
          pd,
          rem,
          unpInt,
          l.date || '',
          l.dueDate || '',
          `"${String(l.interest || '').replace(/"/g, '""')}"`,
          l.settled ? 'Da tat toan' : 'Dang mo',
          `"${String(l.note || '').replace(/"/g, '""')}"`
        ];
      })
    ];
    const blob = new Blob(['\uFEFF' + rows.map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `so-vay-muon-lich-am-${todayIso()}.csv`;
    a.click();
    setLoanStatus('✓ Đã xuất file CSV tổng hợp sổ vay mượn!');
  });

  renderAll();
  renderLoans();

  return {
    refreshFromStorage: () => {
      txs = loadExpenses();
      loans = loadLoans();
      prevExpSigs = buildSigMap(txs);
      prevLoanSigs = buildSigMap(loans);
      renderAll();
      renderLoans();
    }
  };
}

/* ==================== 2. NHẮC UỐNG THUỐC & LƯU ĐƠN THUỐC ==================== */

const MED_LS_KEY = 'lich_am_medicine_v1';
const MED_LOG_LS_KEY = 'lich_am_medicine_log_v1';

function loadMeds() {
  try {
    const d = JSON.parse(localStorage.getItem(MED_LS_KEY) || '{}');
    return { items: Array.isArray(d.items) ? d.items : [], rxPhotos: Array.isArray(d.rxPhotos) ? d.rxPhotos : [] };
  } catch (_e) { return { items: [], rxPhotos: [] }; }
}
function notifyExtraLocalChanged(deletedId = '') {
  if (typeof window !== 'undefined' && typeof CustomEvent !== 'undefined') {
    try { window.dispatchEvent(new CustomEvent('licham-local-data-changed', { detail: { deletedId } })); } catch (_e) {}
  }
}

function saveMeds(d, deletedId = '') {
  try { localStorage.setItem(MED_LS_KEY, JSON.stringify(d)); } catch (_e) {}
  notifyExtraLocalChanged(deletedId);
}
function loadMedLog() {
  try { return JSON.parse(localStorage.getItem(MED_LOG_LS_KEY) || '{}') || {}; } catch (_e) { return {}; }
}
function saveMedLog(l) {
  try { localStorage.setItem(MED_LOG_LS_KEY, JSON.stringify(l)); } catch (_e) {}
  notifyExtraLocalChanged();
}

export function mountMedicineModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onAddReminder = null } = opts;

  let store = loadMeds();
  let medLog = loadMedLog();
  let busy = false;

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-sky">
        <div>
          <h2 class="sf-hero-title">💊 Nhắc Uống Thuốc &amp; Lưu Đơn Thuốc</h2>
          <div class="sf-hero-sub">Hẹn giờ uống thuốc theo cữ (trước/sau ăn) cho bản thân &amp; bố mẹ, chụp lưu đơn thuốc &amp; đồng bộ chuông báo thức.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-med-back">← Thêm</button>
      </div>

      <div class="sf-card">
        <h3 class="sf-card-title" style="color:#0369A1;">✅ Cữ uống thuốc hôm nay (${todayIso()})</h3>
        <div id="med-today-list" class="sf-kv-list"></div>
      </div>

      <div class="sf-card">
        <h3 class="sf-card-title" style="color:#0369A1;">➕ Thêm lịch uống thuốc mới</h3>
        <div class="sf-grid-2">
          <div class="sf-field"><label for="med-member">Người uống</label><select id="med-member"><option value="👤 Bản thân">👤 Bản thân</option><option value="👴 Bố">👴 Bố</option><option value="👵 Mẹ">👵 Mẹ</option><option value="👶 Con nhỏ">👶 Con nhỏ</option><option value="💑 Vợ / Chồng">💑 Vợ / Chồng</option></select></div>
          <div class="sf-field"><label for="med-name">Tên thuốc / Vitamin</label><input id="med-name" type="text" placeholder="VD: Huyết áp Amlodipine, Omega 3..." maxlength="80" /></div>
        </div>
        <div class="sf-grid-3">
          <div class="sf-field"><label for="med-dose">Liều lượng</label><input id="med-dose" type="text" value="1 viên" maxlength="40" /></div>
          <div class="sf-field"><label for="med-meal">Thời điểm</label><select id="med-meal"><option value="Sau ăn 30p">Sau ăn 30p</option><option value="Trước ăn 30p">Trước ăn 30p</option><option value="Trong bữa ăn">Trong bữa ăn</option><option value="Trước khi ngủ">Trước khi ngủ</option></select></div>
          <div class="sf-field"><label for="med-times">Các giờ uống (phẩy)</label><input id="med-times" type="text" value="07:30, 19:30" placeholder="07:30, 12:30, 19:30" /></div>
        </div>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:#0369A1;margin-bottom:8px;">
          <input type="checkbox" id="med-sync-alarm" checked />
          🔔 Tự động đồng bộ vào Báo thức Nhắc nhở &amp; Telegram hằng ngày
        </label>
        <button type="button" id="btn-med-add" class="sf-btn primary full">💾 Lưu lịch uống thuốc</button>
        <div id="med-status" class="sf-status"></div>
      </div>

      <div class="sf-card">
        <div class="sf-btn-row" style="justify-content:space-between;margin-bottom:8px;">
          <strong style="font-size:13.5px;color:#0369A1;">📄 Lưu ảnh Đơn thuốc &amp; AI Đọc đơn</strong>
          <label class="sf-btn ai" style="cursor:pointer;">
            📸 Chụp / Tải đơn thuốc
            <input id="med-rx-file" type="file" accept="image/*" class="hidden" />
          </label>
        </div>
        <div id="med-rx-list" class="sf-kv-list"></div>
      </div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  const setStatus = (m, err = false) => {
    q('#med-status').className = err ? 'sf-status err' : 'sf-status';
    q('#med-status').textContent = m || '';
  };

  const VALID_MEALS = ['Sau ăn 30p', 'Trước ăn 30p', 'Trong bữa ăn', 'Trước khi ngủ'];
  const normalizeMedMeal = (raw) => {
    const s = String(raw || '').toLowerCase();
    if (/trước\s*(khi\s*)?ngủ|tối\s*đi\s*ngủ|bedtime|before\s*sleep/i.test(s)) return 'Trước khi ngủ';
    if (/trước\s*(bữa\s*)?ăn|đói|before\s*meal/i.test(s)) return 'Trước ăn 30p';
    if (/trong\s*(khi\s*|bữa\s*)?ăn|cùng\s*bữa|with\s*(food|meal)/i.test(s)) return 'Trong bữa ăn';
    return 'Sau ăn 30p';
  };
  const normalizeMedTimes = (rawTimes, rawMeal = '') => {
    const list = [];
    const pushTime = (hh, mm) => {
      const h = Number(hh);
      const m = Number(mm);
      if (Number.isFinite(h) && Number.isFinite(m) && h >= 0 && h <= 23 && m >= 0 && m <= 59) {
        const t = `${pad2(h)}:${pad2(m)}`;
        if (!list.includes(t)) list.push(t);
      }
    };
    const arr = Array.isArray(rawTimes) ? rawTimes : String(rawTimes || '').split(/[,;|/\n]+/);
    arr.forEach((part) => {
      const txt = String(part || '').trim();
      const m = txt.match(/(\d{1,2})\s*[:hH]\s*(\d{2})?/);
      if (m) {
        pushTime(m[1], m[2] || '00');
      } else {
        const low = txt.toLowerCase();
        if (/sáng|morning/.test(low)) pushTime(7, 30);
        if (/trưa|noon|lunch/.test(low)) pushTime(12, 30);
        if (/chiều|afternoon/.test(low)) pushTime(16, 30);
        if (/tối|evening|dinner/.test(low)) pushTime(19, 30);
        if (/ngủ|khuya|bedtime|night/.test(low)) pushTime(21, 30);
      }
    });
    if (list.length === 0) {
      if (normalizeMedMeal(rawMeal) === 'Trước khi ngủ') return ['21:30'];
      return ['07:30', '19:30'];
    }
    return list.sort();
  };

  const parsePrescriptionAiResponse = (rawText) => {
    const text = String(rawText || '').trim();
    let parsed = null;
    try {
      const cleaned = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
      const firstBrace = cleaned.indexOf('{');
      const lastBrace = cleaned.lastIndexOf('}');
      if (firstBrace >= 0 && lastBrace > firstBrace) {
        parsed = JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));
      }
    } catch (_e) { parsed = null; }

    const meds = [];
    if (parsed && Array.isArray(parsed.medicines)) {
      parsed.medicines.forEach((m) => {
        const name = String(m?.name || m?.tenThuoc || m?.medicine || '').trim().slice(0, 80);
        if (!name) return;
        const dose = String(m?.dose || m?.lieuLuong || '1 viên').trim().slice(0, 40) || '1 viên';
        const meal = VALID_MEALS.includes(m?.meal) ? m.meal : normalizeMedMeal(m?.meal || m?.thoiDiem);
        const times = normalizeMedTimes(m?.times || m?.gioUong, meal);
        meds.push({ name, dose, meal, times });
      });
    }

    // Fallback heuristic if Gemini replied in plain markdown without valid JSON
    if (meds.length === 0 && text) {
      const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
      for (const ln of lines) {
        const m1 = ln.match(/^(?:\d+[.)]\s*|[-*•]\s*)\*{0,2}(?:Tên thuốc\s*:\s*)?([^:–—(\n]{3,65})\*{0,2}(?:[:–—(].*)?$/i);
        if (m1) {
          const cand = m1[1].replace(/[*`#_]/g, '').trim();
          if (cand && !/^(lưu ý|ghi chú|chẩn đoán|bác sĩ|bệnh nhân|ngày|lời khuyên|hướng dẫn|tổng quan)/i.test(cand)) {
            const doseM = ln.match(/(\d+(?:[.,]\d+)?\s*(?:viên|gói|ống|ml|giọt|lần|muỗng|thìa))/i);
            const meal = normalizeMedMeal(ln);
            const times = normalizeMedTimes(ln, meal);
            meds.push({ name: cand.slice(0, 80), dose: doseM ? doseM[1].trim() : '1 viên', meal, times });
            if (meds.length >= 8) break;
          }
        }
      }
    }

    const summary = String(parsed?.summary || '').trim() || text;
    return { summary, medicines: meds };
  };

  const fillMedForm = (med, { scroll = true } = {}) => {
    if (!med || !med.name) return;
    const nameEl = q('#med-name');
    const doseEl = q('#med-dose');
    const mealEl = q('#med-meal');
    const timesEl = q('#med-times');
    if (nameEl) nameEl.value = String(med.name || '').slice(0, 80);
    if (doseEl) doseEl.value = String(med.dose || '1 viên').slice(0, 40);
    if (mealEl) {
      const targetMeal = normalizeMedMeal(med.meal);
      if ([...mealEl.options].some((o) => o.value === targetMeal)) mealEl.value = targetMeal;
    }
    if (timesEl) {
      const tArr = normalizeMedTimes(med.times, med.meal);
      timesEl.value = tArr.join(', ');
    }
    if (nameEl) {
      nameEl.classList.remove('med-field-flash');
      void nameEl.offsetWidth;
      nameEl.classList.add('med-field-flash');
      if (scroll) {
        try {
          nameEl.closest('.sf-card')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } catch (_e) {}
      }
    }
  };

  const addMedScheduleItem = ({ member, name, dose, meal, times, syncAlarm }) => {
    const cleanName = String(name || '').trim().slice(0, 80);
    if (!cleanName) return null;
    const cleanDose = String(dose || '1 viên').trim().slice(0, 40) || '1 viên';
    const cleanMeal = normalizeMedMeal(meal);
    const cleanTimes = normalizeMedTimes(times, cleanMeal);
    const item = {
      id: `med-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      member: member || q('#med-member')?.value || '👤 Bản thân',
      name: cleanName,
      dose: cleanDose,
      meal: cleanMeal,
      times: cleanTimes
    };
    store.items.push(item);
    if (syncAlarm && typeof onAddReminder === 'function') {
      cleanTimes.forEach((tm) => {
        onAddReminder({
          title: `💊 Uống thuốc: ${cleanName} (${item.member})`,
          date: todayIso(),
          time: tm,
          repeat: 'daily',
          note: `Liều: ${cleanDose} • ${cleanMeal}`
        });
      });
    }
    return item;
  };

  const isMedAlreadySaved = (medName) => {
    const k = String(medName || '').trim().toLowerCase();
    return Boolean(k && store.items.some((x) => String(x.name || '').trim().toLowerCase() === k));
  };

  const runRxAiScan = async (rx, btnEl = null) => {
    if (busy || !rx) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      setStatus('🔑 Chưa cấu hình Gemini AI để tự đọc đơn thuốc. Bấm ⚙️ Cài đặt → Trợ lý Gemini AI để bật nhé!', true);
      onOpenGeminiSettings();
      return;
    }
    busy = true;
    if (btnEl) btnEl.disabled = true;
    setStatus('✨ Gemini Vision đang đọc tên thuốc, liều lượng & giờ uống trên đơn thuốc...');
    try {
      const b64 = String(rx.dataUrl || '').replace(/^data:image\/\w+;base64,/, '');
      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là trợ lý y tế giúp người nhà đọc đơn thuốc chụp lại (luôn nhắc tuân theo chỉ định bác sĩ). Trả về ĐÚNG 1 khối JSON hợp lệ, không thêm chữ ngoài JSON.',
        userPrompt: [
          'Hãy đọc ảnh đơn thuốc / vỏ thuốc này và trả về đúng JSON theo mẫu sau:',
          '{',
          '  "summary": "Tóm tắt tiếng Việt rõ ràng, dễ hiểu cho người lớn tuổi: tên từng thuốc, hàm lượng, liều mỗi lần, sáng/trưa/tối trước hay sau ăn, và lưu ý quan trọng.",',
          '  "medicines": [',
          '    {',
          '      "name": "Tên thuốc + hàm lượng (VD: Amlodipine 5mg)",',
          '      "dose": "Liều 1 lần (VD: 1 viên, 1 gói, 5ml)",',
          '      "meal": "Sau ăn 30p",',
          '      "times": ["07:30", "19:30"]',
          '    }',
          '  ]',
          '}',
          'Quy ước: "meal" chỉ chọn 1 trong 4 giá trị: "Sau ăn 30p", "Trước ăn 30p", "Trong bữa ăn", "Trước khi ngủ".',
          'Quy ước giờ "times" định dạng HH:MM: Sáng="07:30", Trưa="12:30", Chiều="16:30", Tối="19:30", Trước khi ngủ="21:30". Nếu là ảnh hộp/vỉ 1 loại thuốc thì trả về 1 phần tử trong mảng "medicines".'
        ].join('\n'),
        images: [b64],
        temperature: 0.2,
        thinkingLevel: 'MEDIUM',
        timeoutMs: 35000
      });
      const { summary, medicines } = parsePrescriptionAiResponse(ans);
      rx.aiNote = summary;
      rx.extractedMeds = medicines;
      saveMeds(store);
      renderMeds();
      if (medicines.length > 0) {
        fillMedForm(medicines[0], { scroll: true });
        if (medicines.length === 1) {
          setStatus(`✅ Đã quét xong & tự điền "${medicines[0].name}" (${medicines[0].dose} • ${medicines[0].times.join(', ')}) — bấm "💾 Lưu lịch uống thuốc" để lưu!`);
        } else {
          setStatus(`✅ Đã đọc được ${medicines.length} loại thuốc & tự điền "${medicines[0].name}" vào ô trên — bạn có thể bấm "💾 Lưu lịch uống thuốc" hoặc bấm "➕ Lưu tất cả ${medicines.length} thuốc" bên dưới!`);
        }
      } else {
        setStatus('✅ Đã đọc xong đơn thuốc! Hãy nhập tên thuốc vào ô trên để lưu lịch uống.');
      }
    } catch (err) {
      setStatus(`⚠️ ${err?.message || 'Lỗi đọc đơn thuốc'}`, true);
    } finally {
      busy = false;
      if (btnEl) btnEl.disabled = false;
    }
  };

  const renderMeds = () => {
    const tk = todayIso();
    const todayBox = q('#med-today-list');
    todayBox.innerHTML = '';

    const slots = [];
    store.items.forEach((m) => {
      (m.times || []).forEach((tm) => {
        slots.push({ med: m, time: tm, logKey: `${tk}::${m.id}::${tm}` });
      });
    });
    slots.sort((a, b) => a.time.localeCompare(b.time));

    if (slots.length === 0) {
      todayBox.innerHTML = '<div style="font-size:12px;color:#6B7280;text-align:center;padding:8px;">Chưa có lịch uống thuốc nào. Thêm ở form bên dưới hoặc chụp đơn thuốc để AI tự đọc!</div>';
    } else {
      slots.forEach((s) => {
        const done = Boolean(medLog[s.logKey]);
        const card = document.createElement('div');
        card.className = `med-slot-card${done ? ' taken' : ''}`;
        card.innerHTML = `
          <div style="min-width:0;flex:1;">
            <div style="font-size:13px;font-weight:800;color:#0F172A;">⏰ ${escHtml(s.time)} • ${escHtml(s.med.name)}</div>
            <div style="font-size:11.5px;color:#475569;">${escHtml(s.med.member)} • ${escHtml(s.med.dose)} • ${escHtml(s.med.meal)}</div>
          </div>
          <div style="display:flex;gap:5px;align-items:center;">
            <button type="button" class="sf-btn ${done ? 'emerald' : ''}" data-act="toggle" style="padding:5px 9px;font-size:11.5px;">${done ? '✓ Đã uống' : 'Uống'}</button>
            <button type="button" class="sf-btn" data-act="del" style="padding:5px 7px;font-size:11px;" title="Xóa thuốc này">🗑</button>
          </div>
        `;
        card.querySelector('[data-act="toggle"]')?.addEventListener('click', () => {
          medLog[s.logKey] = !medLog[s.logKey];
          saveMedLog(medLog);
          renderMeds();
        });
        card.querySelector('[data-act="del"]')?.addEventListener('click', () => {
          store.items = store.items.filter((x) => x.id !== s.med.id);
          saveMeds(store, s.med.id);
          renderMeds();
        });
        todayBox.appendChild(card);
      });
    }

    // Saved prescription photos
    const rxBox = q('#med-rx-list');
    rxBox.innerHTML = '';
    if (store.rxPhotos.length === 0) {
      rxBox.innerHTML = '<div style="font-size:12px;color:#6B7280;text-align:center;padding:6px;">Chưa lưu ảnh đơn thuốc nào. Chụp đơn thuốc để lưu phòng khi cần &amp; nhờ AI tự đọc điền tên thuốc.</div>';
    } else {
      store.rxPhotos.forEach((rx) => {
        const extracted = Array.isArray(rx.extractedMeds) ? rx.extractedMeds : [];
        const unsavedCount = extracted.filter((m) => !isMedAlreadySaved(m.name)).length;
        const div = document.createElement('div');
        div.className = 'sf-kv-item';
        div.innerHTML = `
          <div class="sf-kv-head">
            <strong>📄 ${escHtml(rx.member)} • ${escHtml(rx.date)}</strong>
            <div class="sf-btn-row">
              <button type="button" class="sf-btn ai" data-rx="ai" style="padding:3px 8px;font-size:11px;">✨ AI Đọc đơn</button>
              <button type="button" class="sf-btn" data-rx="del" style="padding:3px 7px;font-size:11px;">🗑</button>
            </div>
          </div>
          <img class="med-rx-img" src="${rx.dataUrl}" alt="Đơn thuốc" />
          ${extracted.length > 0 ? `
            <div class="med-extracted-box">
              <div class="med-extracted-head">
                <span>💊 AI nhận diện được <strong>${extracted.length}</strong> loại thuốc</span>
                ${extracted.length > 1 && unsavedCount > 0 ? `<button type="button" class="sf-btn emerald" data-rx="save-all" style="padding:4px 9px;font-size:11px;">➕ Lưu tất cả (${unsavedCount})</button>` : ''}
              </div>
              <div class="med-extracted-list">
                ${extracted.map((m, idx) => {
                  const saved = isMedAlreadySaved(m.name);
                  return `
                    <div class="med-extracted-row">
                      <div style="min-width:0;flex:1;">
                        <div class="med-extracted-name">${escHtml(m.name)}</div>
                        <div class="med-extracted-meta">${escHtml(m.dose)} • ${escHtml(m.meal)} • ⏰ ${escHtml((m.times || []).join(', '))}</div>
                      </div>
                      <div style="display:flex;gap:4px;flex-shrink:0;">
                        <button type="button" class="sf-btn" data-rx-fill="${idx}" style="padding:4px 7px;font-size:11px;" title="Điền vào ô nhập phía trên">⬆️ Điền</button>
                        <button type="button" class="sf-btn ${saved ? 'emerald' : 'primary'}" data-rx-save="${idx}" style="padding:4px 8px;font-size:11px;" ${saved ? 'disabled' : ''}>${saved ? '✓ Đã lưu' : '➕ Lưu'}</button>
                      </div>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>
          ` : ''}
          ${rx.aiNote ? `<div style="margin-top:6px;font-size:12px;white-space:pre-line;">${fmtMd(rx.aiNote)}</div>` : ''}
        `;
        div.querySelector('[data-rx="del"]')?.addEventListener('click', () => {
          store.rxPhotos = store.rxPhotos.filter((x) => x.id !== rx.id);
          saveMeds(store, rx.id);
          renderMeds();
        });
        div.querySelector('[data-rx="ai"]')?.addEventListener('click', (ev) => {
          runRxAiScan(rx, ev.currentTarget);
        });
        div.querySelector('[data-rx="save-all"]')?.addEventListener('click', () => {
          const member = q('#med-member')?.value || rx.member || '👤 Bản thân';
          const syncAlarm = Boolean(q('#med-sync-alarm')?.checked);
          let added = 0;
          extracted.forEach((m) => {
            if (isMedAlreadySaved(m.name)) return;
            if (addMedScheduleItem({ member, ...m, syncAlarm })) added += 1;
          });
          if (added > 0) {
            saveMeds(store);
            setStatus(`✅ Đã lưu tất cả ${added} loại thuốc từ đơn vào lịch${syncAlarm ? ' & đồng bộ báo thức hằng ngày!' : '!'}`);
            renderMeds();
          }
        });
        div.querySelectorAll('[data-rx-fill]').forEach((btn) => {
          btn.addEventListener('click', () => {
            const m = extracted[Number(btn.getAttribute('data-rx-fill'))];
            if (!m) return;
            fillMedForm(m, { scroll: true });
            setStatus(`✅ Đã điền "${m.name}" vào form — chỉnh nếu cần rồi bấm "💾 Lưu lịch uống thuốc"!`);
          });
        });
        div.querySelectorAll('[data-rx-save]').forEach((btn) => {
          btn.addEventListener('click', () => {
            const m = extracted[Number(btn.getAttribute('data-rx-save'))];
            if (!m || isMedAlreadySaved(m.name)) return;
            const member = q('#med-member')?.value || rx.member || '👤 Bản thân';
            const syncAlarm = Boolean(q('#med-sync-alarm')?.checked);
            addMedScheduleItem({ member, ...m, syncAlarm });
            saveMeds(store);
            setStatus(`✅ Đã lưu lịch uống ${m.name} (${(m.times || []).join(', ')})${syncAlarm ? ' & đồng bộ báo thức hằng ngày!' : ''}`);
            renderMeds();
          });
        });
        rxBox.appendChild(div);
      });
    }
  };

  q('#btn-med-back')?.addEventListener('click', onBack);
  q('#btn-med-add')?.addEventListener('click', () => {
    const name = q('#med-name').value.trim();
    if (!name) { setStatus('Hãy nhập tên thuốc trước nhé!', true); return; }
    const member = q('#med-member').value;
    const dose = q('#med-dose').value.trim() || '1 viên';
    const meal = q('#med-meal').value;
    const times = (q('#med-times').value || '07:30')
      .split(/[,;\s]+/)
      .map((s) => s.trim())
      .filter((s) => /^\d{1,2}:\d{2}$/.test(s))
      .map((s) => { const [h, m] = s.split(':'); return `${pad2(Number(h))}:${m}`; });
    if (times.length === 0) { setStatus('Nhập ít nhất 1 mốc giờ chuẩn HH:MM (VD: 07:30, 19:30).', true); return; }

    const syncAlarm = Boolean(q('#med-sync-alarm')?.checked);
    addMedScheduleItem({ member, name, dose, meal, times, syncAlarm });
    saveMeds(store);

    q('#med-name').value = '';
    setStatus(`✅ Đã lưu lịch uống ${name} (${times.join(', ')})${syncAlarm ? ' & đồng bộ báo thức hằng ngày!' : ''}`);
    renderMeds();
  });

  q('#med-rx-file')?.addEventListener('change', (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const img = new Image();
    const u = URL.createObjectURL(f);
    img.onload = () => {
      const { dataUrl } = compressImageSourceToBase64(img, 900, 0.8, false);
      URL.revokeObjectURL(u);
      const newRx = { id: `rx-${Date.now()}`, member: q('#med-member').value, date: todayIso(), dataUrl, aiNote: '', extractedMeds: [] };
      store.rxPhotos.unshift(newRx);
      store.rxPhotos = store.rxPhotos.slice(0, 6);
      saveMeds(store);
      renderMeds();
      if (isGeminiConfigured(getState()?.geminiSettings)) {
        runRxAiScan(newRx);
      } else {
        setStatus('✅ Đã lưu ảnh đơn thuốc! Bật Gemini AI rồi bấm "✨ AI Đọc đơn" để tự điền tên thuốc & giờ uống.');
      }
    };
    img.src = u;
    e.target.value = '';
  });

  if (typeof window !== 'undefined') {
    window.addEventListener('licham-cloud-extra-applied', () => {
      store = loadMeds();
      medLog = loadMedLog();
      renderMeds();
    });
  }

  renderMeds();
}

/* ==================== 3. HÔM NAY ĂN GÌ? (AI THỰC ĐƠN THEO BỮA, SỐ NGƯỜI, DỊP LỄ, THỜI TIẾT & M1/RẰM) ==================== */

const MEAL_TIMES = [
  { id: 'sang', label: '🌅 Sáng' },
  { id: 'trua', label: '☀️ Trưa' },
  { id: 'chieu', label: '🌤️ Chiều' },
  { id: 'toi', label: '🌆 Tối' },
  { id: 'khuya', label: '🌙 Khuya' }
];

const MEAL_OCCASIONS = [
  { id: 'thuong', label: '🍚 Ngày thường' },
  { id: 'sinh-nhat', label: '🎂 Sinh nhật' },
  { id: 'le-tet', label: '🎉 Lễ Tết / Họp mặt' },
  { id: 'gio-cung', label: '🏮 Ngày Giỗ / Cúng lễ' },
  { id: 'dai-khach', label: '🥂 Đãi khách / Liên hoan' },
  { id: 'nhau', label: '🍻 Tụ tập / Nhậu lai rai' },
  { id: 'hen-ho', label: '💑 Hẹn hò / Kỷ niệm' }
];

const MEAL_WEATHER_MOODS = [
  { id: 'auto', label: '🤖 Theo thời tiết hôm nay' },
  { id: 'oi-buc', label: '🥵 Oi bức (mát, dễ ăn)' },
  { id: 'mua-nhau', label: '🌧️ Trời mưa (món nhậu / ấm)' },
  { id: 'lanh', label: '❄️ Trời lạnh (lẩu / kho nóng)' },
  { id: 'mat-me', label: '⛅ Mát mẻ dễ chịu' }
];

const MEAL_POOLS = {
  savory: {
    main: ['Thịt kho tàu trứng cút', 'Cá thu sốt cà chua', 'Gà rang gừng sả', 'Sườn xào chua ngọt', 'Bò xào bông cải xanh', 'Chả lá lốt chiên thơm', 'Tôm rim mặn ngọt', 'Thịt ba chỉ rang cháy cạnh', 'Cá lóc kho tộ tiêu xanh', 'Đậu hũ nhồi thịt sốt cà'],
    soup: ['Canh chua cá lóc dọc mùng', 'Canh cua rau đay mồng tơi', 'Canh bí đỏ nấu thịt bằm', 'Canh cải cúc nấu tôm', 'Canh sườn non củ sen', 'Canh mướp đắng nhồi thịt', 'Canh rau ngót thịt băm', 'Canh nghêu nấu thì là chua thanh'],
    side: ['Rau muống xào tỏi', 'Su su xào trứng', 'Cải thìa xào dầu hào nấm', 'Bắp cải luộc chấm trứng dầm', 'Dưa chuột trộn chua ngọt', 'Đậu que xào tỏi', 'Cà pháo muối xổi', 'Mướp hương xào giá đỗ']
  },
  veg: {
    main: ['Đậu hũ sốt nấm đông cô', 'Nấm đùi gà kho tiêu xanh', 'Chả giò chay rán giòn', 'Sườn non chay rim sả ớt', 'Cà tím nướng mỡ hành chay', 'Đậu phụ sốt cà chua hành lá', 'Nấm bào ngư xào sả ớt'],
    soup: ['Canh nấm hạt sen củ quả', 'Canh chua chay dọc mùng đậu hũ', 'Canh bí đao nấu nấm rơm', 'Canh rong biển đậu phụ non', 'Canh rau củ ngũ sắc thanh ngọt'],
    side: ['Bông cải xanh xào nấm hương', 'Rau củ luộc chấm kho quẹt chay', 'Đậu bắp luộc chấm chao', 'Gỏi ngó sen chay thanh mát', 'Mướp xào nấm mèo']
  },
  sang: {
    main: ['Phở bò tái nạm nóng hổi', 'Bún riêu cua đậu rán', 'Xôi xéo hành phi chả lụa', 'Bánh mì ốp la pate bơ', 'Bún chả Hà Nội', 'Cháo sườn quẩy giòn', 'Hủ tiếu Nam Vang', 'Bánh cuốn nóng chả quế'],
    soup: ['Sữa đậu nành ấm / Cà phê sữa đá', 'Trà gừng mật ong ấm bụng', 'Nước cam tươi ép', 'Sữa chua nếp cẩm'],
    side: ['Trứng chần / Quẩy nóng', 'Dưa góp đu đủ cà rốt', 'Rau sống ăn kèm tươi sạch', 'Trái cây tráng miệng nhẹ']
  },
  khuya: {
    main: ['Cháo trắng lá dứa hột vịt muối & chà bông', 'Mì gói xào bò rau cải', 'Miến gà xé nóng hổi', 'Bánh bao nhân thịt trứng cút', 'Trứng vịt lộn rau răm gừng', 'Nui xào trứng thịt bằm'],
    soup: ['Canh trứng cà chua nấu nhanh 5 phút', 'Súp cua nấm hương ấm bụng', 'Trà hoa cúc / Sữa ấm dễ ngủ'],
    side: ['Dưa cải chua / Củ kiệu', 'Bánh flan caramel nhẹ bụng', 'Hoa quả cắt miếng dễ tiêu']
  },
  hot: {
    main: ['Thịt ba chỉ luộc chấm mắm tép / mắm nêm', 'Đậu phụ rán tẩm hành mát bụng', 'Tôm hấp sả cuốn bánh tráng rau sống', 'Gà xé phay bóp rau răm hành tây', 'Chả cá thì là ăn bún', 'Cá hấp xì dầu gừng thanh ngọt'],
    soup: ['Canh cua đồng rau đay mồng tơi + cà pháo', 'Canh rau muống luộc dầm sấu / chanh', 'Canh ngao nấu dứa cà chua chua thanh', 'Canh bí đao nấu tôm tươi giải nhiệt'],
    side: ['Nộm xoài xanh tai heo / khô bò', 'Gỏi dưa leo tôm thịt giòn mát', 'Rau củ luộc chấm muối vừng', 'Cà pháo muối xổi giòn tan']
  },
  rainyNhau: {
    main: ['Lẩu ếch măng cay / Lẩu Thái hải sản chua cay', 'Sụn gà rang muối ớt lá chanh', 'Bò nhúng giấm cuốn bánh tráng', 'Chân gà sả tắc ngâm giòn', 'Bạch tuộc / Mực nướng sa tế', 'Bò lúc lắc tiêu đen / Gân bò xào sa tế', 'Ốc hương xào bơ tỏi bánh mì'],
    soup: ['Nước lẩu cay nóng hổi xì xụp', 'Canh kim chi thịt ba chỉ đậu non', 'Súp hải sản cay ấm bụng'],
    side: ['Đậu hũ chiên giòn chấm mắm tôm / mắm hành', 'Lạc rang muối / Ngô chiên bơ', 'Cóc non / Xoài xanh chấm muối tôm', 'Khoai tây chiên lắc phô mai']
  },
  feast: {
    main: ['Gà ta luộc lá chanh óng vàng', 'Tôm sú hấp bia sả tươi ngọt', 'Bò sốt vang / Bò nướng tảng tiêu xanh', 'Sườn nướng mật ong / Chân giò hầm hạt sen', 'Cá chẽm hấp Hồng Kông'],
    soup: ['Lẩu riêu cua bắp bò sườn sụn', 'Canh bóng thả thập cẩm cổ truyền', 'Canh măng móng giò / Súp bào ngư nấm'],
    side: ['Nem rán (Chả giò) hải sản giòn rụm', 'Nộm ngó sen tôm thịt bóp chua ngọt', 'Xôi gấc / Xôi vò hạt sen', 'Rau củ thập cẩm xào mực / tôm']
  }
};

const MEAL_DIET_STYLES = [
  { id: 'gia-dinh', label: '🍚 Cơm gia đình' },
  { id: 'an-nhau', label: '🍻 Ăn nhậu / Lai rai' },
  { id: 'chay', label: '🪷 Ăn Chay' },
  { id: 'eat-clean', label: '🥗 Eat Clean / Giữ dáng' },
  { id: 'nhanh-15p', label: '⚡ Nấu nhanh 15 phút' },
  { id: 'tiet-kiem', label: '💰 Tiết kiệm chi phí' }
];

function detectDefaultMealTime(h) {
  if (h >= 5 && h < 10) return 'sang';
  if (h >= 10 && h < 14) return 'trua';
  if (h >= 14 && h < 17) return 'chieu';
  if (h >= 17 && h < 21) return 'toi';
  return 'khuya';
}

export function mountMealPlannerModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const { getState = () => ({}), onBack = () => {}, onOpenGeminiSettings = () => {}, onSendTelegram = null, onOpenDiet = null } = opts;

  const now = new Date();
  const lunar = convertSolar2Lunar(now.getDate(), now.getMonth() + 1, now.getFullYear(), TIMEZONE_VN);
  const isVegDay = lunar.day === 1 || lunar.day === 15 || lunar.day === 14 || lunar.day === 30;
  let mealTime = detectDefaultMealTime(now.getHours());
  let diet = isVegDay ? 'chay' : 'gia-dinh';
  let occasion = 'thuong';
  let weatherMood = 'auto';
  let mealModeTab = 'family'; // 'family' | 'diet'
  let familyConds = new Set(); // Multi-select diseases/restrictions (0 = không kiêng, 1..N = nhiều bệnh cùng lúc!)
  let familyCondOpen = false;
  let lastAi = '';
  let busy = false;

  const readLiveWeather = () => {
    const wx = getState()?.weatherData;
    const temp = wx?.current?.temp ?? null;
    const label = wx?.current?.label || '';
    const isRain = /mưa|dông|bão|rain|shower|storm/i.test(label);
    const isHot = temp !== null && temp >= 31;
    const isCold = temp !== null && temp <= 20;
    return { temp, label, isRain, isHot, isCold };
  };

  mountEl.innerHTML = `
    <div class="sf-wrap">
      <div class="sf-hero theme-orange">
        <div>
          <h2 class="sf-hero-title">🍲 Hôm Nay Ăn Gì? &amp; Ăn Kiêng Gia Đình</h2>
          <div class="sf-hero-sub">Gợi ý thực đơn theo Bữa, Số người, Dịp lễ, Ăn nhậu, Thời tiết &amp; Chế độ ăn kiêng cho người có 1 hoặc nhiều bệnh nền.</div>
        </div>
        <button type="button" class="sf-back-btn" id="btn-meal-back">← Thêm</button>
      </div>

      <!-- 2 Clean Tabs: Nấu cho gia đình | Cẩm nang & Nấu cho người kiêng cữ -->
      <div class="sf-seg" id="meal-mode-seg" style="margin-bottom:0;">
        <button type="button" class="sf-seg-btn active" data-mtab="family">🍚 Gợi ý thực đơn</button>
        <button type="button" class="sf-seg-btn" data-mtab="diet">🥗 Ăn kiêng &amp; Bệnh lý</button>
      </div>

      <div id="meal-pane-family">
      <div class="sf-card">
        ${isVegDay
          ? `<div class="meal-veg-banner">🪷 Hôm nay là ngày ${lunar.day}/${lunar.month} Âm lịch (${lunar.day === 1 ? 'Mùng 1' : lunar.day === 15 ? 'Ngày Rằm' : 'Ngày Trai'}) — Tự động ưu tiên Thực đơn Chay thanh đạm!</div>`
          : `<div id="meal-live-meta" style="font-size:12px;color:#9A3412;font-weight:700;margin-bottom:8px;">📅 Hôm nay: ${lunar.day}/${lunar.month} ÂL</div>`}

        <div class="sf-grid-2">
          <div class="sf-field">
            <label for="meal-time-sel">⏰ Chọn bữa ăn</label>
            <select id="meal-time-sel">
              ${MEAL_TIMES.map((t) => `<option value="${t.id}"${t.id === mealTime ? ' selected' : ''}>${t.label}</option>`).join('')}
            </select>
          </div>
          <div class="sf-field">
            <label for="meal-servings">👥 Nấu cho mấy người?</label>
            <select id="meal-servings">
              <option value="1">1 người (ăn một mình)</option>
              <option value="2">2 người (cặp đôi / 2 bạn)</option>
              <option value="4" selected>3 – 4 người (gia đình nhỏ)</option>
              <option value="6">5 – 6 người (gia đình đông)</option>
              <option value="10">8 – 12 người (tiệc / 1–2 mâm)</option>
              <option value="20">15 – 20+ người (tiệc lớn / giỗ)</option>
            </select>
          </div>
        </div>

        <div class="sf-grid-2">
          <div class="sf-field">
            <label for="meal-diet-sel">🍽️ Phong cách / Chế độ ăn</label>
            <select id="meal-diet-sel">
              ${MEAL_DIET_STYLES.map((d) => `<option value="${d.id}"${d.id === diet ? ' selected' : ''}>${d.label}</option>`).join('')}
            </select>
          </div>
          <div class="sf-field">
            <label for="meal-occasion">🎉 Dịp trọng đại / Hoàn cảnh</label>
            <select id="meal-occasion">
              ${MEAL_OCCASIONS.map((o) => `<option value="${o.id}">${o.label}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="sf-field">
          <label for="meal-weather-mood">🌤️ Thời tiết &amp; Không khí ăn uống:</label>
          <select id="meal-weather-mood">
            ${MEAL_WEATHER_MOODS.map((w) => `<option value="${w.id}">${w.label}</option>`).join('')}
          </select>
        </div>

        <!-- Multi-select Collapsible Checkbox Dropdown for Family Dietary Restrictions (0, 1, 2, 3+ conditions!) -->
        <div class="sf-field">
          <div class="diet-dd-wrap">
            <button type="button" class="diet-dd-trigger" id="meal-cond-trigger">
              <div style="min-width:0;flex:1;text-align:left;">
                <div style="font-size:11px;font-weight:700;color:#047857;">🩺 Nhà có người ăn kiêng / bệnh nền? (tích chọn nhiều bệnh — tùy chọn)</div>
                <div id="meal-cond-summary" style="font-size:12px;font-weight:800;color:#111827;margin-top:1px;">✅ Bình thường (Không kiêng đặc biệt)</div>
              </div>
              <span id="meal-cond-arrow" style="font-size:12px;font-weight:900;color:#047857;">▼</span>
            </button>
            <div id="meal-cond-panel" class="diet-dd-panel hidden">
              <div class="diet-dd-actions">
                <span style="font-size:11px;font-weight:700;color:#475569;">Tích chọn 1, 2, 3+ bệnh cùng lúc hoặc bỏ trống:</span>
                <div style="display:flex;gap:5px;">
                  <button type="button" class="sf-btn" id="btn-meal-cond-clear" style="padding:3px 8px;font-size:11px;color:#DC2626;">🧹 Bỏ tích hết</button>
                  <button type="button" class="sf-btn emerald" id="btn-meal-cond-done" style="padding:3px 9px;font-size:11px;">✓ Xong</button>
                </div>
              </div>
              <div class="diet-check-grid" id="meal-cond-grid">
                ${DIET_CONDITIONS.map((c) => `
                  <label class="diet-check-item">
                    <input type="checkbox" value="${c.id}" />
                    <span>${c.icon} ${escHtml(c.shortName)}</span>
                  </label>
                `).join('')}
              </div>
            </div>
          </div>
        </div>

        <div class="sf-field">
          <label for="meal-fridge">💬 Bạn muốn ăn gì / Tủ lạnh có sẵn gì? (Gõ tự nhiên — AI ưu tiên số 1 theo ý bạn!)</label>
          <div class="sf-btn-row" style="flex-wrap:nowrap;">
            <input id="meal-fridge" type="text" placeholder='VD: "2 vợ chồng tối nay ăn lẩu trời mưa", "món nhậu 4 người", "tủ lạnh có trứng, thịt bằm"...' maxlength="240" style="flex:1;min-width:0;" />
            <button type="button" id="btn-meal-voice" class="sf-btn" title="Nói yêu cầu món ăn tiếng Việt">🎙️</button>
          </div>
        </div>

        <div class="sf-btn-row">
          <button type="button" id="btn-meal-spin" class="sf-btn primary" style="flex:1;">🎰 Gợi ý nhanh</button>
          <button type="button" id="btn-meal-ai" class="sf-btn ai" style="flex:1;">✨ AI Lên Thực Đơn &amp; Cách Nấu</button>
        </div>
        <div id="meal-status" class="sf-status"></div>
        <div id="meal-trio-box" class="meal-trio"></div>
      </div>

      <div id="meal-ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong id="meal-ai-title">✨ Thực đơn &amp; Công thức từ Đầu bếp AI</strong>
          <div class="sf-btn-row">
            <button type="button" id="btn-meal-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" id="btn-meal-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" id="btn-meal-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div id="meal-ai-body" class="dream-result-body"></div>
      </div>
      </div>

      <div id="meal-pane-diet" class="hidden"></div>
    </div>
  `;

  const q = (s) => mountEl.querySelector(s);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  const refreshLiveMeta = () => {
    const wx = readLiveWeather();
    const el = q('#meal-live-meta');
    if (el) {
      el.textContent = `📅 Hôm nay: ${lunar.day}/${lunar.month} ÂL${wx.temp !== null ? ` • 🌤️ Thời tiết thực tế: ${Math.round(wx.temp)}°C (${wx.label})` : ''}`;
    }
    return wx;
  };

  const getEffectiveMood = (wx) => {
    if (weatherMood !== 'auto') return weatherMood;
    if (wx.isRain) return 'mua-nhau';
    if (wx.isHot) return 'oi-buc';
    if (wx.isCold) return 'lanh';
    return 'mat-me';
  };

  const spinMenu = () => {
    const wx = refreshLiveMeta();
    const effMood = getEffectiveMood(wx);
    const servings = Number(q('#meal-servings')?.value || 4);
    occasion = q('#meal-occasion')?.value || 'thuong';

    let pool = MEAL_POOLS.savory;
    let cat1 = '🍖 Món Mặn Chính', cat2 = '🥣 Món Canh', cat3 = '🥬 Rau / Món Phụ';
    let moodNote = `Khẩu phần ~${servings} người ăn`;

    if (diet === 'chay') {
      pool = MEAL_POOLS.veg;
      cat1 = '🪷 Món Chính Chay';
      moodNote = `Thực đơn Chay cho ${servings} người`;
    } else if (diet === 'an-nhau' || occasion === 'nhau' || effMood === 'mua-nhau') {
      pool = MEAL_POOLS.rainyNhau;
      cat1 = '🍻 Món Nhậu Chủ Lực'; cat2 = '🍲 Lẩu / Nóng Hổi'; cat3 = '🥗 Món Nhắm Lai Rai';
      moodNote = effMood === 'mua-nhau' ? 'Trời mưa ngồi lai rai cực cuốn!' : 'Đồ nhậu bén mồi tụ tập cực đã';
    } else if (['sinh-nhat', 'le-tet', 'gio-cung', 'dai-khach', 'hen-ho'].includes(occasion)) {
      pool = MEAL_POOLS.feast;
      cat1 = '🎉 Món Tiệc Chính'; cat2 = '🍲 Canh / Lẩu Tiệc'; cat3 = '🥢 Khai Vị / Nộm';
      moodNote = `Mâm tiệc đẹp mắt cho ${servings} người`;
    } else if (mealTime === 'sang') {
      pool = MEAL_POOLS.sang;
      cat1 = '🌅 Món Sáng Chính'; cat2 = '☕ Đồ Uống Kèm'; cat3 = '🥬 Ăn Kèm';
      moodNote = 'Nhanh gọn đủ năng lượng buổi sáng';
    } else if (mealTime === 'khuya') {
      pool = MEAL_POOLS.khuya;
      cat1 = '🌙 Món Ăn Khuya'; cat2 = '🥣 Canh / Ấm Bụng'; cat3 = '🍎 Nhẹ Bụng';
      moodNote = 'Dễ tiêu, không quá nặng bụng';
    } else if (effMood === 'oi-buc') {
      pool = MEAL_POOLS.hot;
      cat1 = '🥗 Món Chính Dễ Ăn'; cat2 = '🥣 Canh Giải Nhiệt'; cat3 = '🥒 Nộm / Chua Mát';
      moodNote = 'Trời oi bức — thanh mát, ít dầu mỡ!';
    }

    const m1 = pick(pool.main);
    const m2 = pick(pool.soup);
    const m3 = pick(pool.side);
    q('#meal-trio-box').innerHTML = `
      <div class="meal-dish-card"><div class="meal-dish-cat">${cat1}</div><div class="meal-dish-name">${m1}</div><div class="meal-dish-note">${moodNote}</div></div>
      <div class="meal-dish-card"><div class="meal-dish-cat">${cat2}</div><div class="meal-dish-name">${m2}</div><div class="meal-dish-note">${effMood === 'oi-buc' ? 'Thanh mát giải nhiệt' : 'Ấm bụng trọn vị'}</div></div>
      <div class="meal-dish-card"><div class="meal-dish-cat">${cat3}</div><div class="meal-dish-name">${m3}</div><div class="meal-dish-note">Cân bằng khẩu vị</div></div>
    `;
  };

  q('#btn-meal-back')?.addEventListener('click', onBack);

  // Mount embedded Diet Guide into Tab 2 ("Nấu cho người kiêng cữ")
  mountDietGuideModule(q('#meal-pane-diet'), {
    embedded: true,
    getState,
    onBack,
    onOpenGeminiSettings,
    onSendTelegram
  });
  q('#meal-mode-seg')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-seg-btn');
    if (!b) return;
    mealModeTab = b.dataset.mtab || 'family';
    q('#meal-mode-seg').querySelectorAll('.sf-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
    q('#meal-pane-family')?.classList.toggle('hidden', mealModeTab !== 'family');
    q('#meal-pane-diet')?.classList.toggle('hidden', mealModeTab !== 'diet');
  });
  const syncFamilyCondUi = () => {
    const selected = DIET_CONDITIONS.filter((c) => familyConds.has(c.id));
    q('#meal-cond-grid')?.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
      cb.checked = familyConds.has(cb.value);
      cb.closest('.diet-check-item')?.classList.toggle('checked', cb.checked);
    });
    const sum = q('#meal-cond-summary');
    if (sum) {
      sum.textContent = selected.length === 0
        ? '✅ Bình thường (Không kiêng đặc biệt)'
        : `🩺 Đang chọn ${selected.length}: ${selected.map((c) => `${c.icon} ${c.shortName}`).join(' + ')}`;
    }
    q('#meal-cond-panel')?.classList.toggle('hidden', !familyCondOpen);
    if (q('#meal-cond-arrow')) q('#meal-cond-arrow').textContent = familyCondOpen ? '▲' : '▼';
  };

  q('#meal-cond-trigger')?.addEventListener('click', () => {
    familyCondOpen = !familyCondOpen;
    syncFamilyCondUi();
  });
  q('#btn-meal-cond-done')?.addEventListener('click', () => {
    familyCondOpen = false;
    syncFamilyCondUi();
  });
  q('#btn-meal-cond-clear')?.addEventListener('click', () => {
    familyConds.clear();
    syncFamilyCondUi();
  });
  q('#meal-cond-grid')?.addEventListener('change', (e) => {
    const cb = e.target;
    if (!cb || cb.type !== 'checkbox') return;
    if (cb.checked) familyConds.add(cb.value);
    else familyConds.delete(cb.value);
    syncFamilyCondUi();
  });

  q('#meal-time-sel')?.addEventListener('change', (e) => {
    mealTime = e.target.value || 'trua';
    spinMenu();
  });
  q('#meal-diet-sel')?.addEventListener('change', (e) => {
    diet = e.target.value || 'gia-dinh';
    spinMenu();
  });
  q('#meal-servings')?.addEventListener('change', spinMenu);
  q('#meal-occasion')?.addEventListener('change', (e) => { occasion = e.target.value || 'thuong'; spinMenu(); });
  q('#meal-weather-mood')?.addEventListener('change', (e) => { weatherMood = e.target.value || 'auto'; spinMenu(); });
  q('#btn-meal-spin')?.addEventListener('click', spinMenu);

  // Smart auto-sync filters when user types natural requests like "2 vợ chồng tối nay ăn lẩu trời mưa"
  const syncFiltersFromFreeText = (raw) => {
    const t = String(raw || '').toLowerCase();
    if (!t) return;
    if (/\b(?:sáng|sang)\b/.test(t)) mealTime = 'sang';
    else if (/\b(?:trưa|trua)\b/.test(t)) mealTime = 'trua';
    else if (/\b(?:chiều|chieu)\b/.test(t)) mealTime = 'chieu';
    else if (/\b(?:tối|toi)\b/.test(t)) mealTime = 'toi';
    else if (/\b(?:khuya|đêm|dem)\b/.test(t)) mealTime = 'khuya';
    if (q('#meal-time-sel')) q('#meal-time-sel').value = mealTime;

    if (/(?:mưa|mua|nhậu|nhau|lẩu|lau)/i.test(t) && q('#meal-weather-mood')) {
      weatherMood = /mưa|mua/i.test(t) ? 'mua-nhau' : weatherMood;
      q('#meal-weather-mood').value = weatherMood;
    } else if (/(?:oi bức|oi buc|nóng|nong)/i.test(t) && q('#meal-weather-mood')) {
      weatherMood = 'oi-buc';
      q('#meal-weather-mood').value = weatherMood;
    } else if (/(?:lạnh|lanh|rét|ret)/i.test(t) && q('#meal-weather-mood')) {
      weatherMood = 'lanh';
      q('#meal-weather-mood').value = weatherMood;
    }

    const mPeople = t.match(/(\d+)\s*(?:người|nguoi|vợ chồng|vo chong|anh em|bạn|ban|khách|khach)/i);
    if (mPeople && q('#meal-servings')) {
      const cnt = Number(mPeople[1]);
      const pickVal = cnt <= 1 ? '1' : cnt <= 2 ? '2' : cnt <= 4 ? '4' : cnt <= 6 ? '6' : cnt <= 12 ? '10' : '20';
      q('#meal-servings').value = pickVal;
    }
    if (/(?:sinh nhật|sinh nhat)/i.test(t) && q('#meal-occasion')) { occasion = 'sinh-nhat'; q('#meal-occasion').value = occasion; }
    else if (/(?:nhậu|nhau|bia|rượu|ruou)/i.test(t)) {
      occasion = 'nhau';
      diet = 'an-nhau';
      if (q('#meal-occasion')) q('#meal-occasion').value = occasion;
      if (q('#meal-diet-sel')) q('#meal-diet-sel').value = diet;
    } else if (/(?:giỗ|gio|cúng|cung)/i.test(t) && q('#meal-occasion')) { occasion = 'gio-cung'; q('#meal-occasion').value = occasion; }
    if (/(?:chay)/i.test(t)) {
      diet = 'chay';
      if (q('#meal-diet-sel')) q('#meal-diet-sel').value = diet;
    }
    let condAdded = false;
    if (/(?:tiểu đường|tieu duong|đường huyết|duong huyet)/i.test(t)) { familyConds.add('tieu-duong'); condAdded = true; }
    if (/(?:bụng to|bung to|mỡ bụng|mo bung|bụng bia|bung bia)/i.test(t)) { familyConds.add('bung-to'); condAdded = true; }
    if (/(?:huyết áp|huyet ap|tim mạch|tim mach)/i.test(t)) { familyConds.add('huyet-ap'); condAdded = true; }
    if (/(?:mỡ máu|mo mau|gan nhiễm mỡ|gan nhiem mo)/i.test(t)) { familyConds.add('mo-mau'); condAdded = true; }
    if (/(?:gout|gút|gut|uric)/i.test(t)) { familyConds.add('gout'); condAdded = true; }
    if (/(?:dạ dày|da day|trào ngược|trao nguoc)/i.test(t)) { familyConds.add('da-day'); condAdded = true; }
    if (condAdded) syncFamilyCondUi();
  };

  q('#meal-fridge')?.addEventListener('change', (e) => syncFiltersFromFreeText(e.target.value));
  q('#meal-fridge')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      syncFiltersFromFreeText(e.target.value);
      q('#btn-meal-ai')?.click();
    }
  });

  let mealVoiceRec = null;
  q('#btn-meal-voice')?.addEventListener('click', () => {
    const vBtn = q('#btn-meal-voice');
    const finishMealVoice = (spText) => {
      const val = String(spText || q('#meal-fridge')?.value || '').trim();
      if (val && q('#meal-fridge')) q('#meal-fridge').value = val;
      if (val) {
        syncFiltersFromFreeText(val);
        q('#btn-meal-ai')?.click();
      }
    };
    if (typeof window.__toggleUnifiedVoice === 'function') {
      window.__toggleUnifiedVoice({
        btnEl: vBtn,
        silenceMs: 3500,
        onStart: () => {
          q('#meal-status').className = 'sf-status';
          q('#meal-status').textContent = '🎙️ Đang nghe... Nói VD: "2 vợ chồng tối nay ăn lẩu" (ngừng 3.5 giây tự gửi)';
        },
        onInterim: (sp) => { if (q('#meal-fridge')) q('#meal-fridge').value = sp; },
        onFinal: finishMealVoice,
        onError: (msg) => {
          if (msg) { q('#meal-status').className = 'sf-status err'; q('#meal-status').textContent = msg; }
        }
      });
      return;
    }
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      q('#meal-status').className = 'sf-status err';
      q('#meal-status').textContent = '⚠️ Thiết bị chưa hỗ trợ Micro trực tiếp ở đây — bạn gõ thẳng vào ô trên rồi bấm AI nhé!';
      return;
    }
    if (mealVoiceRec) { try { mealVoiceRec.stop(); } catch (_e) {} return; }
    const rec = new SpeechRec();
    mealVoiceRec = rec;
    rec.lang = 'vi-VN';
    rec.interimResults = true;
    rec.continuous = true;
    let silT = null;
    rec.onstart = () => { vBtn.textContent = '🔴'; q('#meal-status').className = 'sf-status'; q('#meal-status').textContent = '🎙️ Đang nghe... Ngừng 3.5 giây tự gửi'; };
    rec.onresult = (ev) => {
      const sp = Array.from(ev.results).map((r) => r[0].transcript).join(' ').trim();
      if (sp) {
        q('#meal-fridge').value = sp;
        if (silT) clearTimeout(silT);
        silT = setTimeout(() => { try { rec.stop(); } catch (_e) {} }, 3500);
      }
    };
    rec.onerror = () => { if (silT) clearTimeout(silT); mealVoiceRec = null; vBtn.textContent = '🎙️'; };
    rec.onend = () => {
      if (silT) clearTimeout(silT);
      mealVoiceRec = null;
      vBtn.textContent = '🎙️';
      finishMealVoice(q('#meal-fridge')?.value);
    };
    try { rec.start(); } catch (_e) { mealVoiceRec = null; }
  });

  q('#btn-meal-ai')?.addEventListener('click', async () => {
    if (busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      q('#meal-status').className = 'sf-status err';
      q('#meal-status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" id="btn-meal-cfg">Nhập Key</button>';
      q('#btn-meal-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }
    const fridge = q('#meal-fridge').value.trim();
    if (fridge) syncFiltersFromFreeText(fridge);

    busy = true;
    q('#btn-meal-ai').disabled = true;
    q('#meal-status').className = 'sf-status';
    q('#meal-status').textContent = '✨ Đầu bếp AI đang lên gợi ý món ăn, đồ uống & định lượng đi chợ...';
    q('#meal-ai-card').classList.remove('hidden');
    q('#meal-ai-body').innerHTML = '✨ Đang thiết kế thực đơn & đồ uống hợp ý nhất...';
    try {
      const wx = refreshLiveMeta();
      const servingsSel = q('#meal-servings');
      const servingsText = servingsSel?.options?.[servingsSel.selectedIndex]?.textContent || '4 người';
      const mtLabel = MEAL_TIMES.find((t) => t.id === mealTime)?.label || 'Bữa Trưa';
      const occLabel = MEAL_OCCASIONS.find((o) => o.id === occasion)?.label || 'Ngày thường';
      const moodLabel = MEAL_WEATHER_MOODS.find((w) => w.id === weatherMood)?.label || 'Theo thời tiết hôm nay';
      const dietMap = { 'gia-dinh': 'Cơm gia đình Việt Nam', 'an-nhau': 'Món ăn nhậu / lai rai bén mồi kèm đồ uống', chay: 'Thực đơn Chay thanh đạm', 'eat-clean': 'Eat Clean ít dầu mỡ giảm cân', 'nhanh-15p': 'Nấu siêu nhanh 15 phút', 'tiet-kiem': 'Tiết kiệm chi phí' };
      const pickedConds = DIET_CONDITIONS.filter((c) => familyConds.has(c.id));
      const condLine = pickedConds.length > 0
        ? `\n- 🩺 LƯU Ý ĂN KIÊNG QUAN TRỌNG (ĐỒNG THỜI ${pickedConds.length} TÌNH TRẠNG): ${pickedConds.map((c) => `${c.name} (${c.subtitle})`).join('; ')} — BẮT BUỘC cân chỉnh gia vị, cách chế biến & chỉ rõ món nào nên ăn / kiêng cho từng người!`
        : '';
      const liveWxStr = wx.temp !== null ? `Thời tiết thực tế ngoài trời: ${Math.round(wx.temp)}°C (${wx.label}).` : '';

      const prompt = `${fridge ? `🎯 YÊU CẦU TRỌNG TÂM CỦA NGƯỜI DÙNG (ƯU TIÊN TUYỆT ĐỐI SỐ 1 — NẾU NGƯỜI DÙNG NÓI RÕ MÓN NHƯ LẨU / NƯỚNG / NHẬU / SỐ NGƯỜI / THỜI TIẾT THÌ BÁM SÁT 100% CÂU NÀY, KHÔNG BỊ RÀNG BUỘC BỞI MỤC CHỌN MẶC ĐỊNH BÊN DƯỚI):\n"${fridge}"\n\n` : ''}Thông tin bối cảnh tham khảo thêm:
- Bữa ăn: ${mtLabel}
- Số người ăn: ${servingsText}
- Dịp / Hoàn cảnh: ${occLabel} (Hôm nay ${lunar.day}/${lunar.month} ÂL${isVegDay ? ' — ngày ăn chay Mùng 1/Rằm' : ''})
- Thời tiết / Không khí: ${moodLabel}. ${liveWxStr}
- Phong cách ăn: ${dietMap[diet] || diet}${condLine}

QUY TẮC GỢI Ý THÔNG MINH:
1. Nếu người dùng muốn ăn **Lẩu** (VD: "2 vợ chồng tối nay ăn lẩu trời mưa"): gợi ý **3–4 loại Lẩu ngon nhất** hợp đúng số người & không khí (mô tả vị nước dùng + đồ nhúng/rau đặc trưng cho từng loại), chọn 1 set tiêu biểu nhất kèm định lượng đi chợ cho đúng số người đó!
2. Nếu người dùng muốn **đồ nướng / món nhậu / ăn sáng / ăn khuya / dùng nguyên liệu tủ lạnh**: gợi ý trực diện đúng thể loại đó (KHÔNG ép thành mâm cơm 3 món nếu họ muốn ăn lẩu/nướng/nhậu!).
3. **LUÔN CÓ mục gợi ý 🥤🍺 Đồ uống đi kèm cực hợp** (VD: trời mưa ăn lẩu hợp bia lạnh, trà tắc nóng/đá, nước mơ ngâm, trà gừng mật ong, rượu táo mèo nhẹ...; trời oi bức hợp nước sấu, trà chanh, nước mía...).

Trình bày gọn đẹp đúng 4 mục:
**1. 🍲 Gợi ý các lựa chọn món ngon nhất (đúng ý & đúng số người):**
**2. 🥤🍺 Đồ uống & Tráng miệng đi kèm cực hợp:**
**3. 🛒 Danh sách đi chợ (ghi rõ định lượng gram / lạng / bó & ước tính chi phí VNĐ):**
**4. 👩‍🍳 Bí quyết nấu / pha nước dùng & nước chấm ngon tròn vị:**`;

      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là đầu bếp & chuyên gia ẩm thực Việt Nam cực kỳ tâm lý, am hiểu từ cơm gia đình, lẩu, nướng, món nhậu đến đồ uống đi kèm. Luôn ưu tiên tuyệt đối câu yêu cầu tự nhiên của người dùng.',
        userPrompt: prompt,
        temperature: 0.6
      }, (p) => { if (p) q('#meal-ai-body').innerHTML = fmtMd(p); });
      lastAi = `🍲 Gợi ý món ăn${fridge ? `: ${fridge}` : ` (${mtLabel} • ${servingsText})`}\n\n${ans}`;
      q('#meal-ai-body').innerHTML = fmtMd(ans);
      q('#meal-status').textContent = '✅ Đã lên gợi ý món ngon & đồ uống kèm định lượng! Bấm 💬 Zalo gửi ngay cho người nhà nhé!';
    } catch (err) {
      q('#meal-status').className = 'sf-status err';
      q('#meal-status').textContent = `⚠️ ${err?.message || 'Lỗi AI'}`;
    } finally {
      busy = false;
      q('#btn-meal-ai').disabled = false;
    }
  });

  q('#btn-meal-copy')?.addEventListener('click', async () => { if (lastAi) { try { await navigator.clipboard.writeText(lastAi); } catch (_e) {} q('#meal-status').textContent = '✓ Đã sao chép thực đơn!'; } });
  q('#btn-meal-zalo')?.addEventListener('click', () => { if (lastAi) shareToZaloQuick(lastAi); });
  q('#btn-meal-tg')?.addEventListener('click', (e) => { if (lastAi && onSendTelegram) onSendTelegram(escHtml(lastAi), e.currentTarget); });

  spinMenu();
}
