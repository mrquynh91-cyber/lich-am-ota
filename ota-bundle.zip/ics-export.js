/**
 * Google Calendar & RFC-5545 .ICS Exporter
 * - Converts repeating Vietnamese Lunar events (Ngày giỗ, Sinh nhật Âm lịch) into exact Solar dates
 *   across the next 5 years so Google Calendar / Apple Calendar / OPPO Calendar remind you accurately!
 * - Exports Mùng 1 & Rằm (next 12 months) and Timed Reminders to .ICS
 * - Builds 1-click Google Calendar event URLs
 */

import { convertLunar2Solar, convertSolar2Lunar, jdFromDate, jdToDate, TIMEZONE_VN } from './lunar.js';

function pad2(n) {
  return String(n).padStart(2, '0');
}

function escapeIcsText(str) {
  return String(str || '')
    .replace(/\\/g, '\\\\')
    .replace(/\r?\n/g, '\\n')
    .replace(/,/g, '\\,')
    .replace(/;/g, '\\;');
}

function formatIcsDateOnly(y, m, d) {
  return `${y}${pad2(m)}${pad2(d)}`;
}

function nextSolarDate(y, m, d) {
  const dt = new Date(y, m - 1, d + 1);
  return { year: dt.getFullYear(), month: dt.getMonth() + 1, day: dt.getDate() };
}

function buildVEvent({ uid, summary, description, location = '', startDate, startTime = null, alarmDaysBefore = [0, 3] }) {
  const nowStamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  const lines = [
    'BEGIN:VEVENT',
    `UID:${uid}`,
    `DTSTAMP:${nowStamp}`,
    `SUMMARY:${escapeIcsText(summary)}`,
    `DESCRIPTION:${escapeIcsText(description)}`
  ];

  if (location) {
    lines.push(`LOCATION:${escapeIcsText(location)}`);
  }

  if (startTime) {
    const [hh, mm] = startTime.split(':').map(Number);
    const startDt = new Date(startDate.year, startDate.month - 1, startDate.day, hh || 8, mm || 0);
    const endDt = new Date(startDt.getTime() + 60 * 60 * 1000);
    const fmtLocal = (dt) =>
      `${dt.getFullYear()}${pad2(dt.getMonth() + 1)}${pad2(dt.getDate())}T${pad2(dt.getHours())}${pad2(dt.getMinutes())}00`;
    lines.push(`DTSTART;TZID=Asia/Ho_Chi_Minh:${fmtLocal(startDt)}`);
    lines.push(`DTEND;TZID=Asia/Ho_Chi_Minh:${fmtLocal(endDt)}`);
    lines.push('BEGIN:VALARM', 'ACTION:DISPLAY', 'TRIGGER:-PT15M', `DESCRIPTION:${escapeIcsText(summary)}`, 'END:VALARM');
  } else {
    const nxt = nextSolarDate(startDate.year, startDate.month, startDate.day);
    lines.push(`DTSTART;VALUE=DATE:${formatIcsDateOnly(startDate.year, startDate.month, startDate.day)}`);
    lines.push(`DTEND;VALUE=DATE:${formatIcsDateOnly(nxt.year, nxt.month, nxt.day)}`);
    for (const days of alarmDaysBefore) {
      const trigger = days === 0 ? 'PT8H' : `-P${days}DT16H`;
      lines.push(
        'BEGIN:VALARM',
        'ACTION:DISPLAY',
        `TRIGGER:${trigger}`,
        `DESCRIPTION:${escapeIcsText(days === 0 ? `Hôm nay: ${summary}` : `Còn ${days} ngày: ${summary}`)}`,
        'END:VALARM'
      );
    }
  }

  lines.push('END:VEVENT');
  return lines.join('\r\n');
}

function wrapVCalendar(eventsBlocks, calName = 'Lịch Âm Việt Nam') {
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//LichAmVietNam//DINH VAN QUYNH//VI',
    'CALSCALE:GREGORIAN',
    `X-WR-CALNAME:${escapeIcsText(calName)}`,
    'X-WR-TIMEZONE:Asia/Ho_Chi_Minh',
    ...eventsBlocks,
    'END:VCALENDAR'
  ].join('\r\n');
}

/**
 * Export personal Lunar/Solar Anniversaries (Ngày giỗ, Sinh nhật Âm lịch) for the next `yearsAhead` years
 */
export function buildAnniversariesIcs(customEvents = [], yearsAhead = 5) {
  const now = new Date();
  const baseYear = now.getFullYear();
  const blocks = [];

  for (const ev of customEvents) {
    const remindDays = Number(ev.remindBeforeDays) > 0 ? [0, Number(ev.remindBeforeDays)] : [0, 3, 7];
    const kindLabel = ev.kind === 'gio' ? '🕯 Ngày giỗ' : ev.kind === 'sinhnhat' ? '🎂 Sinh nhật' : '⭐ Sự kiện';

    for (let y = baseYear; y < baseYear + yearsAhead; y++) {
      let solar = null;
      if (ev.calendar === 'lunar') {
        solar = convertLunar2Solar(ev.day, ev.month, y, Boolean(ev.leap), TIMEZONE_VN);
        if (!solar && ev.day === 30) {
          solar = convertLunar2Solar(29, ev.month, y, Boolean(ev.leap), TIMEZONE_VN);
        }
      } else {
        solar = { day: ev.day, month: ev.month, year: y };
      }
      if (!solar) continue;

      let milestoneNote = '';
      if (ev.originYear && Number(ev.originYear) > 1900 && y >= Number(ev.originYear)) {
        const diff = y - Number(ev.originYear);
        if (ev.kind === 'gio' && diff > 0) milestoneNote = ` (Giỗ lần thứ ${diff})`;
        else if (ev.kind === 'sinhnhat' && diff > 0) milestoneNote = ` (Tròn ${diff} tuổi)`;
      }

      const calTag = ev.calendar === 'lunar' ? `${ev.day}/${ev.month}${ev.leap ? 'N' : ''} ÂL` : `${ev.day}/${ev.month} DL`;
      blocks.push(
        buildVEvent({
          uid: `licham-ev-${ev.id}-${y}@dinhvanquynh.vn`,
          summary: `${kindLabel}: ${ev.name}${milestoneNote}`,
          description: `${ev.name}${milestoneNote} — Ngày ${calTag}${ev.note ? `\nGhi chú: ${ev.note}` : ''}\n(Xuất từ Lịch Âm Việt Nam)`,
          startDate: solar,
          alarmDaysBefore: remindDays
        })
      );
    }
  }

  return wrapVCalendar(blocks, 'Ngày Giỗ & Sự kiện Âm lịch');
}

/**
 * Export Mùng 1 & Ngày Rằm for the next 365 days into .ICS
 */
export function buildMung1RamIcs(daysAhead = 365) {
  const now = new Date();
  const startJd = jdFromDate(now.getDate(), now.getMonth() + 1, now.getFullYear());
  const blocks = [];

  for (let i = 0; i <= daysAhead; i++) {
    const s = jdToDate(startJd + i);
    const l = convertSolar2Lunar(s.day, s.month, s.year, TIMEZONE_VN);
    if (l.day === 1 || l.day === 15) {
      const label = l.day === 1
        ? `🏮 Mùng 1 tháng ${l.month}${l.leap ? ' nhuận' : ''} Âm lịch`
        : `🌕 Ngày Rằm (15) tháng ${l.month}${l.leap ? ' nhuận' : ''} Âm lịch`;
      blocks.push(
        buildVEvent({
          uid: `licham-m1r-${s.year}${pad2(s.month)}${pad2(s.day)}@dinhvanquynh.vn`,
          summary: label,
          description: `${label} — Dương lịch: ${pad2(s.day)}/${pad2(s.month)}/${s.year}.`,
          startDate: s,
          alarmDaysBefore: [0, 1]
        })
      );
    }
  }

  return wrapVCalendar(blocks, 'Mùng 1 & Ngày Rằm — Lịch Âm VN');
}

/**
 * Export all active timed reminders into .ICS
 */
export function buildTimedRemindersIcs(timedReminders = []) {
  const blocks = [];
  for (const rem of timedReminders) {
    if (rem.done || !rem.date) continue;
    const [y, m, d] = rem.date.split('-').map(Number);
    if (!y || !m || !d) continue;
    blocks.push(
      buildVEvent({
        uid: `licham-rem-${rem.id}@dinhvanquynh.vn`,
        summary: rem.title,
        description: rem.note || 'Nhắc nhở từ Lịch Âm Việt Nam',
        startDate: { year: y, month: m, day: d },
        startTime: rem.time || '09:00'
      })
    );
  }
  return wrapVCalendar(blocks, 'Nhắc nhở — Lịch Âm VN');
}

/**
 * Build a 1-click Google Calendar event URL
 */
export function buildGoogleCalendarUrl({ title, details = '', location = '', dateObj, timeStr = null }) {
  const params = new URLSearchParams({ action: 'TEMPLATE', text: title });
  if (details) params.set('details', details);
  if (location) params.set('location', location);

  if (timeStr) {
    const [hh, mm] = timeStr.split(':').map(Number);
    const startDt = new Date(dateObj.year, dateObj.month - 1, dateObj.day, hh || 8, mm || 0);
    const endDt = new Date(startDt.getTime() + 60 * 60 * 1000);
    const fmt = (dt) =>
      `${dt.getFullYear()}${pad2(dt.getMonth() + 1)}${pad2(dt.getDate())}T${pad2(dt.getHours())}${pad2(dt.getMinutes())}00`;
    params.set('dates', `${fmt(startDt)}/${fmt(endDt)}`);
    params.set('ctz', 'Asia/Ho_Chi_Minh');
  } else {
    const nxt = nextSolarDate(dateObj.year, dateObj.month, dateObj.day);
    params.set(
      'dates',
      `${formatIcsDateOnly(dateObj.year, dateObj.month, dateObj.day)}/${formatIcsDateOnly(nxt.year, nxt.month, nxt.day)}`
    );
  }

  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

export function downloadIcsFile(icsContent, filename) {
  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
