/**
 * Shared helpers for:
 * 1. Water Drinking Reminder schedule (startTime..endTime, count times)
 * 2. Exact Date & Time Reminders (one-time & repeating)
 * 3. Smart Vietnamese NLP Quick-Input Parser
 */

import { convertSolar2Lunar, convertLunar2Solar, TIMEZONE_VN } from './lunar.js';

export const DEFAULT_WATER_SETTINGS = {
  enabled: false,
  startTime: '08:00',
  endTime: '21:00',
  count: 8,
  soundEnabled: true,
  volume: 0.85
};

export function pad2(n) {
  return String(n).padStart(2, '0');
}

export function formatDateKey(y, m, d) {
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

export function parseTimeToMinutes(timeStr) {
  if (!timeStr || typeof timeStr !== 'string') return 0;
  const [hStr, mStr] = timeStr.split(':');
  const h = Math.max(0, Math.min(23, Number(hStr) || 0));
  const m = Math.max(0, Math.min(59, Number(mStr) || 0));
  return h * 60 + m;
}

export function formatMinutesToTime(totalMinutes) {
  const clamped = Math.max(0, Math.min(23 * 60 + 59, Math.round(totalMinutes)));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${pad2(h)}:${pad2(m)}`;
}

/**
 * Compute evenly spaced water reminder slots between startTime and endTime.
 */
export function computeWaterSchedule(waterSettings = DEFAULT_WATER_SETTINGS) {
  const startMin = parseTimeToMinutes(waterSettings.startTime || '08:00');
  const endMin = parseTimeToMinutes(waterSettings.endTime || '21:00');
  const count = Math.max(1, Math.min(30, Math.round(Number(waterSettings.count) || 8)));

  if (endMin < startMin) {
    return { valid: false, slots: [], intervalMinutes: 0 };
  }

  const slots = [];
  if (count === 1 || endMin === startMin) {
    slots.push({
      index: 0,
      minutes: startMin,
      label: formatMinutesToTime(startMin)
    });
    return { valid: true, slots, intervalMinutes: 0 };
  }

  const span = endMin - startMin;
  const step = span / (count - 1);
  for (let i = 0; i < count; i++) {
    const mins = Math.round(startMin + step * i);
    slots.push({
      index: i,
      minutes: mins,
      label: formatMinutesToTime(mins)
    });
  }

  return {
    valid: true,
    slots,
    intervalMinutes: Math.round(step)
  };
}

/**
 * Get the next upcoming water reminder timestamp (ms) after `now`
 */
export function getNextWaterSlotTimestamp(waterSettings, now = new Date()) {
  const schedule = computeWaterSchedule(waterSettings);
  if (!schedule.valid || schedule.slots.length === 0) return null;

  const nowMs = now.getTime();
  const baseYear = now.getFullYear();
  const baseMonth = now.getMonth();
  const baseDate = now.getDate();

  for (const slot of schedule.slots) {
    const h = Math.floor(slot.minutes / 60);
    const m = slot.minutes % 60;
    const candidate = new Date(baseYear, baseMonth, baseDate, h, m, 0, 0);
    // Schedule if at least 5 seconds in the future
    if (candidate.getTime() > nowMs + 5000) {
      return {
        when: candidate.getTime(),
        slotIndex: slot.index,
        label: slot.label,
        totalSlots: schedule.slots.length
      };
    }
  }

  // Otherwise schedule first slot of tomorrow
  const first = schedule.slots[0];
  const tomorrow = new Date(
    baseYear,
    baseMonth,
    baseDate + 1,
    Math.floor(first.minutes / 60),
    first.minutes % 60,
    0,
    0
  );
  return {
    when: tomorrow.getTime(),
    slotIndex: first.index,
    label: first.label,
    totalSlots: schedule.slots.length
  };
}

/**
 * Parse a YYYY-MM-DD + HH:mm into a local JS Date
 */
export function parseReminderDateTime(dateStr, timeStr) {
  const [y, m, d] = (dateStr || '').split('-').map(Number);
  const [hh, mm] = (timeStr || '08:00').split(':').map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d, hh || 0, mm || 0, 0, 0);
}

/**
 * Compute next future trigger timestamp (ms) for a timed reminder
 */
export function getNextReminderTimestamp(reminder, nowMs = Date.now()) {
  if (!reminder || reminder.done) return null;
  const base = parseReminderDateTime(reminder.date, reminder.time);
  if (!base) return null;

  const repeat = reminder.repeat || 'none';
  if (repeat === 'none') {
    return base.getTime() > nowMs + 2000 ? base.getTime() : null;
  }

  // Lunar Monthly recurrence (e.g., Mùng 1, Rằm 15 every Lunar month)
  if (repeat === 'lunar-monthly') {
    const [ry, rm, rd] = reminder.date.split('-').map(Number);
    const [hh, mm] = (reminder.time || '08:00').split(':').map(Number);
    const baseLunar = convertSolar2Lunar(rd, rm, ry, TIMEZONE_VN);
    const nowDt = new Date(nowMs);
    const startDt = new Date(
      Math.max(
        new Date(ry, rm - 1, rd).getTime(),
        new Date(nowDt.getFullYear(), nowDt.getMonth(), nowDt.getDate()).getTime()
      )
    );
    for (let offset = 0; offset <= 65; offset++) {
      const probe = new Date(startDt.getFullYear(), startDt.getMonth(), startDt.getDate() + offset, hh || 0, mm || 0, 0, 0);
      if (probe.getTime() <= nowMs + 2000) continue;
      const pl = convertSolar2Lunar(probe.getDate(), probe.getMonth() + 1, probe.getFullYear(), TIMEZONE_VN);
      const dayMatch = pl.day === baseLunar.day || (baseLunar.day === 30 && pl.monthLength === 29 && pl.day === 29);
      if (dayMatch) return probe.getTime();
    }
    return null;
  }

  // Lunar Yearly recurrence (e.g., Ngày giỗ, Sinh nhật Âm lịch, 23 tháng Chạp)
  if (repeat === 'lunar-yearly') {
    const [ry, rm, rd] = reminder.date.split('-').map(Number);
    const [hh, mm] = (reminder.time || '08:00').split(':').map(Number);
    const baseLunar = convertSolar2Lunar(rd, rm, ry, TIMEZONE_VN);
    const nowDt = new Date(nowMs);
    const curLunar = convertSolar2Lunar(nowDt.getDate(), nowDt.getMonth() + 1, nowDt.getFullYear(), TIMEZONE_VN);
    const startLunarYear = Math.max(baseLunar.year, curLunar.year - 1);
    for (let ly = startLunarYear; ly <= startLunarYear + 4; ly++) {
      let s = convertLunar2Solar(baseLunar.day, baseLunar.month, ly, false, TIMEZONE_VN);
      if (!s && baseLunar.day === 30) {
        s = convertLunar2Solar(29, baseLunar.month, ly, false, TIMEZONE_VN);
      }
      if (!s) continue;
      const dt = new Date(s.year, s.month - 1, s.day, hh || 0, mm || 0, 0, 0);
      if (dt.getTime() > nowMs + 2000) return dt.getTime();
    }
    return null;
  }

  if (repeat === 'monthly') {
    const [ry, rm, rd] = reminder.date.split('-').map(Number);
    const [hh, mm] = (reminder.time || '08:00').split(':').map(Number);
    let cy = ry;
    let cm = rm - 1;
    let guard = 0;
    while (guard < 240) {
      const maxDay = new Date(cy, cm + 1, 0).getDate();
      const cand = new Date(cy, cm, Math.min(rd, maxDay), hh || 0, mm || 0, 0, 0);
      if (cand.getTime() > nowMs + 2000) return cand.getTime();
      cm++;
      if (cm > 11) {
        cm = 0;
        cy++;
      }
      guard++;
    }
    return null;
  }

  let candidate = new Date(base.getTime());
  let guard = 0;
  while (candidate.getTime() <= nowMs + 2000 && guard < 2000) {
    guard++;
    if (repeat === 'daily') {
      candidate.setDate(candidate.getDate() + 1);
    } else if (repeat === 'weekly') {
      candidate.setDate(candidate.getDate() + 7);
    } else if (repeat === 'yearly') {
      candidate.setFullYear(candidate.getFullYear() + 1);
    } else {
      return null;
    }
  }
  return candidate.getTime() > nowMs + 2000 ? candidate.getTime() : null;
}

/**
 * Check if a timed reminder applies to a specific solar date string (YYYY-MM-DD)
 */
export function doesReminderOccurOnDate(reminder, targetDateStr) {
  if (!reminder || !reminder.date || !targetDateStr) return false;
  if (reminder.date === targetDateStr) return true;

  const repeat = reminder.repeat || 'none';
  if (repeat === 'none') return false;

  const [ry, rm, rd] = reminder.date.split('-').map(Number);
  const [ty, tm, td] = targetDateStr.split('-').map(Number);
  const rDate = new Date(ry, rm - 1, rd);
  const tDate = new Date(ty, tm - 1, td);

  if (tDate < rDate) return false;
  if (repeat === 'daily') return true;
  if (repeat === 'weekly') return tDate.getDay() === rDate.getDay();
  if (repeat === 'monthly') {
    const lastDay = new Date(ty, tm, 0).getDate();
    return td === rd || (rd > lastDay && td === lastDay);
  }
  if (repeat === 'yearly') return tm === rm && td === rd;
  if (repeat === 'lunar-monthly' || repeat === 'lunar-yearly') {
    const rLunar = convertSolar2Lunar(rd, rm, ry, TIMEZONE_VN);
    const tLunar = convertSolar2Lunar(td, tm, ty, TIMEZONE_VN);
    const dayMatch = tLunar.day === rLunar.day || (rLunar.day === 30 && tLunar.monthLength === 29 && tLunar.day === 29);
    if (repeat === 'lunar-monthly') return dayMatch;
    return !tLunar.leap && tLunar.month === rLunar.month && dayMatch;
  }
  return false;
}

export const REPEAT_LABELS = {
  none: 'Một lần',
  daily: 'Hàng ngày',
  weekly: 'Hàng tuần',
  monthly: 'Hàng tháng (DL)',
  yearly: 'Hàng năm (DL)',
  'lunar-monthly': 'Hàng tháng (Âm lịch)',
  'lunar-yearly': 'Hàng năm (Âm lịch)'
};

export const HIGHLIGHT_COLORS = {
  yellow: { label: 'Vàng nổi bật', hex: '#FACC15' },
  blue: { label: 'Xanh dương', hex: '#38BDF8' },
  green: { label: 'Xanh lá', hex: '#34D399' },
  pink: { label: 'Hồng phấn', hex: '#F472B6' }
};

/**
 * Check whether a YYYY-MM-DD date string falls within a highlighted range [startDate, endDate]
 */
export function getHighlightsForDate(dateKey, highlightedRanges = []) {
  if (!dateKey || !Array.isArray(highlightedRanges)) return [];
  return highlightedRanges.filter((h) => {
    if (!h || !h.startDate) return false;
    const end = h.endDate || h.startDate;
    return dateKey >= h.startDate && dateKey <= end;
  });
}

/**
 * Legacy seed IDs — cleaned up once so no browser/user ever has hardcoded flight data
 */
export const LEGACY_SEED_HIGHLIGHT_ID = 'hl-uzxn8g-20261215';
export const LEGACY_SEED_REMINDER_PREFIX = 'rem-uzxn8g-';

const MONTH_MAP = {
  jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6,
  jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12
};

const AIRLINE_PREFIX = {
  VJ: 'VietJet Air',
  VN: 'Vietnam Airlines',
  QH: 'Bamboo Airways',
  VU: 'Vietravel Airlines',
  BL: 'Pacific Airlines',
  '9G': 'Sun PhuQuoc Airways',
  AK: 'AirAsia',
  FD: 'Thai AirAsia',
  D7: 'AirAsia X',
  SQ: 'Singapore Airlines',
  TR: 'Scoot',
  KE: 'Korean Air',
  OZ: 'Asiana Airlines',
  TW: "T'way Air",
  LJ: 'Jin Air',
  '7C': 'Jeju Air',
  BR: 'EVA Air',
  CI: 'China Airlines',
  JX: 'STARLUX',
  JL: 'Japan Airlines',
  NH: 'ANA',
  CX: 'Cathay Pacific',
  TG: 'Thai Airways',
  VZ: 'Thai VietJet',
  MH: 'Malaysia Airlines',
  OD: 'Batik Air',
  EK: 'Emirates',
  QR: 'Qatar Airways',
  PR: 'Philippine Airlines',
  '5J': 'Cebu Pacific',
  CZ: 'China Southern',
  MU: 'China Eastern',
  CA: 'Air China'
};

// Common 2-letter words/abbreviations that are NOT airline flight prefixes
const NON_AIRLINE_PREFIXES = new Set([
  'ID', 'NO', 'PM', 'AM', 'SO', 'IN', 'TO', 'AT', 'ON', 'BY', 'OF', 'OR',
  'IS', 'IT', 'MY', 'US', 'UK', 'EU', 'GB', 'MB', 'KB', 'PX', 'PT', 'KG',
  'KM', 'CM', 'MM', 'HR', 'TH', 'ST', 'ND', 'RD', 'AD', 'BC', 'PO', 'CO',
  'VN0', 'T1', 'T2', 'T3', 'B1', 'B2', 'G1', 'A1', 'E1', 'OK', 'RE', 'FW'
]);

const KNOWN_AIRPORTS = new Set([
  'SGN', 'HAN', 'DAD', 'HPH', 'CXR', 'PQC', 'VII', 'HUI', 'VCA', 'DLI',
  'BMV', 'UIH', 'VCL', 'THD', 'VDO', 'VDH', 'DIN', 'TBB', 'PXU', 'VKG',
  'CAH', 'VCS', 'SIN', 'BKK', 'DMK', 'KUL', 'ICN', 'GMP', 'PUS', 'NRT',
  'HND', 'KIX', 'TPE', 'KHH', 'HKG', 'MFM', 'MNL', 'CGK', 'DPS', 'SYD',
  'MEL', 'DXB', 'DOH', 'LHR', 'CDG', 'FRA', 'LAX', 'SFO', 'CAN', 'PVG', 'PEK'
]);

/**
 * Parse a date from Vietnamese or English formats inside a text snippet.
 * Returns { dateKey: 'YYYY-MM-DD', index } or null.
 */
function extractDateFromSnippet(snippet) {
  const candidates = [];

  // 1. ISO: 2026-12-15
  for (const m of snippet.matchAll(/\b(20\d{2})-(0?[1-9]|1[0-2])-(0?[1-9]|[12]\d|3[01])\b/g)) {
    candidates.push({ index: m.index, dateKey: formatDateKey(Number(m[1]), Number(m[2]), Number(m[3])) });
  }
  // 2. English: Dec 15, 2026 / December 15 2026
  for (const m of snippet.matchAll(/\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2}),?\s+(20\d{2})\b/gi)) {
    const mon = MONTH_MAP[m[1].slice(0, 3).toLowerCase()];
    const d = Number(m[2]);
    if (mon && d >= 1 && d <= 31) {
      candidates.push({ index: m.index, dateKey: formatDateKey(Number(m[3]), mon, d) });
    }
  }
  // 3. English: 15 Dec 2026 / 15DEC26 / 15-Dec-2026
  for (const m of snippet.matchAll(/\b(\d{1,2})[\s\-]?(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[\s\-,]*(20\d{2}|\d{2})\b/gi)) {
    const mon = MONTH_MAP[m[2].slice(0, 3).toLowerCase()];
    const d = Number(m[1]);
    const y = m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3]);
    if (mon && d >= 1 && d <= 31 && y >= 2020 && y <= 2099) {
      candidates.push({ index: m.index, dateKey: formatDateKey(y, mon, d) });
    }
  }
  // 4. Vietnamese: 15 tháng 12 năm 2026 / 15 Thg 12, 2026 / 15 Th12 2026
  for (const m of snippet.matchAll(/\b(\d{1,2})\s*(?:tháng|thg|th)\.?\s*(\d{1,2})(?:[\s,]*(?:năm\s*)?(20\d{2}))?\b/gi)) {
    const d = Number(m[1]);
    const mon = Number(m[2]);
    const y = m[3] ? Number(m[3]) : new Date().getFullYear();
    if (mon >= 1 && mon <= 12 && d >= 1 && d <= 31) {
      candidates.push({ index: m.index, dateKey: formatDateKey(y, mon, d) });
    }
  }
  // 5. Numeric DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
  for (const m of snippet.matchAll(/\b(0?[1-9]|[12]\d|3[01])[\/\-\.](0?[1-9]|1[0-2])[\/\-\.](20\d{2})\b/g)) {
    candidates.push({ index: m.index, dateKey: formatDateKey(Number(m[3]), Number(m[2]), Number(m[1])) });
  }
  // 6. Short Vietnamese date without year: "ngày 25/11", "thứ 4, 25/11", "25/11 lúc"
  if (candidates.length === 0) {
    const nowYear = new Date().getFullYear();
    for (const m of snippet.matchAll(/(?:ngày|thứ\s*[2-7]|chủ\s*nhật|hôm\s*nay|vào)\s*,?\s*(0?[1-9]|[12]\d|3[01])[\/\-](0?[1-9]|1[0-2])\b(?!\s*[\/\-]\s*\d{2,4})/gi)) {
      candidates.push({ index: m.index, dateKey: formatDateKey(nowYear, Number(m[2]), Number(m[1])) });
    }
  }

  return candidates;
}

/**
 * Parse Schema.org FlightReservation JSON-LD blocks (embedded in Vietnam Airlines, Traveloka, Agoda, Trip.com, international airlines)
 */
function parseJsonLdFlights(jsonLdBlocks = []) {
  const legs = [];
  let pnr = '';
  const seen = new Set();

  function visit(node) {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }

    const type = String(node['@type'] || '');
    if (type.includes('FlightReservation')) {
      if (node.reservationNumber && !pnr) {
        pnr = String(node.reservationNumber).trim().toUpperCase();
      }
      const fl = node.reservationFor;
      if (fl && typeof fl === 'object') {
        const airlineCode = fl.airline?.iataCode || '';
        const flightNumRaw = String(fl.flightNumber || '').trim();
        const flightNo = flightNumRaw.match(/^[A-Z0-9]{2}\d+$/i)
          ? flightNumRaw.toUpperCase()
          : `${airlineCode}${flightNumRaw}`.toUpperCase();

        const depIso = String(fl.departureTime || '');
        const arrIso = String(fl.arrivalTime || '');
        const depMatch = depIso.match(/(20\d{2})-(\d{2})-(\d{2})[T\s](\d{2}):(\d{2})/);
        const arrMatch = arrIso.match(/(\d{2}):(\d{2})/);

        if (depMatch) {
          const date = `${depMatch[1]}-${depMatch[2]}-${depMatch[3]}`;
          const depTime = `${depMatch[4]}:${depMatch[5]}`;
          const arrTime = arrMatch ? `${arrMatch[1]}:${arrMatch[2]}` : '';
          const depPort = fl.departureAirport?.iataCode || fl.departureAirport?.name || '';
          const arrPort = fl.arrivalAirport?.iataCode || fl.arrivalAirport?.name || '';
          const route = depPort && arrPort ? `${depPort} → ${arrPort}` : '';
          const airline = fl.airline?.name || AIRLINE_PREFIX[airlineCode.toUpperCase()] || '';

          const key = `${flightNo}-${date}-${depTime}`;
          if (!seen.has(key)) {
            seen.add(key);
            legs.push({ flightNo: flightNo || 'FLIGHT', airline, date, depTime, arrTime, route });
          }
        }
      }
    }

    for (const val of Object.values(node)) {
      if (val && typeof val === 'object') visit(val);
    }
  }

  for (const raw of jsonLdBlocks) {
    try {
      const obj = typeof raw === 'string' ? JSON.parse(raw) : raw;
      visit(obj);
    } catch (_e) {
      // Ignore malformed JSON-LD
    }
  }

  return { pnr, legs };
}

/**
 * Universal flight ticket parser:
 * 1) Schema.org JSON-LD FlightReservation (used by Vietnam Airlines, Traveloka, Agoda, Trip.com, international airlines)
 * 2) Universal IATA flight numbers (VJ, VN, QH, VU, BL, SQ, KE, AK, etc.) + bidirectional date/time/route extraction
 * 3) Fallback Airport IATA pair (e.g. SGN -> HAN) + date/time extraction
 */
export function parseFlightText(rawText, jsonLdBlocks = []) {
  // Strategy 1: JSON-LD structured flight data
  const fromLd = parseJsonLdFlights(jsonLdBlocks);

  const text = String(rawText || '').replace(/\s+/g, ' ').trim();

  // Extract 6-char PNR booking code
  let pnr = fromLd.pnr || '';
  if (!pnr) {
    const pnrPatterns = [
      /(?:RESERVATION\s*#|Mã đặt chỗ|Mã chỗ|Booking\s*(?:code|ref(?:erence)?|ID)|Confirmation\s*(?:code|number)?|PNR|Record\s*locator)[\s:#\-]*([A-Z0-9]{6})\b/i,
      /\b(?:Vietjet|Vietnam\s*Airlines|Bamboo|Vietravel)\s+([A-Z0-9]{6})\b/i
    ];
    for (const re of pnrPatterns) {
      const pm = text.match(re);
      if (pm && /[A-Z]/i.test(pm[1]) && !/^(FLIGHT|TICKET|BOOKED|ONLINE|STATUS|NUMBER|TRAVEL|DETAIL)$/i.test(pm[1])) {
        pnr = pm[1].toUpperCase();
        break;
      }
    }
  }

  const legs = [...fromLd.legs];
  const seen = new Set(legs.map((l) => `${l.flightNo}-${l.date}-${l.depTime}`));

  // Strategy 2: Universal IATA flight numbers (2-char carrier code + 2..4 digits)
  // Matches known prefixes OR uppercase 2-letter/alphanumeric carrier + space? + 2..4 digits
  const flightRegex = /\b([A-Z]{2}|[0-9][A-Z]|[A-Z][0-9])\s?(\d{2,4})\b/g;
  let m;

  while ((m = flightRegex.exec(text)) !== null) {
    const prefix = m[1].toUpperCase();
    const num = m[2];
    if (NON_AIRLINE_PREFIXES.has(prefix)) continue;

    // For unknown prefixes (not in AIRLINE_PREFIX), require flight-context keywords nearby
    const isKnownCarrier = Boolean(AIRLINE_PREFIX[prefix]);
    const beforeStart = Math.max(0, m.index - 150);
    const afterEnd = Math.min(text.length, m.index + 280);
    const aroundText = text.slice(beforeStart, afterEnd);
    const afterText = text.slice(m.index, afterEnd);

    if (!isKnownCarrier) {
      const hasFlightContext = /(?:flight|chuyến bay|khởi hành|depart|boarding|terminal|sân bay|airport|eco|economy|business|airlines|airways)/i.test(aroundText);
      if (!hasFlightContext) continue;
      // Avoid matching years like "IN 2026" or prices
      if (num.length === 4 && (num.startsWith('19') || num.startsWith('20'))) continue;
    }

    // Find closest date: prefer dates AFTER flightNo within 180 chars, else closest BEFORE flightNo
    const afterDates = extractDateFromSnippet(afterText.slice(0, 180));
    let dateKey = afterDates.length > 0 ? afterDates[0].dateKey : null;
    if (!dateKey) {
      const beforeSlice = text.slice(beforeStart, m.index);
      const beforeDates = extractDateFromSnippet(beforeSlice);
      if (beforeDates.length > 0) {
        dateKey = beforeDates[beforeDates.length - 1].dateKey;
      }
    }
    if (!dateKey) continue;

    // Extract departure & arrival times (prefer after flightNo, fallback around)
    let timeMatches = [...afterText.slice(0, 240).matchAll(/\b([01]?\d|2[0-3]):([0-5]\d)\b/g)];
    let timeBaseText = afterText.slice(0, 240);
    if (timeMatches.length === 0) {
      timeMatches = [...aroundText.matchAll(/\b([01]?\d|2[0-3]):([0-5]\d)\b/g)];
      timeBaseText = aroundText;
    }
    if (timeMatches.length === 0) continue;

    const depTime = `${pad2(Number(timeMatches[0][1]))}:${timeMatches[0][2]}`;
    const arrTime = timeMatches[1] ? `${pad2(Number(timeMatches[1][1]))}:${timeMatches[1][2]}` : '';

    // Try to extract route
    let route = '';
    const iataPair = aroundText.match(/\b([A-Z]{3})\s*(?:[-–→>]|to|đến)\s*([A-Z]{3})\b/);
    if (iataPair && KNOWN_AIRPORTS.has(iataPair[1]) && KNOWN_AIRPORTS.has(iataPair[2])) {
      route = `${iataPair[1]} → ${iataPair[2]}`;
    } else if (timeMatches[0] && timeMatches[1]) {
      const afterDep = timeBaseText
        .slice(timeMatches[0].index + timeMatches[0][0].length, timeMatches[1].index)
        .replace(/^[\s\-–:|]+/, '')
        .replace(/\s+/g, ' ')
        .trim();
      const afterArrRaw = timeBaseText
        .slice(timeMatches[1].index + timeMatches[1][0].length, timeMatches[1].index + timeMatches[1][0].length + 45)
        .replace(/^[\s\-–:|]+/, '');
      const afterArr = afterArrRaw
        .split(/\b(?:[A-Z]{2}\s?\d{2,4})\b|Email|Tax|Booking|Note|Lưu ý|Tổng|Total/i)[0]
        .replace(/\s+/g, ' ')
        .trim();

      if (afterDep && afterArr && afterDep.length <= 40 && afterArr.length <= 40) {
        route = `${afterDep} → ${afterArr}`;
      }
    }

    const flightNo = `${prefix}${num}`;
    const key = `${flightNo}-${dateKey}-${depTime}`;
    if (!seen.has(key)) {
      seen.add(key);
      legs.push({
        flightNo,
        airline: AIRLINE_PREFIX[prefix] || prefix,
        date: dateKey,
        depTime,
        arrTime,
        route
      });
    }
  }

  // Strategy 3: Fallback if email has NO flight number, only airport IATA pairs (e.g. SGN -> HAN) + date + time
  if (legs.length === 0) {
    const pairRegex = /\b([A-Z]{3})\s*(?:[-–→>]|to|đến)\s*([A-Z]{3})\b/g;
    let pm;
    while ((pm = pairRegex.exec(text)) !== null) {
      if (!KNOWN_AIRPORTS.has(pm[1]) || !KNOWN_AIRPORTS.has(pm[2])) continue;
      const around = text.slice(Math.max(0, pm.index - 140), Math.min(text.length, pm.index + 220));
      const dates = extractDateFromSnippet(around);
      const times = [...around.matchAll(/\b([01]?\d|2[0-3]):([0-5]\d)\b/g)];
      if (dates.length > 0 && times.length > 0) {
        const dateKey = dates[0].dateKey;
        const depTime = `${pad2(Number(times[0][1]))}:${times[0][2]}`;
        const arrTime = times[1] ? `${pad2(Number(times[1][1]))}:${times[1][2]}` : '';
        const route = `${pm[1]} → ${pm[2]}`;
        const key = `${route}-${dateKey}-${depTime}`;
        if (!seen.has(key)) {
          seen.add(key);
          legs.push({ flightNo: `${pm[1]}-${pm[2]}`, airline: '', date: dateKey, depTime, arrTime, route });
        }
      }
    }
  }

  legs.sort((a, b) => `${a.date} ${a.depTime}`.localeCompare(`${b.date} ${b.depTime}`));
  return { pnr, legs };
}

/**
 * Parse iCalendar (.ics) content (DTSTART, DTEND, SUMMARY, LOCATION, DESCRIPTION)
 */
export function parseIcsText(icsText) {
  const unfolded = String(icsText || '').replace(/\r?\n[ \t]/g, '');
  const events = [];
  const blocks = unfolded.match(/BEGIN:VEVENT[\s\S]*?END:VEVENT/gi) || [];

  function parseIcsDateTime(rawLine) {
    const val = (rawLine.split(':').slice(1).join(':') || '').trim();
    const m = val.match(/^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?(Z)?)?/);
    if (!m) return null;
    let y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
    let hh = m[4] !== undefined ? Number(m[4]) : 9;
    let mm = m[5] !== undefined ? Number(m[5]) : 0;

    if (m[7] === 'Z') {
      const utc = new Date(Date.UTC(y, mo - 1, d, hh, mm, 0));
      // Convert UTC to local browser time (Vietnam GMT+7)
      y = utc.getFullYear();
      mo = utc.getMonth() + 1;
      d = utc.getDate();
      hh = utc.getHours();
      mm = utc.getMinutes();
    }
    return {
      date: formatDateKey(y, mo, d),
      time: `${pad2(hh)}:${pad2(mm)}`
    };
  }

  for (const block of blocks) {
    if (/STATUS\s*:\s*CANCELLED/i.test(block)) continue;
    const summaryM = block.match(/^SUMMARY(?:;[^:]*)?:(.*)$/im);
    const startM = block.match(/^DTSTART(?:;[^:]*)?:(.*)$/im);
    const endM = block.match(/^DTEND(?:;[^:]*)?:(.*)$/im);
    const locM = block.match(/^LOCATION(?:;[^:]*)?:(.*)$/im);
    const descM = block.match(/^DESCRIPTION(?:;[^:]*)?:(.*)$/im);

    const start = startM ? parseIcsDateTime(startM[0]) : null;
    if (!start) continue;
    const end = endM ? parseIcsDateTime(endM[0]) : null;

    const cleanIcsStr = (s) => (s || '').replace(/\\n/g, ' ').replace(/\\,/g, ',').replace(/\\;/g, ';').trim();
    const title = cleanIcsStr(summaryM?.[1]) || 'Lịch hẹn / Cuộc họp';
    let location = cleanIcsStr(locM?.[1]);
    const desc = cleanIcsStr(descM?.[1]);

    if (!location && desc) {
      const meetM = desc.match(/https?:\/\/(?:meet\.google\.com|zoom\.us|teams\.microsoft\.com)[^\s<>"')]+/i);
      if (meetM) location = meetM[0];
    }

    events.push({
      kind: 'event',
      title,
      date: start.date,
      time: start.time,
      endTime: end ? end.time : '',
      location,
      note: location ? `Địa điểm / Link: ${location}` : desc.slice(0, 140)
    });
  }
  return events;
}

/**
 * Parse time string including 24h ("15:15", "9h30", "14h"), 12h ("3:15 pm", "9:00 AM"),
 * and Vietnamese ("15 giờ 30", "9 giờ sáng", "3 giờ chiều")
 */
function parseTimeMatches(text) {
  const found = [];
  // 12h format: 3:15pm / 3:15 PM / 9 AM
  for (const m of text.matchAll(/\b(1[0-2]|0?[1-9])(?::([0-5]\d))?\s*(am|pm)\b/gi)) {
    let h = Number(m[1]);
    const min = Number(m[2] || 0);
    const ampm = m[3].toLowerCase();
    if (ampm === 'pm' && h < 12) h += 12;
    if (ampm === 'am' && h === 12) h = 0;
    found.push({ index: m.index, time: `${pad2(h)}:${pad2(min)}` });
  }
  // 24h format: 15:15 or 15h15 or 9h30
  for (const m of text.matchAll(/\b([01]?\d|2[0-3])[:h]([0-5]\d)\b/gi)) {
    if (found.some((f) => Math.abs(f.index - m.index) <= 1)) continue;
    found.push({ index: m.index, time: `${pad2(Number(m[1]))}:${m[2]}` });
  }
  // Vietnamese "15 giờ 30", "3 giờ chiều", "9 giờ sáng"
  for (const m of text.matchAll(/\b([01]?\d|2[0-3])\s*giờ(?:\s*([0-5]\d))?(?:\s*(sáng|trưa|chiều|tối))?/gi)) {
    if (found.some((f) => Math.abs(f.index - m.index) <= 2)) continue;
    let h = Number(m[1]);
    const min = Number(m[2] || 0);
    const period = (m[3] || '').toLowerCase();
    if ((period === 'chiều' || period === 'tối') && h >= 1 && h <= 11) h += 12;
    found.push({ index: m.index, time: `${pad2(h)}:${pad2(min)}` });
  }
  // Short "9h" or "14h" preceded by "lúc" / "từ" / "vào" / "-"
  for (const m of text.matchAll(/(?:lúc|từ|vào|đến|[-–])\s*([01]?\d|2[0-3])h\b(?!\d)/gi)) {
    const idx = m.index;
    if (found.some((f) => Math.abs(f.index - idx) <= 3)) continue;
    found.push({ index: idx, time: `${pad2(Number(m[1]))}:00` });
  }
  found.sort((a, b) => a.index - b.index);
  return found;
}

/**
 * Parse Schema.org Event JSON-LD blocks
 */
function parseJsonLdEvents(jsonLdBlocks = []) {
  const events = [];
  function visit(node) {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }
    const type = String(node['@type'] || '');
    if ((type === 'Event' || type.includes('EventReservation')) && !type.includes('Flight')) {
      const target = node.reservationFor || node;
      const startIso = String(target.startDate || '');
      const m = startIso.match(/(20\d{2})-(\d{2})-(\d{2})(?:[T\s](\d{2}):(\d{2}))?/);
      if (m) {
        const endIso = String(target.endDate || '');
        const em = endIso.match(/[T\s](\d{2}):(\d{2})/);
        const loc = typeof target.location === 'string'
          ? target.location
          : (target.location?.name || target.location?.address?.streetAddress || target.location?.url || '');
        events.push({
          kind: 'event',
          title: String(target.name || 'Sự kiện').trim(),
          date: `${m[1]}-${m[2]}-${m[3]}`,
          time: m[4] ? `${m[4]}:${m[5]}` : '09:00',
          endTime: em ? `${em[1]}:${em[2]}` : '',
          location: String(loc || '').trim(),
          note: loc ? `Địa điểm: ${loc}` : ''
        });
      }
    }
    for (const v of Object.values(node)) {
      if (v && typeof v === 'object') visit(v);
    }
  }
  for (const raw of jsonLdBlocks) {
    try {
      visit(typeof raw === 'string' ? JSON.parse(raw) : raw);
    } catch (_e) {}
  }
  return events;
}

/**
 * Universal parser for ANY Meeting / Google Calendar Invite / Appointment / Event with Date + Time + Location/Link
 */
export function parseMeetingOrEventText(subject = '', bodyText = '', jsonLdBlocks = [], icsTexts = []) {
  const cleanSubject = String(subject || '').replace(/\s+/g, ' ').trim();
  const cleanBody = String(bodyText || '').trim();

  // Skip canceled events or pure newsletters/bank alerts
  if (/^(?:đã hủy|canceled|cancelled)\b/i.test(cleanSubject)) return [];
  if (/\[qc\]|\(qc\)|sao ke|giao dich thanh cong|khuyến mãi|siêu sale|bản tin thị trường/i.test(cleanSubject)) return [];

  // 1. Prefer exact .ics attachments if present
  const fromIcs = [];
  for (const ics of icsTexts) {
    fromIcs.push(...parseIcsText(ics));
  }
  if (fromIcs.length > 0) return fromIcs;

  // 2. Next check Schema.org Event JSON-LD
  const fromLd = parseJsonLdEvents(jsonLdBlocks);
  if (fromLd.length > 0) return fromLd;

  const combined = `${cleanSubject}\n${cleanBody}`;

  // Extract meeting link (Google Meet, Zoom, Microsoft Teams)
  const linkMatch = combined.match(/https?:\/\/(?:meet\.google\.com\/[a-z0-9\-]+|[\w.-]*zoom\.us\/j\/\d+[^\s<>"')]*|teams\.microsoft\.com\/l\/meetup-join[^\s<>"')]*)/i);
  const meetingLink = linkMatch ? linkMatch[0] : '';

  // Extract explicit physical location ("Địa điểm:", "Tại:", "Địa chỉ:", "Location:", "Where:", "Venue:", "Phòng họp:")
  let location = '';
  const locLineMatch = cleanBody.match(/(?:Địa điểm|Địa chỉ|Tại|Nơi tổ chức|Phòng họp|Khách sạn|Nhà hàng|Phòng khám|Bệnh viện|Location|Where|Venue|Address)\s*[:：]\s*([^\n\r]{3,110})/i);
  if (locLineMatch) {
    location = locLineMatch[1].trim();
  }
  if (!location && meetingLink) {
    if (/meet\.google\.com/i.test(meetingLink)) location = `Google Meet (${meetingLink})`;
    else if (/zoom\.us/i.test(meetingLink)) location = `Zoom (${meetingLink})`;
    else if (/teams\.microsoft\.com/i.test(meetingLink)) location = `MS Teams (${meetingLink})`;
    else location = meetingLink;
  }

  // Extract organizer / host ("Người thực hiện:", "Người tổ chức:", "Organizer:")
  let organizer = '';
  const orgMatch = cleanBody.match(/(?:Người thực hiện|Người tổ chức|Chủ trì|Organizer|Host)\s*[:：\t ]+\s*([^\n\r]{2,60})/i);
  if (orgMatch) {
    organizer = orgMatch[1].replace(/\*+$/, '').trim();
  }

  const buildEventNote = (startT, endT) => [
    endT ? `Khung giờ: ${startT} – ${endT}` : `Giờ: ${startT}`,
    organizer ? `Người thực hiện: ${organizer}` : '',
    location ? `Địa điểm / Link: ${location}` : ''
  ].filter(Boolean).join(' • ');

  // 3. Google Calendar / Outlook invite subject pattern:
  // "Lời mời ...: <Title> @ thứ 4, 11 Tháng 11, 2026 15:15 - 16:15 (GMT+7)"
  // "Invitation: <Title> @ Wed Nov 11, 2026 3:15pm - 4:15pm"
  const inviteAtMatch = cleanSubject.match(/^(?:(?:Lời mời[^:]*|Invitation|Updated invitation[^:]*|Re|Fwd)\s*:\s*)+(.+?)\s*@\s*(.+)$/i);
  if (inviteAtMatch) {
    const title = inviteAtMatch[1].trim().replace(/\.$/, '');
    const whenPart = inviteAtMatch[2];
    const dates = extractDateFromSnippet(whenPart);
    const times = parseTimeMatches(whenPart);
    if (dates.length > 0 && times.length > 0) {
      return [{
        kind: 'event',
        title,
        date: dates[0].dateKey,
        time: times[0].time,
        endTime: times[1] ? times[1].time : '',
        location,
        organizer,
        note: buildEventNote(times[0].time, times[1] ? times[1].time : '')
      }];
    }
  }

  // 4. General Email with Date + Time + (Location OR Meeting Link OR Broad Appointment/Booking/Event Signal)
  const hasScheduleSignal = Boolean(
    location ||
    meetingLink ||
    organizer ||
    /(?:lịch họp|cuộc họp|lời mời|hẹn gặp|lịch hẹn|xác nhận đặt|đặt bàn|đặt phòng|nhận phòng|khám bệnh|nha khoa|phỏng vấn|tư vấn|hội thảo|sự kiện|chương trình|lịch học|khai giảng|bảo dưỡng|giao hàng|hạn chót|thời gian|consultation|meeting|appointment|booking|reservation|check-in|interview|webinar|workshop|event|calendar|google ads|google meet|zoom|teams|địa điểm)/i.test(combined)
  );
  if (!hasScheduleSignal) return [];

  // Search body lines first for a line or adjacent pair containing BOTH a date and a time
  const lines = cleanBody.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  let matchedDate = null;
  let matchedStartTime = null;
  let matchedEndTime = '';

  // Priority pass: lines explicitly labeled "Thời gian", "Ngày giờ", "When", "Date", "Time", "Check-in"
  for (let i = 0; i < lines.length; i++) {
    if (!/(?:thời gian|ngày giờ|khi nào|lịch hẹn|nhận phòng|khởi hành|when|date\s*&?\s*time|start|check-in)/i.test(lines[i])) continue;
    const chunk = i + 1 < lines.length ? `${lines[i]} ${lines[i + 1]}` : lines[i];
    const dates = extractDateFromSnippet(chunk);
    const times = parseTimeMatches(chunk);
    if (dates.length > 0 && times.length > 0) {
      matchedDate = dates[0].dateKey;
      matchedStartTime = times[0].time;
      matchedEndTime = times[1] ? times[1].time : '';
      break;
    }
  }

  if (!matchedDate || !matchedStartTime) {
    for (let i = 0; i < lines.length; i++) {
      const chunk = i + 1 < lines.length ? `${lines[i]} ${lines[i + 1]}` : lines[i];
      if (/^(?:From|To|Sent|Date|Cc|Bcc|Ngày gửi|Ngày đặt)\s*:/i.test(lines[i])) continue;
      const dates = extractDateFromSnippet(chunk);
      const times = parseTimeMatches(chunk);
      if (dates.length > 0 && times.length > 0) {
        matchedDate = dates[0].dateKey;
        matchedStartTime = times[0].time;
        matchedEndTime = times[1] ? times[1].time : '';
        break;
      }
    }
  }

  // Fallback: look across combined subject + first 1400 chars of body
  if (!matchedDate || !matchedStartTime) {
    const head = `${cleanSubject} ${cleanBody.slice(0, 1400)}`;
    const dates = extractDateFromSnippet(head);
    const times = parseTimeMatches(head);
    if (dates.length > 0 && times.length > 0) {
      matchedDate = dates[0].dateKey;
      matchedStartTime = times[0].time;
      matchedEndTime = times[1] ? times[1].time : '';
    }
  }

  if (!matchedDate || !matchedStartTime) return [];

  let cleanTitle = cleanSubject
    .replace(/^(?:(?:Re|Fwd|Fw|Lời mời[^:]*|Invitation|Updated invitation[^:]*)\s*:\s*)+/i, '')
    .replace(/\s*@.*$/, '')
    .trim();
  if (!cleanTitle) cleanTitle = 'Lịch hẹn từ Gmail';

  return [{
    kind: 'event',
    title: cleanTitle.slice(0, 90),
    date: matchedDate,
    time: matchedStartTime,
    endTime: matchedEndTime,
    location,
    organizer,
    note: buildEventNote(matchedStartTime, matchedEndTime)
  }];
}

/**
 * Smart Vietnamese Natural-Language Reminder Parser (NLP)
 * Examples:
 *  - "Họp Lê Sơn 9h30 sáng mai"
 *  - "Đưa con đi khám 3h chiều thứ 6 tại BV Nhi"
 *  - "Cúng rằm 7h sáng 15/10 âm"
 *  - "Bay Sài Gòn 16:45 ngày 28/11"
 *  - "Gọi khách hàng 20h tối nay"
 */
export function parseVietnameseNlpReminder(rawInput, refDate = new Date()) {
  const original = String(rawInput || '').normalize('NFC').replace(/[\u00A0\u200B]+/g, ' ').trim();
  if (original.length < 3) return null;

  let working = ` ${original} `;
  let targetDate = new Date(refDate.getFullYear(), refDate.getMonth(), refDate.getDate());
  let dateMatched = false;
  let isLunarSource = false;
  let lunarNote = '';

  // Normalize spoken Vietnamese weekdays & spoken hours/counts (crucial for Voice-to-Text!)
  const vnWeekdayWords = [
    ['hai', '2'],
    ['ba', '3'],
    ['tư', '4'],
    ['bốn', '4'],
    ['năm', '5'],
    ['sáu', '6'],
    ['bảy', '7'],
    ['bẩy', '7']
  ];
  for (const [word, digit] of vnWeekdayWords) {
    working = working.replace(
      new RegExp(`(?<=^|[\\s,.;:])thứ\\s+${word}(?=$|[\\s,.;:])`, 'gi'),
      `thứ ${digit}`
    );
  }

  const vnSpokenNums = [
    ['hai mươi ba', '23'], ['hai ba', '23'],
    ['hai mươi hai', '22'], ['hai hai', '22'],
    ['hai mươi mốt', '21'], ['hai mốt', '21'],
    ['hai mươi', '20'],
    ['mười chín', '19'], ['mười tám', '18'], ['mười bảy', '17'], ['mười bẩy', '17'],
    ['mười sáu', '16'], ['mười lăm', '15'], ['mười bốn', '14'], ['mười ba', '13'],
    ['mười hai', '12'], ['mười một', '11'], ['mười', '10'],
    ['chín', '9'], ['tám', '8'], ['bảy', '7'], ['bẩy', '7'],
    ['sáu', '6'], ['năm', '5'], ['bốn', '4'], ['tư', '4'],
    ['ba', '3'], ['hai', '2'], ['một', '1']
  ];
  for (const [word, digit] of vnSpokenNums) {
    working = working.replace(
      new RegExp(`(?<=^|[\\s,.;:])${word}(?=\\s*(?:giờ|rưỡi|lần)(?=$|[\\s,.;:]))`, 'gi'),
      digit
    );
  }
  // Normalize "8 giờ rưỡi" -> "8h30", "4 giờ kém 15" -> "3h45"
  working = working.replace(/(?<=^|[\s,.;:])(\d{1,2})\s*(?:giờ|h|g)\s*rưỡi(?=$|[\s,.;:])/gi, '$1h30');
  working = working.replace(/(?<=^|[\s,.;:])(\d{1,2})\s*(?:giờ|h|g)\s*kém\s*(\d{1,2})(?:\s*(?:p|phút))?(?=$|[\s,.;:])/gi, (_m, hStr, mStr) => {
    let h = Number(hStr) - 1;
    if (h < 0) h = 23;
    const min = Math.max(0, Math.min(59, 60 - Number(mStr)));
    return `${h}h${pad2(min)}`;
  });

  const normalizePeriodHour = (h, period = '') => {
    const p = (period || '').toLowerCase();
    if ((p === 'chiều' || p === 'tối' || p === 'pm') && h >= 1 && h <= 11) return h + 12;
    if (p === 'trưa' && h >= 1 && h <= 5) return h + 12;
    if ((p === 'sáng' || p === 'am') && h === 12) return 0;
    if (p === 'đêm' && h >= 7 && h <= 11) return h + 12;
    return h;
  };

  // 0. Extract optional "nhắc (thêm) từ 8h tối hôm trước [để chuẩn bị đồ]" or "từ hôm trước" pre-reminder clause FIRST
  // so its time ("8h tối") does NOT overwrite the main event's date/time!
  let prevDayAlert = null;
  let followUpMorningHint = false;
  const prevClausePatterns = [
    /(?:,|\s|^)(?:(?:nhắc(?:\s+nhở)?(?:\s+thêm)?|báo)\s*)?(?:từ|trước|lúc|vào)?\s*(\d{1,2})\s*(?:h|g|giờ|:)\s*(\d{1,2})?\s*(sáng|trưa|chiều|tối|tôi|đêm|am|pm)?\s*(?:ngày\s+)?(?:(?:tối|tôi)\s+)?(?:hôm\s+trước|trước\s+1\s+ngày)(?:\s+(?:thứ\s*[2-7]|chủ\s+nhật|cn)(?:\s+là\s+(?:thứ\s*[2-7]|chủ\s+nhật|cn))?)?(?:\s+(để\s+(?:(?!,|\.|;|\n|\s+(?:đến|tới)\s+(?:sáng|trưa|chiều|tối)).){2,70}))?/i,
    /(?:,|\s|^)(?:(?:nhắc(?:\s+nhở)?(?:\s+thêm)?|báo)\s*)?(?:từ|trước|lúc|vào)?\s*(?:(?:tối|tôi)\s+hôm\s+trước|hôm\s+trước|trước\s+1\s+ngày)(?:\s+(?:từ|lúc|vào)?\s*(\d{1,2})\s*(?:h|g|giờ|:)\s*(\d{1,2})?\s*(sáng|trưa|chiều|tối|tôi|đêm|am|pm)?)?(?:\s+(?:thứ\s*[2-7]|chủ\s+nhật|cn)(?:\s+là\s+(?:thứ\s*[2-7]|chủ\s+nhật|cn))?)?(?:\s+(để\s+(?:(?!,|\.|;|\n|\s+(?:đến|tới)\s+(?:sáng|trưa|chiều|tối)).){2,70}))?/i
  ];
  for (const re of prevClausePatterns) {
    const pm = working.match(re);
    if (!pm) continue;
    let ph = pm[1] !== undefined ? Number(pm[1]) : 20;
    const pmin = pm[2] !== undefined ? Number(pm[2]) : 0;
    let pPeriod = (pm[3] || '').toLowerCase();
    if (pPeriod === 'tôi') pPeriod = 'tối';
    if (!pPeriod && ph >= 1 && ph <= 11 && /(?:tối|tôi)/i.test(pm[0])) pPeriod = 'tối';
    ph = normalizePeriodHour(ph, pPeriod);
    if (ph >= 0 && ph <= 23 && pmin >= 0 && pmin <= 59) {
      prevDayAlert = {
        time: `${pad2(ph)}:${pad2(pmin)}`,
        purpose: (pm[4] || '').trim()
      };
      working = working.replace(pm[0], ' ');
      break;
    }
  }

  // Strip optional "đến sáng thứ 7 / sáng hôm sau (thì) nhắc lại" clause & remember morning default
  const followUpRe = /(?:,|\s|^)(?:đến|tới)?\s*(sáng|trưa|chiều|tối)\s*(?:thứ\s*[2-7]|chủ\s+nhật|cn|hôm\s+sau|hôm\s+đó)?\s*(?:thì\s+)?(?:nhắc(?:\s+lại)?|báo(?:\s+lại)?)/i;
  const fMatch = working.match(followUpRe);
  if (fMatch) {
    if ((fMatch[1] || '').toLowerCase() === 'sáng') followUpMorningHint = true;
    working = working.replace(fMatch[0], ' ');
  }

  // 0B. Detect sentence-level Vietnamese time-of-day context ("chiều nay ... lúc 3 giờ", "tối mai ... nhắc 8:00")
  let sentencePeriod = '';
  const sentPeriodMatch = working.match(
    /(?<=^|[\s,.;:])(?:vào\s+)?(?:buổi\s+)?(sáng|trưa|chiều|tối|đêm)(?=\s+(?:hôm\s+nay|nay|ngày\s+mai|mai|ngày\s+kia|kia|ngày\s+mốt|mốt|thứ\s*[2-7]|chủ\s+nhật|cn|tuần|ngày\s+\d|\d{1,2}\s*[\/\-]))/i
  ) || working.match(/(?<=^|[\s,.;:])(?:vào\s+)?buổi\s+(sáng|trưa|chiều|tối|đêm)(?=$|[\s,.;:])/i);
  if (sentPeriodMatch) {
    sentencePeriod = sentPeriodMatch[1].toLowerCase();
  }

  // 1. Extract explicit time — using TRUE Vietnamese boundaries
  let hour = null;
  let minute = 0;
  let timeMatched = false;

  // 1A. Relative offset from now ("30 phút nữa", "2 tiếng nữa", "sau 1 giờ nữa")
  const relOffsetMatch = working.match(
    /(?<=^|[\s,.;:])(?:(?:nhắc(?:\s+nhở)?|báo)\s+)?(?:sau\s+)?(\d{1,2})\s*(phút|p|tiếng|giờ)\s*(?:nữa|sau)(?=$|[\s,.;:])/i
  );
  if (relOffsetMatch) {
    const qty = Number(relOffsetMatch[1]);
    const unit = relOffsetMatch[2].toLowerCase();
    if (qty > 0 && qty <= 480) {
      const addMs = (unit === 'tiếng' || unit === 'giờ' ? qty * 60 : qty) * 60 * 1000;
      const futureDt = new Date(refDate.getTime() + addMs);
      targetDate = new Date(futureDt.getFullYear(), futureDt.getMonth(), futureDt.getDate());
      hour = futureDt.getHours();
      minute = futureDt.getMinutes();
      dateMatched = true;
      timeMatched = true;
      working = working.replace(relOffsetMatch[0], ' ');
    }
  }

  if (!timeMatched) {
    const timePatterns = [
      /(?<=^|[\s,.;:])(?:(?:nhắc(?:\s+nhở)?|báo)\s+)?(?:(?:vào|từ)\s+)?(?:lúc\s+)?(\d{1,2})\s*(?:giờ|h|g|:)\s*(\d{1,2})?(?:\s*(?:p|phút))?(?:\s*(sáng|trưa|chiều|tối|đêm|am|pm))?(?=$|[\s,.;:!?])/i,
      /(?<=^|[\s,.;:])(?:(?:nhắc(?:\s+nhở)?|báo)\s+)?(?:(?:vào|từ)\s+)?(?:lúc\s+)?(\d{1,2})\s*rưỡi(?:\s*(sáng|trưa|chiều|tối|đêm))?(?=$|[\s,.;:!?])/i,
      /(?<=^|[\s,.;:])(?:(?:nhắc(?:\s+nhở)?|báo)\s+)?(?:vào\s+)?lúc\s+(\d{1,2})(?:\s*(sáng|trưa|chiều|tối|đêm|am|pm))?(?=$|[\s,.;:!?])/i
    ];

    for (let idx = 0; idx < timePatterns.length; idx++) {
      const m = working.match(timePatterns[idx]);
      if (!m) continue;
      let h = Number(m[1]);
      let min = idx === 1 ? 30 : (idx === 0 && m[2] !== undefined ? Number(m[2]) : 0);
      const explicitPeriod = String((idx === 0 ? m[3] : m[2]) || '').toLowerCase();
      const effectivePeriod = explicitPeriod || sentencePeriod;

      if (h >= 0 && h <= 23 && min >= 0 && min <= 59) {
        h = normalizePeriodHour(h, effectivePeriod);
        hour = h;
        minute = min;
        timeMatched = true;
        working = working.replace(m[0], ' ');
        if (sentPeriodMatch && !explicitPeriod) {
          working = working.replace(
            new RegExp(`(?<=^|[\\s,.;:])(?:vào\\s+)?(?:buổi\\s+)?${sentencePeriod}(?=\\s+(?:hôm\\s+nay|nay|ngày\\s+mai|mai|ngày\\s+kia|kia|ngày\\s+mốt|mốt|thứ\\s*[2-7]|chủ\\s+nhật|cn|tuần|ngày\\s+\\d|\\d{1,2}\\s*[\\/\\-]))`, 'i'),
            ' '
          );
          working = working.replace(new RegExp(`(?<=^|[\\s,.;:])(?:vào\\s+)?buổi\\s+${sentencePeriod}(?=$|[\\s,.;:])`, 'i'), ' ');
        }
        break;
      }
    }
  }

  // Standalone period without explicit hour ("sáng mai", "chiều nay", "chiều ngày kia", "tối mai", "sáng thứ 7")
  if (!timeMatched) {
    const pOnly = working.match(/(?<=^|[\s,.;:])(?:vào\s+)?(?:buổi\s+)?(sáng|trưa|chiều|tối|đêm)\s+(hôm\s+nay|nay|ngày\s+mai|mai|ngày\s+kia|kia|ngày\s+mốt|mốt|thứ\s*[2-7]|chủ\s+nhật|cn)(?=$|[\s,.;:])/i);
    if (pOnly) {
      const p = pOnly[1].toLowerCase();
      hour = p === 'sáng' ? 8 : p === 'trưa' ? 12 : p === 'chiều' ? 14 : p === 'tối' ? 19 : 21;
      minute = 0;
      timeMatched = true;
      working = working.replace(pOnly[0], pOnly[2]);
    }
  }

  // 2. Extract date: explicit Lunar ("15/10 âm", "mùng 1 tháng 11 âm")
  const lunarExplicit = working.match(/(?:ngày\s+|mùng\s+)?(\d{1,2})\s*[\/\-]\s*(\d{1,2})(?:\s*[\/\-]\s*(\d{4}))?\s*(?:âm(?:\s*lịch)?|âl)\b/i);
  if (lunarExplicit) {
    const ld = Number(lunarExplicit[1]);
    const lm = Number(lunarExplicit[2]);
    let ly = lunarExplicit[3] ? Number(lunarExplicit[3]) : refDate.getFullYear();
    if (ld >= 1 && ld <= 30 && lm >= 1 && lm <= 12) {
      let s = convertLunar2Solar(ld, lm, ly, false, TIMEZONE_VN);
      if (s) {
        const dt = new Date(s.year, s.month - 1, s.day);
        if (!lunarExplicit[3] && dt < targetDate) {
          const sNext = convertLunar2Solar(ld, lm, ly + 1, false, TIMEZONE_VN);
          if (sNext) s = sNext;
        }
        targetDate = new Date(s.year, s.month - 1, s.day);
        dateMatched = true;
        isLunarSource = true;
        lunarNote = `Ngày ${ld}/${lm} Âm lịch`;
        working = working.replace(lunarExplicit[0], ' ');
      }
    }
  }

  // Explicit Solar date ("28/11", "28/11/2026", "ngày 5 tháng 12")
  if (!dateMatched) {
    const solMatch = working.match(/(?:ngày\s+)?(\d{1,2})\s*[\/\-]\s*(\d{1,2})(?:\s*[\/\-]\s*(\d{4}))?\b/i) ||
      working.match(/(?:ngày\s+)(\d{1,2})\s+tháng\s+(\d{1,2})(?:\s+năm\s+(\d{4}))?\b/i);
    if (solMatch) {
      const sd = Number(solMatch[1]);
      const sm = Number(solMatch[2]);
      let sy = solMatch[3] ? Number(solMatch[3]) : refDate.getFullYear();
      if (sd >= 1 && sd <= 31 && sm >= 1 && sm <= 12) {
        let dt = new Date(sy, sm - 1, sd);
        if (!solMatch[3] && dt < targetDate) {
          dt = new Date(sy + 1, sm - 1, sd);
        }
        if (dt.getDate() === sd && dt.getMonth() === sm - 1) {
          targetDate = dt;
          dateMatched = true;
          working = working.replace(solMatch[0], ' ');
        }
      }
    }
  }

  // Relative Vietnamese days ("hôm nay", "tối nay", "ngày mai", "mai", "ngày kia", "ngày mốt")
  if (!dateMatched) {
    const relToday = working.match(/\b(?:hôm\s+nay|nay)\b/i);
    const relTomorrow = working.match(/\b(?:ngày\s+mai|sáng\s+mai|trưa\s+mai|chiều\s+mai|tối\s+mai|mai)\b/i);
    const relDayAfter = working.match(/\b(?:ngày\s+kia|ngày\s+mốt|mốt)\b/i);

    if (relDayAfter) {
      targetDate.setDate(targetDate.getDate() + 2);
      dateMatched = true;
      working = working.replace(relDayAfter[0], ' ');
    } else if (relTomorrow) {
      targetDate.setDate(targetDate.getDate() + 1);
      dateMatched = true;
      working = working.replace(relTomorrow[0], ' ');
    } else if (relToday) {
      dateMatched = true;
      working = working.replace(relToday[0], ' ');
    }
  }

  // Vietnamese weekdays ("thứ 2".."thứ 7", "thứ hai".."thứ bảy", "chủ nhật", "cuối tuần")
  // with optional "tuần này" / "tuần sau" / "tuần tới" / "tuần sau nữa" (Vietnamese Mon→Sun calendar weeks)
  if (!dateMatched) {
    const wdMatch = working.match(
      /(?<=^|[\s,.;:])(?:(thứ\s*([2-7])|t([2-7])|chủ\s+nhật|cn|cuối\s+tuần))(?:\s+(tuần\s+này|tuần\s+sau\s+nữa|tuần\s+tới\s+nữa|tuần\s+sau|tuần\s+tới|này|sau\s+nữa|sau|tới))?(?=$|[\s,.;:])/i
    );
    if (wdMatch) {
      const rawDay = (wdMatch[1] || '').toLowerCase();
      const num = wdMatch[2] || wdMatch[3];
      // Vietnamese Monday-based week index: 0=T2(Mon), 1=T3, 2=T4, 3=T5, 4=T6, 5=T7(Sat), 6=CN(Sun)
      let targetMonIdx;
      if (/cuối\s+tuần/.test(rawDay)) {
        targetMonIdx = 5; // Saturday
      } else if (num) {
        targetMonIdx = Number(num) - 2; // T2->0 .. T7->5
      } else {
        targetMonIdx = 6; // Chủ nhật -> 6
      }
      const curMonIdx = (targetDate.getDay() + 6) % 7;
      const weekMod = (wdMatch[4] || '').toLowerCase();
      const inTwoWeeks = /(?:sau|tới)\s+nữa/.test(weekMod);
      const nextWeek = !inTwoWeeks && /sau|tới/.test(weekMod);
      const thisWeek = /này/.test(weekMod);

      let delta;
      if (inTwoWeeks) {
        delta = (14 - curMonIdx) + targetMonIdx;
      } else if (nextWeek) {
        delta = (7 - curMonIdx) + targetMonIdx;
      } else if (thisWeek) {
        delta = targetMonIdx - curMonIdx;
        if (delta < 0) delta += 7;
      } else {
        delta = (targetMonIdx - curMonIdx + 7) % 7;
        if (delta === 0) delta = 7;
      }

      targetDate.setDate(targetDate.getDate() + delta);
      dateMatched = true;
      working = working.replace(wdMatch[0], ' ');
    }
  }

  // Require at least date OR time matched so random words don't trigger false positives
  if (!dateMatched && !timeMatched) return null;

  // 3. Extract optional repeat frequency ("hàng ngày", "mỗi tuần", "hàng tháng âm", "hàng năm âm"...)
  let detectedRepeat = null;
  const repeatPatterns = [
    [/\b(?:hàng|mỗi)\s+năm\s+(?:âm(?:\s*lịch)?|âl)\b/i, 'lunar-yearly'],
    [/\b(?:hàng|mỗi)\s+tháng\s+(?:âm(?:\s*lịch)?|âl)\b/i, 'lunar-monthly'],
    [/\b(?:hàng|mỗi)\s+ngày\b/i, 'daily'],
    [/\b(?:hàng|mỗi)\s+tuần\b/i, 'weekly'],
    [/\b(?:hàng|mỗi)\s+tháng\b/i, 'monthly'],
    [/\b(?:hàng|mỗi)\s+năm\b/i, 'yearly']
  ];
  for (const [re, mode] of repeatPatterns) {
    const rm = working.match(re);
    if (rm) {
      detectedRepeat = mode;
      working = working.replace(rm[0], ' ');
      break;
    }
  }

  // 4. Extract optional multi-alert count ("nhắc 2 lần", "báo 3 lần", "nhắc nhở 2 lần")
  let remindCount = 1;
  const countMatch = working.match(/\b(?:nhắc(?:\s+nhở)?|báo)\s*(\d)\s*lần\b/i) || working.match(/\b(\d)\s*lần\b/i);
  if (countMatch) {
    const n = Number(countMatch[1]);
    if (n >= 2 && n <= 5) {
      remindCount = n;
      working = working.replace(countMatch[0], ' ');
    }
  }

  // 5. Extract optional location ("tại ...", "ở ...") with true Vietnamese word boundary
  let location = '';
  const locMatch = working.match(/(?<=^|[\s,.;:])(?:tại|ở)\s+([^,.;\n]{2,60})$/i);
  if (locMatch) {
    const candidate = locMatch[1].trim();
    if (candidate && !/^(?:lúc|vào|ngày|sáng|trưa|chiều|tối|đêm|hôm\s+nay|ngày\s+mai)$/i.test(candidate)) {
      location = candidate;
      working = working.replace(locMatch[0], ' ');
    }
  }

  // Clean remaining title & strip Vietnamese politeness fillers & trailing "nhắc/báo" words
  let title = working
    .replace(/(?<=^|[\s,.;:])(?:cho\s+tôi|cho\s+mình|giúp\s+tôi|giúp\s+mình|với\s+nhé|nhé|nha)(?=$|[\s,.;:])/gi, ' ')
    .replace(/(?<=^|[\s,.;:])(?:tuần\s+này|tuần\s+sau\s+nữa|tuần\s+tới\s+nữa|tuần\s+sau|tuần\s+tới)(?=$|[\s,.;:])/gi, ' ')
    .replace(/(?<=^|[\s,.;:])(?:nhắc(?:\s+nhở)?(?:\s+tôi|\s+mình)?|báo)\s*(?:vào\s+)?(?:lúc\s*)?$/i, '')
    .replace(/(?<=^|[\s,.;:])(?:lúc|vào|ngày|buổi|sáng|trưa|chiều|tối|đêm)\s*$/i, '')
    .replace(/^\s*(?:nhắc(?:\s+nhở)?(?:\s+tôi|\s+mình)?|đặt\s+lịch|lịch)\s*/i, '')
    .replace(/\s+/g, ' ')
    .replace(/^[\s\-–,:]+|[\s\-–,:]+$/g, '')
    .trim();

  if (title) {
    title = title.charAt(0).toUpperCase() + title.slice(1);
  }
  if (!title) title = 'Lịch hẹn mới';
  if (hour === null) {
    hour = prevDayAlert || followUpMorningHint ? 8 : 9;
    minute = 0;
  }

  const dateKey = formatDateKey(targetDate.getFullYear(), targetDate.getMonth() + 1, targetDate.getDate());
  const timeStr = `${pad2(hour)}:${pad2(minute)}`;

  let prevDayDateKey = null;
  if (prevDayAlert) {
    const prevDt = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate() - 1);
    prevDayDateKey = formatDateKey(prevDt.getFullYear(), prevDt.getMonth() + 1, prevDt.getDate());
  }

  // Compute staggered reminder times when remindCount > 1 (e.g. 2x -> -15m & exact time; 3x -> -30m, -15m & exact time)
  const mainMins = hour * 60 + minute;
  const earlyOffsetsMap = {
    1: [0],
    2: [15, 0],
    3: [30, 15, 0],
    4: [60, 30, 15, 0],
    5: [90, 60, 30, 15, 0]
  };
  const remindSlots = (earlyOffsetsMap[remindCount] || [0]).map((offMin) => {
    const m = Math.max(0, mainMins - offMin);
    return {
      offsetMinutes: offMin,
      time: `${pad2(Math.floor(m / 60))}:${pad2(m % 60)}`
    };
  });

  const noteParts = [];
  if (location) noteParts.push(`📍 ${location}`);
  if (prevDayAlert?.purpose) noteParts.push(`📝 ${prevDayAlert.purpose}`);
  if (isLunarSource && lunarNote) noteParts.push(`🌙 ${lunarNote}`);

  return {
    title: title.slice(0, 80),
    date: dateKey,
    time: timeStr,
    location,
    note: noteParts.join(' • '),
    isLunarSource,
    repeat: detectedRepeat,
    remindCount,
    remindSlots,
    prevDayAlert: prevDayAlert ? { date: prevDayDateKey, time: prevDayAlert.time, purpose: prevDayAlert.purpose } : null
  };
}

/**
 * Bulk Recurring Schedule Presets (Daily routines, Monthly bills, Weekly & Lunar rituals)
 */
export const BULK_REMINDER_PRESETS = {
  daily: [
    { enabled: true, title: '⏰ Thức dậy buổi sáng', repeat: 'daily', dayOfMonth: 1, weekday: 1, lunarDay: 1, time: '06:00', sendTelegram: false, note: 'Bắt đầu ngày mới tràn đầy năng lượng' },
    { enabled: true, title: '🌙 Chuẩn bị đi ngủ', repeat: 'daily', dayOfMonth: 1, weekday: 1, lunarDay: 1, time: '22:30', sendTelegram: false, note: 'Nghỉ ngơi đúng giờ giữ sức khỏe' }
  ],
  monthly_bills: [
    { enabled: true, title: '🏠 Thanh toán tiền nhà', repeat: 'monthly', dayOfMonth: 5, weekday: 1, lunarDay: 1, time: '09:00', sendTelegram: true, note: 'Chuyển khoản tiền nhà / phí quản lý' },
    { enabled: true, title: '⚡ Thanh toán tiền điện', repeat: 'monthly', dayOfMonth: 10, weekday: 1, lunarDay: 1, time: '09:00', sendTelegram: true, note: 'Kiểm tra hóa đơn điện hàng tháng' },
    { enabled: true, title: '🚰 Thanh toán tiền nước', repeat: 'monthly', dayOfMonth: 10, weekday: 1, lunarDay: 1, time: '09:05', sendTelegram: true, note: 'Thanh toán hóa đơn nước sinh hoạt' },
    { enabled: true, title: '🌐 Thanh toán cước Internet / ĐT', repeat: 'monthly', dayOfMonth: 15, weekday: 1, lunarDay: 1, time: '09:00', sendTelegram: true, note: 'Đóng cước Wifi / điện thoại định kỳ' },
    { enabled: true, title: '💳 Thanh toán thẻ tín dụng', repeat: 'monthly', dayOfMonth: 20, weekday: 1, lunarDay: 1, time: '09:00', sendTelegram: true, note: 'Kiểm tra sao kê & thanh toán đúng hạn' }
  ],
  weekly_lunar: [
    { enabled: true, title: '🧹 Dọn dẹp & lên kế hoạch tuần', repeat: 'weekly', dayOfMonth: 1, weekday: 0, lunarDay: 1, time: '09:00', sendTelegram: false, note: 'Tổng kết tuần & chuẩn bị cho tuần mới' },
    { enabled: true, title: '🏮 Thắp hương Mùng 1 Âm lịch', repeat: 'lunar-monthly', dayOfMonth: 1, weekday: 1, lunarDay: 1, time: '07:00', sendTelegram: true, note: 'Sắm lễ hoa quả thắp hương đầu tháng' },
    { enabled: true, title: '🌕 Thắp hương Ngày Rằm (15 ÂL)', repeat: 'lunar-monthly', dayOfMonth: 15, weekday: 1, lunarDay: 15, time: '07:00', sendTelegram: true, note: 'Thắp hương ngày Rằm hàng tháng' }
  ]
};

/**
 * Compute the clean YYYY-MM-DD anchor date for a bulk schedule row
 */
export function computeStartDateForBulkRow(row, now = new Date()) {
  const repeat = row.repeat || 'daily';
  const y = now.getFullYear();
  const m = now.getMonth() + 1;
  const d = now.getDate();
  const todayKey = formatDateKey(y, m, d);

  if (repeat === 'daily') {
    return todayKey;
  }

  if (repeat === 'weekly') {
    const targetDow = Number.isInteger(Number(row.weekday)) ? Number(row.weekday) : now.getDay();
    const curDow = now.getDay();
    const diff = (targetDow - curDow + 7) % 7;
    const dt = new Date(y, m - 1, d + diff);
    return formatDateKey(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
  }

  if (repeat === 'monthly') {
    const targetDay = Math.max(1, Math.min(31, Number(row.dayOfMonth) || d));
    const maxCur = new Date(y, m, 0).getDate();
    const [hh, mm] = String(row.time || '09:00').split(':').map(Number);
    const curMonthDt = new Date(y, m - 1, Math.min(targetDay, maxCur), hh || 9, mm || 0, 0, 0);
    if (curMonthDt.getTime() > now.getTime() + 60 * 1000) {
      return formatDateKey(y, m, Math.min(targetDay, maxCur));
    }
    const ny = m === 12 ? y + 1 : y;
    const nm = m === 12 ? 1 : m + 1;
    const maxNext = new Date(ny, nm, 0).getDate();
    return formatDateKey(ny, nm, Math.min(targetDay, maxNext));
  }

  if (repeat === 'lunar-monthly') {
    const targetLunarDay = Math.max(1, Math.min(30, Number(row.lunarDay) || 1));
    const [hh, mm] = String(row.time || '07:00').split(':').map(Number);
    for (let off = 0; off <= 45; off++) {
      const probe = new Date(y, m - 1, d + off, hh || 7, mm || 0, 0, 0);
      if (probe.getTime() <= now.getTime() + 60 * 1000) continue;
      const l = convertSolar2Lunar(probe.getDate(), probe.getMonth() + 1, probe.getFullYear(), TIMEZONE_VN);
      if (l.day === targetLunarDay || (targetLunarDay === 30 && l.monthLength === 29 && l.day === 29)) {
        return formatDateKey(probe.getFullYear(), probe.getMonth() + 1, probe.getDate());
      }
    }
    return todayKey;
  }

  return row.date && /^\d{4}-\d{2}-\d{2}$/.test(row.date) ? row.date : todayKey;
}

/**
 * Parse multi-line Vietnamese bulk schedule text (1 line = 1 recurring/one-time reminder)
 */
export function parseBulkReminderLines(rawText, now = new Date()) {
  const lines = String(rawText || '')
    .split(/\r?\n|;/)
    .map((s) => s.replace(/^[-•*+\d.)\s]+/, '').trim())
    .filter((s) => s.length >= 2);

  const results = [];
  for (const line of lines) {
    const lower = line.toLowerCase();
    let repeat = 'none';
    let dayOfMonth = now.getDate();
    let weekday = now.getDay();
    let lunarDay = 1;
    let time = '09:00';
    let title = line;

    const tmMatch = lower.match(/(?:lúc\s+)?(\d{1,2})\s*(?:h|:|giờ)\s*(\d{1,2})?\s*(p|phút|rưỡi)?\s*(sáng|trưa|chiều|tối|đêm)?/i);
    if (tmMatch) {
      let hh = Number(tmMatch[1]);
      let mm = tmMatch[2] ? Number(tmMatch[2]) : (tmMatch[3] === 'rưỡi' ? 30 : 0);
      const period = tmMatch[4] || '';
      if ((period === 'chiều' || period === 'tối' || period === 'đêm') && hh >= 1 && hh <= 11) hh += 12;
      if (period === 'trưa' && hh >= 1 && hh <= 11) hh += 12;
      hh = Math.max(0, Math.min(23, hh));
      mm = Math.max(0, Math.min(59, mm));
      time = `${pad2(hh)}:${pad2(mm)}`;
    }

    if (/(?:mỗi|hàng|hằng)\s*ngày|daily/i.test(lower)) {
      repeat = 'daily';
      if (!tmMatch) time = '07:00';
    } else if (/(?:âm\s*lịch|âl|al|mùng\s*\d|rằm)/i.test(lower) && /(?:mỗi|hàng|hằng)\s*tháng/i.test(lower)) {
      repeat = 'lunar-monthly';
      if (/rằm/i.test(lower)) {
        lunarDay = 15;
      } else {
        const lm = lower.match(/(?:mùng|ngày)\s*(\d{1,2})/i);
        if (lm) lunarDay = Math.max(1, Math.min(30, Number(lm[1])));
      }
      if (!tmMatch) time = '07:00';
    } else if (/(?:mỗi|hàng|hằng)\s*tháng|monthly/i.test(lower)) {
      repeat = 'monthly';
      const dm = lower.match(/(?:ngày|mùng)\s*(\d{1,2})/i);
      if (dm) dayOfMonth = Math.max(1, Math.min(31, Number(dm[1])));
    } else if (/(?:mỗi|hàng|hằng)\s*tuần|weekly/i.test(lower)) {
      repeat = 'weekly';
      if (/chủ\s*nhật|cn\b/i.test(lower)) weekday = 0;
      else {
        const wm = lower.match(/thứ\s*([2-7]|hai|ba|tư|năm|sáu|bảy|bẩy)/i);
        const map = { '2': 1, hai: 1, '3': 2, ba: 2, '4': 3, tư: 3, '5': 4, năm: 4, '6': 5, sáu: 5, '7': 6, bảy: 6, bẩy: 6 };
        if (wm && map[wm[1]] !== undefined) weekday = map[wm[1]];
      }
    } else if (/(?:mỗi|hàng|hằng)\s*năm|yearly/i.test(lower)) {
      repeat = 'yearly';
    }

    if (repeat !== 'none') {
      title = line
        .replace(/(?:mỗi|hàng|hằng)\s*(?:ngày|tuần|tháng|năm)/gi, ' ')
        .replace(/(?:âm\s*lịch|dương\s*lịch|âl)\b/gi, ' ')
        .replace(/(?:vào\s+)?(?:ngày|mùng)\s*\d{1,2}\b/gi, ' ')
        .replace(/(?:vào\s+)?(?:thứ\s*(?:[2-7]|hai|ba|tư|năm|sáu|bảy|bẩy)|chủ\s*nhật)\b/gi, ' ')
        .replace(/(?:lúc\s+)?\d{1,2}\s*(?:h|:|giờ)\s*(?:\d{1,2})?\s*(?:p|phút|rưỡi)?\s*(?:sáng|trưa|chiều|tối|đêm)?/gi, ' ')
        .replace(/^[\s,:;\-–—]+|[\s,:;\-–—]+$/g, '')
        .replace(/\s{2,}/g, ' ')
        .trim();
      if (!title) title = line;
      title = title.charAt(0).toUpperCase() + title.slice(1);

      const isBillOrImportant = /(?:thanh toán|tiền|thẻ|hóa đơn|nợ|họp|cước|thuế|lương|đóng|nộp|thắp hương)/i.test(lower);
      results.push({
        enabled: true,
        title: title.slice(0, 90),
        repeat,
        dayOfMonth,
        weekday,
        lunarDay,
        date: formatDateKey(now.getFullYear(), now.getMonth() + 1, now.getDate()),
        time,
        sendTelegram: repeat !== 'daily' || isBillOrImportant,
        note: ''
      });
    } else {
      const nlp = parseVietnameseNlpReminder(line, now);
      results.push({
        enabled: true,
        title: (nlp?.title || line).slice(0, 90),
        repeat: nlp?.repeat || 'none',
        dayOfMonth: nlp?.date ? Number(nlp.date.split('-')[2]) : now.getDate(),
        weekday: now.getDay(),
        lunarDay: 1,
        date: nlp?.date || formatDateKey(now.getFullYear(), now.getMonth() + 1, now.getDate()),
        time: nlp?.time || time,
        sendTelegram: true,
        note: nlp?.note || ''
      });
    }
  }
  return results;
}


export const AUTO_DELETE_EXPIRED_OPTIONS = [
  { days: 0, label: 'Không tự động xóa' },
  { days: 7, label: 'Sau 7 ngày' },
  { days: 30, label: 'Sau 1 tháng (30 ngày)' },
  { days: 90, label: 'Sau 3 tháng (90 ngày)' },
  { days: 180, label: 'Sau 6 tháng (180 ngày)' },
  { days: 365, label: 'Sau 1 năm (365 ngày)' }
];

/**
 * Auto-prune completed or expired one-time reminders older than `maxDays`.
 * Active / recurring reminders with future occurrences are NEVER deleted.
 */
export function pruneExpiredReminders(timedReminders, maxDays, nowMs = Date.now()) {
  const days = Number(maxDays) || 0;
  const list = Array.isArray(timedReminders) ? timedReminders : [];
  if (days <= 0) {
    return { kept: list, removedIds: [] };
  }
  const thresholdMs = days * 24 * 60 * 60 * 1000;
  const kept = [];
  const removedIds = [];

  for (const rem of list) {
    if (!rem) continue;
    const nextMs = !rem.done ? getNextReminderTimestamp(rem, nowMs) : null;
    // Still active with an upcoming occurrence -> keep!
    if (!rem.done && nextMs !== null) {
      kept.push(rem);
      continue;
    }

    const schedDt = parseReminderDateTime(rem.date, rem.time);
    const schedMs = schedDt ? schedDt.getTime() : 0;
    const refTs = rem.done
      ? Number(rem.completedAt || rem.updatedAt || schedMs || rem.createdAt || nowMs)
      : Number(schedMs || rem.updatedAt || rem.createdAt || nowMs);

    if (refTs > 0 && nowMs - refTs >= thresholdMs) {
      if (rem.id) removedIds.push(rem.id);
    } else {
      kept.push(rem);
    }
  }

  return { kept, removedIds };
}
