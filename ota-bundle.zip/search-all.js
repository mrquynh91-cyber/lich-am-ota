/**
 * Global Spotlight Search Engine ("Tìm kiếm toàn bộ ứng dụng — không vùng cấm")
 * Vietnamese accent-insensitive fuzzy matching across ALL 8 domains:
 *  1. Direct Date Jump (Solar DD/MM/YYYY & Lunar DD/MM âm)
 *  2. Timed Reminders (both Active & Expired/Completed)
 *  3. Custom Events (Ngày giỗ, Sinh nhật, Sự kiện cá nhân)
 *  4. 23 Traditional Vietnamese Prayers (Văn khấn — title, shortTitle, occasion, offerings, full template & date shorthands)
 *  5. Highlighted Date Ranges (Đánh dấu / Bôi màu)
 *  6. Vietnamese Holidays (Âm lịch & Dương lịch)
 *  7. Auspicious Task Catalog (Xem ngày tốt theo công việc)
 *  8. App Features & Settings Shortcuts (Uống nước, Telegram, Zalo, Đồng bộ, Tự xóa...)
 */
import { convertLunar2Solar, convertSolar2Lunar, TIMEZONE_VN } from './lunar.js';
import { getUpcomingEvents } from './holidays.js';
import { REPEAT_LABELS, pad2 } from './reminders.js';
import { PRAYERS_CATALOG, PRAYER_CATEGORIES, getRecommendedPrayersForDate } from './prayers.js';
import { DREAMS_CATALOG } from './dreams.js';
import { TASK_CATALOG } from './auspicious.js';

export function normalizeVnSearch(str) {
  return String(str || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/\s+/g, ' ')
    .trim();
}

function matchesAllTokens(haystackNorm, tokens) {
  if (!tokens.length) return false;
  return tokens.every((t) => haystackNorm.includes(t));
}

const PRAYER_CATEGORY_LABELS = Object.fromEntries(
  (PRAYER_CATEGORIES || []).map((c) => [c.id, c.label])
);

// Extra date shorthands & everyday Vietnamese synonyms for every prayer in PRAYERS_CATALOG
const PRAYER_EXTRA_TAGS = {
  'ram-tho-cong': '1/1 01/01 15/1 15/01 m1 mung 1 ngay ram 15 am lich hang thang tho cong than linh ban tho ong dia tao quan',
  'ram-gia-tien': '1/1 01/01 15/1 15/01 m1 mung 1 ngay ram 15 am lich hang thang gia tien to tien ong ba cha me ban tho',
  'ram-thang-gieng': '15/1 15/01 ram thang gieng thang 1 nguyen tieu thuong nguyen dau nam banh troi xoi gac',
  'than-tai': '10/1 10/01 mung 10 thang gieng via than tai mua vang tam sen ca loc nuong kinh doanh buôn ban',
  'han-thuc': '3/3 03/03 mung 3 thang 3 han thuc thanh minh banh troi banh chay',
  'doan-ngo': '5/5 05/05 mung 5 thang 5 doan ngo diet sau bo giua nam ruou nep banh u tro',
  'vu-lan-gia-tien': '15/7 15/07 ram thang 7 vu lan bao hieu trung nguyen gia tien xa toi vong nhan',
  'vu-lan-chung-sinh': '15/7 15/07 ram thang 7 co hon chung sinh cung ngoai san chao loang muoi gao xa toi vong nhan',
  'trung-thu': '15/8 15/08 ram thang 8 trung thu doan vien banh nuong banh deo com',
  'ha-nguyen': '15/10 15/10 ram thang 10 ha nguyen com moi gao moi',
  'ong-tao': '23/12 23 thang chap ong cong ong tao tao quan ca chep phong sinh chau troi',
  'tat-nien': '29/12 30/12 chieu 30 tet chieu 29 tet tat nien cuoi nam thang chap banh chung',
  'giao-thua-ngoai': '29/12 30/12 1/1 01/01 dem giao thua ngoai troi ngoai san gio ty hanh khien tru tich',
  'giao-thua-trong': '29/12 30/12 1/1 01/01 dem giao thua trong nha ban tho gia tien don xuan',
  'mung1-tet': '1/1 01/01 m1 mung 1 tet nguyen dan thang gieng dau nam moi am lich',
  'hoa-vang': '3/1 03/01 4/1 5/1 mung 3 tet hoa vang tien to tien tien vang ma',
  'ngay-gio': 'ngay gio cat ky gio thuong huy nhat cung gio ong ba cha me nguoi than',
  'khai-truong': 'khai truong cua hang cong ty van phong mo hang dau xuan kinh doanh buôn ban',
  'nhap-trach': 'nhap trach ve nha moi chuyen nha can ho chung cu an cu',
  'dong-tho': 'dong tho khoi cong xay nha sua nha cong trinh dap tuong lam nha',
  'tet-duong-lich': '1/1 01/01 tet duong lich tet tay nam moi duong lich thang 1',
  'mung2-tet': '2/1 02/01 m2 mung 2 tet nguyen dan thang gieng',
  'cung-sao-giai-han': '8/1 08/01 15/1 15/01 cung sao giai han dau nam sao chieu menh thai bach la hau ke do',
  'ta-mo-thanh-minh': '4/4 04/04 5/4 05/04 3/3 tao mo thanh minh ngoai nghia trang phan mo',
  'gio-to-hung-vuong': '10/3 10/03 mung 10 thang 3 gio to hung vuong vua hung banh chung banh day',
  'phat-dan': '15/4 15/04 ram thang 4 phat dan vesak cung phat le chay',
  'that-tich': '7/7 07/07 mung 7 thang 7 that tich che dau do cau duyen',
  'vu-lan-than-linh': '15/7 15/07 ram thang 7 vu lan than linh tho cong ban tho',
  'trung-cuu': '9/9 09/09 mung 9 thang 9 trung cuu trung duong tra hoa cuc truong tho',
  'ta-dat-cuoi-nam': 'ta dat ta than linh cuoi nam thang chap 23/12 25/12 28/12',
  'cung-mu': 'cung mu day thang thoi noi be em be 12 ba mu 3 duc ong xoi che',
  'cung-xe': 'cung xe moi mua xe oto o to xe may xuat hanh thuong lo binh an'
};

const PRAYER_COUNT = (PRAYERS_CATALOG || []).length;

const APP_SHORTCUTS = [
  { id: 'sc-gemini-ai', icon: '✨', title: 'Trợ lý Gemini AI (Hỏi đáp Lịch Âm & Tạo lịch)', sub: 'Chat hỏi lịch tuần này, xem ngày tốt, tự tạo nhắc nhở & soạn văn khấn', keywords: 'gemini ai tro ly chat hoi dap thong minh', action: { type: 'open-ai' } },
  { id: 'sc-rem-add', icon: '➕', title: 'Thêm nhắc nhở mới', sub: 'Mở form tạo lịch hẹn ngày giờ / giọng nói', keywords: 'them nhac nho tao lich hen giong noi mic', action: { type: 'nav', tab: 'reminders', sub: 'rem', open: 'rem-form' } },
  { id: 'sc-rem-bulk', icon: '📋', title: 'Đặt lịch hàng loạt (Thói quen & Hóa đơn)', sub: 'Thức dậy mỗi ngày, tiền nhà, điện nước, thẻ tín dụng', keywords: 'dat lich hang loat dinh ky hoa don the tin dung tien nha dien nuoc thuc day', action: { type: 'nav', tab: 'reminders', sub: 'rem', open: 'bulk-form' } },
  { id: 'sc-prayer', icon: '🙏', title: `Thư viện ${PRAYER_COUNT} bài Văn khấn cổ truyền`, sub: 'Văn khấn Mùng 1, Rằm, Giao thừa, Gia tiên, Khai trương...', keywords: 'van khan cung bai khan mung 1 ram gia tien than tai', action: { type: 'nav', tab: 'prayers' } },
  { id: 'sc-dreams', icon: '🌙', title: 'Giải mã giấc mơ (Sổ Mơ & Gemini AI)', sub: 'Tra cứu sổ mơ dân gian & luận giải chi tiết bằng AI', keywords: 'giai mong giai ma giac mo so mo diem bao con so may man', action: { type: 'nav', tab: 'dreams' } },
  { id: 'sc-moles', icon: '🪞', title: 'Quét khuôn mặt & Xem nốt ruồi (AI Camera)', sub: 'Cam trước tự lật, cam sau giữ nguyên, tải ảnh & bản đồ 18 vị trí', keywords: 'not ruoi quet khuon mat nhan tuong hoc camera soi mat tuong mat', action: { type: 'nav', tab: 'moles' } },
  { id: 'sc-palmistry', icon: '🖐️', title: 'Xem chỉ tay (Cam sau / Tải ảnh + AI)', sub: 'Quét đường Sinh Đạo, Trí Đạo, Tâm Đạo, Vận Mệnh & bản đồ bàn tay', keywords: 'xem chi tay ban tay sinh dao tri dao tam dao van menh thu tuong hoc camera', action: { type: 'nav', tab: 'palmistry' } },
  { id: 'sc-fortune', icon: '📜', title: 'Luận giải Quẻ Đình Chùa & Lá Số Tử Vi (AI)', sub: 'Chụp ảnh tờ giấy quẻ xăm đình chùa, lá số Tử Vi 12 cung để AI dịch & luận giải', keywords: 'que xam dinh chua rut que la so tu vi 12 cung chup anh to giay luan giai quan am linh xam kinh dich bat tu', action: { type: 'nav', tab: 'fortune' } },
  { id: 'sc-tuvi', icon: '⭐', title: 'Lập Lá Số Tử Vi & Xem Hạn Năm', sub: 'An 14 Chính tinh, xem hạn Tam Tai, Thái Tuế, Kim Lâu, Hoang Ốc & Cửu Diệu', keywords: 'lap la so tu vi xem han tam tai thai tue kim lau hoang oc sao chieu menh cuu dieu 12 cung van han nam', action: { type: 'nav', tab: 'tuvi' } },
  { id: 'sc-fengshui', icon: '🏠', title: 'AI Chấm điểm Phong thủy không gian (AI Camera)', sub: 'Chụp bàn làm việc, phòng ngủ, bàn thờ soi lỗi & gợi ý cây xanh hợp mệnh', keywords: 'phong thuy khong gian ban lam viec phong ngu ban tho bat trach huong tot cay xanh ai camera', action: { type: 'nav', tab: 'fengshui' } },
  { id: 'sc-simplate', icon: '📱', title: 'Bói Sim, Biển số xe & Số tài khoản', sub: 'Chấm điểm SĐT, biển số xe, STK theo Ngũ hành & Kinh Dịch 80 số', keywords: 'boi sim dien thoai bien so xe so tai khoan ngan hang stk cham diem phong thuy kinh dich', action: { type: 'nav', tab: 'simplate' } },
  { id: 'sc-compat', icon: '💑', title: 'Xem tuổi hợp (Vợ chồng, Làm ăn & Sinh con)', sub: 'Kiểm tra xung khắc Ngũ hành, Thiên Can, Địa Chi, Cung Phi Bát Trạch', keywords: 'xem tuoi hop vo chong tinh duyen cuoi hoi lam an hop tac sinh con xung khac', action: { type: 'nav', tab: 'compat' } },
  { id: 'sc-tarot', icon: '🃏', title: 'Thần số học & Rút bài Tarot AI', sub: 'Con số Đường đời, Năm cá nhân Pythagoras & rút bài Tarot hỏi đáp nhanh', keywords: 'than so hoc pythagoras duong doi nam ca nhan rut bai tarot 3 la hoi dap ai', action: { type: 'nav', tab: 'tarot' } },
  { id: 'sc-iching', icon: '🎲', title: 'Gieo quẻ Kinh Dịch & Xin xăm Quan Âm', sub: 'Lắc máy gieo quẻ 64 quẻ, xin xăm đầu năm & AI giải theo câu hỏi riêng', keywords: 'gieo que kinh dich 64 que xin xam quan am lac may ong xam dong xu', action: { type: 'nav', tab: 'iching' } },
  { id: 'sc-expense', icon: '💰', title: 'Ghi chép thu chi AI (Giọng nói & Bill)', sub: 'Nói nhanh hoặc quét ảnh hóa đơn / bill chuyển khoản tự ghi sổ & thống kê', keywords: 'ghi chep thu chi tai chinh quan ly chi tieu quet bill hoa don giong noi ai scan csv', action: { type: 'nav', tab: 'expense' } },
  { id: 'sc-medicine', icon: '💊', title: 'Nhắc uống thuốc & Lưu đơn thuốc', sub: 'Hẹn giờ uống thuốc theo cữ (trước/sau ăn), chụp đơn thuốc & AI đọc đơn', keywords: 'nhac uong thuoc luu don thuoc suc khoe gia dinh bo me truoc an sau an', action: { type: 'nav', tab: 'medicine' } },
  { id: 'sc-meal', icon: '🍲', title: 'Hôm nay ăn gì? (AI Gợi ý thực đơn)', sub: 'Gợi ý món ngon theo thời tiết, tủ lạnh & thực đơn chay Mùng 1, Rằm', keywords: 'hom nay an gi thuc don goi y mon ngon an chay mung 1 ram tu lanh nau an', action: { type: 'nav', tab: 'meal' } },
  { id: 'sc-docscan', icon: '📄', title: 'Quét tài liệu AI (CamScanner Pro)', sub: 'AI tự bắt 4 góc & căn phẳng giấy — Xuất Ảnh, PDF A4, Word (.doc) & Excel (.xls)', keywords: 'quet tai lieu scan camscanner can chinh giay xuat pdf word doc excel xls csv anh ocr', action: { type: 'nav', tab: 'docscan' } },
  { id: 'sc-ausp', icon: '🔮', title: 'Xem ngày giờ tốt theo tuổi', sub: 'Tìm ngày Hoàng Đạo hợp mệnh & công việc', keywords: 'xem ngay tot gio hoang dao hop tuoi menh ngu hanh', action: { type: 'nav', tab: 'auspicious' } },
  { id: 'sc-holidays', icon: '🏮', title: 'Lễ Tết, Ngày giỗ & Sinh nhật', sub: 'Đếm ngược Tết, quản lý ngày giỗ Âm lịch', keywords: 'le tet ngay gio sinh nhat dem nguoc ca nhan', action: { type: 'nav', tab: 'holidays' } },
  { id: 'sc-water', icon: '💧', title: 'Nhắc uống nước', sub: 'Lịch chia cữ uống nước & tiếng rót nước', keywords: 'uong nuoc ly nuoc suc khoe nhac uong nuoc', action: { type: 'nav', tab: 'water', sub: 'water' } },
  { id: 'sc-hl', icon: '🖍', title: 'Bôi màu khoảng ngày & Quét PDF / ICS', sub: 'Đánh dấu chuyến đi, quét vé máy bay', keywords: 'boi mau danh dau khoang ngay quet pdf ics ve may bay', action: { type: 'nav', tab: 'reminders', sub: 'hl' } },
  { id: 'sc-conv', icon: '🔄', title: 'Quy đổi đa năng (5 nhóm — 20+ công cụ)', sub: 'Âm↔Dương, Đo lường/Vàng/Sào, Ngoại tệ/Crypto, Lương Gross↔Net, CNTT, Đời sống', keywords: 'doi ngay quy doi am duong lich mui gio timestamp do dai khoi luong vang chi luong dien tich sao mau the tich nhiet do toc do dien cong suat btu ngoai te usd vnd crypto btc eth luong gross net thue tncn so thanh chu dung luong toc do mang he co so hex rgb cmyk anh jpg png webp size giay ao nau an cup diem gpa ielts toeic so la ma', action: { type: 'nav', tab: 'converter' } },
  { id: 'sc-cloud', icon: '☁️', title: 'Đồng bộ tự động 2 chiều (Firebase / GitHub)', sub: 'Ghép nối PC ↔ OPPO Find X9', keywords: 'dong bo cloud firebase github ma ket noi ghep noi', action: { type: 'nav', tab: 'settings', focus: 'cloud' } },
  { id: 'sc-tg', icon: '✈️', title: 'Cài đặt nhóm Telegram', sub: 'Bot Token, Chat ID, chống trùng thiết bị', keywords: 'telegram bot token chat id nhom thong bao', action: { type: 'nav', tab: 'settings', focus: 'telegram' } },
  { id: 'sc-zalo', icon: '💬', title: 'Chia sẻ Zalo & Webhook', sub: 'Gửi nhanh lịch hẹn qua Zalo', keywords: 'zalo webhook chia se', action: { type: 'nav', tab: 'settings', focus: 'zalo' } },
  { id: 'sc-autodel', icon: '🧹', title: 'Tự động xóa tin đã xong / hết hạn', sub: 'Cài mốc tự dọn sau 7 ngày, 1/3/6 tháng, 1 năm', keywords: 'tu dong xoa het han da xong don dep cai dat', action: { type: 'nav', tab: 'settings', focus: 'autodel' } },
  { id: 'sc-settings', icon: '⚙️', title: 'Cài đặt ứng dụng & Sao lưu JSON', sub: 'Quyền thông báo, tối ưu pin, sao lưu khôi phục', keywords: 'cai dat sao luu khoi phuc json pin coloros thong bao', action: { type: 'nav', tab: 'settings' } }
];

function extractDateParts(raw, now = new Date()) {
  const txt = String(raw || '').trim();
  const isLunar = /(?:âm|am|âl|al|mùng|mung|rằm|ram)/i.test(txt);
  const isSolar = /(?:dương|duong|dl)/i.test(txt);
  const m = txt.match(/(\d{1,2})\s*[\/\-\.]\s*(\d{1,2})(?:\s*[\/\-\.]\s*(\d{4}))?/);
  if (!m) return null;
  const d = Number(m[1]);
  const mo = Number(m[2]);
  const y = m[3] ? Number(m[3]) : now.getFullYear();
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || y < 1900 || y > 2100) return null;
  return { d, mo, y, hasYear: Boolean(m[3]), isLunar, isSolar };
}

function tryParseDirectDateQueries(raw, now = new Date()) {
  const parts = extractDateParts(raw, now);
  if (!parts) return [];
  const { d, mo, y, isLunar, isSolar } = parts;
  const hits = [];

  if (!isLunar) {
    const dt = new Date(y, mo - 1, d);
    if (dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d) {
      const l = convertSolar2Lunar(d, mo, y, TIMEZONE_VN);
      hits.push({
        icon: '📅',
        title: `Đi tới ngày ${pad2(d)}/${pad2(mo)}/${y} (Dương lịch)`,
        sub: `Âm lịch: Ngày ${l.day}/${l.month}${l.leap ? 'N' : ''}/${l.year} ÂL`,
        action: { type: 'date', solar: { day: d, month: mo, year: y } }
      });
    }
  }

  if ((isLunar || !isSolar) && d <= 30) {
    const s = convertLunar2Solar(d, mo, y, false, TIMEZONE_VN);
    if (s) {
      hits.push({
        icon: '🌙',
        title: `Đi tới ngày ${d}/${mo}/${y} Âm lịch`,
        sub: `Tương ứng Dương lịch: ${pad2(s.day)}/${pad2(s.month)}/${s.year}`,
        action: { type: 'date', solar: { day: s.day, month: s.month, year: s.year } }
      });
    }
  }

  return hits;
}

/**
 * Search EVERYTHING in the app and return categorized result groups.
 */
export function runGlobalAppSearch(rawQuery, state, today = new Date()) {
  const qNorm = normalizeVnSearch(rawQuery);
  const tokens = qNorm ? qNorm.split(' ').filter(Boolean) : [];
  const groups = [];

  if (tokens.length === 0) {
    // Show helpful quick shortcuts when search box is empty
    groups.push({
      key: 'shortcuts',
      label: '⚡ Lối tắt nhanh',
      items: APP_SHORTCUTS.slice(0, 8)
    });
    return groups;
  }

  // 1. Direct date jump (both Solar & Lunar when typing e.g. "1/1" or "15/7")
  const dateParts = extractDateParts(rawQuery, today);
  const dateHits = tryParseDirectDateQueries(rawQuery, today);
  if (dateHits.length > 0) {
    groups.push({ key: 'date', label: '📅 Nhảy nhanh tới ngày', items: dateHits });
  }

  // 2. Timed Reminders (active + expired/completed)
  const remHits = [];
  for (const r of state.timedReminders || []) {
    if (!r) continue;
    const [y, m, d] = (r.date || '').split('-').map(Number);
    const vnDate = y && m && d ? `${pad2(d)}/${pad2(m)}/${y}` : (r.date || '');
    const repLabel = REPEAT_LABELS[r.repeat || 'none'] || 'Một lần';
    const hay = normalizeVnSearch(`${r.title} ${r.note || ''} ${vnDate} ${r.date || ''} ${r.time || ''} ${repLabel}`);
    if (matchesAllTokens(hay, tokens)) {
      remHits.push({
        icon: r.done ? '☑️' : '⏰',
        title: r.title,
        sub: `${vnDate} • ${r.time || ''} • ${repLabel}${r.done ? ' • Đã xong' : ''}${r.note ? ` • ${r.note}` : ''}`,
        action: { type: 'reminder', id: r.id, done: Boolean(r.done) }
      });
    }
  }
  if (remHits.length > 0) {
    groups.push({ key: 'reminders', label: `⏰ Nhắc nhở (${remHits.length})`, items: remHits.slice(0, 12) });
  }

  // 3. Custom Events (Ngày giỗ, Sinh nhật, Sự kiện cá nhân)
  const ceHits = [];
  for (const ce of state.customEvents || []) {
    if (!ce) continue;
    const calLbl = ce.calendar === 'lunar' ? 'Âm lịch AL' : 'Dương lịch DL';
    const kindLbl = ce.kind === 'gio' ? 'ngày giỗ cúng' : ce.kind === 'sinhnhat' ? 'sinh nhật' : 'sự kiện cá nhân';
    const hay = normalizeVnSearch(`${ce.name} ${ce.note || ''} ${ce.day}/${ce.month} ${pad2(ce.day)}/${pad2(ce.month)} ${calLbl} ${kindLbl} ${ce.originYear || ''}`);
    if (matchesAllTokens(hay, tokens)) {
      ceHits.push({
        icon: ce.kind === 'gio' ? '🕯' : ce.kind === 'sinhnhat' ? '🎂' : '⭐',
        title: ce.name,
        sub: `Ngày ${ce.day}/${ce.month} ${ce.calendar === 'lunar' ? 'ÂL' : 'DL'}${ce.originYear ? ` • Năm ${ce.originYear}` : ''}${ce.note ? ` • ${ce.note}` : ''}`,
        action: { type: 'custom-event', id: ce.id }
      });
    }
  }
  if (ceHits.length > 0) {
    groups.push({ key: 'custom', label: `🕯 Ngày giỗ & Cá nhân (${ceHits.length})`, items: ceHits.slice(0, 10) });
  }

  // 4. Traditional Vietnamese Prayers (title, shortTitle, occasion, offerings, full template & date-aware match!)
  const dateRecommendedIds = new Set();
  if (dateParts) {
    const { d, mo, y, isLunar, isSolar } = dateParts;
    // Check recommended prayers when treating query as Lunar date (e.g. 1/1, 15/1, 1/11, 15/7, 23/12, 30/12)
    if (!isSolar && d <= 30) {
      const recLunar = getRecommendedPrayersForDate(
        { day: 0, month: 0, year: y },
        { day: d, month: mo, year: y, leap: false, monthLength: d === 29 ? 29 : 30 },
        []
      );
      if (recLunar.isSpecialRitualDay) {
        for (const id of recLunar.prayerIds) dateRecommendedIds.add(id);
      }
    }
    // Check recommended prayers when treating query as Solar date (e.g. 1/1 DL, 4/4, 5/4)
    if (!isLunar) {
      const recSolar = getRecommendedPrayersForDate(
        { day: d, month: mo, year: y },
        { day: 0, month: 0, year: y, leap: false, monthLength: 30 },
        []
      );
      if (recSolar.isSpecialRitualDay) {
        for (const id of recSolar.prayerIds) dateRecommendedIds.add(id);
      }
    }
  }

  const scoredPrayers = [];
  for (const p of PRAYERS_CATALOG || []) {
    const catLbl = PRAYER_CATEGORY_LABELS[p.category] || '';
    const extraTags = PRAYER_EXTRA_TAGS[p.id] || '';
    const primaryHay = normalizeVnSearch(`${p.title} ${p.shortTitle || ''} ${p.occasion || ''} ${catLbl}`);
    const secondaryHay = normalizeVnSearch(`${primaryHay} ${p.offerings || ''} ${extraTags} van khan bai khan cung le`);
    const fullHay = normalizeVnSearch(`${secondaryHay} ${p.template || ''}`);

    let score = 0;
    if (dateRecommendedIds.has(p.id)) {
      score = 4;
    } else if (matchesAllTokens(primaryHay, tokens)) {
      score = 3;
    } else if (matchesAllTokens(secondaryHay, tokens)) {
      score = 2;
    } else if (matchesAllTokens(fullHay, tokens)) {
      score = 1;
    }

    if (score > 0) {
      scoredPrayers.push({
        score,
        item: {
          icon: '🙏',
          title: p.title,
          sub: p.occasion || 'Bài văn khấn cổ truyền Việt Nam',
          action: { type: 'prayer', id: p.id }
        }
      });
    }
  }
  scoredPrayers.sort((a, b) => b.score - a.score);
  if (scoredPrayers.length > 0) {
    groups.push({
      key: 'prayers',
      label: `🙏 Văn khấn (${scoredPrayers.length})`,
      items: scoredPrayers.slice(0, 25).map((x) => x.item)
    });
  }

  // 4B. Dream Dictionary (Giải mã giấc mơ)
  const dreamHits = [];
  for (const dm of DREAMS_CATALOG || []) {
    const hay = normalizeVnSearch(`${dm.title} ${dm.keywords || ''} ${dm.meaning || ''} giai mong giac mo so mo`);
    if (matchesAllTokens(hay, tokens)) {
      dreamHits.push({
        icon: '🌙',
        title: dm.title,
        sub: `${dm.omenLabel} • Số tham khảo: ${dm.luckyNums}`,
        action: { type: 'dream', id: dm.id }
      });
    }
  }
  if (dreamHits.length > 0) {
    groups.push({ key: 'dreams', label: `🌙 Giải mã giấc mơ (${dreamHits.length})`, items: dreamHits.slice(0, 10) });
  }

  // 5. Highlighted Date Ranges
  const hlHits = [];
  for (const hl of state.highlightedRanges || []) {
    if (!hl) continue;
    const hay = normalizeVnSearch(`${hl.title} ${hl.note || ''} ${hl.startDate} ${hl.endDate}`);
    if (matchesAllTokens(hay, tokens)) {
      const [y, m, d] = (hl.startDate || '').split('-').map(Number);
      hlHits.push({
        icon: '🖍',
        title: hl.title,
        sub: `${hl.startDate} → ${hl.endDate}${hl.note ? ` • ${hl.note}` : ''}`,
        action: y && m && d ? { type: 'date', solar: { day: d, month: m, year: y } } : { type: 'nav', tab: 'reminders', sub: 'hl' }
      });
    }
  }
  if (hlHits.length > 0) {
    groups.push({ key: 'highlights', label: `🖍 Đánh dấu / Bôi màu (${hlHits.length})`, items: hlHits.slice(0, 8) });
  }

  // 6. Vietnamese Holidays (next 366 days)
  const upcomingHols = getUpcomingEvents(today, 366, [], {
    includeSolar: true,
    includeLunar: true,
    includeMung1Ram: true
  });
  const seenHol = new Set();
  const holHits = [];
  for (const ev of upcomingHols) {
    if (seenHol.has(ev.id)) continue;
    const solarStr = `${pad2(ev.solar.day)}/${pad2(ev.solar.month)}/${ev.solar.year}`;
    const lunarStr = `${ev.lunar.day}/${ev.lunar.month} âm lịch`;
    const hay = normalizeVnSearch(`${ev.name} ${ev.desc || ''} ${solarStr} ${lunarStr}`);
    if (matchesAllTokens(hay, tokens)) {
      seenHol.add(ev.id);
      holHits.push({
        icon: ev.type === 'solar' ? '🎆' : '🏮',
        title: ev.name,
        sub: `${solarStr} (DL) • ${ev.lunar.day}/${ev.lunar.month} ÂL • ${ev.daysUntil === 0 ? 'Hôm nay' : `Còn ${ev.daysUntil} ngày`}`,
        action: { type: 'date', solar: ev.solar }
      });
    }
  }
  if (holHits.length > 0) {
    groups.push({ key: 'holidays', label: `🏮 Lễ Tết & Mùng 1/Rằm (${holHits.length})`, items: holHits.slice(0, 8) });
  }

  // 7. Auspicious Task Finder
  const taskHits = [];
  for (const t of TASK_CATALOG || []) {
    const hay = normalizeVnSearch(`${t.label} ${t.id} xem ngay tot`);
    if (matchesAllTokens(hay, tokens)) {
      taskHits.push({
        icon: '🔮',
        title: `Xem ngày tốt: ${t.label}`,
        sub: 'Tra cứu ngày giờ Hoàng Đạo hợp tuổi cho công việc này',
        action: { type: 'auspicious', taskId: t.id }
      });
    }
  }
  if (taskHits.length > 0) {
    groups.push({ key: 'auspicious', label: `🔮 Chọn ngày tốt (${taskHits.length})`, items: taskHits.slice(0, 6) });
  }

  // 8. App Features & Settings Shortcuts
  const scHits = APP_SHORTCUTS.filter((sc) =>
    matchesAllTokens(normalizeVnSearch(`${sc.title} ${sc.sub} ${sc.keywords}`), tokens)
  );
  if (scHits.length > 0) {
    groups.push({ key: 'shortcuts', label: `⚙️ Chức năng & Cài đặt (${scHits.length})`, items: scHits.slice(0, 8) });
  }

  return groups;
}
