/**
 * Shared Telegram Bot API helper (used by both popup.js and background.js)
 * NOTE: Never use encodeURIComponent() on botToken — Telegram requires the literal ":" between bot ID and secret!
 */

export function escapeTelegramHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function sanitizeBotToken(rawToken) {
  return String(rawToken || '')
    .trim()
    .replace(/^bot/i, '')
    .replace(/[^a-zA-Z0-9:_-]/g, '');
}

/**
 * Send HTML-formatted message to a Telegram chat or group
 */
export async function sendTelegramApiMessage({ botToken, chatId, htmlText }) {
  const token = sanitizeBotToken(botToken);
  const cid = String(chatId || '').trim();

  if (!token || !token.includes(':')) {
    return {
      ok: false,
      error: 'Bot Token không đúng định dạng (phải có dấu ":" từ @BotFather, VD: 123456:ABC...).'
    };
  }
  if (!cid) {
    return {
      ok: false,
      error: 'Chưa nhập Chat ID nhóm Telegram.'
    };
  }

  try {
    const resp = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: cid,
        text: htmlText,
        parse_mode: 'HTML',
        disable_web_page_preview: true
      })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.ok) {
      return {
        ok: false,
        error: `Telegram báo lỗi: ${data.description || `HTTP ${resp.status}`}`
      };
    }
    return { ok: true, messageId: data.result?.message_id };
  } catch (err) {
    return { ok: false, error: `Lỗi kết nối Telegram: ${err?.message || 'kiểm tra mạng hoặc Reload tiện ích'}` };
  }
}

/**
 * Auto-detect recent Telegram groups/supergroups/channels/DMs from getUpdates
 */
export async function detectTelegramChatsApi(rawToken) {
  const token = sanitizeBotToken(rawToken);
  if (!token || !token.includes(':')) {
    return {
      ok: false,
      error: 'Bot Token không đúng định dạng (phải có dấu ":" từ @BotFather).'
    };
  }

  try {
    // offset=-30 returns the most recent 30 updates even if bot has old backlog
    const resp = await fetch(`https://api.telegram.org/bot${token}/getUpdates?offset=-30&limit=30`);
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.ok) {
      return {
        ok: false,
        error: `Lỗi Telegram: ${data.description || `HTTP ${resp.status}`}`
      };
    }

    const chatMap = new Map();
    for (const upd of data.result || []) {
      const chat =
        upd.message?.chat ||
        upd.edited_message?.chat ||
        upd.channel_post?.chat ||
        upd.my_chat_member?.chat ||
        upd.chat_member?.chat ||
        upd.callback_query?.message?.chat;
      if (!chat || chat.id === undefined) continue;
      const idStr = String(chat.id);
      const title =
        chat.title ||
        [chat.first_name, chat.last_name].filter(Boolean).join(' ') ||
        chat.username ||
        idStr;
      chatMap.set(idStr, { id: idStr, title, type: chat.type || 'unknown' });
    }

    // Put groups/supergroups first, then channels, then private DMs
    const chats = Array.from(chatMap.values()).sort((a, b) => {
      const rank = (t) => (t === 'supergroup' || t === 'group' ? 0 : t === 'channel' ? 1 : 2);
      return rank(a.type) - rank(b.type);
    });

    if (chats.length === 0) {
      return {
        ok: false,
        error: 'Chưa thấy tin nhắn nào tới Bot. Hãy thêm Bot vào nhóm rồi gõ /start@ten_bot trong nhóm, sau đó bấm lại!'
      };
    }

    return { ok: true, chats };
  } catch (err) {
    return {
      ok: false,
      error: `Không gọi được Telegram API (${err?.message || 'lỗi mạng'}). Hãy Reload (⟳) tiện ích trên chrome://extensions/ rồi thử lại.`
    };
  }
}
