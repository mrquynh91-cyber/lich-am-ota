/**
 * Traditional Vietnamese Văn Khấn (Prayers / Ritual Invocations) Library
 * Dynamically fills the selected Lunar date, Can Chi year/month/day, and optional homeowner info.
 */

import {
  LUNAR_MONTH_NAMES,
  getYearCanChi,
  getMonthCanChi,
  getDayCanChi
} from './lunar.js';

export const DEFAULT_PRAYER_PREFS = {
  homeownerName: '',
  address: '',
  fontSize: 14,
  autoOpenOnSpecialDay: true
};

export const PRAYER_CATEGORIES = [
  { id: 'recommended', label: 'Gợi ý ngày chọn' },
  { id: 'all', label: 'Tất cả' },
  { id: 'mung1_ram', label: 'Mùng 1 & Rằm' },
  { id: 'le_tet', label: 'Lễ Tết' },
  { id: 'cong_viec', label: 'Hiếu sự & Công việc' }
];

export const PRAYERS_CATALOG = [
  {
    id: 'ram-tho-cong',
    category: 'mung1_ram',
    title: 'Văn khấn Thổ Công & Chư Vị Tôn Thần (Mùng 1 / Ngày Rằm)',
    shortTitle: 'Thổ Công (M1 / Rằm)',
    occasion: 'Ngày Mùng 1 và Ngày Rằm (15 Âm lịch) hàng tháng',
    offerings: 'Hương hoa tươi, trầu cau, ngũ quả, nước sạch, trà, rượu trắng, xôi chè hoặc lễ mặn tùy tâm gia chủ.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Đông Trù Tư mệnh Táo phủ Thần quân.
Con kính lạy ngài Bản gia Thổ địa Long Mạch Tôn thần.
Con kính lạy các ngài Ngũ phương, Ngũ thổ, Phúc đức Tôn thần.
Con kính lạy ngài Tiền hậu Địa chủ Tài thần.
Con kính lạy các Tôn thần cai quản trong khu vực này.

Tín chủ (chúng) con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch), gặp tiết {{OCCASION_LABEL}}.
Tín chủ con thành tâm sửa biện hương hoa, lễ vật, trà quả và các thứ cúng dâng, bày lên trước án.

Chúng con thành tâm kính mời:
Ngài Kim Niên Đương cai Thái Tuế chí đức Tôn thần, ngài Bản cảnh Thành hoàng Chư vị Đại Vương, ngài Đông Trù Tư mệnh Táo phủ Thần quân, ngài Bản gia Thổ địa Long Mạch Tôn thần, các ngài Ngũ phương, Ngũ thổ, Phúc đức chính thần, các vị Tôn thần cai quản trong khu vực này.

Cúi xin các Ngài nghe thấu lời mời, thương xót tín chủ, giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật.
Phù hộ độ trì cho toàn gia chúng con luôn luôn mạnh khỏe, mọi sự bình an, vạn sự tốt lành, gia đạo hưng long thịnh vượng, lộc tài tăng tiến, tâm đạo mở mang, sở cầu tất ứng, sở nguyện tòng tâm.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'ram-gia-tien',
    category: 'mung1_ram',
    title: 'Văn khấn Gia Tiên (Mùng 1 / Ngày Rằm)',
    shortTitle: 'Gia Tiên (M1 / Rằm)',
    occasion: 'Ngày Mùng 1 và Ngày Rằm (15 Âm lịch) hàng tháng',
    offerings: 'Hương, hoa tươi, đèn nến, trầu cau, đĩa trái cây, nước lọc, chén trà hoặc mâm cơm cúng gia tiên.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, Thúc Bá Đệ Huynh, Cô Di Tỷ Muội họ nội, họ ngoại.

Tín chủ (chúng) con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (ngày {{DAY_CAN_CHI}}, tháng {{MONTH_CAN_CHI}}).
Gặp tiết {{OCCASION_LABEL}}, tín chủ con nhờ ơn đức Trời Đất, Chư vị Tôn thần và Tổ tiên phù hộ, nay thành tâm sửa biện hương hoa, lễ vật, trà quả thắp nén tâm hương dâng lên trước án.

Chúng con kính mời:
Bản gia Tiên tổ, Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, Bá Thúc Huynh Đệ, Cô Di Tỷ Muội và các hương linh nội ngoại đồng lai hâm hưởng.

Cúi xin Tổ tiên thương xót con cháu, linh thiêng hiện về, chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho con cháu trong nhà được mạnh khỏe bình an, hòa thuận hiếu thảo, học hành tấn tới, công việc hanh thông, vạn sự cát tường.

Tín chủ con lại xin kính mời các vị Tiền chủ, Hậu chủ ngụ tại đất này cùng về thụ hưởng lễ vật, phù hộ cho gia trung yên ổn.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'ram-thang-gieng',
    category: 'le_tet',
    title: 'Văn khấn Rằm tháng Giêng (Tết Nguyên Tiêu — 15/1 ÂL)',
    shortTitle: 'Rằm tháng Giêng',
    occasion: 'Ngày 15 tháng Giêng (Tết Nguyên Tiêu / Lễ Thượng Nguyên)',
    offerings: 'Hương hoa, đèn nến, trầu cau, ngũ quả, bánh trôi nước, xôi gấc, chè, lễ chay cúng Phật và lễ mặn cúng Gia tiên.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, chư vị Hương linh gia tiên nội ngoại.

Tín chủ (chúng) con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Rằm tháng Giêng năm {{YEAR_CAN_CHI}}, gặp tiết Nguyên Tiêu (Lễ Thượng Nguyên đầu năm).
Tín chủ con lòng thành sửa biện hương đăng, hoa quả, trà thực dâng lên trước án.

Cúi xin Chư vị Tôn thần và Gia tiên tiền tổ giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật.
Cầu xin năm mới {{YEAR_CAN_CHI}} mưa thuận gió hòa, gia đạo bình an, sức khỏe dồi dào, tiêu trừ tai ách, công danh sự nghiệp hanh thông, tài lộc vượng tiến, vạn sự như ý.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'than-tai',
    category: 'le_tet',
    title: 'Văn khấn Ngày Vía Thần Tài (Mùng 10 tháng Giêng & hàng tháng)',
    shortTitle: 'Vía Thần Tài',
    occasion: 'Ngày Mùng 10 tháng Giêng (Vía Thần Tài) và mùng 10 Âm lịch hàng tháng',
    offerings: 'Hoa cúc/đồng tiền, ngũ quả, bộ tam sên (thịt luộc, trứng luộc, tôm/cua), cá lóc nướng (tùy vùng), trà, rượu, nước sạch, vàng mã.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Đông Trù Tư mệnh Táo phủ Thần quân.
Con kính lạy ngài Thần Tài vị tiền.
Con kính lạy các ngài Thần linh, Thổ địa cai quản trong xứ này.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}}.
Tín chủ con thành tâm sửa biện hương hoa, lễ vật, kim ngân, trà quả và các thứ cúng dâng, bày ra trước án kính mời ngài Thần Tài vị tiền và ngài Thổ Địa chính thần.

Cúi xin các Ngài thương xót tín chủ, giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật.
Phù trì cho tín chủ con an ninh khang thái, vạn sự tốt lành, gia đạo hưng long thịnh vượng, buôn may bán đắt, khách hàng tấp nập, công việc thuận lợi, lộc tài tăng tiến, tâm đạo mở mang, sở cầu tất ứng, sở nguyện tòng tâm.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'han-thuc',
    category: 'le_tet',
    title: 'Văn khấn Tết Hàn Thực / Tiết Thanh Minh (3/3 ÂL)',
    shortTitle: 'Tết Hàn Thực (3/3)',
    occasion: 'Ngày Mùng 3 tháng 3 Âm lịch (Tết Hàn Thực / Thanh Minh)',
    offerings: 'Bánh trôi, bánh chay, hương hoa tươi, trầu cau, ngũ quả, trà, nước sạch.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, Thúc Bá Đệ Huynh, Cô Di Tỷ Muội họ nội, họ ngoại.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Mùng 3 tháng Ba năm {{YEAR_CAN_CHI}}, nhân tiết Hàn Thực (Thanh Minh), tín chủ con nhớ công ơn sinh thành dưỡng dục của Tổ tiên, thành tâm sửa biện hương hoa, bánh trôi bánh chay, trà quả dâng lên trước án.

Kính mời Chư vị Tôn thần và Gia tiên nội ngoại giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật.
Cúi xin Tổ tiên phù hộ độ trì cho con cháu trong gia đình mạnh khỏe, bình an, hòa thuận, vạn sự hanh thông tốt lành.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'doan-ngo',
    category: 'le_tet',
    title: 'Văn khấn Tết Đoan Ngọ (Mùng 5 tháng 5 ÂL)',
    shortTitle: 'Tết Đoan Ngọ (5/5)',
    occasion: 'Ngày Mùng 5 tháng 5 Âm lịch (Tết Đoan Ngọ — Giữa năm)',
    offerings: 'Cơm rượu nếp, bánh ú tro, trái cây mùa hè (mận, vải, dưa hấu...), hương hoa, nước sạch, trà.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Tổ tiên, Hiển khảo, Hiển tỷ, chư vị Hương linh gia tiên nội ngoại.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Mùng 5 tháng Năm năm {{YEAR_CAN_CHI}}, nhân tiết Đoan Ngọ giữa năm, tín chủ con thành tâm sửa biện hương hoa, rượu nếp, bánh trái, lễ vật dâng lên trước án.

Kính mời Chư vị Tôn thần và Gia tiên tiền tổ giáng lâm chứng giám lòng thành, thụ hưởng lễ vật.
Cúi xin phù hộ độ trì cho toàn gia mạnh khỏe, tiêu trừ bệnh tật, tránh khỏi tai ương, công việc hanh thông, mùa màng thuận lợi, gia đạo an khang.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'vu-lan-gia-tien',
    category: 'le_tet',
    title: 'Văn khấn Lễ Vu Lan — Rằm tháng 7 (Cúng Gia Tiên)',
    shortTitle: 'Vu Lan — Gia Tiên',
    occasion: 'Ngày Rằm tháng 7 (15/7 Âm lịch — Lễ Vu Lan Báo Hiếu)',
    offerings: 'Hương hoa, đèn nến, ngũ quả, trầu cau, mâm cơm chay hoặc mặn, chè xôi, nước sạch, vàng mã (tùy tâm).',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Đức Địa Tạng Vương Bồ Tát, Đức Mục Kiền Liên Tôn Giả.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Tổ tiên nội ngoại, Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Rằm tháng Bảy năm {{YEAR_CAN_CHI}}, gặp tiết Trung Nguyên — mùa Vu Lan báo hiếu, Xá tội vong nhân.
Nhớ ơn sâu nghĩa nặng của Tổ tiên, cha mẹ nhiều đời, tín chủ con thành tâm sửa biện hương hoa, trà quả, cơm canh lễ vật dâng lên trước án.

Kính mời Gia tiên tiền tổ nội ngoại chư vị hương linh giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật.
Cầu nguyện cho cửu huyền thất tổ siêu sinh tịnh độ, cha mẹ hiện tiền tăng long phúc thọ, toàn gia mạnh khỏe bình an, con cháu hiếu thuận, vạn sự tốt lành.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'vu-lan-chung-sinh',
    category: 'le_tet',
    title: 'Văn khấn Cúng Chúng Sinh / Cô Hồn (Tháng 7 ÂL)',
    shortTitle: 'Cúng Chúng Sinh (Rằm 7)',
    occasion: 'Rằm tháng 7 (từ mùng 2 đến 15/7 Âm lịch — Cúng ngoài sân/trước cửa)',
    offerings: 'Muối gạo (1 đĩa), cháo trắng loãng (12 chén nhỏ), bánh kẹo, bỏng ngô, khoai luộc, mía chặt khúc, nước sạch, hương, nến.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy Đức Phật A Di Đà, Đức Quán Thế Âm Bồ Tát, Đức Địa Tạng Vương Bồ Tát.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, các vị Tôn thần cai quản khu vực này.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, tháng Bảy năm {{YEAR_CAN_CHI}}, nhân tiết Trung Nguyên xá tội vong nhân.
Tín chủ con thành tâm sắm sửa cháo loãng, muối gạo, bánh trái, hương đăng bày ra trước cửa/ngoài sân, kính mời các chư vị cô hồn, thập loại chúng sinh không nơi nương tựa ở quanh vùng này đồng lai thụ hưởng.

Xin các vị hoan hỷ thọ thực vật phẩm, lòng sinh từ bi, sớm được siêu thoát về cõi lành, phù hộ cho gia chủ chúng con bình an, mạnh khỏe, làm ăn thuận lợi, mọi sự hanh thông.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'trung-thu',
    category: 'le_tet',
    title: 'Văn khấn Tết Trung Thu (Rằm tháng 8 — 15/8 ÂL)',
    shortTitle: 'Tết Trung Thu (15/8)',
    occasion: 'Ngày Rằm tháng Tám (15/8 Âm lịch — Tết Đoàn Viên)',
    offerings: 'Bánh nướng, bánh dẻo, cốm, mâm ngũ quả (bưởi, hồng, na, chuối...), trà sen, hương hoa tươi.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, chư vị Hương linh gia tiên nội ngoại.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Rằm tháng Tám năm {{YEAR_CAN_CHI}}, gặp tiết Trung Thu — Tết Đoàn Viên.
Tín chủ con thành tâm sửa biện hương hoa, trà quả, bánh Trung thu, cốm mới dâng lên trước án.

Kính mời Chư vị Tôn thần và Gia tiên nội ngoại giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật.
Cúi xin phù hộ độ trì cho gia đình sum vầy hạnh phúc, người lớn khỏe mạnh, trẻ nhỏ chăm ngoan học giỏi, mọi sự bình an tốt lành.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'ha-nguyen',
    category: 'le_tet',
    title: 'Văn khấn Tết Hạ Nguyên / Cơm Mới (Rằm tháng 10 — 15/10 ÂL)',
    shortTitle: 'Tết Hạ Nguyên (15/10)',
    occasion: 'Ngày Rằm tháng Mười (15/10 Âm lịch — Tết Cơm Mới / Hạ Nguyên)',
    offerings: 'Cơm gạo mới, xôi mới, bánh dày/bánh trôi, hương hoa tươi, trầu cau, ngũ quả, trà, nước sạch.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, chư vị Hương linh gia tiên nội ngoại.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Rằm tháng Mười năm {{YEAR_CAN_CHI}} (ngày {{DAY_CAN_CHI}}, tháng {{MONTH_CAN_CHI}}), gặp tiết Hạ Nguyên — Tết Cơm Mới.
Nhớ ơn Trời Đất cho mưa thuận gió hòa, nhớ công ơn Tổ tiên phù hộ, tín chủ con thành tâm nấu cơm gạo mới, sửa biện hương hoa, trà quả, lễ vật dâng lên trước án.

Kính mời Chư vị Tôn thần và Gia tiên nội ngoại giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật.
Cúi xin phù hộ độ trì cho gia đạo bình an, sức khỏe dồi dào, cuối năm công việc viên mãn, tài lộc sung túc, vạn sự cát tường.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'ong-tao',
    category: 'le_tet',
    title: 'Văn khấn Ông Công Ông Táo (23 tháng Chạp)',
    shortTitle: 'Ông Công Ông Táo (23/12)',
    occasion: 'Ngày 23 tháng Chạp (Tiễn Táo Quân chầu Trời — cúng trước 12h trưa)',
    offerings: 'Hương hoa, trầu cau, ngũ quả, 3 con cá chép sống (phóng sinh sau lễ), mũ áo Táo Quân, xôi gà hoặc mâm cơm cúng, trà rượu.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Ngài Đông Trù Tư mệnh Táo phủ Thần quân.

Tín chủ (chúng) con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày 23 tháng Chạp năm {{YEAR_CAN_CHI}}, tín chủ chúng con thành tâm sắp sửa hương hoa phẩm vật, xiêm hài áo mũ, cá chép, trà quả dâng lên trước án, kính cẩn tiễn Ngài Đông Trù Tư mệnh Táo phủ Thần quân lên chầu Thượng Đế.

Cảm tạ Ngài suốt một năm qua đã phù hộ độ trì cho toàn gia chúng con yên ấm, mạnh khỏe.
Cúi xin Ngài gia ân xá tội cho mọi lỗi lầm trong năm qua của gia chủ, lên tâu với Ngọc Hoàng Thượng Đế những điều tốt lành, cầu xin ban phúc lộc, bình an cho cả gia đình trong năm mới.

Chúng con lễ bạc tâm thành, cúi xin kính lễ tiễn Ngài, mong được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'tat-nien',
    category: 'le_tet',
    title: 'Văn khấn Lễ Tất Niên (Chiều 29 / 30 tháng Chạp)',
    shortTitle: 'Lễ Tất Niên',
    occasion: 'Chiều 29 hoặc 30 tháng Chạp (Cúng Tất niên tiễn năm cũ)',
    offerings: 'Mâm ngũ quả, hoa đào/hoa mai/cúc, hương đèn, trầu cau, bánh chưng, mâm cỗ mặn (gà luộc, xôi, nem, canh măng...) hoặc cỗ chay.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Kim Niên Đương cai Thái Tuế chí đức Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, chư vị Hương linh gia tiên nội ngoại.

Tín chủ (chúng) con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, tháng Chạp năm {{YEAR_CAN_CHI}} — ngày Tất Niên cuối năm.
Theo lệ cổ truyền, tín chủ con thành tâm sửa biện hương hoa, lễ vật, mâm cơm Tất niên dâng lên trước án, tạ ơn Chư vị Tôn thần và Gia tiên đã che chở suốt một năm qua, đồng thời kính mời Tổ tiên nội ngoại về sum họp đón Xuân cùng con cháu.

Cúi xin Chư vị Tôn thần và Gia tiên chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho toàn gia đón năm mới an khang thịnh vượng, sức khỏe dồi dào, vạn sự như ý.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'giao-thua-ngoai',
    category: 'le_tet',
    title: 'Văn khấn Giao Thừa Ngoài Trời (Đêm 30 Tết)',
    shortTitle: 'Giao Thừa Ngoài Trời',
    occasion: 'Đúng giờ Tý (23h–1h) đêm Giao Thừa — Cúng ngoài sân / ban công',
    offerings: 'Bàn lễ đặt ngoài trời: gà trống luộc, bánh chưng, xôi, mâm ngũ quả, hương hoa, đèn nến, trầu cau, trà, rượu, muối gạo.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con kính lạy Đức Đương lai hạ sinh Di Lặc Tôn Phật.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy Ngài Cựu niên Đương cai Hành khiển, Hành binh chi thần, Phán quan năm cũ.
Con kính lạy Ngài Đương niên Hành khiển, Hành binh chi thần, Phán quan năm mới.
Con kính lạy các ngài Ngũ phương, Ngũ thổ, Long mạch, Táo quân, chư vị Tôn thần cai quản trong khu vực này.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Nay phút Giao Thừa thiêng liêng chuyển giao năm cũ sang năm mới.
Tín chủ con thành tâm sửa biện hương hoa, lễ vật dâng lên trước án, kính tiễn vị Thần năm cũ và nghênh đón vị Thần năm mới giáng lâm cai quản hạ giới.

Cúi xin các Ngài chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho toàn gia chúng con năm mới mạnh khỏe bình an, gia đạo hưng thịnh, công việc hanh thông, tài lộc dồi dào, mọi sự tốt lành.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'giao-thua-trong',
    category: 'le_tet',
    title: 'Văn khấn Giao Thừa Trong Nhà',
    shortTitle: 'Giao Thừa Trong Nhà',
    occasion: 'Đêm Giao Thừa (sau khi cúng ngoài trời xong)',
    offerings: 'Mâm ngũ quả, bánh chưng, xôi, mứt Tết, hương hoa, đèn nến, trầu cau, rượu trà đặt trên bàn thờ gia tiên.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Đức Đương lai hạ sinh Di Lặc Tôn Phật.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Tổ tiên nội ngoại, Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Phút Giao Thừa vừa điểm, năm cũ đã qua, năm mới đã tới.
Tín chủ con cùng toàn thể gia quyến thành tâm thắp nén hương thơm, dâng lễ vật trước án, kính mời Chư vị Tôn thần và Gia tiên tiền tổ cùng về vui Tết đón Xuân với con cháu.

Cúi xin phù hộ độ trì cho gia đình năm mới bình an, khỏe mạnh, hòa thuận, phát tài phát lộc, vạn sự cát tường như ý.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'mung1-tet',
    category: 'le_tet',
    title: 'Văn khấn Mùng 1 Tết Nguyên Đán',
    shortTitle: 'Mùng 1 Tết',
    occasion: 'Sáng Mùng 1 tháng Giêng (Ngày đầu năm mới Âm lịch)',
    offerings: 'Mâm ngũ quả, bánh chưng, mứt Tết, hương hoa tươi, đèn nến, trà, rượu, mâm cỗ đầu xuân.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Đức Đương lai hạ sinh Di Lặc Tôn Phật.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy Ngài Đương niên Thái Tuế chí đức Tôn thần năm {{YEAR_CAN_CHI}}.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, Tiên tổ nội ngoại chư vị Hương linh.

Tín chủ (chúng) con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Mùng 1 tháng Giêng, năm {{YEAR_CAN_CHI}} — ngày Nguyên Đán đầu Xuân.
Tín chủ con cùng toàn thể gia quyến thành tâm sửa biện hương hoa, lễ vật, mâm cỗ đầu năm dâng lên trước án, kính chúc Tân Xuân và mời Chư vị Tôn thần, Gia tiên tiền tổ giáng lâm chứng giám, thụ hưởng lễ vật.

Cúi xin phù hộ độ trì cho toàn gia trong năm mới {{YEAR_CAN_CHI}} luôn dồi dào sức khỏe, an khang thịnh vượng, công danh thăng tiến, tài lộc hanh thông, gia đạo hòa thuận, vạn sự cát tường.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'hoa-vang',
    category: 'le_tet',
    title: 'Văn khấn Lễ Hóa Vàng (Mùng 3 Tết)',
    shortTitle: 'Hóa Vàng (Mùng 3)',
    occasion: 'Ngày Mùng 3 Tết (hoặc Mùng 4, Mùng 5 tùy gia đình — Tiễn Tổ tiên)',
    offerings: 'Mâm cỗ mặn/chay, bánh chưng, mâm ngũ quả, hương hoa, trầu cau, trà rượu, tiền vàng mã.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, Tiên tổ nội ngoại chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, tháng Giêng năm {{YEAR_CAN_CHI}}.
Tín chủ con thành tâm sửa biện hương hoa, lễ vật, kim ngân tiền vàng dâng lên trước án, làm lễ tạ ơn và hóa vàng tiễn chân Chư vị Tôn thần cùng Gia tiên nội ngoại sau những ngày sum họp đón Xuân cùng con cháu.

Cúi xin Gia tiên và Chư vị Tôn thần chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho toàn gia năm mới {{YEAR_CAN_CHI}} bình an, mạnh khỏe, làm ăn phát đạt, vạn sự hanh thông.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'ngay-gio',
    category: 'cong_viec',
    title: 'Văn khấn Ngày Giỗ (Cát Kỵ / Giỗ Thường)',
    shortTitle: 'Ngày Giỗ',
    occasion: 'Ngày giỗ hàng năm của Ông Bà, Cha Mẹ, Người thân',
    offerings: 'Hương hoa tươi, trầu cau, đĩa trái cây, nước sạch, trà, rượu, mâm cơm cúng ngày giỗ.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Tổ tiên nội ngoại chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (ngày {{SOLAR_FULL}} Dương lịch), chính ngày húy nhật (ngày giỗ) của: [Ghi rõ vai vế & họ tên người đã khuất].

Nhớ công ơn sinh thành dưỡng dục (hoặc tình nghĩa sâu nặng), toàn thể con cháu gia quyến hôm nay tụ họp đông đủ, thành tâm sửa biện hương hoa, trà quả, mâm cơm canh dâng lên trước án.

Kính mời hương linh [Vai vế & họ tên người được cúng giỗ] cùng liệt vị Gia tiên nội ngoại đồng lai chứng giám lòng thành, thụ hưởng lễ vật.
Cầu nguyện hương linh an nghỉ cõi vĩnh hằng, sớm siêu sinh miền cực lạc, và phù hộ độ trì cho con cháu trong gia đình mạnh khỏe, hòa thuận, bình an, ăn nên làm ra.

Chúng con lễ bạc tâm thành, trước án kính lễ.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'khai-truong',
    category: 'cong_viec',
    title: 'Văn khấn Khai Trương Cửa Hàng / Công Ty',
    shortTitle: 'Khai Trương',
    occasion: 'Ngày khai trương cửa hàng, văn phòng, đầu xuân mở hàng',
    offerings: 'Hoa tươi (đồng tiền/cúc), mâm ngũ quả, trầu cau, hương đèn, xôi gà hoặc heo quay, trà rượu, muối gạo, vàng mã.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Quan Đương niên Hành khiển Thái Tuế chí đức Tôn thần.
Con kính lạy các ngài Bản cảnh Thành hoàng chư vị Đại Vương.
Con kính lạy các ngài Ngũ phương, Ngũ thổ, Long mạch, Tài thần, Định phúc Táo quân, các ngài Địa chủ cai quản trong khu vực này.

Tín chủ con là: {{HOMEOWNER}}
Địa chỉ kinh doanh: {{ADDRESS}}

Hôm nay là ngày lành tháng tốt: ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch).
Tín chủ con thành tâm sắm sửa hương hoa, lễ vật, trà quả bày ra trước án, kính cáo Chư vị Tôn thần nhân dịp khai trương [Tên cửa hàng / Công ty].

Cúi xin các Ngài giáng lâm trước án, chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho việc kinh doanh buôn bán của chúng con được khai trương hồng phát, khách hàng tấp nập, đối tác thuận hòa, tài lộc vượng tiến, vạn sự hanh thông tốt lành.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'nhap-trach',
    category: 'cong_viec',
    title: 'Văn khấn Nhập Trạch (Về Nhà Mới)',
    shortTitle: 'Nhập Trạch',
    occasion: 'Ngày tốt chuyển về nhà mới / căn hộ mới',
    offerings: 'Mâm ngũ quả, hương hoa tươi, trầu cau, đèn nến, muối gạo nước, bếp/ấm đun nước sôi pha trà, xôi gà hoặc mâm cỗ.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy các ngài Thần linh, Bản gia Thổ địa, Long mạch, Táo quân cai quản trong xứ này.
Con kính lạy Gia tiên nội ngoại chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Cùng toàn thể gia quyến chuyển về nơi ở mới tại: {{ADDRESS}}

Hôm nay là ngày lành tháng tốt: ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch).
Tín chủ con thành tâm sửa biện hương hoa, lễ vật, trà quả dâng lên trước án, làm lễ Nhập Trạch kính cáo Chư vị Tôn thần và rước Gia tiên tiền tổ về ngự tại ngôi nhà mới.

Cúi xin Chư vị Tôn thần và Gia tiên chứng giám lòng thành, thụ hưởng lễ vật, cho phép gia đình chúng con được an cư lạc nghiệp tại đây.
Phù hộ độ trì cho toàn gia luôn mạnh khỏe, bình an, hòa thuận, công việc hanh thông, tài lộc thịnh vượng, mọi sự tốt lành.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'dong-tho',
    category: 'cong_viec',
    title: 'Văn khấn Động Thổ / Sửa Chữa Nhà Cửa',
    shortTitle: 'Động Thổ / Sửa Nhà',
    occasion: 'Ngày khởi công xây dựng, động thổ, sửa chữa nhà cửa',
    offerings: 'Hoa tươi, ngũ quả, trầu cau, hương đèn, muối gạo, nước sạch, rượu trắng, gà luộc + xôi (hoặc bộ tam sên).',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy Quan Đương niên Thái Tuế chí đức Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, Long mạch, Định phúc Táo quân và các vị Thần linh cai quản khu vực này.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại / Địa điểm thi công: {{ADDRESS}}

Hôm nay là ngày lành tháng tốt: ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch).
Tín chủ con thành tâm sửa biện hương hoa, lễ vật dâng lên trước án, kính cáo Chư vị Tôn thần xin phép được khởi công động thổ / sửa chữa công trình tại mảnh đất này.

Cúi xin các Ngài chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho quá trình thi công được thuận buồm xuôi gió, thợ thuyền bình an, công trình bền vững đẹp đẽ, hoàn thành đúng tiến độ, gia đạo an khang.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'tet-duong-lich',
    category: 'le_tet',
    title: 'Văn khấn Tết Dương Lịch (01/01 Dương lịch)',
    shortTitle: 'Tết Dương Lịch (1/1 DL)',
    occasion: 'Ngày Mùng 1 tháng 1 Dương lịch (Đầu năm mới Dương lịch)',
    offerings: 'Hương hoa tươi, ngũ quả, trầu cau, nước sạch, trà, bánh kẹo hoặc mâm cơm đầu năm mới.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Tổ tiên nội ngoại, Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, chư vị Hương linh.

Tín chủ (chúng) con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{SOLAR_FULL}} Dương lịch (tức ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} Âm lịch), nhân dịp đầu năm mới Dương lịch.
Tín chủ con thành tâm sửa biện hương hoa, lễ vật, trà quả dâng lên trước án, tạ ơn Trời Đất, Chư vị Tôn thần và Gia tiên đã che chở trong năm qua.

Cúi xin Chư vị Tôn thần và Gia tiên chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho toàn gia bước sang năm mới luôn mạnh khỏe bình an, công việc thuận lợi, tài lộc hanh thông, vạn sự tốt lành.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'mung2-tet',
    category: 'le_tet',
    title: 'Văn khấn Mùng 2 Tết Nguyên Đán',
    shortTitle: 'Mùng 2 Tết',
    occasion: 'Ngày Mùng 2 tháng Giêng (Tết Nguyên Đán — Cúng Thần Linh & Gia Tiên)',
    offerings: 'Mâm cơm cúng Tết (bánh chưng, xôi, gà luộc, canh măng...), hương hoa tươi, trầu cau, ngũ quả, trà, rượu.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, Tiên tổ nội ngoại chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Mùng 2 tháng Giêng năm {{YEAR_CAN_CHI}}, những ngày đầu Xuân năm mới.
Tín chủ con cùng toàn thể gia quyến thành tâm sửa biện hương hoa, trà quả, mâm cơm đầu xuân dâng lên trước án kính mời Chư vị Tôn thần và Gia tiên tiền tổ nội ngoại đồng lai hâm hưởng.

Cúi xin phù hộ độ trì cho toàn gia năm mới {{YEAR_CAN_CHI}} an khang thịnh vượng, sức khỏe dồi dào, họ hàng nội ngoại hòa thuận yên vui, công danh sự nghiệp hanh thông, vạn sự cát tường.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'cung-sao-giai-han',
    category: 'le_tet',
    title: 'Văn khấn Cúng Sao Giải Hạn Đầu Năm (Tháng Giêng)',
    shortTitle: 'Cúng Sao Giải Hạn',
    occasion: 'Đầu xuân tháng Giêng (Mùng 8, Rằm tháng Giêng hoặc ngày sao đăng viên hàng tháng)',
    offerings: 'Hương hoa tươi, trầu cau, ngũ quả, nước sạch, trà, gạo muối, nến/đèn tùy theo sao chiếu mệnh.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Đức Hiệu Thiên chí tôn Kim Quyết Ngọc Hoàng Thượng Đế.
Con kính lạy Đức Trung Thiên Tinh Chúa Bắc Cực Tử Vi Trường Sinh Đại Đế.
Con kính lạy ngài Tả Nam Tào Lục Ty Duyên Thọ Tinh Quân.
Con kính lạy ngài Hữu Bắc Đẩu Cửu Hàm Giải Ách Tinh Quân.
Con kính lạy các vị Tinh Quân bản mệnh chiếu mệnh trong năm {{YEAR_CAN_CHI}}.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch).
Tín chủ con thành tâm sửa biện hương đăng, hoa quả, lễ vật dâng lên trước án, kính lễ chư vị Tinh Quân cầu xin giải trừ vận hạn, tiêu tai giảm ách.

Cúi xin các Ngài chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho tín chủ con cùng toàn thể gia quyến trong năm {{YEAR_CAN_CHI}} được thân tâm an lạc, tai qua nạn khỏi, bệnh tật tiêu trừ, sức khỏe dồi dào, công việc thuận buồm xuôi gió, gia đạo bình an.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'ta-mo-thanh-minh',
    category: 'le_tet',
    title: 'Văn khấn Tảo Mộ Tiết Thanh Minh (Ngoài Nghĩa Trang)',
    shortTitle: 'Tảo Mộ Thanh Minh',
    occasion: 'Tiết Thanh Minh (khoảng 4–5/4 Dương lịch hoặc đầu tháng 3 Âm lịch)',
    offerings: 'Hương hoa tươi, trầu cau, đĩa trái cây, nước sạch, trà, rượu trắng, xôi/gà hoặc bánh chưng, vàng mã đặt tại phần mộ.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con kính lạy ngài Kim Niên Đương cai Thái Tuế chí đức Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng Chư vị Đại Vương.
Con kính lạy ngài Bản xứ Thần linh Thổ địa Tôn thần cai quản khu vực phần mộ này.
Con kính lạy các ngài Ngũ phương, Ngũ thổ, Long Mạch, Tiền Chu Tước, Hậu Huyền Vũ, Tả Thanh Long, Hữu Bạch Hổ và chư vị Tôn thần cai quản trong xứ này.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch), nhân tiết Thanh Minh.
Toàn thể con cháu chúng con thành tâm sắm sửa hương hoa, lễ vật, trà quả đến tại phần mộ của [Ghi tên Tổ tiên / Ông Bà / Cha Mẹ...] để phát quang cỏ rậm, đắp sửa phần mộ khang trang, dâng lễ tri ân.

Kính cáo Chư vị Thần linh Thổ địa chứng giám cho phép con cháu được sửa sang phần mộ yên ổn.
Kính mời hương linh Tổ tiên, Ông Bà, Cha Mẹ về chứng giám lòng thành của con cháu, thụ hưởng lễ vật, phù hộ độ trì cho toàn thể gia tộc bình an, mạnh khỏe, con cháu hiếu thuận hưng long.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'gio-to-hung-vuong',
    category: 'le_tet',
    title: 'Văn khấn Giỗ Tổ Hùng Vương (Mùng 10 tháng 3 ÂL)',
    shortTitle: 'Giỗ Tổ Hùng Vương (10/3)',
    occasion: 'Ngày Mùng 10 tháng 3 Âm lịch (Quốc lễ Giỗ Tổ Hùng Vương)',
    offerings: 'Bánh chưng, bánh dày, hương hoa tươi, trầu cau, mâm ngũ quả, nước sạch, trà.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy các Vua Hùng đã có công dựng nước và các bậc tiền nhân giữ nước.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Cao Tằng Tổ Khảo, Cao Tằng Tổ Tỷ, Tiên tổ nội ngoại họ hàng chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Mùng 10 tháng Ba năm {{YEAR_CAN_CHI}} — ngày Giỗ Tổ Hùng Vương.
Uống nước nhớ nguồn, tín chủ con thành tâm sửa biện hương hoa, bánh chưng bánh dày, trà quả dâng lên trước án tưởng nhớ công đức các Vua Hùng và Tổ tiên nhiều đời.

Cúi xin Tổ tiên và Chư vị Tôn thần chứng giám lòng thành, phù hộ độ trì cho đất nước thái bình thịnh trị, gia đình chúng con luôn mạnh khỏe, bình an, hòa thuận, con cháu học hành thành đạt, vạn sự tốt lành.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'phat-dan',
    category: 'le_tet',
    title: 'Văn khấn Lễ Phật Đản (Rằm tháng 4 — 15/4 ÂL)',
    shortTitle: 'Lễ Phật Đản (15/4)',
    occasion: 'Ngày Rằm tháng Tư (15/4 Âm lịch — Đại lễ Phật Đản / Vesak)',
    offerings: 'Lễ chay thanh tịnh: hoa sen/hoa cúc tươi, mâm ngũ quả, xôi chè chay, nước tinh khiết, trà, hương đèn.',
    template: `Nam mô Bổn Sư Thích Ca Mâu Ni Phật! (3 lần)
Nam mô A Di Đà Phật! (3 lần)

Con kính lạy mười phương Chư Phật, Chư Đại Bồ Tát, Chư Hiền Thánh Tăng.
Con kính lạy Đức Bản Sư Thích Ca Mâu Ni Phật — bậc Đạo Sư từ bi trí tuệ giáng sinh vì lợi lạc chúng sinh.

Đệ tử / Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Rằm tháng Tư năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch), gặp ngày Đại lễ Phật Đản.
Đệ tử con thành tâm sửa biện hương hoa, lễ chay thanh tịnh, trà quả dâng lên trước Phật đài, kính mừng ngày Đức Phật đản sinh.

Nguyện xin oai lực từ bi của mười phương Chư Phật gia hộ cho quốc thái dân an, thế giới hòa bình, chúng sinh an lạc; gia đình chúng con thân tâm thanh tịnh, tiêu trừ nghiệp chướng, tăng trưởng thiện căn, sức khỏe bình an, gia đạo hưng thịnh.

Nam mô Bổn Sư Thích Ca Mâu Ni Phật! (3 lần)`
  },
  {
    id: 'that-tich',
    category: 'le_tet',
    title: 'Văn khấn Lễ Thất Tịch (Mùng 7 tháng 7 ÂL)',
    shortTitle: 'Lễ Thất Tịch (7/7)',
    occasion: 'Ngày Mùng 7 tháng 7 Âm lịch (Lễ Thất Tịch — Cầu duyên, hòa thuận gia đạo)',
    offerings: 'Hương hoa tươi, ngũ quả, chè đậu đỏ, bánh trái thanh tịnh, nước sạch, trà.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Gia tiên nội ngoại chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Mùng 7 tháng Bảy năm {{YEAR_CAN_CHI}} — ngày Lễ Thất Tịch.
Tín chủ con thành tâm sửa biện hương hoa, trà quả, lễ vật thanh tịnh dâng lên trước án.

Cúi xin Chư vị Tôn thần và Gia tiên chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho gia đình hòa thuận yêu thương, vợ chồng gắn bó son sắt, người chưa lập gia đình sớm gặp nhân duyên tốt lành, mọi sự bình an viên mãn.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'vu-lan-than-linh',
    category: 'le_tet',
    title: 'Văn khấn Thần Linh Rằm tháng 7 (15/7 ÂL)',
    shortTitle: 'Rằm tháng 7 — Thần Linh',
    occasion: 'Ngày Rằm tháng 7 Âm lịch (Cúng Thần Linh trước khi cúng Gia Tiên & Chúng Sinh)',
    offerings: 'Hương hoa tươi, trầu cau, ngũ quả, nước sạch, trà, rượu, xôi gà hoặc lễ chay đặt trên ban thờ Thần Linh.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Đức Địa Tạng Vương Bồ Tát, Đức Mục Kiền Liên Tôn Giả.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân, Ngũ phương Ngũ thổ Phúc đức chính thần cùng các vị Tôn thần cai quản trong khu vực này.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Rằm tháng Bảy năm {{YEAR_CAN_CHI}}, nhân tiết Trung Nguyên — Đại lễ Vu Lan báo hiếu, Xá tội vong nhân.
Tín chủ con thành tâm sửa biện hương hoa, lễ vật, trà quả dâng lên trước án kính mời Chư vị Tôn thần giáng lâm chứng giám lòng thành, thụ hưởng lễ vật.

Cúi xin các Ngài phù hộ độ trì cho toàn gia mạnh khỏe bình an, tiêu trừ tai ách, công việc hanh thông, tài lộc tăng tiến, đồng thời cho phép Gia tiên nội ngoại của gia đình chúng con được về thụ hưởng lễ vật ngày Rằm tháng Bảy.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'trung-cuu',
    category: 'le_tet',
    title: 'Văn khấn Tết Trùng Cửu (Mùng 9 tháng 9 ÂL)',
    shortTitle: 'Tết Trùng Cửu (9/9)',
    occasion: 'Ngày Mùng 9 tháng 9 Âm lịch (Tết Trùng Dương / Trùng Cửu — Cầu trường thọ)',
    offerings: 'Hoa cúc vàng, trà hoa cúc, bánh trái, ngũ quả, hương đèn, nước sạch.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa, ngài Bản gia Táo quân cùng chư vị Tôn thần.
Con kính lạy Gia tiên tiền tổ nội ngoại chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày Mùng 9 tháng Chín năm {{YEAR_CAN_CHI}} — Tết Trùng Cửu (Trùng Dương).
Tín chủ con thành tâm sửa biện hương hoa, trà cúc, lễ quả dâng lên trước án.

Cúi xin Chư vị Tôn thần và Gia tiên chứng giám lòng thành, thụ hưởng lễ vật, phù hộ độ trì cho ông bà cha mẹ sống lâu mạnh khỏe, gia đạo bình an, con cháu hiếu thuận, công việc cuối năm thuận lợi tốt lành.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'ta-dat-cuoi-nam',
    category: 'le_tet',
    title: 'Văn khấn Lễ Tạ Đất / Tạ Thần Linh Cuối Năm (Tháng Chạp)',
    shortTitle: 'Tạ Đất Cuối Năm (Tháng Chạp)',
    occasion: 'Tháng Chạp cuối năm (từ sau Rằm tháng Chạp đến trước 29/30 Tết)',
    offerings: 'Hương hoa tươi, mâm ngũ quả, trầu cau, trà, rượu, muối gạo, xôi gà hoặc bộ tam sên, vàng mã tạ lễ.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy Ngài Kim Niên Đương cai Thái Tuế chí đức Tôn thần.
Con kính lạy Ngài Bản cảnh Thành Hoàng Chư vị Đại Vương.
Con kính lạy các ngài Ngũ phương, Ngũ thổ, Long Mạch, Tài Thần, Định phúc Táo quân và chư vị Tôn thần cai quản trong xứ này.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, tháng Chạp năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch).
Nhân dịp cuối năm, tín chủ con thành tâm sửa biện hương hoa, phẩm vật, trà rượu dâng lên trước án, làm lễ Tạ Đất — kính tạ ơn Đức Trời Đất và Chư vị Tôn thần đã che chở, phù hộ cho gia đình chúng con bình an, ấm no suốt một năm qua.

Cúi xin các Ngài chứng giám lòng thành, thụ hưởng lễ vật, xá miễn những điều sơ sót trong năm, tiếp tục phù hộ độ trì cho gia trung yên ổn, đất đai vững bền, năm mới tài lộc vượng tiến, vạn sự cát tường.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'cung-mu',
    category: 'cong_viec',
    title: 'Văn khấn Cúng Mụ (Đầy Tháng / Thôi Nôi Bé)',
    shortTitle: 'Cúng Mụ (Đầy tháng / Thôi nôi)',
    occasion: 'Lễ Đầy tháng hoặc Thôi nôi (tròn 1 tuổi Âm lịch) cho bé',
    offerings: '12 chén chè nhỏ + 1 tô chè lớn, 12 đĩa xôi nhỏ + 1 đĩa xôi lớn, gà luộc hoặc vịt luộc, trầu têm cánh phượng, hương hoa, trà rượu, trái cây.',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con kính lạy Đệ nhất Thiên tỷ đại tiên chúa.
Con kính lạy Đệ nhị Thiên đế đại tiên chúa.
Con kính lạy Đệ tam Thiên Mụ đại tiên chúa.
Con kính lạy Tam thập lục cung chư vị Tiên Nương (12 Bà Mụ và 3 Đức Ông).

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (tức ngày {{SOLAR_FULL}} Dương lịch).
Vợ chồng chúng con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Nhân dịp cháu [Họ tên bé] sinh ngày [Ngày sinh bé] tròn [đầy tháng / thôi nôi], gia đình chúng con thành tâm sắm sửa hương hoa, xôi chè, trà quả phẩm vật bày lên trước án, kính dâng chư vị Tiên Nương và Đức Ông.

Cảm tạ ơn đức các Ngài đã nặn hình hài, chở che cho cháu được mẹ tròn con vuông, khỏe mạnh đến hôm nay.
Cúi xin các Ngài chứng giám lòng thành, thụ hưởng lễ vật, tiếp tục phù hộ độ trì cho cháu hay ăn chóng lớn, ngủ ngon khỏe mạnh, thông minh ngoan ngoãn, bình an suốt đời, lớn lên hiếu thảo thành tài.

Nam mô A Di Đà Phật! (3 lần)`
  },
  {
    id: 'cung-xe',
    category: 'cong_viec',
    title: 'Văn khấn Cúng Xe Mới / Cầu Bình An Xuất Hành',
    shortTitle: 'Cúng Xe Mới',
    occasion: 'Ngày nhận xe mới (ô tô, xe máy) hoặc cầu bình an đi đường',
    offerings: 'Hoa tươi, đĩa trái cây, hương đèn, muối gạo, ly nước sạch, trà, rượu (có thể thêm xôi gà hoặc đồ chay tùy tâm).',
    template: `Nam mô A Di Đà Phật! (3 lần)

Con lạy chín phương Trời, mười phương Chư Phật, Chư Phật mười phương.
Con kính lạy Hoàng Thiên Hậu Thổ chư vị Tôn thần.
Con kính lạy ngài Bản cảnh Thành Hoàng, ngài Bản xứ Thổ địa và các vị Tôn thần cai quản khu vực này.
Con kính lạy Gia tiên nội ngoại chư vị Hương linh.

Tín chủ con là: {{HOMEOWNER}}
Ngụ tại: {{ADDRESS}}

Hôm nay là ngày {{LUNAR_DAY_FULL}}, {{LUNAR_MONTH_FULL}}, năm {{YEAR_CAN_CHI}} (ngày {{SOLAR_FULL}} Dương lịch).
Tín chủ con có sắm được chiếc xe [Loại xe / Biển số], nay thành tâm sửa biện hương hoa, lễ vật dâng lên trước án kính cáo Chư vị Tôn thần và Gia tiên.

Cúi xin phù hộ độ trì cho tín chủ con cùng gia đình mỗi khi đi lại trên chiếc xe này luôn được thượng lộ bình an, tay lái vững vàng, tránh mọi rủi ro tai nạn, công việc làm ăn thuận lợi phát đạt.

Chúng con lễ bạc tâm thành, trước án kính lễ, cúi xin được phù hộ độ trì.

Nam mô A Di Đà Phật! (3 lần)`
  }
];

/**
 * Determine recommended prayers and occasion badge for a specific date.
 * Returns { isSpecialRitualDay, reason, prayerIds }
 */
export function getRecommendedPrayersForDate(solar, lunar, customEvents = []) {
  const ids = [];
  const reasons = [];

  const pushUnique = (id) => {
    if (!ids.includes(id)) ids.push(id);
  };

  // Solar special ritual days
  if (solar.day === 1 && solar.month === 1) {
    reasons.push('Tết Dương Lịch (01/01 DL)');
    pushUnique('tet-duong-lich');
  }
  if (solar.month === 4 && (solar.day === 4 || solar.day === 5)) {
    reasons.push('Tiết Thanh Minh (Tảo mộ)');
    pushUnique('ta-mo-thanh-minh');
    pushUnique('han-thuc');
  }

  if (!lunar.leap) {
    // Tết Nguyên Đán & Xuân
    if (lunar.month === 1 && lunar.day === 1) {
      reasons.push('Mùng 1 Tết Nguyên Đán');
      pushUnique('mung1-tet');
      pushUnique('ram-tho-cong');
    } else if (lunar.month === 1 && lunar.day === 2) {
      reasons.push('Mùng 2 Tết Nguyên Đán');
      pushUnique('mung2-tet');
      pushUnique('ram-gia-tien');
    } else if (lunar.month === 1 && lunar.day === 3) {
      reasons.push('Mùng 3 Tết (Hóa Vàng)');
      pushUnique('hoa-vang');
    } else if (lunar.month === 1 && lunar.day === 8) {
      reasons.push('Mùng 8 tháng Giêng (Cúng Sao Giải Hạn)');
      pushUnique('cung-sao-giai-han');
    } else if (lunar.month === 1 && lunar.day === 10) {
      reasons.push('Ngày Vía Thần Tài (10/1 ÂL)');
      pushUnique('than-tai');
    } else if (lunar.month === 1 && lunar.day === 15) {
      reasons.push('Rằm tháng Giêng (Tết Nguyên Tiêu)');
      pushUnique('ram-thang-gieng');
      pushUnique('cung-sao-giai-han');
      pushUnique('ram-tho-cong');
      pushUnique('ram-gia-tien');
    } else if (lunar.month === 3 && lunar.day === 3) {
      reasons.push('Tết Hàn Thực / Thanh Minh (3/3 ÂL)');
      pushUnique('han-thuc');
      pushUnique('ta-mo-thanh-minh');
    } else if (lunar.month === 3 && lunar.day === 10) {
      reasons.push('Giỗ Tổ Hùng Vương (10/3 ÂL)');
      pushUnique('gio-to-hung-vuong');
      pushUnique('ram-gia-tien');
    } else if (lunar.month === 4 && lunar.day === 15) {
      reasons.push('Đại lễ Phật Đản — Rằm tháng 4 (15/4 ÂL)');
      pushUnique('phat-dan');
      pushUnique('ram-tho-cong');
      pushUnique('ram-gia-tien');
    } else if (lunar.month === 5 && lunar.day === 5) {
      reasons.push('Tết Đoan Ngọ (5/5 ÂL)');
      pushUnique('doan-ngo');
    } else if (lunar.month === 7 && lunar.day === 7) {
      reasons.push('Lễ Thất Tịch (7/7 ÂL)');
      pushUnique('that-tich');
    } else if (lunar.month === 7 && lunar.day === 15) {
      reasons.push('Rằm tháng 7 (Lễ Vu Lan — Xá tội vong nhân)');
      pushUnique('vu-lan-than-linh');
      pushUnique('vu-lan-gia-tien');
      pushUnique('vu-lan-chung-sinh');
    } else if (lunar.month === 8 && lunar.day === 15) {
      reasons.push('Tết Trung Thu (Rằm tháng 8)');
      pushUnique('trung-thu');
      pushUnique('ram-gia-tien');
      pushUnique('ram-tho-cong');
    } else if (lunar.month === 9 && lunar.day === 9) {
      reasons.push('Tết Trùng Cửu (9/9 ÂL)');
      pushUnique('trung-cuu');
    } else if (lunar.month === 10 && lunar.day === 15) {
      reasons.push('Tết Hạ Nguyên — Rằm tháng 10');
      pushUnique('ha-nguyen');
      pushUnique('ram-tho-cong');
      pushUnique('ram-gia-tien');
    } else if (lunar.month === 12 && lunar.day === 23) {
      reasons.push('Ngày Ông Công Ông Táo (23 tháng Chạp)');
      pushUnique('ong-tao');
      pushUnique('ta-dat-cuoi-nam');
    } else if (lunar.month === 12 && lunar.day === lunar.monthLength) {
      reasons.push(`Tất Niên & Đêm Giao Thừa (${lunar.day} Tết)`);
      pushUnique('tat-nien');
      pushUnique('giao-thua-ngoai');
      pushUnique('giao-thua-trong');
    } else if (lunar.month === 12 && lunar.day >= 24 && lunar.day < lunar.monthLength) {
      // Cuối tháng Chạp: gợi ý Lễ Tạ Đất (không ép tự mở tab)
      pushUnique('ta-dat-cuoi-nam');
      pushUnique('tat-nien');
    }
  }

  // Monthly Mùng 1 & Rằm (15 ÂL)
  if (lunar.day === 1) {
    if (reasons.length === 0) reasons.push(`Mùng 1 tháng ${LUNAR_MONTH_NAMES[lunar.month] || lunar.month}${lunar.leap ? ' nhuận' : ''} ÂL`);
    pushUnique('ram-tho-cong');
    pushUnique('ram-gia-tien');
  } else if (lunar.day === 15) {
    if (reasons.length === 0) reasons.push(`Ngày Rằm (15) tháng ${LUNAR_MONTH_NAMES[lunar.month] || lunar.month}${lunar.leap ? ' nhuận' : ''} ÂL`);
    pushUnique('ram-tho-cong');
    pushUnique('ram-gia-tien');
  } else if (lunar.day === 10 && !lunar.leap && lunar.month !== 1) {
    // Monthly Thần Tài day (subtle recommendation, don't force auto-jump unless 10/1)
    pushUnique('than-tai');
  }

  // Check if user has a personal Ngày Giỗ custom event on this date
  const hasGioEvent = (customEvents || []).some((ce) => {
    const isGio = /giỗ|gio|cúng|cung|húy/i.test(`${ce.name || ''} ${ce.note || ''}`);
    if (!isGio) return false;
    if (ce.calendar === 'lunar') {
      return ce.month === lunar.month && Boolean(ce.leap) === lunar.leap &&
        (ce.day === lunar.day || (ce.day === 30 && lunar.monthLength === 29 && lunar.day === 29));
    }
    return ce.day === solar.day && ce.month === solar.month;
  });

  if (hasGioEvent) {
    reasons.unshift('Ngày Giỗ / Cúng sự kiện cá nhân');
    ids.unshift('ngay-gio');
  }

  const isSpecialRitualDay = reasons.length > 0;

  // Fallback suggestions for regular days
  if (ids.length === 0) {
    pushUnique('ram-tho-cong');
    pushUnique('ram-gia-tien');
    pushUnique('khai-truong');
    pushUnique('ngay-gio');
  }

  return {
    isSpecialRitualDay,
    reason: reasons.join(' • ') || 'Ngày thường — Chọn bài văn khấn phù hợp công việc',
    prayerIds: ids
  };
}

/**
 * Fill dynamic date (Lunar + Can Chi + Solar) & homeowner fields into a prayer template
 */
export function formatPrayerContent(prayer, solar, lunar, prefs = DEFAULT_PRAYER_PREFS) {
  const pad2 = (n) => String(n).padStart(2, '0');
  const dayLabel = lunar.day <= 10 ? `Mùng ${lunar.day}` : lunar.day === 15 ? 'Rằm (15)' : `${lunar.day}`;
  const monthLabel = `tháng ${LUNAR_MONTH_NAMES[lunar.month] || lunar.month}${lunar.leap ? ' (Nhuận)' : ''}`;
  const yearCanChi = getYearCanChi(lunar.year);
  const monthCanChi = getMonthCanChi(lunar.month, lunar.year);
  const dayCanChi = getDayCanChi(lunar.jd).name;
  const solarFull = `${pad2(solar.day)}/${pad2(solar.month)}/${solar.year}`;

  let occasionLabel = 'ngày lành tháng tốt';
  if (lunar.day === 1) occasionLabel = 'ngày Sóc (Mùng 1 đầu tháng)';
  else if (lunar.day === 15) occasionLabel = 'ngày Vọng (Ngày Rằm giữa tháng)';

  const homeowner = (prefs.homeownerName || '').trim() || '[Họ tên tín chủ / Gia chủ]';
  const address = (prefs.address || '').trim() || '[Địa chỉ nhà / Nơi thờ cúng]';

  return prayer.template
    .replace(/\{\{HOMEOWNER\}\}/g, homeowner)
    .replace(/\{\{ADDRESS\}\}/g, address)
    .replace(/\{\{LUNAR_DAY_FULL\}\}/g, dayLabel)
    .replace(/\{\{LUNAR_MONTH_FULL\}\}/g, monthLabel)
    .replace(/\{\{YEAR_CAN_CHI\}\}/g, yearCanChi)
    .replace(/\{\{MONTH_CAN_CHI\}\}/g, monthCanChi)
    .replace(/\{\{DAY_CAN_CHI\}\}/g, dayCanChi)
    .replace(/\{\{SOLAR_FULL\}\}/g, solarFull)
    .replace(/\{\{OCCASION_LABEL\}\}/g, occasionLabel);
}
