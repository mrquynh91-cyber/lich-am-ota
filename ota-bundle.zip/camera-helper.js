/**
 * Shared Smart Wide-Angle Camera Helper (v3.4.0 — PC & OPPO Find X9)
 * Fixes the common Android multi-lens WebView camera zoom bug:
 *  - Avoids 1:1 square / 16:9 EIS cropped streams by requesting natural 4:3 (1280x960)
 *  - Explicitly selects the primary wide 1x rear lens (skips telephoto / macro / depth lenses)
 *  - Resets hardware track zoom to widest 1x / min zoom and enables continuous autofocus
 *  - Provides an interactive floating Zoom (0.6x / 1x / 2x) + Rear Lens Switcher + Native Camera HUD bar
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

function isTeleOrAuxLabel(lbl) {
  return /(?:tele|zoom|macro|depth|bokeh|tof|infrared|ir\b|mono|aux)/i.test(String(lbl || ''));
}

function isFrontLabel(lbl) {
  return /(?:front|user|selfie|facing front)/i.test(String(lbl || ''));
}

function isBackLabel(lbl) {
  return /(?:back|rear|environment|facing back)/i.test(String(lbl || ''));
}

async function applyWidestZoomAndFocus(stream) {
  const track = stream?.getVideoTracks?.()?.[0];
  if (!track) return { track: null, zoomCaps: null, currentZoom: 1 };
  let zoomCaps = null;
  let currentZoom = 1;
  try {
    const caps = typeof track.getCapabilities === 'function' ? track.getCapabilities() : null;
    const adv = [];
    if (caps?.focusMode && Array.isArray(caps.focusMode) && caps.focusMode.includes('continuous')) {
      adv.push({ focusMode: 'continuous' });
    }
    if (caps?.zoom && typeof caps.zoom.min === 'number' && typeof caps.zoom.max === 'number') {
      zoomCaps = { min: caps.zoom.min, max: caps.zoom.max, step: caps.zoom.step || 0.1 };
      // Prefer widest natural view (1.0 if min <= 1.0 else min; if min is 0.5-0.7 ultrawide, default 1.0 so it matches phone 1x!)
      const targetZoom = zoomCaps.min <= 1.0 && zoomCaps.max >= 1.0 ? 1.0 : zoomCaps.min;
      adv.push({ zoom: targetZoom });
      currentZoom = targetZoom;
    }
    if (adv.length > 0 && typeof track.applyConstraints === 'function') {
      await track.applyConstraints({ advanced: adv }).catch(() => {});
    }
    const settings = typeof track.getSettings === 'function' ? track.getSettings() : null;
    if (settings && typeof settings.zoom === 'number') currentZoom = settings.zoom;
  } catch (_e) {}
  return { track, zoomCaps, currentZoom };
}

/**
 * Opens a natural uncropped 4:3 camera stream using the primary wide lens (never telephoto 3x!).
 * Returns { stream, track, zoomCaps, currentZoom, rearDevices, activeDeviceId, setZoom(z), switchRearLens(onNewStream) }
 */
export async function openSmartCamera(facing = 'environment', opts = {}) {
  const { preferredDeviceId = null } = opts;
  const isBack = facing === 'environment';

  // Helper to request a clean 4:3 uncropped stream (avoids Android 16:9 EIS zoom crop & 1:1 crop!)
  const requestStream = async (videoConstraints) => {
    try {
      return await navigator.mediaDevices.getUserMedia({ video: videoConstraints, audio: false });
    } catch (_e) {
      return await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: facing } },
        audio: false
      }).catch(() => navigator.mediaDevices.getUserMedia({ video: true, audio: false }));
    }
  };

  let rearDevices = [];
  let chosenDeviceId = preferredDeviceId;

  try {
    const devs = await navigator.mediaDevices.enumerateDevices();
    const videos = devs.filter((d) => d.kind === 'videoinput');
    const labeled = videos.some((d) => d.label && d.label.trim().length > 0);
    if (labeled && isBack) {
      rearDevices = videos.filter((d) => isBackLabel(d.label) || (!isFrontLabel(d.label) && videos.length > 1));
      if (!chosenDeviceId && rearDevices.length > 0) {
        // Pick primary wide lens: prefer camera2 0 / wide / normal, never tele/macro/depth
        const primary =
          rearDevices.find((d) => /camera2\s*0\b/i.test(d.label) && !isTeleOrAuxLabel(d.label)) ||
          rearDevices.find((d) => /wide|main|normal/i.test(d.label) && !isTeleOrAuxLabel(d.label)) ||
          rearDevices.find((d) => !isTeleOrAuxLabel(d.label)) ||
          rearDevices[0];
        chosenDeviceId = primary?.deviceId || null;
      }
    }
  } catch (_e) {}

  const baseConstraints = chosenDeviceId
    ? { deviceId: { exact: chosenDeviceId }, width: { ideal: 1280 }, height: { ideal: 960 }, aspectRatio: { ideal: 4 / 3 } }
    : { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 960 }, aspectRatio: { ideal: 4 / 3 } };

  let stream = await requestStream(baseConstraints);

  // If device labels weren't unlocked before first permission grant, re-enumerate and verify we didn't get a telephoto lens!
  if (isBack && rearDevices.length === 0) {
    try {
      const devs2 = await navigator.mediaDevices.enumerateDevices();
      const videos2 = devs2.filter((d) => d.kind === 'videoinput');
      rearDevices = videos2.filter((d) => isBackLabel(d.label) || (!isFrontLabel(d.label) && videos2.length > 1));
      const curTrack = stream.getVideoTracks()[0];
      const curLabel = curTrack?.label || '';
      const curId = curTrack?.getSettings?.()?.deviceId || '';
      if (rearDevices.length > 1 && isTeleOrAuxLabel(curLabel)) {
        const primary =
          rearDevices.find((d) => /camera2\s*0\b/i.test(d.label) && !isTeleOrAuxLabel(d.label)) ||
          rearDevices.find((d) => !isTeleOrAuxLabel(d.label));
        if (primary && primary.deviceId !== curId) {
          stream.getTracks().forEach((t) => { try { t.stop(); } catch (_e) {} });
          stream = await requestStream({
            deviceId: { exact: primary.deviceId },
            width: { ideal: 1280 },
            height: { ideal: 960 },
            aspectRatio: { ideal: 4 / 3 }
          });
        }
      }
    } catch (_e) {}
  }

  const { track, zoomCaps, currentZoom } = await applyWidestZoomAndFocus(stream);
  const activeDeviceId = track?.getSettings?.()?.deviceId || chosenDeviceId || '';

  const ctrl = {
    stream,
    track,
    zoomCaps,
    currentZoom,
    rearDevices,
    activeDeviceId,
    async setZoom(targetZ) {
      if (!ctrl.track || !ctrl.zoomCaps) return ctrl.currentZoom;
      const clamped = Math.max(ctrl.zoomCaps.min, Math.min(ctrl.zoomCaps.max, targetZ));
      try {
        await ctrl.track.applyConstraints({ advanced: [{ zoom: clamped }] });
        ctrl.currentZoom = clamped;
      } catch (_e) {}
      return ctrl.currentZoom;
    }
  };
  return ctrl;
}

/**
 * Mounts a sleek OPPO-style floating camera zoom (0.6x / 1x / 2x), rear-lens switcher,
 * and optional "📱 Cam máy" (native phone camera) bar inside any camera stage container.
 */
export function attachCameraControlBar(stageEl, camCtrl, opts = {}) {
  if (!stageEl) return;
  removeCameraControlBar(stageEl);

  const { onSwitchRearLens = null, onOpenNativeCamera = null } = opts;
  const bar = document.createElement('div');
  bar.className = 'cam-ctrl-hud';

  const pills = [];
  if (camCtrl?.zoomCaps && camCtrl.zoomCaps.max > camCtrl.zoomCaps.min + 0.15) {
    const { min, max } = camCtrl.zoomCaps;
    const candidates = [];
    if (min <= 0.85) candidates.push({ label: `${min.toFixed(1)}x`, val: min });
    if (min <= 1.05 && max >= 1.0) candidates.push({ label: '1x', val: Math.max(min, 1.0) });
    else candidates.push({ label: `${min.toFixed(1)}x`, val: min });
    if (max >= 1.9) candidates.push({ label: '2x', val: 2.0 });

    // Deduplicate labels
    const seen = new Set();
    candidates.forEach((c) => {
      if (seen.has(c.label)) return;
      seen.add(c.label);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `cam-zoom-pill${Math.abs(camCtrl.currentZoom - c.val) < 0.25 ? ' active' : ''}`;
      btn.textContent = c.label;
      btn.addEventListener('click', async (ev) => {
        ev.stopPropagation();
        await camCtrl.setZoom(c.val);
        pills.forEach((p) => p.classList.toggle('active', p === btn));
      });
      pills.push(btn);
      bar.appendChild(btn);
    });
  }

  if (onSwitchRearLens && Array.isArray(camCtrl?.rearDevices) && camCtrl.rearDevices.length > 1) {
    const lensBtn = document.createElement('button');
    lensBtn.type = 'button';
    lensBtn.className = 'cam-zoom-pill';
    const curIdx = Math.max(0, camCtrl.rearDevices.findIndex((d) => d.deviceId === camCtrl.activeDeviceId));
    lensBtn.textContent = `🔄 Ống kính (${curIdx + 1}/${camCtrl.rearDevices.length})`;
    lensBtn.title = 'Đổi ống kính góc rộng / siêu rộng';
    lensBtn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const nextIdx = (curIdx + 1) % camCtrl.rearDevices.length;
      onSwitchRearLens(camCtrl.rearDevices[nextIdx].deviceId);
    });
    bar.appendChild(lensBtn);
  }

  if (typeof onOpenNativeCamera === 'function') {
    const natBtn = document.createElement('button');
    natBtn.type = 'button';
    natBtn.className = 'cam-zoom-pill native';
    natBtn.textContent = '📷 Cam máy';
    natBtn.title = 'Mở trực tiếp ứng dụng Camera chuẩn của điện thoại';
    natBtn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      onOpenNativeCamera();
    });
    bar.appendChild(natBtn);
  }

  if (bar.children.length > 0) {
    stageEl.appendChild(bar);
  }
}

export function removeCameraControlBar(stageEl) {
  stageEl?.querySelectorAll('.cam-ctrl-hud').forEach((n) => n.remove());
}
