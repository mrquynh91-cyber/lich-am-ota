/**
 * Lịch Âm Việt Nam Mobile App (PWA + Native Android WebView for OPPO Find X9)
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import {
  THU_VN,
  TIMEZONE_VN,
  convertSolar2Lunar,
  convertLunar2Solar,
  jdFromDate,
  getYearCanChi,
  getMonthCanChi,
  getDayCanChi,
  getFullDayDetails,
  getBiorhythmForDate,
  computeDateDiff,
  formatLunarDayShort,
  formatLunarDateFull
} from './lunar.js';

import {
  getEventsForDate,
  getUpcomingEvents,
  getNextTetCountdown,
  getNextSolarNewYearCountdown
} from './holidays.js';

import {
  REPEAT_LABELS,
  pad2,
  formatDateKey,
  computeWaterSchedule,
  getNextWaterSlotTimestamp,
  getNextReminderTimestamp,
  doesReminderOccurOnDate,
  getHighlightsForDate,
  parseFlightText,
  parseIcsText,
  parseMeetingOrEventText,
  parseVietnameseNlpReminder,
  BULK_REMINDER_PRESETS,
  computeStartDateForBulkRow,
  parseBulkReminderLines,
  pruneExpiredReminders
} from './reminders.js';

import {
  TASK_CATALOG,
  getBirthProfile,
  evaluateDateForTask,
  findAuspiciousDays
} from './auspicious.js';

import {
  PRAYER_CATEGORIES,
  PRAYERS_CATALOG,
  getRecommendedPrayersForDate,
  formatPrayerContent
} from './prayers.js';

import {
  DEFAULT_WEATHER_PREFS,
  VN_CITIES,
  resolveWeatherLocation,
  fetchWeatherForecast,
  getSmartWeatherAdvice,
  requestGpsPosition,
  searchVietnamLocations,
  reverseGeocodeVietnam,
  haversineKm,
  buildLiveRadarUrl
} from './weather.js';

import {
  buildAnniversariesIcs,
  buildMung1RamIcs,
  buildTimedRemindersIcs,
  buildGoogleCalendarUrl,
  downloadIcsFile
} from './ics-export.js';

import {
  shareToZaloQuick,
  sendWebhookNotification
} from './zalo.js';

import {
  DEFAULT_CLOUDFLARE_SYNC_URL,
  DEFAULT_CLOUD_SYNC_CONFIG,
  SYNCABLE_DATA_KEYS,
  generateRandomKey,
  encodePairingCode,
  decodePairingCode,
  buildSyncSnapshot,
  mergeCloudSnapshot,
  applyLocalExtraData,
  registerCloudflareAccount,
  loginCloudflareAccount,
  logoutCloudflareAccount,
  createGitHubSyncGist,
  pullCloudSnapshot,
  pushCloudSnapshot,
  claimTelegramSendSlot,
  claimTelegramSendSlotDetailed,
  testTelegramLockAccess
} from './cloud-sync.js';

import { extractTextFromPdfBuffer } from './pdf-extract.js';
import {
  escapeTelegramHtml,
  sendTelegramApiMessage,
  detectTelegramChatsApi
} from './telegram.js';
import { playWaterPourSound, playReminderChime } from './sound.js';

import {
  APP_VERSION,
  loadMobileData,
  saveMobileField,
  exportAllDataJson,
  importAllDataJson,
  isRunningInAndroidApk,
  syncNativeAndroidAlarms,
  triggerNativeTestNotification,
  openAndroidBatterySettings,
  requestAndroidExactAlarmPermission,
  getAndroidAlarmHealth
} from './storage-mobile.js';
import { runGlobalAppSearch, normalizeVnSearch } from './search-all.js';
import { DREAM_CATEGORIES, DREAM_QUICK_PROMPTS, DREAMS_CATALOG } from './dreams.js';
import { FACE_MOLE_SPOTS, compressImageSourceToBase64 } from './moles.js';
import { PALM_FEATURES, buildEnhancedPalmImages } from './palmistry.js';
import { mountConverterHub } from './converters-hub.js';
import { mountFortuneModule } from './fortune.js';
import { mountTuViModule, mountSimPlateModule, mountCompatibilityModule } from './tuvi-compat.js';
import { mountFengShuiSpaceModule, mountTarotNumerologyModule, mountIChingXamModule } from './spiritual-ai.js';
import { mountExpenseAiModule, mountMedicineModule, mountMealPlannerModule } from './lifestyle-ai.js';
import { mountDietGuideModule } from './diet-guide.js';
import { mountDocScannerModule } from './doc-scanner.js';
import { openSmartCamera, attachCameraControlBar, removeCameraControlBar } from './camera-helper.js';
import {
  DEFAULT_GEMINI_SETTINGS,
  isGeminiConfigured,
  testGeminiConnection,
  listAvailableGeminiModels,
  getLastGeminiMeta,
  chatWithLunarAssistant,
  parseRemindersWithGemini,
  generateCustomPrayerWithGemini,
  expandPrayerForSpeech,
  splitPrayerIntoSpeechChunks,
  synthesizePrayerChunkWithGemini,
  splitPrayerIntoFastVnSentences,
  synthesizeFastVnVoiceChunk,
  decodeDreamWithGemini,
  analyzeFaceMolesWithGemini,
  analyzePalmLinesWithGemini
} from './gemini-ai.js';

const $ = (id) => document.getElementById(id);

let today = new Date();
const urlParams = new URLSearchParams(window.location.search);

function parseDateParam(str) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str || '');
  if (!m) return null;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  const dt = new Date(y, mo - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
  return { day: d, month: mo, year: y };
}

const initialDate = parseDateParam(urlParams.get('date')) || {
  day: today.getDate(),
  month: today.getMonth() + 1,
  year: today.getFullYear()
};

const data = loadMobileData();

const state = {
  activeTab: 'calendar',
  activeRemSub: 'rem',
  viewYear: initialDate.year,
  viewMonth: initialDate.month,
  selectedDate: { ...initialDate },
  holidayFilter: 'all',
  converterMode: 's2l',
  prayerCategory: 'recommended',
  prayerSearch: '',
  selectedPrayerId: 'ram-tho-cong',
  activeModalAlarm: null,
  deferredInstallPrompt: null,
  weatherData: null,
  weatherError: '',
  editingReminderId: null,
  ...data
};

function shiftDateKey(key, deltaDays) {
  const [y, m, d] = key.split('-').map(Number);
  const dt = new Date(y, m - 1, d + deltaDays);
  return formatDateKey(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
}

function getCurrentTimeHM(d = new Date()) {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

let activeWebSpeechRec = null;
let mobileVoiceTarget = 'rem'; // 'rem' | 'gm-chat'

function autoResizeMobileGmInput(el) {
  const ta = el || $('gm-chat-input');
  if (!ta) return;
  ta.style.height = 'auto';
  const h = Math.min(ta.scrollHeight || 38, 132);
  ta.style.height = `${Math.max(38, h)}px`;
  ta.scrollTop = ta.scrollHeight;
}

function setMobileGmVoiceUi(on) {
  const b = $('btn-gm-chat-voice');
  if (!b) return;
  b.classList.toggle('listening', on);
  b.textContent = on ? '🔴' : '🎙️';
  const inp = $('gm-chat-input');
  if (inp) {
    inp.placeholder = on ? '🎙️ Đang nghe tiếng Việt...' : 'Hỏi, gửi 📷 ảnh, hoặc bấm 🎙️ nói...';
  }
}

function attachMobileVoiceInput() {
  const btn = $('btn-rem-voice');
  const inp = $('rem-title');
  const prev = $('rem-nlp-preview');
  if (!btn || !inp) return;

  const setListeningUi = (on) => {
    btn.classList.toggle('listening', on);
    btn.textContent = on ? '🔴' : '🎙️';
  };

  let activeCustomNativeVoice = null;
  let activeUnifiedWebRec = null;
  let activeUnifiedWebBtn = null;

  // Universal voice controller for ALL voice buttons (AI Chat, Reminders, Dreams, Expense, Loans, Meal, Diet):
  // - On Android APK: uses 100% inline native SpeechRecognizer (no system Google popup, guaranteed 3.5s silence auto-stop & send)
  // - On Browser/PWA: uses Web Speech API with matching 3.5s silence auto-stop & send
  window.__toggleUnifiedVoice = (opts = {}) => {
    const {
      btnEl = null,
      silenceMs = 3500,
      onStart = () => {},
      onInterim = () => {},
      onFinal = () => {},
      onError = () => {}
    } = opts;

    if (isRunningInAndroidApk() && typeof window.AndroidBridge.startVoiceInput === 'function') {
      const sameBtnListening = Boolean(btnEl && btnEl.classList.contains('listening'));
      if (sameBtnListening) {
        window.AndroidBridge.startVoiceInput();
        return;
      }
      // Reset any previously active custom voice button
      if (activeCustomNativeVoice && activeCustomNativeVoice.btnEl && activeCustomNativeVoice.btnEl !== btnEl) {
        activeCustomNativeVoice.btnEl.classList.remove('listening');
        activeCustomNativeVoice.btnEl.textContent = '🎙️';
      }
      mobileVoiceTarget = 'custom';
      activeCustomNativeVoice = { btnEl, onStart, onInterim, onFinal, onError };
      if (btnEl) {
        btnEl.classList.add('listening');
        btnEl.textContent = '🔴';
      }
      onStart();
      window.AndroidBridge.startVoiceInput();
      return;
    }

    if (activeUnifiedWebRec) {
      const prevBtn = activeUnifiedWebBtn;
      try { activeUnifiedWebRec.stop(); } catch (_e) {}
      if (prevBtn === btnEl) return;
    }
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      onError('⚠️ Thiết bị chưa hỗ trợ Micro trực tiếp tại đây.');
      return;
    }
    const rec = new SpeechRec();
    activeUnifiedWebRec = rec;
    activeUnifiedWebBtn = btnEl;
    rec.lang = 'vi-VN';
    rec.interimResults = true;
    rec.continuous = true;
    let spoken = '';
    let silTimer = null;
    let finished = false;

    const cleanup = () => {
      if (silTimer) { clearTimeout(silTimer); silTimer = null; }
      if (activeUnifiedWebRec === rec) {
        activeUnifiedWebRec = null;
        activeUnifiedWebBtn = null;
      }
      if (btnEl) {
        btnEl.classList.remove('listening');
        btnEl.textContent = '🎙️';
      }
    };

    rec.onstart = () => {
      if (btnEl) {
        btnEl.classList.add('listening');
        btnEl.textContent = '🔴';
      }
      onStart();
    };
    rec.onresult = (ev) => {
      let t = '';
      for (let i = 0; i < ev.results.length; i++) t += ev.results[i][0].transcript;
      spoken = t.trim();
      if (spoken) {
        onInterim(spoken);
        if (silTimer) clearTimeout(silTimer);
        silTimer = setTimeout(() => {
          try { rec.stop(); } catch (_e) {}
        }, silenceMs);
      }
    };
    rec.onerror = (ev) => {
      if (spoken && !finished) {
        finished = true;
        cleanup();
        onFinal(spoken);
        return;
      }
      cleanup();
      onError(ev?.error === 'not-allowed' ? 'Hãy cấp quyền Micro để dùng giọng nói.' : '');
    };
    rec.onend = () => {
      if (finished) return;
      finished = true;
      cleanup();
      if (spoken) onFinal(spoken);
      else onError('');
    };
    try { rec.start(); } catch (_e) { cleanup(); }
  };

  // Native Android Speech Recognizer callbacks (called from MainActivity.kt — routes cleanly to ANY voice target!)
  window.__onNativeVoiceResult = (transcript, isFinal = true) => {
    const text = String(transcript || '').trim();

    if (mobileVoiceTarget === 'custom' && activeCustomNativeVoice) {
      const h = activeCustomNativeVoice;
      if (isFinal) {
        activeCustomNativeVoice = null;
        if (h.btnEl) {
          h.btnEl.classList.remove('listening');
          h.btnEl.textContent = '🎙️';
        }
        if (text) h.onFinal(text);
      } else if (text) {
        h.onInterim(text);
      }
      return;
    }

    if (mobileVoiceTarget === 'gm-chat') {
      if (isFinal) setMobileGmVoiceUi(false);
      const gmInp = $('gm-chat-input');
      if (text && gmInp) {
        gmInp.value = text;
        autoResizeMobileGmInput(gmInp);
        if (isFinal && !mobileGeminiBusy) {
          gmInp.value = '';
          autoResizeMobileGmInput(gmInp);
          sendMobileGeminiChatMessage(text);
        }
      }
      return;
    }

    if (mobileVoiceTarget === 'dream') {
      const dBtn = $('btn-dream-voice');
      if (isFinal && dBtn) {
        dBtn.classList.remove('listening');
        dBtn.textContent = '🎙️';
      }
      const dInp = $('dream-input');
      if (text && dInp) {
        dInp.value = text;
        if (isFinal && typeof window.__runMobileDreamDecode === 'function') {
          window.__runMobileDreamDecode(text);
        }
      }
      return;
    }

    if (isFinal) setListeningUi(false);
    const targetInput = $('rem-title');
    const previewEl = $('rem-nlp-preview');
    if (text && targetInput) {
      $('rem-form')?.classList.remove('hidden');
      targetInput.value = text;
      targetInput.focus();
      targetInput.dispatchEvent(new Event('input', { bubbles: true }));
      if (!isFinal && previewEl) {
        previewEl.classList.remove('hidden');
        previewEl.textContent = `🎙️ Đang nghe: "${text}"...`;
      }
    }
  };
  window.__onNativeVoiceError = (msg) => {
    if (mobileVoiceTarget === 'custom' && activeCustomNativeVoice) {
      const h = activeCustomNativeVoice;
      activeCustomNativeVoice = null;
      if (h.btnEl) {
        h.btnEl.classList.remove('listening');
        h.btnEl.textContent = '🎙️';
      }
      h.onError(msg || '');
      return;
    }
    if (mobileVoiceTarget === 'gm-chat') {
      setMobileGmVoiceUi(false);
      if (msg) {
        mobileGeminiChatHistory.push({ role: 'assistant', isError: true, text: `🎙️ ${msg}` });
        renderMobileGeminiMessages();
      }
      return;
    }
    if (mobileVoiceTarget === 'dream') {
      const dBtn = $('btn-dream-voice');
      if (dBtn) { dBtn.classList.remove('listening'); dBtn.textContent = '🎙️'; }
      if (msg && $('dream-ai-status')) {
        $('dream-ai-status').className = 'status-msg err';
        $('dream-ai-status').textContent = `🎙️ ${msg}`;
      }
      return;
    }
    setListeningUi(false);
    const previewEl = $('rem-nlp-preview');
    if (previewEl) {
      if (msg) {
        previewEl.classList.remove('hidden');
        previewEl.textContent = `🎙️ ${msg}`;
      } else if (!$('rem-title')?.value.trim()) {
        previewEl.classList.add('hidden');
      }
    }
  };

  btn.addEventListener('click', () => {
    mobileVoiceTarget = 'rem';
    // 1. Inside OPPO Find X9 APK: launch native Android Vietnamese voice recognizer!
    if (isRunningInAndroidApk() && typeof window.AndroidBridge.startVoiceInput === 'function') {
      const wasListening = btn.classList.contains('listening');
      setListeningUi(!wasListening);
      if (!wasListening && prev) {
        prev.classList.remove('hidden');
        prev.textContent = '🎙️ Đang nghe tiếng Việt... Hãy nói nội dung nhắc nhở (bấm 🔴 để dừng)';
      }
      window.AndroidBridge.startVoiceInput();
      return;
    }

    // 2. Fallback for Chrome / PWA: Web Speech API
    if (activeWebSpeechRec) {
      try { activeWebSpeechRec.stop(); } catch (_e) {}
      return;
    }
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      const onIos = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
        (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
      if (prev) {
        prev.classList.remove('hidden');
        prev.textContent = onIos
          ? '🎙️ Mẹo trên iPhone 13: Chạm vào ô tiêu đề rồi bấm nút Micro 🎙️ ở góc dưới phải bàn phím iPhone để đọc tiếng Việt trực tiếp — hệ thống sẽ tự tách ngày & giờ!'
          : '⚠️ Trình duyệt chưa hỗ trợ giọng nói. Cài file APK hoặc mở trên Chrome / Safari mới nhất.';
      }
      inp.focus();
      return;
    }
    const rec = new SpeechRec();
    activeWebSpeechRec = rec;
    rec.lang = 'vi-VN';
    rec.interimResults = true;
    rec.continuous = true;
    let remSilTimer = null;
    rec.onstart = () => {
      setListeningUi(true);
      if (prev) {
        prev.classList.remove('hidden');
        prev.textContent = '🎙️ Đang nghe giọng nói tiếng Việt... Ngừng 3.5 giây tự gửi!';
      }
    };
    rec.onresult = (ev) => {
      let t = '';
      for (let i = 0; i < ev.results.length; i++) t += ev.results[i][0].transcript;
      if (t.trim()) {
        inp.value = t.trim();
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        if (remSilTimer) clearTimeout(remSilTimer);
        remSilTimer = setTimeout(() => { try { rec.stop(); } catch (_e) {} }, 3500);
      }
    };
    rec.onerror = (ev) => {
      activeWebSpeechRec = null;
      setListeningUi(false);
      if (prev) {
        prev.classList.remove('hidden');
        prev.textContent = ev.error === 'not-allowed'
          ? '⚠️ Bạn chưa cấp quyền Micro cho ứng dụng.'
          : '🎙️ Chưa nghe thấy giọng nói, hãy thử bấm 🎙️ lại nhé!';
      }
    };
    rec.onend = () => {
      activeWebSpeechRec = null;
      setListeningUi(false);
    };
    try { rec.start(); } catch (_e) { activeWebSpeechRec = null; setListeningUi(false); }
  });
}

function getTodayKey(d = new Date()) {
  return formatDateKey(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

function getSelectedKey() {
  const { year, month, day } = state.selectedDate;
  return formatDateKey(year, month, day);
}

function formatKeyVN(key) {
  if (!key) return '';
  const [y, m, d] = key.split('-');
  return `${d}/${m}/${y}`;
}

function esc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

let mCloudPushTimer = null;
let mCloudSyncBusy = false;
let mCloudLocalDirty = false;
let mSuppressCloudPush = false;

if (!state.cloudSyncConfig) state.cloudSyncConfig = { ...DEFAULT_CLOUD_SYNC_CONFIG };
if (!state.cloudSyncConfig.deviceId) {
  state.cloudSyncConfig.deviceId = generateRandomKey('android');
  saveMobileField('cloudSyncConfig', state.cloudSyncConfig);
}
if (!state.cloudDeletedIds) state.cloudDeletedIds = {};

function setMobileCloudStatus(msg, isErr = false) {
  const el = $('cs-status');
  if (!el) return;
  el.className = isErr ? 'status-msg err' : 'status-msg';
  el.textContent = msg;
}

function recordMobileDeletedId(id) {
  if (!id) return;
  state.cloudDeletedIds[id] = Date.now();
  saveMobileField('cloudDeletedIds', state.cloudDeletedIds);
}

let mobExpenseCtrl = null;

function scheduleMobileCloudPush() {
  if (mSuppressCloudPush || !state.cloudSyncConfig?.enabled) return;
  mCloudLocalDirty = true;
  clearTimeout(mCloudPushTimer);
  mCloudPushTimer = setTimeout(() => {
    syncMobileCloudNow('push', false);
  }, 250);
}

async function syncMobileCloudNow(mode = 'both', showFeedback = false) {
  const cfg = state.cloudSyncConfig;
  if (!cfg?.enabled || mCloudSyncBusy) return;
  mCloudSyncBusy = true;
  if (showFeedback) setMobileCloudStatus('🔄 Đang đồng bộ tự động...');
  try {
    const pullRes = await pullCloudSnapshot(cfg);
    if (!pullRes.ok) {
      if (showFeedback) setMobileCloudStatus(pullRes.error || 'Lỗi kết nối Cloud', true);
      return;
    }

    const remoteSnap = pullRes.snapshot;
    const remoteTs = Number(remoteSnap?.updatedAt || 0);
    const localHasUnsyncedFinance = Boolean(
      ((state.loanBook?.length || 0) > 0 && !Array.isArray(remoteSnap?.data?.loanBook)) ||
      ((state.expenseBook?.length || 0) > 0 && !Array.isArray(remoteSnap?.data?.expenseBook))
    );
    const shouldMergeRemote = Boolean(
      remoteSnap && (mode === 'both' || localHasUnsyncedFinance || remoteTs > Number(cfg.lastRemoteUpdatedAt || 0) || remoteSnap.updatedBy !== cfg.deviceId)
    );
    let needsPushBack = false;

    if (shouldMergeRemote) {
      const merged = mergeCloudSnapshot(state, state.cloudDeletedIds, remoteSnap, mCloudLocalDirty || mode === 'push');
      if (merged) {
        needsPushBack = Boolean(merged.needsPushBack);
        mSuppressCloudPush = true;
        try {
          for (const k of SYNCABLE_DATA_KEYS) {
            if (merged.mergedData[k] === undefined) continue;
            state[k] = merged.mergedData[k];
            saveMobileField(k, state[k]);
            if (k === 'expenseBook') {
              try { localStorage.setItem('lich_am_expense_book_v1', JSON.stringify(state.expenseBook || [])); } catch (_e) {}
            } else if (k === 'loanBook') {
              try { localStorage.setItem('lich_am_loan_book_v1', JSON.stringify(state.loanBook || [])); } catch (_e) {}
            }
          }
          state.cloudDeletedIds = merged.mergedDeletedIds;
          saveMobileField('cloudDeletedIds', state.cloudDeletedIds);
          applyLocalExtraData(merged.mergedData);
          cfg.lastRemoteUpdatedAt = merged.remoteUpdatedAt;
          syncNativeAndroidAlarms(state);
          initControls();
          renderMobileGeminiSettings();
          renderAllCalendarViews();
          renderRemindersList();
          renderHighlightsList();
          renderWater();
          renderHolidays();
          renderPrayers(false);
          mobExpenseCtrl?.refreshFromStorage?.();
        } finally {
          mSuppressCloudPush = false;
        }
      }
    }

    const shouldPush = mode === 'push' || mode === 'both' || mCloudLocalDirty || !remoteSnap || needsPushBack;
    if (shouldPush) {
      const snap = buildSyncSnapshot(state, state.cloudDeletedIds, cfg.deviceId || 'oppo');
      const pushRes = await pushCloudSnapshot(cfg, snap);
      if (!pushRes.ok) {
        if (showFeedback) setMobileCloudStatus(pushRes.error || 'Lỗi đẩy dữ liệu lên Cloud', true);
        return;
      }
      mCloudLocalDirty = false;
      cfg.lastRemoteUpdatedAt = snap.updatedAt;
    }

    cfg.lastSyncedAt = Date.now();
    saveMobileField('cloudSyncConfig', cfg);
    const tStr = new Date(cfg.lastSyncedAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setMobileCloudStatus(`🟢 Đã đồng bộ tự động lúc ${tStr}`);
  } finally {
    mCloudSyncBusy = false;
  }
}

function renderMobileCloudSyncUI() {
  const cfg = state.cloudSyncConfig || DEFAULT_CLOUD_SYNC_CONFIG;
  const prov = cfg.provider || 'cloudflare';
  if ($('cs-enabled')) $('cs-enabled').checked = Boolean(cfg.enabled);
  if ($('cs-provider')) $('cs-provider').value = prov;
  if ($('cs-cf-url')) $('cs-cf-url').value = cfg.cfSyncUrl || DEFAULT_CLOUDFLARE_SYNC_URL;
  if ($('cs-fb-url')) $('cs-fb-url').value = cfg.firebaseUrl || '';
  if ($('cs-room-key')) $('cs-room-key').value = cfg.roomKey || '';
  if ($('cs-gh-token')) $('cs-gh-token').value = cfg.githubToken || '';
  if ($('cs-gh-gist')) $('cs-gh-gist').value = cfg.gistId || '';

  const isCf = prov === 'cloudflare';
  const isGh = prov === 'github';
  const isFb = prov === 'firebase';
  $('cs-cloudflare-fields')?.classList.toggle('hidden', !isCf);
  $('cs-firebase-fields')?.classList.toggle('hidden', !isFb);
  $('cs-github-fields')?.classList.toggle('hidden', !isGh);

  const cfLoggedIn = Boolean(cfg.cfToken && cfg.cfUsername);
  $('cs-cf-logged-box')?.classList.toggle('hidden', !cfLoggedIn);
  $('cs-cf-auth-box')?.classList.toggle('hidden', cfLoggedIn);
  if ($('cs-cf-account-label')) {
    $('cs-cf-account-label').textContent = cfg.cfUsername || '—';
  }

  if (cfg.enabled && cfg.lastSyncedAt) {
    const tStr = new Date(cfg.lastSyncedAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const who = isCf && cfg.cfUsername ? ` (${cfg.cfUsername})` : '';
    setMobileCloudStatus(`🟢 Đã đồng bộ 100% dữ liệu${who} lúc ${tStr}`);
  } else if (isCf && !cfLoggedIn) {
    setMobileCloudStatus('⚪ Nhập SĐT (hoặc tên) + Mật khẩu rồi bấm "Tạo tài khoản mới" hoặc "Đăng nhập" để tự động sao lưu 100% dữ liệu.');
  } else if (!cfg.enabled) {
    setMobileCloudStatus('⚪ Chưa bật — Đăng nhập tài khoản hoặc dán mã từ PC để đồng bộ ngay.');
  }
}

function bindMobileCloudSyncEvents() {
  window.addEventListener('licham-local-data-changed', (ev) => {
    const delId = ev?.detail?.deletedId;
    if (delId) {
      state.cloudDeletedIds = state.cloudDeletedIds || {};
      state.cloudDeletedIds[delId] = Date.now();
      saveMobileField('cloudDeletedIds', state.cloudDeletedIds);
    }
    scheduleMobileCloudPush();
  });

  const readCfg = () => {
    const prev = state.cloudSyncConfig || DEFAULT_CLOUD_SYNC_CONFIG;
    state.cloudSyncConfig = {
      ...prev,
      enabled: Boolean($('cs-enabled')?.checked),
      provider: $('cs-provider')?.value || 'cloudflare',
      cfSyncUrl: ($('cs-cf-url')?.value || DEFAULT_CLOUDFLARE_SYNC_URL).trim(),
      firebaseUrl: ($('cs-fb-url')?.value || '').trim(),
      roomKey: ($('cs-room-key')?.value || '').trim(),
      githubToken: ($('cs-gh-token')?.value || '').trim(),
      gistId: ($('cs-gh-gist')?.value || '').trim()
    };
    if (!state.cloudSyncConfig.roomKey && state.cloudSyncConfig.provider === 'firebase') {
      state.cloudSyncConfig.roomKey = generateRandomKey('licham');
    }
    saveMobileField('cloudSyncConfig', state.cloudSyncConfig);
    syncNativeAndroidAlarms(state);
    renderMobileCloudSyncUI();
    refreshMobileSettingsSummaryPills?.();
  };

  ['cs-enabled', 'cs-provider', 'cs-cf-url', 'cs-fb-url', 'cs-room-key', 'cs-gh-token', 'cs-gh-gist'].forEach((id) => {
    $(id)?.addEventListener('change', async () => {
      readCfg();
      if (state.cloudSyncConfig.enabled) {
        if (state.cloudSyncConfig.provider === 'cloudflare' && !state.cloudSyncConfig.cfToken) return;
        await syncMobileCloudNow('both', true);
      }
    });
  });

  const handleCfAuth = async (isRegister) => {
    readCfg();
    const username = ($('cs-cf-user')?.value || '').trim();
    const password = $('cs-cf-pass')?.value || '';
    if (!username || !password) {
      setMobileCloudStatus('⚠️ Vui lòng nhập SĐT/Tên đăng nhập và Mật khẩu!', true);
      return;
    }
    setMobileCloudStatus(isRegister ? '⏳ Đang tạo tài khoản & sao lưu 100% dữ liệu...' : '⏳ Đang đăng nhập & tải dữ liệu về máy...');
    const syncUrl = state.cloudSyncConfig.cfSyncUrl || DEFAULT_CLOUDFLARE_SYNC_URL;
    const deviceId = state.cloudSyncConfig.deviceId || 'oppo';
    const res = isRegister
      ? await registerCloudflareAccount(syncUrl, { username, password, deviceId })
      : await loginCloudflareAccount(syncUrl, { username, password, deviceId });
    if (!res.ok) {
      setMobileCloudStatus(`⚠️ ${res.error || 'Thất bại'}`, true);
      return;
    }
    state.cloudSyncConfig = {
      ...state.cloudSyncConfig,
      enabled: true,
      provider: 'cloudflare',
      cfSyncUrl: res.syncUrl || syncUrl,
      cfToken: res.token,
      cfUsername: res.user?.username || username,
      cfDisplayName: res.user?.displayName || username,
      lastRemoteUpdatedAt: 0
    };
    if ($('cs-cf-pass')) $('cs-cf-pass').value = '';
    saveMobileField('cloudSyncConfig', state.cloudSyncConfig);
    renderMobileCloudSyncUI();
    refreshMobileSettingsSummaryPills?.();
    await syncMobileCloudNow(isRegister ? 'push' : 'both', true);
  };

  $('btn-cs-cf-login')?.addEventListener('click', () => handleCfAuth(false));
  $('btn-cs-cf-register')?.addEventListener('click', () => handleCfAuth(true));
  $('btn-cs-cf-logout')?.addEventListener('click', async () => {
    const cfg = state.cloudSyncConfig || {};
    await logoutCloudflareAccount(cfg.cfSyncUrl, cfg.cfToken);
    state.cloudSyncConfig = {
      ...cfg,
      enabled: false,
      cfToken: '',
      cfUsername: '',
      cfDisplayName: ''
    };
    saveMobileField('cloudSyncConfig', state.cloudSyncConfig);
    renderMobileCloudSyncUI();
    refreshMobileSettingsSummaryPills?.();
    setMobileCloudStatus('✓ Đã đăng xuất khỏi tài khoản đồng bộ (dữ liệu trên máy vẫn giữ nguyên).');
  });

  $('btn-cs-gen-room')?.addEventListener('click', () => {
    if ($('cs-room-key')) $('cs-room-key').value = generateRandomKey('licham');
    readCfg();
  });

  $('btn-cs-create-gist')?.addEventListener('click', async () => {
    readCfg();
    setMobileCloudStatus('⏳ Đang tạo GitHub Gist bí mật...');
    const snap = buildSyncSnapshot(state, state.cloudDeletedIds, state.cloudSyncConfig.deviceId || 'oppo');
    const res = await createGitHubSyncGist(state.cloudSyncConfig.githubToken, snap);
    if (!res.ok) {
      setMobileCloudStatus(res.error || 'Tạo Gist thất bại', true);
      return;
    }
    state.cloudSyncConfig.gistId = res.gistId;
    state.cloudSyncConfig.enabled = true;
    state.cloudSyncConfig.lastSyncedAt = Date.now();
    state.cloudSyncConfig.lastRemoteUpdatedAt = snap.updatedAt;
    saveMobileField('cloudSyncConfig', state.cloudSyncConfig);
    syncNativeAndroidAlarms(state);
    renderMobileCloudSyncUI();
    setMobileCloudStatus(`✓ Đã tạo kho đồng bộ bí mật & đẩy dữ liệu lên thành công!`);
  });

  $('btn-cs-sync-now')?.addEventListener('click', async () => {
    readCfg();
    if (!state.cloudSyncConfig.enabled) {
      state.cloudSyncConfig.enabled = true;
      saveMobileField('cloudSyncConfig', state.cloudSyncConfig);
      renderMobileCloudSyncUI();
    }
    await syncMobileCloudNow('both', true);
  });

  $('btn-cs-copy-code')?.addEventListener('click', async () => {
    readCfg();
    const cfg = state.cloudSyncConfig;
    if (cfg.provider === 'firebase' && !cfg.firebaseUrl) {
      setMobileCloudStatus('Hãy nhập Firebase Database URL trước khi copy mã!', true);
      return;
    }
    if (cfg.provider === 'github' && (!cfg.githubToken || !cfg.gistId)) {
      setMobileCloudStatus('Hãy nhập GitHub Token và tạo kho trước khi copy mã!', true);
      return;
    }
    const code = encodePairingCode(cfg);
    try {
      await navigator.clipboard.writeText(code);
      setMobileCloudStatus('✓ Đã sao chép mã kết nối! Dán mã này sang PC Chrome Extension.');
    } catch (_e) {
      window.prompt('Sao chép mã kết nối này sang PC:', code);
    }
  });

  $('btn-cs-paste-toggle')?.addEventListener('click', () => {
    $('cs-paste-box')?.classList.toggle('hidden');
  });

  $('btn-cs-apply-code')?.addEventListener('click', async () => {
    const raw = $('cs-paste-input')?.value || '';
    try {
      const decoded = decodePairingCode(raw);
      state.cloudSyncConfig = {
        ...state.cloudSyncConfig,
        ...decoded,
        lastRemoteUpdatedAt: 0
      };
      saveMobileField('cloudSyncConfig', state.cloudSyncConfig);
      syncNativeAndroidAlarms(state);
      renderMobileCloudSyncUI();
      $('cs-paste-box')?.classList.add('hidden');
      await syncMobileCloudNow('pull', true);
    } catch (err) {
      setMobileCloudStatus(err?.message || 'Mã kết nối không hợp lệ', true);
    }
  });
}

function persistAndSync(field, val) {
  saveMobileField(field, val);
  syncNativeAndroidAlarms(state);
  if (SYNCABLE_DATA_KEYS.includes(field)) {
    scheduleMobileCloudPush();
  }
}

/* ==================== NAVIGATION (Zalo-style 4 main tabs + Thêm sub-apps) ==================== */
const TAB_ORDER = ['calendar', 'reminders', 'ai', 'more', 'discover'];
const DISCOVER_SUB_TABS = new Set(['prayers', 'dreams', 'moles', 'palmistry', 'fortune', 'tuvi', 'fengshui', 'simplate', 'compat', 'tarot', 'iching', 'expense', 'medicine', 'meal', 'diet', 'docscan', 'auspicious', 'highlights', 'water', 'converter']);
const ALL_TABS = [...TAB_ORDER, 'prayers', 'dreams', 'moles', 'palmistry', 'fortune', 'tuvi', 'fengshui', 'simplate', 'compat', 'tarot', 'iching', 'expense', 'medicine', 'meal', 'diet', 'docscan', 'auspicious', 'highlights', 'water', 'converter', 'settings'];

let mobileTabAnimTimer = null;

function updateMobileBnavSlider(_navHighlight, _instant = false) {
  // Clean flat Zalo-style bar: active state uses silky icon zoom + soft radial halo + label reveal (no boxed slider)
}

function clearMobileTabTransitionState() {
  if (mobileTabAnimTimer) {
    clearTimeout(mobileTabAnimTimer);
    mobileTabAnimTimer = null;
  }
  document.querySelectorAll('.tab-view').forEach((v) => {
    v.classList.remove(
      'slide-from-right', 'slide-from-left',
      'zalo-enter-right', 'zalo-enter-left',
      'zalo-exit-left', 'zalo-exit-right',
      'zalo-dragging', 'zalo-neighbor-preview'
    );
    v.style.transform = '';
    v.style.transition = '';
    v.style.opacity = '';
  });
}

function switchTab(tabName) {
  const prevTab = state.activeTab;
  const next = ALL_TABS.includes(tabName) ? tabName : 'calendar';
  if (next === 'settings' && prevTab !== 'settings') {
    state.prevTab = prevTab || 'calendar';
  }
  state.activeTab = next;

  const navHighlight = DISCOVER_SUB_TABS.has(next) ? 'discover' : next;

  // Silky Zalo-style taskbar icon zoom & glow ONLY — instant clean page switch (zero screen ghosting!)
  document.querySelectorAll('.bnav-btn').forEach((b) => {
    const isAct = b.dataset.tab === navHighlight;
    const wasAct = b.classList.contains('active');
    b.classList.toggle('active', isAct);
    if (isAct && !wasAct) {
      b.classList.remove('zalo-pop');
      void b.offsetWidth;
      b.classList.add('zalo-pop');
    }
  });
  $('btn-open-settings')?.classList.toggle('active', next === 'settings');

  const nextEl = $(`tab-${next}`);
  document.querySelectorAll('.tab-view').forEach((v) => {
    v.classList.toggle('active', v === nextEl);
  });

  $('main-scroll')?.classList.toggle('is-ai-tab', next === 'ai');
  $('main-scroll').scrollTop = 0;

  if (next === 'ai') {
    renderMobileGeminiSettings();
    renderMobileGeminiMessages();
    setTimeout(() => {
      const box = $('gm-chat-messages');
      if (box) box.scrollTop = box.scrollHeight;
    }, 60);
  }
  if (next === 'more') renderHolidays();
  if (next === 'prayers') renderPrayers(false);
  if (next === 'highlights') renderHighlightsList();
  if (next === 'water') renderWater();
  if (next === 'settings') {
    renderMobileCloudSyncUI();
    renderOppoHealthStatus();
    refreshMobileSettingsSummaryPills();
  }
  if (next === 'reminders') {
    renderRemindersList();
    renderHighlightsList();
    renderWater();
  }
  updateRemFabVisibility();
}

function updateRemFabVisibility() {
  const dock = $('rem-fab-dock');
  const remFormOpen = Boolean($('rem-form') && !$('rem-form').classList.contains('hidden'));
  const bulkOpen = Boolean($('bulk-rem-panel') && !$('bulk-rem-panel').classList.contains('hidden'));
  const creatorOpen = remFormOpen || bulkOpen;

  // Sync the 2-tab creator header (Thêm | Thêm hàng loạt) with the title row
  $('rem-create-tabs')?.classList.toggle('hidden', !creatorOpen);
  $('rem-card-head-title')?.classList.toggle('hidden', creatorOpen);
  $('btn-rem-tab-single')?.classList.toggle('active', remFormOpen);
  $('btn-toggle-bulk-rem')?.classList.toggle('active', bulkOpen);

  if (!dock) return;
  const shouldShow = state.activeTab === 'reminders' && !creatorOpen;
  dock.classList.toggle('hidden', !shouldShow);
}

function attachTabSwipeNavigation() {
  const scrollEl = $('main-scroll');
  if (!scrollEl) return;

  let startX = 0;
  let startY = 0;
  let startTime = 0;
  let tracking = false;

  const isInsideInteractiveOrHScroll = (target) => {
    let el = target;
    while (el && el !== scrollEl) {
      if (el.nodeType === 1) {
        const tag = el.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || tag === 'OPTION' || tag === 'CANVAS') {
          return true;
        }
        const style = window.getComputedStyle(el);
        if ((style.overflowX === 'auto' || style.overflowX === 'scroll') && el.scrollWidth > el.clientWidth + 6) {
          return true;
        }
      }
      el = el.parentElement;
    }
    return false;
  };

  scrollEl.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1) { tracking = false; return; }
    if (!$('alarm-modal')?.classList.contains('hidden')) { tracking = false; return; }
    const t = e.touches[0];
    if (t.clientX < 22 || t.clientX > window.innerWidth - 22) { tracking = false; return; }
    if (isInsideInteractiveOrHScroll(e.target)) { tracking = false; return; }
    startX = t.clientX;
    startY = t.clientY;
    startTime = Date.now();
    tracking = true;
  }, { passive: true });

  scrollEl.addEventListener('touchcancel', () => {
    tracking = false;
  }, { passive: true });

  scrollEl.addEventListener('touchend', (e) => {
    if (!tracking || e.changedTouches.length === 0) return;
    tracking = false;
    const t = e.changedTouches[0];
    const dx = t.clientX - startX;
    const dy = t.clientY - startY;
    const dt = Date.now() - startTime;
    const absX = Math.abs(dx);
    const absY = Math.abs(dy);

    const validSwipe = absX >= 62 && absX > absY * 1.5 && (dt <= 600 || absX >= 115);
    if (!validSwipe) return;

    if (state.activeTab === 'settings') {
      if (dx > 0) {
        try { navigator.vibrate?.(10); } catch (_e) {}
        switchTab(state.prevTab || 'calendar');
      }
      return;
    }

    const curIdx = TAB_ORDER.indexOf(state.activeTab);
    if (curIdx < 0) return;
    const nextIdx = curIdx + (dx < 0 ? 1 : -1);
    if (nextIdx < 0 || nextIdx >= TAB_ORDER.length) return;
    try { navigator.vibrate?.(10); } catch (_e) {}
    switchTab(TAB_ORDER[nextIdx]);
  }, { passive: true });
}

function switchRemSub(sub) {
  state.activeRemSub = sub;
  document.querySelectorAll('#tab-reminders .subtab').forEach((b) => {
    b.classList.toggle('active', b.dataset.sub === sub);
  });
  document.querySelectorAll('#tab-reminders .sub-pane').forEach((p) => {
    p.classList.toggle('active', p.id === `sub-${sub}`);
  });
  updateRemFabVisibility();
}

function jumpToSolar(solarObj) {
  if (!solarObj) return;
  state.selectedDate = { day: solarObj.day, month: solarObj.month, year: solarObj.year };
  state.viewMonth = solarObj.month;
  state.viewYear = solarObj.year;
  switchTab('calendar');
  renderAllCalendarViews();
}

function stepDay(delta) {
  const dt = new Date(state.selectedDate.year, state.selectedDate.month - 1, state.selectedDate.day + delta);
  state.selectedDate = { day: dt.getDate(), month: dt.getMonth() + 1, year: dt.getFullYear() };
  state.viewMonth = state.selectedDate.month;
  state.viewYear = state.selectedDate.year;
  renderAllCalendarViews();
}

/* ==================== RENDER CALENDAR + FULL ALMANAC DETAIL ==================== */
function renderUpcomingAppointmentsMobile() {
  const container = $('m-upcoming-card');
  if (!container) return;

  const now = new Date();
  const nowMs = now.getTime();
  const todayJd = jdFromDate(now.getDate(), now.getMonth() + 1, now.getFullYear());
  const todayKey = getTodayKey(now);
  const items = [];

  for (const rem of state.timedReminders) {
    if (!rem || rem.done) continue;
    const nextMs = getNextReminderTimestamp(rem, nowMs);
    if (!nextMs) continue;
    const nd = new Date(nextMs);
    const d = nd.getDate(), m = nd.getMonth() + 1, y = nd.getFullYear();
    const lunar = convertSolar2Lunar(d, m, y, TIMEZONE_VN);
    items.push({
      sortMs: nextMs,
      title: rem.title,
      note: rem.note || '',
      day: d,
      month: m,
      year: y,
      lunarDay: lunar.day,
      lunarMonth: lunar.month,
      time: rem.time || '',
      diffDays: jdFromDate(d, m, y) - todayJd
    });
  }

  for (const hl of state.highlightedRanges) {
    if (!hl || !hl.startDate) continue;
    const endD = hl.endDate || hl.startDate;
    if (endD < todayKey) continue;
    const targetKey = hl.startDate >= todayKey ? hl.startDate : todayKey;
    const [y, m, d] = targetKey.split('-').map(Number);
    let h = 23, min = 59;
    const tm = String(hl.note || '').match(/(\d{1,2}):(\d{2})/);
    if (tm) { h = Number(tm[1]); min = Number(tm[2]); }
    const sortMs = new Date(y, m - 1, d, h, min, 0).getTime();
    if (sortMs <= nowMs) continue;
    const lunar = convertSolar2Lunar(d, m, y, TIMEZONE_VN);
    items.push({
      sortMs,
      title: hl.title,
      note: hl.note || '',
      day: d,
      month: m,
      year: y,
      lunarDay: lunar.day,
      lunarMonth: lunar.month,
      time: tm ? `${pad2(h)}:${pad2(min)}` : '',
      diffDays: jdFromDate(d, m, y) - todayJd
    });
  }

  items.sort((a, b) => a.sortMs - b.sortMs);
  const next = items[0] || null;
  if (!next) {
    container.classList.add('hidden');
    container.innerHTML = '';
    return;
  }

  const pillCls = next.diffDays <= 0 ? 'up-pill today' : next.diffDays <= 3 ? 'up-pill soon' : 'up-pill';
  const pillTxt = next.diffDays <= 0 ? 'Hôm nay' : next.diffDays === 1 ? 'Ngày mai' : `Còn ${next.diffDays} ngày`;
  const timePart = next.time ? `Giờ: ${next.time} • ` : '';
  const datePart = `${pad2(next.day)}/${pad2(next.month)}/${next.year} (${next.lunarDay}/${next.lunarMonth} ÂL)`;

  container.classList.remove('hidden');
  container.style.cursor = 'pointer';
  container.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
      <strong style="font-size:13.5px;color:#78350F;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">⏰ ${esc(next.title)}</strong>
      <span class="${pillCls}">${pillTxt}</span>
    </div>
    <div style="font-size:12px;color:#92400E;margin-top:3px;">${timePart}${datePart}${next.note ? ` • ${esc(next.note)}` : ''}</div>
  `;
  container.onclick = () => {
    state.selectedDate = { day: next.day, month: next.month, year: next.year };
    state.viewMonth = next.month;
    state.viewYear = next.year;
    switchTab('reminders');
    switchRemSub('rem');
  };
}

function renderAllCalendarViews() {
  renderCalendarGrid();
  renderDayDetails();
  renderUpcomingAppointmentsMobile();
  renderCountdowns();
  renderWeatherViews();
}

function renderCalendarGrid() {
  $('select-month').value = String(state.viewMonth);
  $('select-year').value = String(state.viewYear);

  const first = new Date(state.viewYear, state.viewMonth - 1, 1);
  const startOff = (first.getDay() + 6) % 7;
  const daysInM = new Date(state.viewYear, state.viewMonth, 0).getDate();
  const totalCells = Math.ceil((startOff + daysInM) / 7) * 7;

  const todayObj = { day: today.getDate(), month: today.getMonth() + 1, year: today.getFullYear() };
  const frag = document.createDocumentFragment();

  for (let i = 0; i < totalCells; i++) {
    const dt = new Date(state.viewYear, state.viewMonth - 1, 1 - startOff + i);
    const d = dt.getDate(), m = dt.getMonth() + 1, y = dt.getFullYear();
    const dow = dt.getDay();
    const isCur = m === state.viewMonth && y === state.viewYear;
    const cellObj = { day: d, month: m, year: y };
    const cellKey = formatDateKey(y, m, d);
    const lunar = convertSolar2Lunar(d, m, y, TIMEZONE_VN);
    const events = getEventsForDate(d, m, y, state.customEvents, {
      includeSolar: true,
      includeLunar: true,
      includeMung1Ram: false
    });
    const hasTimed = state.timedReminders.some((r) => !r.done && doesReminderOccurOnDate(r, cellKey));
    const hls = getHighlightsForDate(cellKey, state.highlightedRanges);

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'day-cell';
    if (!isCur) btn.classList.add('other-month');
    if (dow === 0) btn.classList.add('is-sun');
    if (dow === 6) btn.classList.add('is-sat');
    if (hls.length > 0) btn.classList.add(`hl-${hls[0].color || 'yellow'}`);
    if (d === todayObj.day && m === todayObj.month && y === todayObj.year) btn.classList.add('is-today');
    if (d === state.selectedDate.day && m === state.selectedDate.month && y === state.selectedDate.year) {
      btn.classList.add('is-selected');
    }

    const lCls = lunar.day === 1 ? 'cell-l m1' : lunar.day === 15 ? 'cell-l ram' : 'cell-l';
    const dots = new Set();
    for (const ev of events) {
      if (ev.type === 'lunar') dots.add('dot-lunar');
      else if (ev.type === 'solar') dots.add('dot-solar');
      else if (ev.type.startsWith('custom')) dots.add('dot-custom');
    }
    if (hasTimed) dots.add('dot-timed');
    if ((lunar.day === 1 || lunar.day === 15) && dots.size === 0) dots.add('dot-ram');

    const wxDay = state.weatherData?.dailyByDate?.[cellKey] || null;
    const wxHtml = wxDay ? `<span class="cell-wx">${wxDay.icon}</span>` : '';

    btn.innerHTML = `
      ${wxHtml}
      <span class="cell-s">${d}</span>
      <span class="${lCls}">${formatLunarDayShort(lunar.day, lunar.month, lunar.leap)}</span>
      <span class="cell-dots">${Array.from(dots).slice(0, 3).map((c) => `<i class="dot ${c}"></i>`).join('')}</span>
    `;

    btn.addEventListener('click', () => {
      state.selectedDate = cellObj;
      if (!isCur) {
        state.viewMonth = m;
        state.viewYear = y;
      }
      renderAllCalendarViews();
      const rec = getRecommendedPrayersForDate(cellObj, lunar, state.customEvents);
      renderPrayers(true);
      if (state.prayerPrefs.autoOpenOnSpecialDay !== false && rec.isSpecialRitualDay) {
        state.prayerCategory = 'recommended';
        renderPrayers(true);
        switchTab('prayers');
      }
    });

    frag.appendChild(btn);
  }

  $('calendar-grid').innerHTML = '';
  $('calendar-grid').appendChild(frag);
}

function renderDayDetails() {
  const { day, month, year } = state.selectedDate;
  const dateKey = getSelectedKey();
  const details = getFullDayDetails(day, month, year, TIMEZONE_VN);
  const { solar, lunar, canChi, hoangDaoDay, truc, hours, xuatHanh, tuoiHopXung, nguHanhDetail, ageRelations, batTu, lyThuanPhong, khongMinh } = details;

  // Header subtitle (always today's lunar date)
  const tLunar = convertSolar2Lunar(today.getDate(), today.getMonth() + 1, today.getFullYear(), TIMEZONE_VN);
  $('header-sub').textContent = `${tLunar.day}/${tLunar.month}${tLunar.leap ? 'N' : ''} ÂL • ${getYearCanChi(tLunar.year)}`;

  // Hero banner
  $('hero-quality').textContent = `Ngày ${hoangDaoDay.type} (${hoangDaoDay.starName})`;
  $('hero-quality').className = `quality-pill ${hoangDaoDay.isGood ? 'good' : 'bad'}`;
  $('hero-weekday').textContent = solar.weekday;
  $('hero-solar-day').textContent = String(solar.day);
  $('hero-solar-my').textContent = `Tháng ${solar.month}, ${solar.year}`;
  $('hero-lunar-kicker').textContent = lunar.leap
    ? `Âm lịch • Tháng nhuận (${lunar.monthLength} ngày)`
    : `Âm lịch • ${lunar.monthLength === 30 ? 'Tháng đủ (30)' : 'Tháng thiếu (29)'}`;
  $('hero-lunar-big').textContent = details.lunarFormatted;
  $('hero-lunar-year').textContent = `Năm ${canChi.year} (Con ${canChi.yearAnimal})`;
  $('hero-canchi-chips').innerHTML = `
    <span class="canchi-chip">Tháng ${canChi.month}</span>
    <span class="canchi-chip">Ngày ${canChi.day}</span>
    <span class="canchi-chip">Tiết ${details.tietKhi}</span>
  `;

  // Contextual prayer button label
  const rec = getRecommendedPrayersForDate(solar, lunar, state.customEvents);
  $('btn-hero-prayer').textContent = rec.isSpecialRitualDay
    ? `🙏 Văn khấn: ${rec.reason.split('•')[0].trim()}`
    : '🙏 Văn khấn ngày này';

  // Active highlights
  const activeHls = getHighlightsForDate(dateKey, state.highlightedRanges);
  if (activeHls.length > 0) {
    $('day-highlight-banner').classList.remove('hidden');
    $('day-highlight-banner').innerHTML = activeHls
      .map((h) => `<div><strong>🖍 ${esc(h.title)}</strong>${h.note ? `<div class="muted-xs">${esc(h.note)}</div>` : ''}</div>`)
      .join('');
  } else {
    $('day-highlight-banner').classList.add('hidden');
  }

  // Day events & timed reminders
  $('day-rem-label').textContent = `${pad2(day)}/${pad2(month)}/${year}`;
  const evs = getEventsForDate(day, month, year, state.customEvents, {
    includeSolar: true,
    includeLunar: true,
    includeMung1Ram: true
  });
  $('day-events-box').innerHTML = evs.length === 0
    ? '<div class="empty-msg">Không có ngày lễ cố định trong ngày này.</div>'
    : evs.map((ev) => `<div class="item-row ${ev.type.includes('solar') ? 'solar' : ev.type.includes('custom') ? 'custom' : ''}"><div class="item-body"><div class="item-name">${esc(ev.name)}</div><div class="item-sub">${esc(ev.desc)} • ${esc(ev.dateText)}</div></div></div>`).join('');

  const dayRems = state.timedReminders
    .filter((r) => doesReminderOccurOnDate(r, dateKey))
    .sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  $('day-reminders-box').innerHTML = '';
  if (dayRems.length === 0) {
    $('day-reminders-box').innerHTML = '<div class="empty-msg">Chưa có nhắc giờ cho ngày này.</div>';
  } else {
    dayRems.forEach((r) => $('day-reminders-box').appendChild(buildReminderRow(r, false)));
  }

  // Almanac info
  $('d-nap-am').textContent = details.napAm;
  $('d-tiet-khi').textContent = details.tietKhi;
  $('d-star-name').textContent = `${hoangDaoDay.starName} (${hoangDaoDay.type})`;
  $('d-star-desc').textContent = hoangDaoDay.desc;
  $('d-first-hour').textContent = `Giờ ${canChi.hourStart} (23h–1h)`;
  $('d-moon-phase').textContent = `${details.moonPhase.icon} ${details.moonPhase.name}`;
  $('d-zodiac-week').textContent = `${solar.zodiac} • Tuần ${solar.weekOfYear}`;
  $('d-can-el').textContent = nguHanhDetail.canDesc;
  $('d-chi-el').textContent = nguHanhDetail.chiDesc;
  $('d-hop-khac').textContent = `Hợp mệnh: ${nguHanhDetail.hopMenh} • Khắc mệnh: ${nguHanhDetail.khacMenh}`;
  $('d-can-chi-rel').textContent = `⚖️ ${nguHanhDetail.relation}`;
  $('d-can-chi-rel').className = `rel-banner ${nguHanhDetail.relationLevel}`;

  // 10-task verdicts
  $('d-task-verdicts').innerHTML = details.taskVerdicts
    .map((v) => `<div class="verdict-row"><span>${esc(v.name)}</span><span class="verdict-tag ${v.level}">${esc(v.label)}</span></div>`)
    .join('');

  // Personal age compatibility
  const profile = getBirthProfile(state.auspiciousPrefs?.birthYear);
  if (profile) {
    const evalDay = evaluateDateForTask(day, month, year, profile, state.auspiciousPrefs?.taskId || 'chung');
    const pills = [
      ...evalDay.pros.map((p) => `<span class="reason-pill pro">✓ ${esc(p)}</span>`),
      ...evalDay.warnings.map((w) => `<span class="reason-pill warn">⚠ ${esc(w)}</span>`)
    ].join('');
    const bestH = evalDay.bestHour ? `${evalDay.bestHour.chi} (${evalDay.bestHour.range})` : '';
    $('d-personal-age').innerHTML = `
      <div class="card-head" style="margin-bottom:4px;">
        <strong>Tuổi ${esc(profile.canChi)} (${esc(profile.napAmName)})</strong>
        <span class="badge-pill ${evalDay.ratingKey === 'bad' ? 'bad' : ''}">${evalDay.rating} (${evalDay.score}/100)</span>
      </div>
      ${bestH ? `<div class="muted-xs" style="margin-bottom:6px;">⏰ Giờ đẹp nhất riêng cho tuổi bạn: <strong>${esc(bestH)}</strong></div>` : ''}
      <div>${pills}</div>
    `;
  } else {
    $('d-personal-age').innerHTML = '<div class="muted-xs">Qua tab <strong>🔮 Ngày tốt</strong> nhập năm sinh (VD: 1991) để xem điểm hợp/xung riêng của ngày với mệnh tuổi của bạn!</div>';
  }

  // Hours
  $('d-hours-good').innerHTML = hours.hoangDao.map((h) => `<div class="hour-chip good"><strong>${h.canChi}</strong><span>${h.range}</span></div>`).join('');
  $('d-hours-bad').innerHTML = hours.hacDao.map((h) => `<div class="hour-chip bad"><strong>${h.canChi}</strong><span>${h.range}</span></div>`).join('');

  // Taboos & Ngọc Hạp
  const { taboos, goodStars, badStars } = details.tabooAndStars;
  $('d-taboos').innerHTML = taboos.length === 0
    ? '<div class="taboo-ok">✓ Không phạm ngày đại kỵ (Tam Nương, Nguyệt Kỵ, Dương Công Kỵ, Sát Chủ, Thọ Tử).</div>'
    : taboos.map((t) => `<div class="taboo-warn"><strong>⚠ Phạm ${esc(t.name)}</strong><span>${esc(t.desc)}</span></div>`).join('');
  $('d-good-stars').innerHTML = goodStars.map((s) => `<li>${esc(s)}</li>`).join('');
  $('d-bad-stars').innerHTML = badStars.map((s) => `<li>${esc(s)}</li>`).join('');

  // 28 Stars
  $('d-battu-name').textContent = `Sao ${batTu.name}`;
  $('d-battu-badge').textContent = batTu.isGood ? 'Sao Tốt' : 'Sao Xấu';
  $('d-battu-badge').className = `badge-pill${batTu.isGood ? '' : ' bad'}`;
  $('d-battu-good').textContent = batTu.good;
  $('d-battu-bad').textContent = batTu.bad;

  // 12 Truc
  $('d-truc-name').textContent = truc.name;
  $('d-truc-good').textContent = truc.good;
  $('d-truc-bad').textContent = truc.bad;

  // Khổng Minh & Lý Thuần Phong
  $('d-km-badge').textContent = `Ngày ${khongMinh.name}`;
  $('d-km-badge').className = `badge-pill${khongMinh.isGood ? '' : ' bad'}`;
  $('d-km-desc').textContent = khongMinh.desc;

  $('d-ltp-badge').textContent = `Ngày ${lyThuanPhong.dayCung.name}`;
  $('d-ltp-badge').className = `badge-pill${lyThuanPhong.dayCung.isGood ? '' : ' bad'}`;
  $('d-ltp-desc').textContent = lyThuanPhong.dayCung.desc;
  $('d-ltp-hours').innerHTML = lyThuanPhong.hourSlots
    .map((s) => `<div class="ltp-chip ${s.isGood ? 'good' : 'bad'}"><strong>${s.isGood ? '✓' : '•'} ${esc(s.name)}</strong><span>${esc(s.label)}</span></div>`)
    .join('');

  // Directions & Age Relations
  $('d-hy-than').textContent = xuatHanh.hyThan;
  $('d-tai-than').textContent = xuatHanh.taiThan;
  $('d-hac-than').textContent = xuatHanh.hacThan;
  $('d-exact-xung').textContent = ageRelations.exactXung;
  $('d-luc-hop').textContent = ageRelations.lucHop;
  $('d-tam-hop').textContent = ageRelations.tamHop;
  $('d-xung-chi').textContent = tuoiHopXung.xung;
  $('d-tuong-hai').textContent = ageRelations.tuongHai;
  $('d-tuong-pha').textContent = ageRelations.tuongPha;
  $('d-tuhanhxung').textContent = ageRelations.tuHanhXung;

  // Thai Thần, Bành Tổ, Quote
  $('d-thai-than').textContent = details.thaiThan;
  $('d-banhto-can').textContent = details.banhTo?.can || '';
  $('d-banhto-chi').textContent = details.banhTo?.chi || '';
  $('d-quote').textContent = `“${details.dailyQuote}”`;

  // Quick Overview Strip + Dưỡng sinh 24 Tiết khí + Nhịp sinh học
  if ($('d-quick-hd')) {
    $('d-quick-hd').innerHTML = `<strong>🕐 Giờ Hoàng Đạo:</strong> ${hours.hoangDao.map((h) => `${h.chi} (${h.range})`).join(' • ')}`;
  }
  if ($('d-quick-nk')) {
    $('d-quick-nk').innerHTML = `
      <div class="tone-box good"><div class="tone-title">✓ Nên làm (${esc(truc.name)})</div><p>${esc(truc.good)}</p></div>
      <div class="tone-box bad"><div class="tone-title">✕ Kiêng kỵ</div><p>${esc(truc.bad)}</p></div>
    `;
  }
  if ($('d-tietkhi-health')) {
    $('d-tietkhi-health').innerHTML = `<strong>🌿 Dưỡng sinh Tiết ${esc(details.tietKhi)}:</strong> ${esc(details.tietKhiHealth)}`;
  }
  if ($('d-bio-box')) {
    const bio = getBiorhythmForDate(state.auspiciousPrefs?.birthYear, day, month, year);
    if (bio) {
      $('d-bio-box').classList.remove('hidden');
      $('d-bio-box').innerHTML = `
        <div><strong>⚡ Nhịp sinh học (${esc(state.auspiciousPrefs.birthYear)}):</strong> Năng lượng <strong>${bio.avg}%</strong></div>
        <div class="bio-bars">
          <div><span>💪 Thể chất ${bio.physical}%</span><div class="bio-track"><div class="bio-fill" style="width:${bio.physical}%;background:#059669;"></div></div></div>
          <div><span>❤️ Cảm xúc ${bio.emotional}%</span><div class="bio-track"><div class="bio-fill" style="width:${bio.emotional}%;background:#DC2626;"></div></div></div>
          <div><span>🧠 Trí tuệ ${bio.intellectual}%</span><div class="bio-track"><div class="bio-fill" style="width:${bio.intellectual}%;background:#2563EB;"></div></div></div>
        </div>
      `;
    } else {
      $('d-bio-box').classList.add('hidden');
    }
  }
}

/* ==================== WEATHER (OPEN-METEO) ==================== */
function populateWeatherCities() {
  const sel = $('wx-city');
  if (!sel) return;
  const prefs = state.weatherPrefs || DEFAULT_WEATHER_PREFS;
  sel.innerHTML = '';
  if ((prefs.cityId === 'gps' || prefs.cityId === 'custom') && Number.isFinite(Number(prefs.customLat))) {
    const g = document.createElement('option');
    g.value = prefs.cityId;
    g.textContent = `📍 ${prefs.customName || (prefs.cityId === 'gps' ? 'Vị trí GPS' : 'Địa điểm đã chọn')}`;
    sel.appendChild(g);
  }
  for (const c of VN_CITIES) {
    const o = document.createElement('option');
    o.value = c.id;
    o.textContent = c.name;
    sel.appendChild(o);
  }
  sel.value = prefs.cityId || 'hanoi';
}

function renderWeatherViews() {
  const wx = state.weatherData;
  const dateKey = getSelectedKey();
  const todayKey = getTodayKey();

  if ($('btn-top-weather')) {
    $('btn-top-weather').textContent = wx?.current ? `${wx.current.icon} ${wx.current.temp}°` : '⛅ --°';
  }

  const body = $('wx-body');
  const adv = $('wx-advice');
  if (!body) return;
  if (state.weatherError && !wx) {
    body.innerHTML = `<div class="muted-xs">Không tải được thời tiết (${esc(state.weatherError)}). Kiểm tra mạng và chạm ⛅ góc trên để thử lại.</div>`;
    if (adv) adv.innerHTML = '';
    return;
  }
  if (!wx) {
    body.innerHTML = '<div class="muted-xs">Đang tải dự báo thời tiết, AQI &amp; Tia UV...</div>';
    if (adv) adv.innerHTML = '';
    return;
  }

  const dayWx = wx.dailyByDate?.[dateKey] || null;
  if (dayWx) {
    const isToday = dateKey === todayKey;
    const tempMain = isToday ? `${wx.current.temp}°C` : `${dayWx.tMin}° ~ ${dayWx.tMax}°C`;
    const pills = [
      `<span class="wx-pill">🌡️ ${dayWx.tMin}°–${dayWx.tMax}°C</span>`,
      `<span class="wx-pill">💧 Mưa ${dayWx.rainProb}%${dayWx.rainMm > 0 ? ` (${dayWx.rainMm}mm)` : ''}</span>`
    ];
    if (dayWx.uvMax !== null && dayWx.uvMax !== undefined) {
      pills.push(`<span class="wx-pill uv-${dayWx.uvInfo?.level || 'good'}">☀️ UV ${dayWx.uvMax} (${dayWx.uvInfo?.label || ''})</span>`);
    }
    if (isToday) {
      if (wx.current.aqi !== null && wx.current.aqi !== undefined) {
        pills.push(`<span class="wx-pill aqi-${wx.current.aqiInfo?.level || 'good'}">🍃 AQI ${wx.current.aqi} (${wx.current.aqiInfo?.label || ''})</span>`);
      }
      pills.push(`<span class="wx-pill">💦 Ẩm ${wx.current.humidity}%</span>`);
      pills.push(`<span class="wx-pill">💨 Gió ${wx.current.wind} km/h</span>`);
    }
    const hourlyHtml = (isToday && Array.isArray(wx.hourlyNext) && wx.hourlyNext.length > 0)
      ? `<div class="wx-hourly-strip">${wx.hourlyNext.map((h) => `
          <div class="wx-hour-item">
            <div class="wx-hour-t">${esc(h.timeLabel)}</div>
            <div class="wx-hour-ico">${h.icon}</div>
            <div class="wx-hour-temp">${h.temp}°</div>
            <div class="wx-hour-rain">💧${h.rainProb}%</div>
          </div>
        `).join('')}</div>`
      : '';
    body.innerHTML = `
      <div class="wx-main">
        <span class="wx-ico">${dayWx.icon}</span>
        <div>
          <div class="wx-temp">${tempMain}</div>
          <div class="wx-cond">${esc(dayWx.label)} • ${esc(wx.locationName)}</div>
        </div>
      </div>
      <div class="wx-pills">${pills.join('')}</div>
      ${hourlyHtml}
      <div class="wx-source-note">
        <span>🛰️ Mô hình: <strong>${esc(wx.sourceLabel || 'ECMWF Châu Âu')}</strong></span>
        ${Number.isFinite(wx.lat) ? `<span>${Number(wx.lat).toFixed(2)}°N, ${Number(wx.lon).toFixed(2)}°E</span>` : ''}
      </div>
    `;
    if (adv) {
      const dayRems = state.timedReminders.filter((r) => !r.done && doesReminderOccurOnDate(r, dateKey));
      const tips = getSmartWeatherAdvice(dayWx, wx.current, isToday, dayRems);
      adv.innerHTML = tips.map((t) => `<div class="wx-advice-item ${t.level}">${esc(t.text)}</div>`).join('');
    }
  } else {
    body.innerHTML = `
      <div class="wx-main">
        <span class="wx-ico">${wx.current.icon}</span>
        <div>
          <div class="wx-cond">Hiện tại (${esc(wx.locationName)}): <strong>${wx.current.temp}°C</strong> — ${esc(wx.current.label)}</div>
          <div class="muted-xs">Dự báo theo ngày hiển thị trong 16 ngày kể từ hôm nay.</div>
        </div>
      </div>
    `;
    if (adv) adv.innerHTML = '';
  }
}

let mobileRadarOpen = false;
let mobileRadarProvider = 'windy';
let lastAutoGpsMoveCheckAt = 0;

function refreshMobileRadarFrame() {
  if (!mobileRadarOpen) return;
  const frame = $('wx-radar-frame');
  const extLink = $('wx-radar-ext');
  if (!frame) return;
  const loc = resolveWeatherLocation(state.weatherPrefs || DEFAULT_WEATHER_PREFS);
  const url = buildLiveRadarUrl(loc.lat, loc.lon, mobileRadarProvider);
  if (frame.dataset.loadedUrl !== url) {
    frame.src = url;
    frame.dataset.loadedUrl = url;
  }
  if (extLink) extLink.href = url;
}

async function maybeAutoRefreshMovingGps() {
  const prefs = state.weatherPrefs || DEFAULT_WEATHER_PREFS;
  if (prefs.cityId !== 'gps') return;
  if (Date.now() - lastAutoGpsMoveCheckAt < 5 * 60 * 1000) return; // throttle 5 min
  lastAutoGpsMoveCheckAt = Date.now();
  try {
    const { lat, lon } = await requestGpsPosition();
    const movedKm = haversineKm(prefs.customLat, prefs.customLon, lat, lon);
    if (movedKm >= 0.8) {
      const placeName = await reverseGeocodeVietnam(lat, lon);
      state.weatherPrefs = { cityId: 'gps', customLat: lat, customLon: lon, customName: placeName };
      populateWeatherCities();
      persistAndSync('weatherPrefs', state.weatherPrefs);
      await loadWeather(true);
      refreshMobileRadarFrame();
    }
  } catch (_e) {
    // Silent background check: ignore if GPS unavailable indoors
  }
}

async function loadWeather(force = false) {
  try {
    state.weatherError = '';
    state.weatherData = await fetchWeatherForecast(state.weatherPrefs || DEFAULT_WEATHER_PREFS, force);
  } catch (err) {
    state.weatherError = err?.message || 'Lỗi mạng';
  }
  renderWeatherViews();
  renderCalendarGrid();
  refreshMobileRadarFrame();
}

/* ==================== COUNTDOWNS ==================== */
function getUpcomingReminders() {
  const nowMs = Date.now();
  const todayJd = jdFromDate(today.getDate(), today.getMonth() + 1, today.getFullYear());
  const list = [];
  for (const rem of state.timedReminders) {
    if (rem.done) continue;
    const nextMs = getNextReminderTimestamp(rem, nowMs);
    if (!nextMs) continue;
    const dt = new Date(nextMs);
    const solar = { day: dt.getDate(), month: dt.getMonth() + 1, year: dt.getFullYear() };
    const daysUntil = jdFromDate(solar.day, solar.month, solar.year) - todayJd;
    if (daysUntil > 365) continue;
    const lunar = convertSolar2Lunar(solar.day, solar.month, solar.year, TIMEZONE_VN);
    list.push({
      id: rem.id,
      name: `⏰ ${rem.title} (${rem.time})`,
      rawTitle: rem.title,
      time: rem.time,
      type: 'reminder',
      daysUntil,
      nextMs,
      solar,
      lunar
    });
  }
  return list.sort((a, b) => a.nextMs - b.nextMs);
}

function fmtCd(days, time = '') {
  if (days === 0) return time ? `Hôm nay • ${time}` : 'Hôm nay 🎉';
  if (days === 1) return time ? `Ngày mai • ${time}` : 'Ngày mai (1 ngày)';
  return `Còn ${days} ngày`;
}

function renderCountdowns() {
  const grid = $('cal-countdown-grid');
  if (!grid) return;
  const solarTet = getNextSolarNewYearCountdown(today);
  const lunarTet = getNextTetCountdown(today);
  const tetCC = getYearCanChi(lunarTet.lunarYear);
  const hols = getUpcomingEvents(today, 365, state.customEvents, { includeSolar: true, includeLunar: true, includeMung1Ram: false });
  const nextHol = hols[0] || null;
  const nextRem = getUpcomingReminders()[0] || null;

  const tiles = [
    {
      cls: 'cd-solar',
      lbl: '🎆 Tết Dương Lịch',
      days: fmtCd(solarTet.daysUntil),
      sub: `01/01/${solarTet.targetYear} (${solarTet.lunar.day}/${solarTet.lunar.month} ÂL)`,
      onClick: () => jumpToSolar(solarTet.solar)
    },
    {
      cls: 'cd-lunar',
      lbl: '🏮 Tết Âm Lịch',
      days: fmtCd(lunarTet.daysUntil),
      sub: `Tết ${tetCC} • ${pad2(lunarTet.tetSolar.day)}/${pad2(lunarTet.tetSolar.month)}/${lunarTet.tetSolar.year}`,
      onClick: () => jumpToSolar(lunarTet.tetSolar)
    },
    nextHol
      ? {
          cls: 'cd-holiday',
          lbl: '🎉 Lễ Tết gần nhất',
          days: fmtCd(nextHol.daysUntil),
          sub: `${nextHol.name} (${pad2(nextHol.solar.day)}/${pad2(nextHol.solar.month)})`,
          onClick: () => jumpToSolar(nextHol.solar)
        }
      : {
          cls: 'cd-holiday',
          lbl: '🎉 Lễ Tết gần nhất',
          days: '—',
          sub: 'Xem danh sách lễ Tết',
          onClick: () => switchTab('more')
        },
    nextRem
      ? {
          cls: 'cd-reminder',
          lbl: '⏰ Nhắc nhở sắp tới',
          days: fmtCd(nextRem.daysUntil, nextRem.time),
          sub: `${nextRem.rawTitle} (${pad2(nextRem.solar.day)}/${pad2(nextRem.solar.month)})`,
          onClick: () => jumpToSolar(nextRem.solar)
        }
      : {
          cls: 'cd-reminder',
          lbl: '⏰ Nhắc nhở sắp tới',
          days: 'Chưa có lịch',
          sub: 'Chạm để đặt lịch hẹn',
          onClick: () => switchTab('reminders')
        }
  ];

  grid.innerHTML = '';
  for (const t of tiles) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `cd-tile ${t.cls}`;
    b.innerHTML = `<span class="cd-lbl">${esc(t.lbl)}</span><span class="cd-days">${esc(t.days)}</span><span class="cd-sub">${esc(t.sub)}</span>`;
    b.addEventListener('click', t.onClick);
    grid.appendChild(b);
  }
}

/* ==================== VĂN KHẤN (32 PRAYERS) ==================== */
function renderPrayerReader() {
  const prayer = PRAYERS_CATALOG.find((p) => p.id === state.selectedPrayerId) || PRAYERS_CATALOG[0];
  if (!prayer) return;
  const { day, month, year } = state.selectedDate;
  const lunar = convertSolar2Lunar(day, month, year, TIMEZONE_VN);
  $('p-view-title').textContent = prayer.title;
  $('p-view-occasion').textContent = `📌 ${prayer.occasion}`;
  $('p-view-offerings').innerHTML = `<strong>🕯 Sắm lễ gợi ý:</strong> ${esc(prayer.offerings)}`;
  $('p-view-text').textContent = formatPrayerContent(prayer, state.selectedDate, lunar, state.prayerPrefs);
  $('p-view-text').style.fontSize = `${state.prayerPrefs.fontSize || 15}px`;
}

function renderPrayers(autoPick = false) {
  const { day, month, year } = state.selectedDate;
  const lunar = convertSolar2Lunar(day, month, year, TIMEZONE_VN);
  const rec = getRecommendedPrayersForDate(state.selectedDate, lunar, state.customEvents);

  $('p-date-summary').textContent = `${formatLunarDateFull(lunar)}, năm ${getYearCanChi(lunar.year)} (${pad2(day)}/${pad2(month)}/${year} DL)`;
  $('p-reason').textContent = rec.isSpecialRitualDay ? `✨ ${rec.reason}` : rec.reason;

  if (autoPick && rec.prayerIds.length > 0) {
    state.selectedPrayerId = rec.prayerIds[0];
  }

  $('p-rec-chips').innerHTML = '';
  for (const pid of rec.prayerIds) {
    const pObj = PRAYERS_CATALOG.find((p) => p.id === pid);
    if (!pObj) continue;
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = `pill${pObj.id === state.selectedPrayerId ? ' active' : ''}`;
    chip.textContent = pObj.shortTitle;
    chip.addEventListener('click', () => {
      state.selectedPrayerId = pObj.id;
      renderPrayers(false);
      $('prayer-reader-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $('p-rec-chips').appendChild(chip);
  }

  $('p-cat-pills').innerHTML = '';
  for (const cat of PRAYER_CATEGORIES) {
    const pill = document.createElement('button');
    pill.type = 'button';
    pill.className = `pill${state.prayerCategory === cat.id ? ' active' : ''}`;
    pill.textContent = cat.label;
    pill.addEventListener('click', () => {
      state.prayerCategory = cat.id;
      renderPrayers(false);
    });
    $('p-cat-pills').appendChild(pill);
  }

  const q = (state.prayerSearch || '').trim().toLowerCase();
  const recSet = new Set(rec.prayerIds);
  const list = PRAYERS_CATALOG.filter((p) => {
    if (q) {
      const hay = `${p.title} ${p.shortTitle} ${p.occasion} ${p.offerings}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (state.prayerCategory === 'recommended') return recSet.has(p.id);
    if (state.prayerCategory === 'all') return true;
    return p.category === state.prayerCategory;
  });

  $('p-list').innerHTML = '';
  if (list.length === 0) {
    $('p-list').innerHTML = '<div class="empty-msg">Không thấy bài khấn phù hợp. Thử chọn "Tất cả".</div>';
  } else {
    for (const p of list) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `p-list-item${p.id === state.selectedPrayerId ? ' active' : ''}`;
      btn.innerHTML = `<div class="p-list-title">${esc(p.shortTitle)}</div><div class="p-list-occ">${esc(p.occasion)}</div>`;
      btn.addEventListener('click', () => {
        state.selectedPrayerId = p.id;
        renderPrayers(false);
        $('prayer-reader-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
      $('p-list').appendChild(btn);
    }
  }

  renderPrayerReader();
}

/* ==================== AUSPICIOUS FINDER ==================== */
function runAuspicious() {
  const birthYear = $('ausp-year').value.trim();
  const taskId = $('ausp-task').value || 'chung';
  const customTitle = $('ausp-custom').value.trim();
  const fromDateKey = $('ausp-from').value || getTodayKey();
  const toDateKey = $('ausp-to').value || fromDateKey;
  const onlyGood = $('ausp-only-good').checked;
  const sortBy = $('ausp-sort').value || 'score';

  state.auspiciousPrefs = { birthYear, taskId, customTitle, onlyGood, sortBy };
  persistAndSync('auspiciousPrefs', state.auspiciousPrefs);

  const profile = getBirthProfile(birthYear);
  if (profile) {
    $('ausp-birth-badge').classList.remove('hidden');
    $('ausp-birth-badge').textContent = `🎂 Tuổi ${profile.canChi} (Con ${profile.animal}) • Mệnh ${profile.napAmName} (${profile.element})`;
  } else {
    $('ausp-birth-badge').classList.add('hidden');
  }

  const { results, error } = findAuspiciousDays({ birthYear, taskId, fromDateKey, toDateKey, onlyGood, sortBy });
  if (error) {
    $('ausp-summary').classList.remove('hidden');
    $('ausp-summary').textContent = error;
    $('ausp-results').innerHTML = '';
    return;
  }

  const taskObj = TASK_CATALOG.find((t) => t.id === taskId) || TASK_CATALOG[TASK_CATALOG.length - 1];
  const shortLabel = customTitle || taskObj.label.split(' / ')[0];
  $('ausp-summary').classList.remove('hidden');
  $('ausp-summary').textContent = `Tìm thấy ${results.length} ngày phù hợp cho "${shortLabel}" (${formatKeyVN(fromDateKey)} → ${formatKeyVN(toDateKey)}).`;

  if (results.length === 0) {
    $('ausp-results').innerHTML = '<div class="empty-msg">Không có ngày tốt trong khoảng này. Hãy mở rộng thời gian hoặc bỏ lọc "Chỉ hiện ngày tốt".</div>';
    return;
  }

  $('ausp-results').innerHTML = '';
  for (const item of results.slice(0, 30)) {
    const card = document.createElement('div');
    card.className = `ausp-card rating-${item.ratingKey}`;
    const bestH = item.bestHour ? `${item.bestHour.chi} (${item.bestHour.range})` : '09:00';
    card.innerHTML = `
      <div class="card-head" style="margin-bottom:5px;">
        <div>
          <strong>${esc(item.solar.weekday)}, ${pad2(item.solar.day)}/${pad2(item.solar.month)}/${item.solar.year}</strong>
          <div class="muted-xs">${esc(item.lunarFormatted)} • Ngày ${esc(item.canChi.day)}</div>
        </div>
        <span class="badge-pill ${item.ratingKey === 'bad' ? 'bad' : ''}">${item.rating} (${item.score})</span>
      </div>
      <div style="margin-bottom:6px;">
        ${item.pros.map((p) => `<span class="reason-pill pro">✓ ${esc(p)}</span>`).join('')}
        ${item.warnings.map((w) => `<span class="reason-pill warn">⚠ ${esc(w)}</span>`).join('')}
      </div>
      <div class="muted-xs" style="margin-bottom:8px;">⏰ Giờ đẹp: <strong>${esc(bestH)}</strong> • 🧭 Hỷ Thần: ${esc(item.xuatHanh.hyThan)} • Tài Thần: ${esc(item.xuatHanh.taiThan)}</div>
      <div class="chip-wrap">
        <button type="button" class="btn-chip primary btn-book">📌 Đặt nhắc (${esc(bestH)})</button>
        <button type="button" class="btn-chip btn-view">📅 Xem chi tiết</button>
      </div>
    `;
    card.querySelector('.btn-book').addEventListener('click', (e) => {
      const remTime = item.bestHour ? item.bestHour.startTime : '09:00';
      const titleText = `🔮 ${shortLabel}`;
      state.highlightedRanges.push({
        id: `hl-${Date.now()}`,
        startDate: item.dateKey,
        endDate: item.dateKey,
        color: 'yellow',
        title: titleText,
        note: `Ngày tốt (${item.score}/100) • Giờ đẹp: ${bestH}`
      });
      state.timedReminders.push({
        id: `rem-${Date.now()}`,
        title: titleText,
        date: item.dateKey,
        time: remTime,
        repeat: 'none',
        sound: true,
        note: `Giờ đẹp: ${bestH} • Hỷ Thần: ${item.xuatHanh.hyThan}`,
        done: false,
        createdAt: Date.now()
      });
      persistAndSync('highlightedRanges', state.highlightedRanges);
      persistAndSync('timedReminders', state.timedReminders);
      renderAllCalendarViews();
      e.currentTarget.textContent = '✓ Đã đặt nhắc!';
      e.currentTarget.disabled = true;
    });
    card.querySelector('.btn-view').addEventListener('click', () => jumpToSolar(item.solar));
    $('ausp-results').appendChild(card);
  }
}

/* ==================== REMINDERS, HIGHLIGHTS & PDF/ICS IMPORT ==================== */
function openMobileRemEdit(rem) {
  if (!rem) return;
  state.editingReminderId = rem.id;
  if (state.activeTab !== 'reminders') switchTab('reminders');
  switchRemSub('rem');
  $('rem-form').classList.remove('hidden');
  $('rem-edit-banner')?.classList.remove('hidden');
  $('rem-prev-eve-wrap')?.classList.add('hidden');
  if ($('rem-prev-eve')) $('rem-prev-eve').checked = false;
  $('rem-nlp-preview')?.classList.add('hidden');

  $('rem-title').value = rem.title || '';
  $('rem-date').value = rem.date || getTodayKey(new Date());
  $('rem-time').value = rem.time || getCurrentTimeHM(new Date());
  $('rem-repeat').value = rem.repeat || 'none';
  $('rem-note').value = rem.note || '';
  if ($('rem-send-tg')) $('rem-send-tg').checked = rem.sendTelegram !== false;
  if ($('btn-rem-submit')) $('btn-rem-submit').textContent = '💾 Cập nhật nhắc nhở';

  $('rem-form').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  $('rem-title').focus();
  updateRemFabVisibility();
}

function resetMobileRemForm(hideForm = false) {
  state.editingReminderId = null;
  $('rem-form').reset();
  const now = new Date();
  $('rem-date').value = getTodayKey(now);
  $('rem-time').value = getCurrentTimeHM(now);
  if ($('rem-send-tg')) $('rem-send-tg').checked = true;
  if ($('rem-prev-eve')) $('rem-prev-eve').checked = false;
  if ($('rem-prev-eve-time')) $('rem-prev-eve-time').value = '20:00';
  $('rem-edit-banner')?.classList.add('hidden');
  $('rem-prev-eve-wrap')?.classList.remove('hidden');
  $('rem-nlp-preview')?.classList.add('hidden');
  if ($('btn-rem-submit')) $('btn-rem-submit').textContent = 'Lưu nhắc nhở';
  if (hideForm) $('rem-form').classList.add('hidden');
  updateRemFabVisibility();
}

function buildReminderRow(rem, showDate = true) {
  const row = document.createElement('div');
  row.className = `item-row reminder${rem.done ? ' done' : ''}`;
  const [y, m, d] = rem.date.split('-').map(Number);
  const lunar = convertSolar2Lunar(d, m, y, TIMEZONE_VN);
  const repeatText = REPEAT_LABELS[rem.repeat || 'none'] || 'Một lần';

  let cdHtml = '';
  if (!rem.done) {
    const todayJd = jdFromDate(today.getDate(), today.getMonth() + 1, today.getFullYear());
    const nextMs = getNextReminderTimestamp(rem, Date.now());
    const diff = nextMs
      ? jdFromDate(new Date(nextMs).getDate(), new Date(nextMs).getMonth() + 1, new Date(nextMs).getFullYear()) - todayJd
      : jdFromDate(d, m, y) - todayJd;
    const cls = diff === 0 ? 'days-pill today' : diff > 0 && diff <= 7 ? 'days-pill soon' : 'days-pill';
    const txt = diff === 0 ? 'Hôm nay' : diff === 1 ? 'Ngày mai' : diff > 1 ? `Còn ${diff} ngày` : `Qua ${Math.abs(diff)} ngày`;
    cdHtml = `<span class="${cls}">${txt}</span>`;
  }

  const dateLine = showDate
    ? `📅 ${pad2(d)}/${pad2(m)}/${y} (${lunar.day}/${lunar.month} ÂL) • ${rem.time} • ${repeatText}`
    : `⏰ ${rem.time} • ${repeatText}`;
  const cleanNote = String(rem.note || '')
    .replace(/(?:^|\s*•\s*)Giờ:\s*\d{1,2}:\d{2}(?:\s*•\s*|$)/gi, ' ')
    .replace(/^[\s•]+|[\s•]+$/g, '')
    .trim();
  const channelParts = [
    rem.sound !== false ? '🔔 Chuông' : '🔕 Tắt chuông',
    rem.sendTelegram !== false ? '✈️ Telegram' : '🔇 Không gửi TG'
  ];
  if (cleanNote) channelParts.push(`📝 ${cleanNote}`);

  row.innerHTML = `
    <div class="rem-top-row">
      <input type="checkbox" class="rem-chk" ${rem.done ? 'checked' : ''} />
      <div class="item-body">
        <div class="item-name">${esc(rem.title)}</div>
        <div class="item-sub">${esc(dateLine)}</div>
        <div class="item-sub rem-note-line">${esc(channelParts.join(' • '))}</div>
      </div>
    </div>
    <div class="rem-foot-row">
      <div class="rem-foot-left">
        ${cdHtml}
        <span class="days-pill" style="background:#F3E8FF;color:#6B21A8;">${esc(rem.time)}</span>
      </div>
      <div class="rem-foot-actions">
        <button type="button" class="icon-act btn-edit-rem" title="Chỉnh sửa nhắc nhở">✏️</button>
        <button type="button" class="icon-act btn-zalo-rem" title="Gửi Zalo">💬</button>
        <button type="button" class="icon-act btn-tg" title="Gửi Telegram">✈️</button>
        <button type="button" class="icon-act btn-test-rem" title="Thử chuông ngay">🔔</button>
        <button type="button" class="icon-act btn-del" title="Xóa">🗑</button>
      </div>
    </div>
  `;

  row.querySelector('.rem-chk').addEventListener('change', (e) => {
    rem.done = e.target.checked;
    rem.updatedAt = Date.now();
    if (rem.done) rem.completedAt = Date.now();
    else delete rem.completedAt;
    persistAndSync('timedReminders', state.timedReminders);
    renderRemindersList();
    renderAllCalendarViews();
  });
  row.querySelector('.btn-edit-rem').addEventListener('click', (e) => {
    e.stopPropagation();
    openMobileRemEdit(rem);
  });
  row.querySelector('.btn-zalo-rem').addEventListener('click', async (e) => {
    e.stopPropagation();
    const zBtn = e.currentTarget;
    const orig = zBtn.textContent;
    const plain = `⏰ Nhắc nhở: ${rem.title}\n📅 Ngày ${pad2(d)}/${pad2(m)}/${y} (${lunar.day}/${lunar.month} ÂL) lúc ${rem.time}${rem.note ? `\n📝 ${rem.note}` : ''}`;
    zBtn.textContent = '⏳';
    if (state.zaloSettings?.enabled && state.zaloSettings?.webhookUrl) {
      await sendWebhookNotification({ webhookUrl: state.zaloSettings.webhookUrl, title: `⏰ Nhắc nhở: ${rem.title}`, text: plain });
    }
    await shareToZaloQuick(plain);
    zBtn.textContent = '✓';
    setTimeout(() => { zBtn.textContent = orig; }, 1600);
  });
  row.querySelector('.btn-tg').addEventListener('click', (e) => {
    const html = `⏰ <b>Nhắc nhở: ${esc(rem.title)}</b>\n📅 ${pad2(d)}/${pad2(m)}/${y} (${lunar.day}/${lunar.month} ÂL) lúc <b>${esc(rem.time)}</b>${rem.note ? `\n📝 ${esc(rem.note)}` : ''}`;
    sendTgHtml(html, e.currentTarget);
  });
  row.querySelector('.btn-test-rem').addEventListener('click', () => {
    openAlarmModal({ kind: 'timed', title: rem.title, meta: `⏰ ${rem.time} — ${pad2(d)}/${pad2(m)}/${y}`, note: rem.note || '', remId: rem.id });
  });
  row.querySelector('.btn-del').addEventListener('click', () => {
    recordMobileDeletedId(rem.id);
    state.timedReminders = state.timedReminders.filter((x) => x.id !== rem.id);
    persistAndSync('timedReminders', state.timedReminders);
    renderRemindersList();
    renderAllCalendarViews();
  });
  if (showDate) {
    row.querySelector('.item-body').addEventListener('click', () => jumpToSolar({ day: d, month: m, year: y }));
  }
  return row;
}

const M_REM_PAGE_SIZE = 5;
let mRemListTab = 'active'; // 'active' | 'expired'
const mRemListPages = { active: 1, expired: 1 };

function partitionMobileReminders(list) {
  const nowMs = Date.now();
  const active = [];
  const expired = [];
  for (const rem of list || []) {
    const nextMs = !rem.done ? getNextReminderTimestamp(rem, nowMs) : null;
    if (!rem.done && nextMs !== null) {
      active.push({ rem, sortTs: nextMs });
    } else {
      expired.push({ rem, sortKey: `${rem.date || ''} ${rem.time || ''}` });
    }
  }
  active.sort((a, b) => a.sortTs - b.sortTs);
  expired.sort((a, b) => b.sortKey.localeCompare(a.sortKey));
  return {
    active: active.map((x) => x.rem),
    expired: expired.map((x) => x.rem)
  };
}

function renderMobileRemPagination(container, currentPage, totalPages, totalItems, onPageChange, unitLabel = 'nhắc nhở') {
  if (!container) return;
  if (totalPages <= 1) {
    container.classList.add('hidden');
    container.innerHTML = '';
    return;
  }
  container.classList.remove('hidden');
  container.innerHTML = '';

  const prevBtn = document.createElement('button');
  prevBtn.type = 'button';
  prevBtn.className = 'rem-page-btn';
  prevBtn.textContent = '← Trước';
  prevBtn.disabled = currentPage <= 1;
  prevBtn.addEventListener('click', () => onPageChange(currentPage - 1));
  container.appendChild(prevBtn);

  const pages = new Set([1, totalPages]);
  for (let p = Math.max(1, currentPage - 1); p <= Math.min(totalPages, currentPage + 1); p++) {
    pages.add(p);
  }
  const sortedPages = [...pages].sort((a, b) => a - b);
  let lastP = 0;
  for (const p of sortedPages) {
    if (lastP && p - lastP > 1) {
      const dots = document.createElement('span');
      dots.style.color = '#6B7280';
      dots.textContent = '…';
      container.appendChild(dots);
    }
    const pBtn = document.createElement('button');
    pBtn.type = 'button';
    pBtn.className = `rem-page-btn${p === currentPage ? ' active' : ''}`;
    pBtn.textContent = String(p);
    pBtn.addEventListener('click', () => onPageChange(p));
    container.appendChild(pBtn);
    lastP = p;
  }

  const nextBtn = document.createElement('button');
  nextBtn.type = 'button';
  nextBtn.className = 'rem-page-btn';
  nextBtn.textContent = 'Sau →';
  nextBtn.disabled = currentPage >= totalPages;
  nextBtn.addEventListener('click', () => onPageChange(currentPage + 1));
  container.appendChild(nextBtn);

  const info = document.createElement('div');
  info.className = 'rem-page-info';
  info.textContent = `Trang ${currentPage}/${totalPages} • Tổng ${totalItems} ${unitLabel}`;
  container.appendChild(info);
}

function renderRemindersList() {
  const { active, expired } = partitionMobileReminders(state.timedReminders);

  if ($('rem-count-active')) $('rem-count-active').textContent = String(active.length);
  if ($('rem-count-expired')) $('rem-count-expired').textContent = String(expired.length);

  document.querySelectorAll('#rem-filter-tabs .rem-status-tab').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.remTab === mRemListTab);
  });
  $('btn-clear-expired-rems')?.classList.toggle('hidden', mRemListTab !== 'expired' || expired.length === 0);
  $('rem-auto-delete-bar')?.classList.toggle('hidden', mRemListTab !== 'expired');
  if ($('rem-auto-delete-select')) {
    $('rem-auto-delete-select').value = String(Number(state.settings?.autoDeleteExpiredDays) || 0);
  }

  const currentList = mRemListTab === 'expired' ? expired : active;
  const totalPages = Math.max(1, Math.ceil(currentList.length / M_REM_PAGE_SIZE));
  if (mRemListPages[mRemListTab] > totalPages) mRemListPages[mRemListTab] = totalPages;
  if (mRemListPages[mRemListTab] < 1) mRemListPages[mRemListTab] = 1;
  const page = mRemListPages[mRemListTab];

  const box = $('all-rem-list');
  const pagEl = $('rem-pagination');
  box.innerHTML = '';

  if (currentList.length === 0) {
    box.innerHTML = mRemListTab === 'expired'
      ? '<div class="empty-msg">Chưa có nhắc nhở nào đã hết hạn hoặc hoàn thành.</div>'
      : '<div class="empty-msg">Không có nhắc nhở còn hạn. Bấm "+ Thêm" hoặc "📋 Hàng loạt" để tạo lịch mới.</div>';
    if (pagEl) {
      pagEl.classList.add('hidden');
      pagEl.innerHTML = '';
    }
    return;
  }

  const start = (page - 1) * M_REM_PAGE_SIZE;
  const slice = currentList.slice(start, start + M_REM_PAGE_SIZE);
  slice.forEach((r) => box.appendChild(buildReminderRow(r, true)));
  renderMobileRemPagination(pagEl, page, totalPages, currentList.length, (nextPage) => {
    mRemListPages[mRemListTab] = nextPage;
    renderRemindersList();
    $('main-scroll')?.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

function runMobileAutoPruneExpired(showFeedback = false) {
  const maxDays = Number(state.settings?.autoDeleteExpiredDays) || 0;
  const noteEl = $('rem-auto-delete-note');
  if (maxDays <= 0) {
    if (showFeedback && noteEl) noteEl.textContent = '✓ Đã tắt tự động xóa';
    return 0;
  }
  const { kept, removedIds } = pruneExpiredReminders(state.timedReminders, maxDays, Date.now());
  if (removedIds.length > 0) {
    removedIds.forEach((id) => recordMobileDeletedId(id));
    state.timedReminders = kept;
    persistAndSync('timedReminders', state.timedReminders);
    renderRemindersList();
    renderAllCalendarViews();
    renderHolidays();
  }
  if (showFeedback && noteEl) {
    noteEl.textContent = removedIds.length > 0
      ? `✓ Đã dọn ${removedIds.length} lịch quá hạn & bật tự động xóa!`
      : '✓ Đã lưu — sẽ tự động xóa khi quá hạn';
  }
  return removedIds.length;
}

function bindMobileReminderTabEvents() {
  document.querySelectorAll('#rem-filter-tabs .rem-status-tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      const next = btn.dataset.remTab === 'expired' ? 'expired' : 'active';
      if (mRemListTab !== next) {
        mRemListTab = next;
        if ($('rem-auto-delete-note')) $('rem-auto-delete-note').textContent = '';
        renderRemindersList();
      }
    });
  });

  $('rem-auto-delete-select')?.addEventListener('change', (e) => {
    state.settings.autoDeleteExpiredDays = Number(e.target.value) || 0;
    persistAndSync('settings', state.settings);
    runMobileAutoPruneExpired(true);
  });

  $('btn-clear-expired-rems')?.addEventListener('click', () => {
    const { active, expired } = partitionMobileReminders(state.timedReminders);
    if (expired.length === 0) return;
    if (!confirm(`Xóa toàn bộ ${expired.length} nhắc nhở đã hết hạn / đã xong?`)) return;
    expired.forEach((r) => recordMobileDeletedId(r.id));
    state.timedReminders = active;
    mRemListPages.expired = 1;
    persistAndSync('timedReminders', state.timedReminders);
    renderRemindersList();
    renderAllCalendarViews();
    renderHolidays();
  });
}

function renderHighlightsList() {
  const box = $('hl-list');
  const sorted = [...state.highlightedRanges].sort((a, b) => (a.startDate || '').localeCompare(b.startDate || ''));
  box.innerHTML = '';
  if (sorted.length === 0) {
    box.innerHTML = '<div class="empty-msg">Chưa có khoảng ngày bôi màu nào.</div>';
    return;
  }
  for (const hl of sorted) {
    const row = document.createElement('div');
    row.className = 'item-row custom';
    const rng = hl.endDate && hl.endDate !== hl.startDate ? `${formatKeyVN(hl.startDate)} → ${formatKeyVN(hl.endDate)}` : formatKeyVN(hl.startDate);
    row.innerHTML = `
      <div class="item-body">
        <div class="item-name">🖍 ${esc(hl.title)}</div>
        <div class="item-sub">📅 ${rng}${hl.note ? ` • ${esc(hl.note)}` : ''}</div>
      </div>
      <button type="button" class="icon-act btn-del">🗑</button>
    `;
    row.querySelector('.item-body').addEventListener('click', () => {
      const p = parseDateParam(hl.startDate);
      if (p) jumpToSolar(p);
    });
    row.querySelector('.btn-del').addEventListener('click', () => {
      recordMobileDeletedId(hl.id);
      state.highlightedRanges = state.highlightedRanges.filter((x) => x.id !== hl.id);
      persistAndSync('highlightedRanges', state.highlightedRanges);
      renderHighlightsList();
      renderAllCalendarViews();
    });
    box.appendChild(row);
  }
}

function importSchedulesFromRaw(text, icsList = []) {
  const parsedFlight = parseFlightText(text, []);
  const parsedEvents = parseMeetingOrEventText('', text, [], icsList);
  let added = 0;

  if (parsedFlight.legs && parsedFlight.legs.length > 0) {
    const first = parsedFlight.legs[0];
    const last = parsedFlight.legs[parsedFlight.legs.length - 1];
    const flightNos = parsedFlight.legs.map((l) => l.flightNo).join(' / ');
    state.highlightedRanges.push({
      id: `hl-fl-${Date.now()}`,
      startDate: first.date,
      endDate: last.date,
      color: 'yellow',
      title: `✈️ ${flightNos}${parsedFlight.pnr ? ` (${parsedFlight.pnr})` : ''}`,
      note: parsedFlight.legs.map((l) => `${l.flightNo}: ${formatKeyVN(l.date)} ${l.depTime}`).join(' • ')
    });
    for (const leg of parsedFlight.legs) {
      state.timedReminders.push({
        id: `rem-fl-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        title: `✈️ Chuyến bay ${leg.flightNo}${parsedFlight.pnr ? ` (${parsedFlight.pnr})` : ''}`,
        date: leg.date,
        time: leg.depTime,
        repeat: 'none',
        sound: true,
        note: `${leg.route || ''} ${leg.arrTime ? `→ ${leg.arrTime}` : ''}`.trim(),
        done: false,
        createdAt: Date.now()
      });
      added++;
    }
  }

  for (const ev of parsedEvents) {
    state.timedReminders.push({
      id: `rem-ev-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      title: ev.title,
      date: ev.date,
      time: ev.time,
      repeat: 'none',
      sound: true,
      note: [ev.location, ev.note].filter(Boolean).join(' • '),
      done: false,
      createdAt: Date.now()
    });
    added++;
  }

  if (added === 0) {
    $('import-status').className = 'status-msg err';
    $('import-status').textContent = 'Không nhận diện được ngày/giờ lịch hẹn hay vé bay trong nội dung này.';
    return;
  }

  persistAndSync('highlightedRanges', state.highlightedRanges);
  persistAndSync('timedReminders', state.timedReminders);
  renderRemindersList();
  renderHighlightsList();
  renderAllCalendarViews();
  $('import-status').className = 'status-msg';
  $('import-status').textContent = `✓ Đã tự động thêm ${added} nhắc nhở lịch trình!`;
}

/* ==================== WATER REMINDER ==================== */
function renderWater() {
  const ws = state.waterSettings;
  $('w-enabled').checked = Boolean(ws.enabled);
  $('w-start').value = ws.startTime || '08:00';
  $('w-end').value = ws.endTime || '21:00';
  $('w-count').value = String(ws.count || 8);
  $('w-sound').checked = ws.soundEnabled !== false;

  const target = Math.max(1, Number(ws.count) || 8);
  const drank = Number(state.waterLog[getTodayKey()] || 0);
  $('w-drank').textContent = String(drank);
  $('w-target').textContent = `/ ${target} ly hôm nay`;
  $('w-bar-fill').style.width = `${Math.min(100, Math.round((drank / target) * 100))}%`;

  const sched = computeWaterSchedule(ws);
  if (!sched.valid) {
    $('w-interval-lbl').textContent = 'Giờ kết thúc phải lớn hơn giờ bắt đầu.';
    $('w-slots-grid').innerHTML = '';
    return;
  }

  $('w-interval-lbl').textContent = sched.slots.length > 1
    ? `Lịch ${sched.slots.length} cữ uống nước (cách nhau ~${sched.intervalMinutes} phút):`
    : 'Lịch uống nước hôm nay:';

  const nowMins = new Date().getHours() * 60 + new Date().getMinutes();
  let nextFound = false;
  $('w-slots-grid').innerHTML = sched.slots
    .map((s) => {
      let cls = 'w-chip';
      if (s.minutes < nowMins) cls += ' past';
      else if (!nextFound) {
        cls += ' next';
        nextFound = true;
      }
      return `<span class="${cls}">💧 ${s.label}</span>`;
    })
    .join('');

  if (ws.enabled) {
    const nextSlot = getNextWaterSlotTimestamp(ws, new Date());
    $('w-next-hint').textContent = nextSlot ? `⏰ Cữ tiếp theo: ${nextSlot.label}` : '';
  } else {
    $('w-next-hint').textContent = 'Đang tắt nhắc uống nước — gạt nút "Bật" ở góc trên để kích hoạt.';
  }
}

/* ==================== HOLIDAYS, CONVERTER & TELEGRAM ==================== */
const M_HOL_PAGE_SIZE = 8;
let mHolPage = 1;
let mHolLastFilter = '';

function renderHolidays() {
  const tet = getNextTetCountdown(today);
  $('tet-lunar-title').textContent = `Tết ${getYearCanChi(tet.lunarYear)} ${tet.tetSolar.year}`;
  $('tet-lunar-date').textContent = `Mùng 1: ${pad2(tet.tetSolar.day)}/${pad2(tet.tetSolar.month)}/${tet.tetSolar.year} • Giao thừa: ${tet.eveLunarDay}/12 ÂL`;
  $('tet-lunar-days').textContent = tet.daysUntil === 0 ? '🎉' : String(tet.daysUntil);

  const sTet = getNextSolarNewYearCountdown(today);
  $('tet-solar-title').textContent = `Năm mới ${sTet.targetYear}`;
  $('tet-solar-date').textContent = `01/01/${sTet.targetYear} (${sTet.lunar.day}/${sTet.lunar.month} ÂL)`;
  $('tet-solar-days').textContent = sTet.daysUntil === 0 ? '🎉' : String(sTet.daysUntil);

  const allHols = getUpcomingEvents(today, 365, state.customEvents, { includeSolar: true, includeLunar: true, includeMung1Ram: false });
  const upRems = getUpcomingReminders();

  let list = [];
  if (state.holidayFilter === 'reminders') list = upRems;
  else if (state.holidayFilter === 'all') list = [...allHols, ...upRems].sort((a, b) => a.daysUntil - b.daysUntil);
  else {
    list = allHols.filter((ev) => {
      if (state.holidayFilter === 'lunar') return ev.type === 'lunar';
      if (state.holidayFilter === 'solar') return ev.type === 'solar';
      if (state.holidayFilter === 'custom') return ev.type.startsWith('custom');
      return true;
    });
  }

  if (mHolLastFilter !== state.holidayFilter) {
    mHolLastFilter = state.holidayFilter;
    mHolPage = 1;
  }
  if ($('hol-filter-select')) $('hol-filter-select').value = state.holidayFilter || 'all';

  const box = $('hol-list');
  const pagEl = $('hol-pagination');
  box.innerHTML = '';
  if (list.length === 0) {
    box.innerHTML = '<div class="empty-msg">Chưa có sự kiện nào trong mục này.</div>';
    if (pagEl) { pagEl.classList.add('hidden'); pagEl.innerHTML = ''; }
    return;
  }

  const totalPages = Math.max(1, Math.ceil(list.length / M_HOL_PAGE_SIZE));
  if (mHolPage > totalPages) mHolPage = totalPages;
  if (mHolPage < 1) mHolPage = 1;
  const startIdx = (mHolPage - 1) * M_HOL_PAGE_SIZE;
  const pageItems = list.slice(startIdx, startIdx + M_HOL_PAGE_SIZE);

  renderMobileRemPagination(pagEl, mHolPage, totalPages, list.length, (nextPage) => {
    mHolPage = nextPage;
    renderHolidays();
    $('hol-filters')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, 'sự kiện');

  for (const ev of pageItems) {
    const isCustom = ev.type === 'custom-lunar' || ev.type === 'custom-solar';
    const row = document.createElement('div');
    row.className = `item-row hol-card ${ev.type === 'solar' ? 'solar' : ev.type === 'reminder' ? 'reminder' : isCustom ? 'custom' : ''}`;
    const pCls = ev.daysUntil === 0 ? 'days-pill today' : ev.daysUntil <= 7 ? 'days-pill soon' : 'days-pill';
    const pTxt = ev.daysUntil === 0 ? 'Hôm nay' : ev.daysUntil === 1 ? 'Ngày mai' : `Còn ${ev.daysUntil} ngày`;
    const dateLine = `📅 ${pad2(ev.solar.day)}/${pad2(ev.solar.month)}/${ev.solar.year} (DL) • ${ev.lunar.day}/${ev.lunar.month}${ev.lunar.leap ? 'N' : ''} ÂL`;
    const extraParts = [];
    if (isCustom) {
      const rDays = Number(ev.remindBeforeDays) || 0;
      const rTime = ev.remindTime || '';
      if (rDays > 0 || rTime) {
        extraParts.push(`🔔 ${rDays > 0 ? `Nhắc trước ${rDays} ngày` : 'Nhắc đúng ngày'}${rTime ? ` lúc ${rTime}` : ''}`);
      }
    } else if (ev.remindBeforeDays) {
      extraParts.push(`🔔 Nhắc trước ${ev.remindBeforeDays} ngày`);
    }
    if (ev.desc && isCustom && ev.desc !== ev.name) extraParts.push(`📝 ${ev.desc}`);

    row.innerHTML = `
      <div class="rem-top-row">
        <div class="item-body">
          <div class="item-name">${esc(ev.name)}</div>
          <div class="item-sub">${esc(dateLine)}</div>
          ${extraParts.length > 0 ? `<div class="item-sub rem-note-line">${esc(extraParts.join(' • '))}</div>` : ''}
        </div>
      </div>
      <div class="rem-foot-row">
        <div class="rem-foot-left">
          <span class="${pCls}">${pTxt}</span>
        </div>
        <div class="rem-foot-actions">
          ${isCustom ? '<button type="button" class="icon-act btn-edit-ce" title="Chỉnh sửa ngày / thông tin">✏️</button>' : ''}
          <button type="button" class="icon-act btn-gcal" title="Thêm Google Calendar">📅</button>
          ${isCustom ? '<button type="button" class="icon-act btn-del" title="Xóa">🗑</button>' : ''}
        </div>
      </div>
    `;
    row.querySelector('.btn-gcal').addEventListener('click', (e) => {
      e.stopPropagation();
      const url = buildGoogleCalendarUrl({
        title: ev.name,
        details: `${ev.desc || ev.name} — ${ev.lunar.day}/${ev.lunar.month} ÂL`,
        dateObj: ev.solar,
        timeStr: ev.time || null
      });
      window.open(url, '_blank', 'noopener');
    });
    row.querySelector('.item-body').addEventListener('click', () => jumpToSolar(ev.solar));
    if (isCustom) {
      row.querySelector('.btn-edit-ce')?.addEventListener('click', (e) => {
        e.stopPropagation();
        const orig = state.customEvents.find((c) => c.id === ev.id);
        if (orig && typeof window.__openMobileCeEdit === 'function') {
          window.__openMobileCeEdit(orig);
        }
      });
      row.querySelector('.btn-del').addEventListener('click', () => {
        recordMobileDeletedId(ev.id);
        state.customEvents = state.customEvents.filter((c) => c.id !== ev.id);
        persistAndSync('customEvents', state.customEvents);
        renderHolidays();
        renderAllCalendarViews();
      });
    }
    box.appendChild(row);
  }
}

function runConverter() {
  const d = Number($('conv-d').value), m = Number($('conv-m').value), y = Number($('conv-y').value);
  const res = $('conv-result');
  res.classList.remove('hidden');
  if (!d || !m || !y || y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) {
    res.textContent = 'Vui lòng nhập ngày, tháng, năm hợp lệ (1900–2100).';
    return;
  }
  if (state.converterMode === 's2l') {
    const dt = new Date(y, m - 1, d);
    if (dt.getDate() !== d || dt.getMonth() !== m - 1) {
      res.textContent = 'Ngày Dương lịch không tồn tại.';
      return;
    }
    const l = convertSolar2Lunar(d, m, y, TIMEZONE_VN);
    res.innerHTML = `<div>${THU_VN[dt.getDay()]}, ${pad2(d)}/${pad2(m)}/${y} (DL)</div><strong>→ ${formatLunarDateFull(l)}, năm ${getYearCanChi(l.year)}</strong><div class="muted-xs">Ngày ${getDayCanChi(l.jd).name} • Tháng ${getMonthCanChi(l.month, l.year)}</div>`;
  } else {
    const leap = $('conv-leap').checked;
    const s = convertLunar2Solar(d, m, y, leap, TIMEZONE_VN);
    if (!s) {
      res.textContent = 'Ngày Âm lịch này không tồn tại.';
      return;
    }
    const dt = new Date(s.year, s.month - 1, s.day);
    res.innerHTML = `<div>Ngày ${d}/${m}${leap ? 'N' : ''}/${y} (ÂL)</div><strong>→ ${THU_VN[dt.getDay()]}, ${pad2(s.day)}/${pad2(s.month)}/${s.year} (DL)</strong>`;
  }
}

async function sendTgHtml(htmlText, btn = null) {
  const token = ($('tg-token').value || state.telegramSettings.botToken || '').trim();
  const chatId = ($('tg-chat-id').value || state.telegramSettings.chatId || '').trim();
  if (!token || !chatId) {
    switchTab('settings');
    expandMobileSettingsCard('telegram');
    setTimeout(() => $('tg-token')?.focus(), 180);
    $('tg-status').className = 'status-msg err';
    $('tg-status').textContent = 'Hãy nhập Bot Token & Chat ID nhóm Telegram trước nhé!';
    return;
  }
  const orig = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = '⏳'; }
  const res = await sendTelegramApiMessage({ botToken: token, chatId, htmlText });
  if (btn) {
    btn.textContent = res.ok ? '✓' : '✕';
    setTimeout(() => { btn.textContent = orig; btn.disabled = false; }, 1600);
  }
  if (!res.ok) {
    $('tg-status').className = 'status-msg err';
    $('tg-status').textContent = res.error;
  }
}

/* ==================== FOREGROUND ALARM LOOP & MODAL ==================== */
function openAlarmModal({ kind, title, meta, note, remId }) {
  state.activeModalAlarm = { kind, title, meta, note, remId };
  $('modal-ico').textContent = kind === 'water' ? '💧' : '⏰';
  $('modal-title').textContent = title;
  $('modal-meta').textContent = meta;
  $('modal-note').textContent = note || '';
  $('modal-note').classList.toggle('hidden', !note);
  $('btn-modal-ok').textContent = kind === 'water' ? '💧 +1 ly nước' : '✓ Đã xong';
  $('alarm-modal').classList.remove('hidden');

  if (kind === 'water' && state.waterSettings.soundEnabled !== false) {
    playWaterPourSound(0.85).catch(() => {});
  } else {
    playReminderChime(0.8).catch(() => {});
  }

  if ('Notification' in window && Notification.permission === 'granted' && !isRunningInAndroidApk()) {
    try {
      new Notification(title, { body: `${meta}${note ? ` — ${note}` : ''}`, icon: './icons/icon128.png' });
    } catch (_e) {}
  }
}

function checkForegroundAlarms() {
  const now = new Date();
  const todayKey = getTodayKey(now);
  const nowMin = now.getHours() * 60 + now.getMinutes();

  // Check timed reminders
  for (const rem of state.timedReminders) {
    if (rem.done || !doesReminderOccurOnDate(rem, todayKey)) continue;
    const [hh, mm] = (rem.time || '00:00').split(':').map(Number);
    const remMin = hh * 60 + mm;
    const key = `rem::${rem.id}::${todayKey}::${rem.time}`;
    if (nowMin >= remMin && nowMin <= remMin + 2 && !state.firedKeys[key]) {
      state.firedKeys[key] = Date.now();
      saveMobileField('firedKeys', state.firedKeys);
      openAlarmModal({ kind: 'timed', title: rem.title, meta: `⏰ ${rem.time} — ${formatKeyVN(todayKey)}`, note: rem.note || '', remId: rem.id });
      if (state.localAllowAutoTelegram !== false && state.telegramSettings.enabled && state.telegramSettings.sendTimed && rem.sendTelegram !== false) {
        claimTelegramSendSlotDetailed(state.cloudSyncConfig, `timed_${rem.id}_${todayKey}_${rem.time}`, 3500, state.telegramSettings).then((slot) => {
          if (slot.allowed) {
            const lockTag = slot.reason && slot.reason !== 'won' && slot.reason !== 'won-d1' && slot.reason !== 'no-cloud-sync'
              ? ` • ⚠️ ${escapeTelegramHtml(slot.reason)}`
              : '';
            sendTgHtml(`⏰ <b>Nhắc nhở: ${escapeTelegramHtml(rem.title)}</b>\n📅 ${formatKeyVN(todayKey)} lúc ${escapeTelegramHtml(rem.time)}${rem.note ? `\n📝 ${escapeTelegramHtml(rem.note)}` : ''}\n<i>📱 Android • v${APP_VERSION}${lockTag}</i>`);
          }
        });
      }
      return;
    }
  }

  // Check water slots (do NOT pop up intrusive in-app water modal when user is already inside the app;
  // Android system notification fires with dedicated water-drop sound instead!)
  if (state.waterSettings.enabled) {
    const sched = computeWaterSchedule(state.waterSettings);
    if (sched.valid) {
      for (const slot of sched.slots) {
        const key = `water::${todayKey}::${slot.label}`;
        if (nowMin === slot.minutes && !state.firedKeys[key]) {
          state.firedKeys[key] = Date.now();
          saveMobileField('firedKeys', state.firedKeys);
          if (state.localAllowAutoTelegram !== false && state.telegramSettings.enabled && state.telegramSettings.sendWater) {
            claimTelegramSendSlot(state.cloudSyncConfig, `water_${todayKey}_${slot.label}`, 1500, state.telegramSettings).then((canSend) => {
              if (canSend) {
                sendTgHtml(`💧 <b>Đến giờ uống nước!</b>\nCữ ${slot.index + 1}/${sched.slots.length} lúc ${slot.label}`);
              }
            });
          }
          return;
        }
      }
    }
  }
}

/* ==================== BIND EVENTS & BOOTSTRAP ==================== */
function initControls() {
  $('app-version').textContent = `v${APP_VERSION}`;
  for (let m = 1; m <= 12; m++) {
    const o = document.createElement('option');
    o.value = String(m);
    o.textContent = `Tháng ${m}`;
    $('select-month').appendChild(o);
  }
  for (let y = 1900; y <= 2100; y++) {
    const o = document.createElement('option');
    o.value = String(y);
    o.textContent = `Năm ${y}`;
    $('select-year').appendChild(o);
  }
  for (const t of TASK_CATALOG) {
    const o = document.createElement('option');
    o.value = t.id;
    o.textContent = t.label;
    $('ausp-task').appendChild(o);
  }

  // Defaults
  const nowInit = new Date();
  const tk = getTodayKey(nowInit);
  $('rem-date').value = tk;
  $('rem-time').value = getCurrentTimeHM(nowInit);
  if ($('rem-send-tg')) $('rem-send-tg').checked = true;
  $('hl-start').value = tk;
  $('hl-end').value = tk;
  if ($('conv-d')) $('conv-d').value = today.getDate();
  if ($('conv-m')) $('conv-m').value = today.getMonth() + 1;
  if ($('conv-y')) $('conv-y').value = today.getFullYear();

  // Auspicious prefs
  $('ausp-year').value = state.auspiciousPrefs.birthYear || '';
  $('ausp-task').value = state.auspiciousPrefs.taskId || 'khai_truong';
  $('ausp-custom').value = state.auspiciousPrefs.customTitle || '';
  $('ausp-only-good').checked = state.auspiciousPrefs.onlyGood !== false;
  $('ausp-sort').value = state.auspiciousPrefs.sortBy || 'score';
  const toDt = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 30);
  $('ausp-from').value = tk;
  $('ausp-to').value = formatDateKey(toDt.getFullYear(), toDt.getMonth() + 1, toDt.getDate());
  document.querySelectorAll('.ausp-quick').forEach((x) => {
    x.classList.toggle('active', Number(x.dataset.days) === 30);
  });

  // Prayer prefs
  $('p-auto-open').checked = state.prayerPrefs.autoOpenOnSpecialDay !== false;
  $('p-homeowner').value = state.prayerPrefs.homeownerName || '';
  $('p-address').value = state.prayerPrefs.address || '';

  // Telegram prefs
  $('tg-enabled').checked = Boolean(state.telegramSettings.enabled);
  $('tg-token').value = state.telegramSettings.botToken || '';
  $('tg-chat-id').value = state.telegramSettings.chatId || '';
  $('tg-send-timed').checked = state.telegramSettings.sendTimed !== false;
  $('tg-send-holidays').checked = state.telegramSettings.sendHolidays !== false;
  $('tg-send-water').checked = Boolean(state.telegramSettings.sendWater);
  if ($('tg-local-device-allow')) $('tg-local-device-allow').checked = state.localAllowAutoTelegram !== false;
  if ($('m-zalo-en')) $('m-zalo-en').checked = Boolean(state.zaloSettings?.enabled);
  if ($('m-zalo-url')) $('m-zalo-url').value = state.zaloSettings?.webhookUrl || '';

  // Holiday notification prefs
  const nhSel = $('set-notify-hour');
  if (nhSel && nhSel.options.length === 0) {
    for (let h = 5; h <= 22; h++) {
      const o = document.createElement('option');
      o.value = String(h);
      o.textContent = `${pad2(h)}:00`;
      nhSel.appendChild(o);
    }
  }
  $('set-notif-on').checked = state.settings.notificationsEnabled !== false;
  $('set-mung1-ram').checked = state.settings.remindMung1Ram !== false;
  $('set-lunar-hol').checked = state.settings.remindLunarHolidays !== false;
  $('set-solar-hol').checked = state.settings.remindSolarHolidays !== false;
  $('set-notify-hour').value = String(state.settings.notifyHour ?? 8);
  if ($('rem-auto-delete-select')) {
    $('rem-auto-delete-select').value = String(Number(state.settings.autoDeleteExpiredDays) || 0);
  }
  const offSet = new Set((state.settings.notifyDaysBefore || [0, 1]).map(Number));
  $('set-notify-days').querySelectorAll('.pill').forEach((p) => {
    p.classList.toggle('active', offSet.has(Number(p.dataset.offset)));
  });

const isIosDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const isStandalonePwa = window.navigator.standalone === true ||
  window.matchMedia?.('(display-mode: standalone)')?.matches === true;

  // Environment badge
  if (isRunningInAndroidApk()) {
    $('env-badge').textContent = `✅ Đang chạy ứng dụng Android gốc v${APP_VERSION} (dùng AlarmClock ưu tiên cao nhất + đồng bộ nền mỗi 2 phút).`;
    $('btn-android-battery')?.classList.remove('hidden');
    $('btn-android-exact')?.classList.remove('hidden');
    renderOppoHealthStatus();
  } else if (isIosDevice && isStandalonePwa) {
    $('env-badge').textContent = '🍎 Đang chạy chế độ Ứng dụng iPhone toàn màn hình (Hỗ trợ ngoại tuyến, vuốt chuyển tab, Apple Calendar .ics & Telegram).';
  } else if (isIosDevice) {
    $('env-badge').textContent = '🍎 Đang mở bằng Safari trên iPhone — Bấm "📲 Cài iPhone" trên góc phải (hoặc Chia sẻ ⬆️ → Thêm vào MH chính) để cài thành App toàn màn hình!';
    const installBtn = $('btn-install-pwa');
    if (installBtn) {
      installBtn.textContent = '📲 Cài iPhone';
      installBtn.classList.remove('hidden');
    }
  } else {
    $('env-badge').textContent = '🌐 Đang chạy bản Web App (PWA) — Mở trên iPhone (Safari) hoặc Android (Chrome) và chọn "Thêm vào Màn hình chính" để dùng như app thật.';
  }
}

function renderOppoHealthStatus() {
  const box = $('oppo-health-box');
  if (!box || !isRunningInAndroidApk()) return;
  const h = getAndroidAlarmHealth();
  if (!h) {
    box.classList.add('hidden');
    return;
  }
  box.classList.remove('hidden');
  const row = (ok, okTxt, warnTxt) =>
    `<div style="color:${ok ? '#047857' : '#B45309'};font-weight:${ok ? '600' : '700'};">${ok ? '✅' : '⚠️'} ${ok ? okTxt : warnTxt}</div>`;
  box.innerHTML = [
    row(h.notifGranted, 'Quyền thông báo: Đã bật', 'Quyền thông báo: Chưa bật — bấm "🔔 Bật quyền thông báo"'),
    row(h.exactGranted, 'Báo thức chính xác (AlarmClock): Đã bật — báo đúng từng giây', 'Báo thức chính xác: Chưa bật — bấm "⏰ Báo thức chính xác"'),
    row(h.batteryUnrestricted, 'Pin nền Android: Không bị giới hạn', 'Pin nền Android: Đang bị tiết kiệm pin (có thể báo trễ) — bấm "🔋 Tắt tiết kiệm pin nền"!'),
    row(h.bgSyncActive, `Đồng bộ nền 2 phút/lần: Đang chạy (${h.scheduledCount || 0} lịch hẹn đang chờ)`, `Lịch hẹn nền Android: ${h.scheduledCount || 0} lịch hẹn đang chờ báo thức`)
  ].join('');
}

function bindEvents() {
  attachTabSwipeNavigation();
  document.querySelectorAll('.bnav-btn').forEach((b) => {
    if (b.dataset.tab) {
      b.addEventListener('click', () => switchTab(b.dataset.tab));
    }
  });
  document.querySelectorAll('#tab-reminders .subtab').forEach((b) => {
    b.addEventListener('click', () => switchRemSub(b.dataset.sub));
  });

  $('btn-brand-home')?.addEventListener('click', () => {
    const nowDt = new Date();
    jumpToSolar({ day: nowDt.getDate(), month: nowDt.getMonth() + 1, year: nowDt.getFullYear() });
  });
  $('btn-global-search')?.addEventListener('click', () => openMobileGlobalSearch());
  $('btn-open-settings')?.addEventListener('click', () => {
    if (state.activeTab === 'settings') {
      switchTab(state.prevTab || 'calendar', -1);
    } else {
      switchTab('settings', 1);
    }
  });
  $('btn-settings-back')?.addEventListener('click', () => {
    switchTab(state.prevTab || 'calendar', -1);
  });
  $('btn-top-weather').addEventListener('click', () => {
    switchTab('calendar');
    loadWeather(true);
    $('wx-card')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  $('wx-city').addEventListener('change', () => {
    state.weatherPrefs = { ...(state.weatherPrefs || DEFAULT_WEATHER_PREFS), cityId: $('wx-city').value };
    persistAndSync('weatherPrefs', state.weatherPrefs);
    loadWeather(true);
  });
  $('btn-wx-search-toggle')?.addEventListener('click', () => {
    const box = $('wx-search-box');
    if (!box) return;
    box.classList.toggle('hidden');
    if (!box.classList.contains('hidden')) $('wx-search-inp')?.focus();
  });
  const runMobileWxSearch = async () => {
    const inp = $('wx-search-inp');
    const resBox = $('wx-search-results');
    if (!inp || !resBox) return;
    const q = inp.value.trim();
    if (q.length < 2) {
      resBox.innerHTML = '<div class="muted-xs">Nhập ít nhất 2 ký tự (VD: Thái Thụy, Diêm Điền, Thái Bình...)</div>';
      return;
    }
    resBox.innerHTML = '<div class="muted-xs">🔍 Đang tìm địa điểm chính xác...</div>';
    const items = await searchVietnamLocations(q);
    if (!items.length) {
      resBox.innerHTML = '<div class="muted-xs">Không tìm thấy — thử nhập tên huyện hoặc tỉnh gần nhất nhé!</div>';
      return;
    }
    resBox.innerHTML = '';
    items.forEach((it) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'wx-search-item';
      btn.innerHTML = `<span>📍 <strong>${esc(it.name)}</strong>${it.subtitle ? ` <span class="muted-xs">(${esc(it.subtitle)})</span>` : ''}</span><span class="muted-xs">${it.lat.toFixed(2)}°, ${it.lon.toFixed(2)}°</span>`;
      btn.addEventListener('click', async () => {
        state.weatherPrefs = { cityId: 'custom', customLat: it.lat, customLon: it.lon, customName: it.label };
        populateWeatherCities();
        persistAndSync('weatherPrefs', state.weatherPrefs);
        $('wx-search-box')?.classList.add('hidden');
        await loadWeather(true);
      });
      resBox.appendChild(btn);
    });
  };
  $('btn-wx-search-go')?.addEventListener('click', runMobileWxSearch);
  $('wx-search-inp')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); runMobileWxSearch(); }
  });

  $('btn-wx-radar-toggle')?.addEventListener('click', () => {
    mobileRadarOpen = !mobileRadarOpen;
    $('wx-radar-box')?.classList.toggle('hidden', !mobileRadarOpen);
    const btn = $('btn-wx-radar-toggle');
    if (btn) {
      btn.textContent = mobileRadarOpen
        ? '▲ Đóng Ra-đa mây mưa trực tiếp'
        : '📡 Xem Ra-đa mây mưa trực tiếp (từng quận/huyện)';
    }
    if (mobileRadarOpen) refreshMobileRadarFrame();
  });
  document.querySelectorAll('#wx-radar-box .wx-radar-tab').forEach((tabBtn) => {
    tabBtn.addEventListener('click', () => {
      mobileRadarProvider = tabBtn.dataset.radar === 'rainviewer' ? 'rainviewer' : 'windy';
      document.querySelectorAll('#wx-radar-box .wx-radar-tab').forEach((b) => b.classList.toggle('active', b === tabBtn));
      refreshMobileRadarFrame();
    });
  });

  $('btn-wx-gps').addEventListener('click', async () => {
    const b = $('btn-wx-gps');
    b.disabled = true;
    b.textContent = '⏳...';
    try {
      const { lat, lon } = await requestGpsPosition();
      const placeName = await reverseGeocodeVietnam(lat, lon);
      state.weatherPrefs = { cityId: 'gps', customLat: lat, customLon: lon, customName: placeName };
      populateWeatherCities();
      persistAndSync('weatherPrefs', state.weatherPrefs);
      await loadWeather(true);
    } catch (err) {
      state.weatherError = err?.message || 'Không lấy được GPS';
      renderWeatherViews();
    } finally {
      b.disabled = false;
      b.textContent = '📍 GPS';
    }
  });
  $('btn-prev-day').addEventListener('click', () => stepDay(-1));
  $('btn-next-day').addEventListener('click', () => stepDay(1));
  $('btn-prev-month').addEventListener('click', () => {
    state.viewMonth -= 1;
    if (state.viewMonth < 1) { state.viewMonth = 12; state.viewYear = Math.max(1900, state.viewYear - 1); }
    renderCalendarGrid();
  });
  $('btn-next-month').addEventListener('click', () => {
    state.viewMonth += 1;
    if (state.viewMonth > 12) { state.viewMonth = 1; state.viewYear = Math.min(2100, state.viewYear + 1); }
    renderCalendarGrid();
  });
  $('select-month').addEventListener('change', () => { state.viewMonth = Number($('select-month').value); renderCalendarGrid(); });
  $('select-year').addEventListener('change', () => { state.viewYear = Number($('select-year').value); renderCalendarGrid(); });

  $('btn-hero-prayer').addEventListener('click', () => {
    state.prayerCategory = 'recommended';
    renderPrayers(true);
    switchTab('prayers');
  });
  $('btn-hero-tg').addEventListener('click', () => {
    const { day, month, year } = state.selectedDate;
    const d = getFullDayDetails(day, month, year, TIMEZONE_VN);
    const html = `🏮 <b>Lịch ngày ${pad2(day)}/${pad2(month)}/${year} (${esc(d.solar.weekday)})</b>\n🌙 Âm lịch: <b>${esc(d.lunarFormatted)}</b> năm ${esc(d.canChi.year)}\n✨ Ngày ${esc(d.hoangDaoDay.type)} (${esc(d.hoangDaoDay.starName)}) • Trực ${esc(d.truc.name)}\n🧭 Hỷ Thần: ${esc(d.xuatHanh.hyThan)} • Tài Thần: ${esc(d.xuatHanh.taiThan)}`;
    sendTgHtml(html, $('btn-hero-tg'));
  });

  const buildDayPlainForZalo = () => {
    const { day, month, year } = state.selectedDate;
    const d = getFullDayDetails(day, month, year, TIMEZONE_VN);
    const wx = state.weatherData?.dailyByDate?.[getSelectedKey()];
    return [
      `🏮 Lịch ngày ${pad2(day)}/${pad2(month)}/${year} (${d.solar.weekday})`,
      `🌙 Âm lịch: ${d.lunarFormatted}, năm ${d.canChi.year} (Ngày ${d.canChi.day})`,
      `✨ Ngày ${d.hoangDaoDay.type} (${d.hoangDaoDay.starName}) • ${d.truc.name}`,
      `🕐 Giờ Hoàng Đạo: ${d.hours.hoangDao.map((h) => `${h.chi} (${h.range})`).join(', ')}`,
      wx ? `${wx.icon} Thời tiết: ${wx.label} (${wx.tMin}°–${wx.tMax}°C, mưa ${wx.rainProb}%)` : ''
    ].filter(Boolean).join('\n');
  };
  const doZaloShare = async (btn, text, title = 'Lịch Âm Việt Nam') => {
    const orig = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳...';
    if (state.zaloSettings?.enabled && state.zaloSettings?.webhookUrl) {
      await sendWebhookNotification({ webhookUrl: state.zaloSettings.webhookUrl, title, text });
    }
    await shareToZaloQuick(text);
    btn.textContent = '✓ Zalo';
    setTimeout(() => { btn.textContent = orig; btn.disabled = false; }, 1600);
  };
  $('btn-hero-zalo')?.addEventListener('click', () => doZaloShare($('btn-hero-zalo'), buildDayPlainForZalo()));
  $('btn-p-zalo')?.addEventListener('click', () => doZaloShare($('btn-p-zalo'), `🙏 ${$('p-view-title').textContent}\n\n${$('p-view-text').textContent}`, $('p-view-title').textContent));

  // Smart NLP integrated directly into Add Reminder form (#rem-form)
  attachMobileVoiceInput();
  let mRemNoteEdited = false;
  let mRemPrevEveEdited = false;
  $('rem-note')?.addEventListener('input', () => { mRemNoteEdited = true; });
  $('rem-prev-eve')?.addEventListener('change', () => { mRemPrevEveEdited = true; });
  $('rem-title')?.addEventListener('input', () => {
    const prev = $('rem-nlp-preview');
    if (state.editingReminderId) {
      prev?.classList.add('hidden');
      return;
    }
    const p = parseVietnameseNlpReminder($('rem-title').value, new Date());
    if (p) {
      $('rem-date').value = p.date;
      $('rem-time').value = p.time;
      if (p.repeat) $('rem-repeat').value = p.repeat;
      if (p.note && !mRemNoteEdited) $('rem-note').value = p.note;
      if (p.prevDayAlert && $('rem-prev-eve') && $('rem-prev-eve-time')) {
        $('rem-prev-eve').checked = true;
        $('rem-prev-eve-time').value = p.prevDayAlert.time;
      } else if (!p.prevDayAlert && !mRemPrevEveEdited && $('rem-prev-eve')) {
        $('rem-prev-eve').checked = false;
      }
      if (prev) {
        prev.classList.remove('hidden');
        const repTxt = p.repeat ? ` • 🔁 ${REPEAT_LABELS[p.repeat] || ''}` : '';
        if (p.prevDayAlert) {
          const mainTxt = p.remindCount > 1
            ? `🔔 Nhắc ${p.remindCount} lần (${p.remindSlots.map((s) => s.time).join(' & ')})`
            : `☀️ ${formatKeyVN(p.date)} ${p.time}`;
          prev.textContent = `✨ Tự tạo 2 mốc nhắc: 🌙 ${formatKeyVN(p.prevDayAlert.date)} ${p.prevDayAlert.time} (tối hôm trước) & ${mainTxt}${repTxt} • Tiêu đề: "${p.title}"${p.note ? ` (${p.note})` : ''}`;
        } else {
          const timesTxt = p.remindCount > 1
            ? `🔔 Nhắc ${p.remindCount} lần (${p.remindSlots.map((s) => s.time).join(' & ')})`
            : `⏰ ${p.time}`;
          prev.textContent = `✨ Tự điền: 📅 ${formatKeyVN(p.date)} • ${timesTxt}${repTxt} • Lưu tiêu đề: "${p.title}"${p.note ? ` (${p.note})` : ''}`;
        }
      }
    } else {
      if (!mRemPrevEveEdited && $('rem-prev-eve')) $('rem-prev-eve').checked = false;
      if (prev) prev.classList.add('hidden');
    }
  });

  // Quick Converter & Date Diff
  const renderMQ = () => {
    const p = parseDateParam($('m-q-date')?.value);
    if (p && $('m-q-lookup-res')) {
      const d = getFullDayDetails(p.day, p.month, p.year, TIMEZONE_VN);
      $('m-q-lookup-res').innerHTML = `<strong>${d.solar.weekday}, ${pad2(p.day)}/${pad2(p.month)}/${p.year}</strong> → <strong>${esc(d.lunarFormatted)}</strong> (${esc(d.canChi.year)})<div class="muted-xs">Ngày ${esc(d.canChi.day)} • ${esc(d.napAm)} • ${esc(d.solar.zodiac)}</div>`;
    }
    const diff = computeDateDiff($('m-q-from')?.value, $('m-q-to')?.value);
    if (diff && $('m-q-diff-res')) {
      $('m-q-diff-res').innerHTML = `Khoảng cách: <strong>${diff.absDays} ngày</strong> (${diff.weeks} tuần ${diff.remDays} ngày • ~${diff.approxMonths} tháng)<div class="muted-xs">Ngày làm việc (T2–T6): <strong>${diff.workDays} ngày</strong></div>`;
    }
  };
  if ($('m-q-date')) $('m-q-date').value = getTodayKey();
  if ($('m-q-from')) $('m-q-from').value = getTodayKey();
  if ($('m-q-to')) {
    const t = getNextTetCountdown(today).tetSolar;
    $('m-q-to').value = formatDateKey(t.year, t.month, t.day);
  }
  $('btn-m-qconv-toggle')?.addEventListener('click', () => {
    $('m-qconv-box').classList.toggle('hidden');
    if (!$('m-qconv-box').classList.contains('hidden')) renderMQ();
  });
  document.querySelectorAll('.m-qtab').forEach((b) => {
    b.addEventListener('click', () => {
      document.querySelectorAll('.m-qtab').forEach((x) => x.classList.toggle('active', x === b));
      $('m-q-lookup').classList.toggle('hidden', b.dataset.mode !== 'lookup');
      $('m-q-diff').classList.toggle('hidden', b.dataset.mode !== 'diff');
      renderMQ();
    });
  });
  $('m-q-date')?.addEventListener('change', renderMQ);
  $('btn-m-q-go')?.addEventListener('click', () => { const p = parseDateParam($('m-q-date').value); if (p) jumpToSolar(p); });
  $('m-q-from')?.addEventListener('change', renderMQ);
  $('m-q-to')?.addEventListener('change', renderMQ);

  // ICS Export & Zalo Webhook settings
  const setMIcs = (t) => { $('m-ics-status').textContent = t; setTimeout(() => { $('m-ics-status').textContent = ''; }, 4500); };
  $('btn-m-ics-anniv')?.addEventListener('click', () => {
    if (state.customEvents.length === 0) { setMIcs('Chưa có Ngày giỗ / Sinh nhật nào để xuất.'); return; }
    downloadIcsFile(buildAnniversariesIcs(state.customEvents, 5), 'ngay-gio-sinh-nhat-5-nam.ics');
    setMIcs(`✓ Đã xuất ${state.customEvents.length} sự kiện (5 năm ÂL→DL) ra file .ics!`);
  });
  $('btn-m-ics-m1r')?.addEventListener('click', () => {
    downloadIcsFile(buildMung1RamIcs(365), 'mung1-ram-lich-am-vn.ics');
    setMIcs('✓ Đã xuất Mùng 1 & Rằm cả năm ra file .ics!');
  });
  $('btn-m-ics-rem')?.addEventListener('click', () => {
    const active = state.timedReminders.filter((r) => !r.done);
    if (active.length === 0) { setMIcs('Chưa có nhắc nhở giờ nào để xuất.'); return; }
    downloadIcsFile(buildTimedRemindersIcs(active), 'nhac-nho-lich-am-vn.ics');
    setMIcs(`✓ Đã xuất ${active.length} nhắc nhở ra file .ics!`);
  });

  const saveMZalo = () => {
    state.zaloSettings = { enabled: Boolean($('m-zalo-en')?.checked), webhookUrl: ($('m-zalo-url')?.value || '').trim() };
    persistAndSync('zaloSettings', state.zaloSettings);
  };
  $('m-zalo-en')?.addEventListener('change', saveMZalo);
  $('m-zalo-url')?.addEventListener('change', saveMZalo);
  $('btn-m-zalo-test')?.addEventListener('click', async () => {
    saveMZalo();
    const devLabel = typeof window.AndroidBridge?.getDeviceName === 'function' ? window.AndroidBridge.getDeviceName() : 'Android';
  const res = await sendWebhookNotification({ webhookUrl: state.zaloSettings.webhookUrl, title: `🏮 Lịch Âm VN (${devLabel})`, text: buildDayPlainForZalo() });
    $('m-zalo-status').className = res.ok ? 'status-msg' : 'status-msg err';
    $('m-zalo-status').textContent = res.ok ? '✓ Đã gửi thử Webhook thành công!' : res.error;
  });
  $('btn-see-all-holidays').addEventListener('click', () => switchTab('more'));
  $('btn-goto-ausp').addEventListener('click', () => switchTab('auspicious'));
  $('btn-quick-rem').addEventListener('click', () => {
    $('bulk-rem-panel')?.classList.add('hidden');
    resetMobileRemForm(false);
    mRemNoteEdited = false;
    mRemPrevEveEdited = false;
    $('rem-date').value = getSelectedKey();
    switchTab('reminders');
    switchRemSub('rem');
    $('rem-form').classList.remove('hidden');
    updateRemFabVisibility();
    $('rem-title').focus();
  });
  $('btn-quick-hl').addEventListener('click', () => {
    $('hl-start').value = getSelectedKey();
    $('hl-end').value = getSelectedKey();
    switchTab('highlights');
    $('hl-form').classList.remove('hidden');
    $('hl-title').focus();
  });

  // Prayers & Discover Hub events
  $('btn-p-back').addEventListener('click', () => switchTab('discover'));
  document.querySelectorAll('.btn-back-discover').forEach((b) => {
    b.addEventListener('click', () => switchTab('discover'));
  });
  document.querySelectorAll('#tab-discover .discover-row').forEach((row) => {
    row.addEventListener('click', () => {
      const act = row.dataset.discoverAction || '';
      if (act === 'open-ai') {
        openMobileGeminiChat();
      } else if (act.startsWith('tab:')) {
        switchTab(act.slice(4));
      } else if (act.startsWith('rem:')) {
        switchTab('reminders');
        switchRemSub(act.slice(4));
      } else if (act === 'settings:converter') {
        switchTab('settings');
        $('conv-d')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });
  });
  $('p-auto-open').addEventListener('change', () => {
    state.prayerPrefs.autoOpenOnSpecialDay = $('p-auto-open').checked;
    persistAndSync('prayerPrefs', state.prayerPrefs);
  });
  $('p-homeowner').addEventListener('input', () => {
    state.prayerPrefs.homeownerName = $('p-homeowner').value;
    renderPrayerReader();
  });
  $('p-homeowner').addEventListener('change', () => persistAndSync('prayerPrefs', state.prayerPrefs));
  $('p-address').addEventListener('input', () => {
    state.prayerPrefs.address = $('p-address').value;
    renderPrayerReader();
  });
  $('p-address').addEventListener('change', () => persistAndSync('prayerPrefs', state.prayerPrefs));
  $('p-search').addEventListener('input', () => {
    state.prayerSearch = $('p-search').value;
    if (state.prayerSearch.trim() && state.prayerCategory === 'recommended') state.prayerCategory = 'all';
    renderPrayers(false);
  });
  $('btn-p-minus').addEventListener('click', () => {
    state.prayerPrefs.fontSize = Math.max(12, (state.prayerPrefs.fontSize || 15) - 1);
    renderPrayerReader();
    persistAndSync('prayerPrefs', state.prayerPrefs);
  });
  $('btn-p-plus').addEventListener('click', () => {
    state.prayerPrefs.fontSize = Math.min(24, (state.prayerPrefs.fontSize || 15) + 1);
    renderPrayerReader();
    persistAndSync('prayerPrefs', state.prayerPrefs);
  });
  $('btn-p-copy').addEventListener('click', async () => {
    const text = `${$('p-view-title').textContent}\n\n${$('p-view-text').textContent}`;
    try {
      await navigator.clipboard.writeText(text);
      $('p-status').textContent = '✓ Đã sao chép bài văn khấn!';
      setTimeout(() => { $('p-status').textContent = ''; }, 3000);
    } catch (_e) {}
  });
  $('btn-p-tg').addEventListener('click', () => {
    const html = `🙏 <b>${esc($('p-view-title').textContent)}</b>\n\n${esc($('p-view-text').textContent)}`;
    sendTgHtml(html, $('btn-p-tg'));
  });

  // Auspicious events
  const syncAuspQuickActive = () => {
    const f = $('ausp-from')?.value || '';
    const t = $('ausp-to')?.value || '';
    const tkNow = getTodayKey();
    document.querySelectorAll('.ausp-quick').forEach((btn) => {
      const days = Number(btn.dataset.days) || 30;
      const dt = new Date(today.getFullYear(), today.getMonth(), today.getDate() + days);
      const expectedTo = formatDateKey(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
      btn.classList.toggle('active', f === tkNow && t === expectedTo);
    });
  };
  document.querySelectorAll('.ausp-quick').forEach((b) => {
    b.addEventListener('click', () => {
      const days = Number(b.dataset.days) || 30;
      const to = new Date(today.getFullYear(), today.getMonth(), today.getDate() + days);
      $('ausp-from').value = getTodayKey();
      $('ausp-to').value = formatDateKey(to.getFullYear(), to.getMonth() + 1, to.getDate());
      document.querySelectorAll('.ausp-quick').forEach((x) => x.classList.toggle('active', x === b));
      runAuspicious();
    });
  });
  $('ausp-from')?.addEventListener('change', syncAuspQuickActive);
  $('ausp-to')?.addEventListener('change', syncAuspQuickActive);
  $('btn-run-ausp').addEventListener('click', runAuspicious);

  // Left tab inside creator switcher: "⏰ Thêm"
  $('btn-rem-tab-single')?.addEventListener('click', () => {
    $('bulk-rem-panel')?.classList.add('hidden');
    if ($('rem-form').classList.contains('hidden')) {
      resetMobileRemForm(false);
      mRemNoteEdited = false;
      mRemPrevEveEdited = false;
      $('rem-form').classList.remove('hidden');
    }
    updateRemFabVisibility();
    $('rem-title')?.focus();
  });

  // Reminders & Highlights forms
  $('btn-toggle-rem').addEventListener('click', () => {
    $('bulk-rem-panel')?.classList.add('hidden');
    if (state.editingReminderId) {
      resetMobileRemForm(false);
      mRemNoteEdited = false;
      mRemPrevEveEdited = false;
      $('rem-form').classList.remove('hidden');
      $('main-scroll')?.scrollTo({ top: 0, behavior: 'smooth' });
      $('rem-title').focus();
      updateRemFabVisibility();
      return;
    }
    const willOpen = $('rem-form').classList.contains('hidden');
    if (willOpen) {
      resetMobileRemForm(false);
      mRemNoteEdited = false;
      mRemPrevEveEdited = false;
      $('rem-form').classList.remove('hidden');
      $('main-scroll')?.scrollTo({ top: 0, behavior: 'smooth' });
      $('rem-title').focus();
    } else {
      resetMobileRemForm(true);
    }
    updateRemFabVisibility();
  });
  $('btn-rem-edit-reset')?.addEventListener('click', () => {
    resetMobileRemForm(false);
    mRemNoteEdited = false;
    mRemPrevEveEdited = false;
    $('rem-title').focus();
  });
  $('btn-cancel-rem').addEventListener('click', () => {
    resetMobileRemForm(true);
    mRemNoteEdited = false;
    mRemPrevEveEdited = false;
    updateRemFabVisibility();
  });
  $('rem-form').addEventListener('submit', (e) => {
    e.preventDefault();
    flushEditableDateTimeFields();
    const rawTitle = $('rem-title').value.trim();
    const sendTelegram = $('rem-send-tg') ? $('rem-send-tg').checked : true;

    if (state.editingReminderId) {
      const target = state.timedReminders.find((r) => r.id === state.editingReminderId);
      const date = $('rem-date').value;
      const time = $('rem-time').value || getCurrentTimeHM(new Date());
      if (!rawTitle || !date || !time) return;
      if (target) {
        target.title = rawTitle;
        target.date = date;
        target.time = time;
        target.repeat = $('rem-repeat').value || 'none';
        target.note = $('rem-note').value.trim();
        target.sendTelegram = sendTelegram;
        target.updatedAt = Date.now();
      }
      persistAndSync('timedReminders', state.timedReminders);
      resetMobileRemForm(true);
      mRemNoteEdited = false;
      mRemPrevEveEdited = false;
      updateRemFabVisibility();
      renderRemindersList();
      renderAllCalendarViews();
      return;
    }

    const nlp = parseVietnameseNlpReminder(rawTitle, new Date());
    const title = nlp ? nlp.title : rawTitle;
    const date = $('rem-date').value || (nlp ? nlp.date : '');
    const time = $('rem-time').value || (nlp ? nlp.time : getCurrentTimeHM(new Date()));
    const note = $('rem-note').value.trim() || (nlp?.note || '');
    const repeat = $('rem-repeat').value || (nlp?.repeat || 'none');
    if (!title || !date || !time) return;

    if ($('rem-prev-eve')?.checked) {
      const prevDate = shiftDateKey(date, -1);
      const prevTime = $('rem-prev-eve-time')?.value || nlp?.prevDayAlert?.time || '20:00';
      state.timedReminders.push({
        id: `rem-pre-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        title: `🌙 Nhắc từ hôm trước: ${title}`,
        date: prevDate,
        time: prevTime,
        repeat: 'none',
        sound: true,
        sendTelegram,
        note: `Chuẩn bị cho ngày mai ${formatKeyVN(date)} lúc ${time}${note ? ` • ${note}` : ''}`,
        done: false,
        createdAt: Date.now()
      });
    }

    const slots = nlp && nlp.remindCount > 1 && nlp.time === time
      ? nlp.remindSlots
      : [{ offsetMinutes: 0, time }];
    for (const sl of slots) {
      state.timedReminders.push({
        id: `rem-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        title: sl.offsetMinutes > 0 ? `🔔 Nhắc trước ${sl.offsetMinutes}p: ${title}` : title,
        date,
        time: sl.time,
        repeat,
        sound: true,
        sendTelegram,
        note: sl.offsetMinutes > 0 ? `Sắp tới lịch lúc ${time}${note ? ` • ${note}` : ''}` : note,
        done: false,
        createdAt: Date.now()
      });
    }
    persistAndSync('timedReminders', state.timedReminders);
    resetMobileRemForm(true);
    mRemNoteEdited = false;
    mRemPrevEveEdited = false;
    updateRemFabVisibility();
    renderRemindersList();
    renderAllCalendarViews();
  });

  $('btn-toggle-hl').addEventListener('click', () => $('hl-form').classList.toggle('hidden'));
  $('btn-cancel-hl').addEventListener('click', () => $('hl-form').classList.add('hidden'));
  $('hl-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const title = $('hl-title').value.trim();
    const startDate = $('hl-start').value;
    const endDate = $('hl-end').value || startDate;
    if (!title || !startDate) return;
    state.highlightedRanges.push({
      id: `hl-${Date.now()}`,
      title,
      startDate,
      endDate: endDate < startDate ? startDate : endDate,
      color: $('hl-color').value || 'yellow',
      note: $('hl-note').value.trim()
    });
    persistAndSync('highlightedRanges', state.highlightedRanges);
    $('hl-form').reset();
    $('hl-form').classList.add('hidden');
    renderHighlightsList();
    renderAllCalendarViews();
  });

  $('import-file').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      if (file.name.toLowerCase().endsWith('.pdf')) {
        const buf = await file.arrayBuffer();
        const txt = await extractTextFromPdfBuffer(buf);
        importSchedulesFromRaw(txt, []);
      } else {
        const txt = await file.text();
        const icsList = file.name.toLowerCase().endsWith('.ics') ? [txt] : [];
        importSchedulesFromRaw(txt, icsList);
      }
    } catch (err) {
      $('import-status').className = 'status-msg err';
      $('import-status').textContent = `Lỗi đọc file: ${err.message}`;
    }
    e.target.value = '';
  });
  $('btn-parse-text').addEventListener('click', () => {
    const txt = $('import-text').value.trim();
    if (!txt) return;
    importSchedulesFromRaw(txt, txt.includes('BEGIN:VEVENT') ? [txt] : []);
  });

  // Water events
  const saveWater = () => {
    state.waterSettings = {
      ...state.waterSettings,
      enabled: $('w-enabled').checked,
      startTime: $('w-start').value || '08:00',
      endTime: $('w-end').value || '21:00',
      count: Math.max(1, Math.min(24, Number($('w-count').value) || 8)),
      soundEnabled: $('w-sound').checked
    };
    persistAndSync('waterSettings', state.waterSettings);
    renderWater();
  };
  ['w-enabled', 'w-start', 'w-end', 'w-count', 'w-sound'].forEach((id) => $(id).addEventListener('change', saveWater));
  $('btn-w-plus').addEventListener('click', () => {
    const k = getTodayKey();
    state.waterLog[k] = Number(state.waterLog[k] || 0) + 1;
    persistAndSync('waterLog', state.waterLog);
    renderWater();
  });
  $('btn-w-minus').addEventListener('click', () => {
    const k = getTodayKey();
    state.waterLog[k] = Math.max(0, Number(state.waterLog[k] || 0) - 1);
    persistAndSync('waterLog', state.waterLog);
    renderWater();
  });
  $('btn-w-test').addEventListener('click', () => playWaterPourSound(0.85).catch(() => {}));

  // Holidays, Custom Events, Converter
  $('btn-tet-lunar').addEventListener('click', () => jumpToSolar(getNextTetCountdown(today).tetSolar));
  $('btn-tet-solar').addEventListener('click', () => jumpToSolar(getNextSolarNewYearCountdown(today).solar));
  $('hol-filter-select')?.addEventListener('change', (e) => {
    state.holidayFilter = e.target.value || 'all';
    renderHolidays();
  });
  let editingCeId = null;

  function resetMobileCeForm(hideForm = true) {
    editingCeId = null;
    $('ce-form').reset();
    if ($('ce-remind')) $('ce-remind').value = '1';
    if ($('ce-remind-time')) $('ce-remind-time').value = '08:00';
    $('ce-edit-banner')?.classList.add('hidden');
    if ($('btn-ce-submit')) $('btn-ce-submit').textContent = 'Lưu & tự quy đổi hàng năm';
    if (hideForm) $('ce-form').classList.add('hidden');
  }

  window.__openMobileCeEdit = (ce) => {
    editingCeId = ce.id;
    if ($('ce-kind')) $('ce-kind').value = ce.kind || 'le';
    if ($('ce-remind')) $('ce-remind').value = String(ce.remindBeforeDays ?? 1);
    if ($('ce-remind-time')) $('ce-remind-time').value = ce.remindTime || '08:00';
    $('ce-name').value = ce.name || '';
    $('ce-cal').value = ce.calendar || 'lunar';
    $('ce-day').value = String(ce.day || 1);
    $('ce-month').value = String(ce.month || 1);
    if ($('ce-origin')) $('ce-origin').value = ce.originYear ? String(ce.originYear) : '';
    $('ce-note').value = ce.note || '';
    $('ce-edit-banner')?.classList.remove('hidden');
    if ($('btn-ce-submit')) $('btn-ce-submit').textContent = '💾 Lưu thay đổi';
    $('ce-form').classList.remove('hidden');
    $('ce-form').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    $('ce-day').focus();
  };

  $('btn-toggle-ce').addEventListener('click', () => {
    if (editingCeId) {
      resetMobileCeForm(false);
      $('ce-form').classList.remove('hidden');
      $('ce-name').focus();
      return;
    }
    const willOpen = $('ce-form').classList.contains('hidden');
    if (willOpen) {
      resetMobileCeForm(false);
      $('ce-form').classList.remove('hidden');
      $('ce-name').focus();
    } else {
      resetMobileCeForm(true);
    }
  });
  $('btn-ce-edit-reset')?.addEventListener('click', () => {
    resetMobileCeForm(false);
    $('ce-name').focus();
  });
  $('btn-cancel-ce').addEventListener('click', () => resetMobileCeForm(true));
  $('ce-form').addEventListener('submit', (e) => {
    e.preventDefault();
    flushEditableDateTimeFields();
    const name = $('ce-name').value.trim();
    const calendar = $('ce-cal').value;
    const day = Number($('ce-day').value);
    const month = Number($('ce-month').value);
    if (!name || day < 1 || day > 31 || month < 1 || month > 12) return;
    if (calendar === 'lunar' && day > 30) {
      alert('Tháng Âm lịch tối đa 30 ngày.');
      return;
    }
    const origY = Number($('ce-origin')?.value || 0);
    const originYear = origY >= 1900 && origY <= 2099 ? origY : null;
    const kind = $('ce-kind')?.value || 'le';
    const remindBeforeDays = Number($('ce-remind')?.value ?? 1);
    const remindTime = ($('ce-remind-time')?.value || '08:00').trim();
    const note = $('ce-note').value.trim();

    if (editingCeId) {
      const target = state.customEvents.find((c) => c.id === editingCeId);
      if (target) {
        target.name = name;
        target.kind = kind;
        target.calendar = calendar;
        target.day = day;
        target.month = month;
        target.originYear = originYear;
        target.remindBeforeDays = remindBeforeDays;
        target.remindTime = remindTime;
        target.note = note;
        target.updatedAt = Date.now();
      }
    } else {
      state.customEvents.push({
        id: `ce-${Date.now()}`,
        name,
        kind,
        calendar,
        day,
        month,
        leap: false,
        originYear,
        remindBeforeDays,
        remindTime,
        note,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }
    persistAndSync('customEvents', state.customEvents);
    resetMobileCeForm(true);
    renderHolidays();
    renderAllCalendarViews();
  });

  document.querySelectorAll('.conv-mode').forEach((b) => {
    b.addEventListener('click', () => {
      state.converterMode = b.dataset.mode;
      document.querySelectorAll('.conv-mode').forEach((x) => x.classList.toggle('active', x === b));
      $('conv-leap-row').classList.toggle('hidden', state.converterMode !== 'l2s');
    });
  });
  $('btn-convert')?.addEventListener('click', runConverter);

  // Telegram events
  const saveTg = () => {
    state.telegramSettings = {
      ...state.telegramSettings,
      enabled: $('tg-enabled').checked,
      botToken: $('tg-token').value.trim(),
      chatId: $('tg-chat-id').value.trim(),
      sendTimed: $('tg-send-timed').checked,
      sendHolidays: $('tg-send-holidays').checked,
      sendWater: $('tg-send-water').checked
    };
    persistAndSync('telegramSettings', state.telegramSettings);
  };
  ['tg-enabled', 'tg-token', 'tg-chat-id', 'tg-send-timed', 'tg-send-holidays', 'tg-send-water'].forEach((id) => $(id).addEventListener('change', saveTg));
  $('tg-local-device-allow')?.addEventListener('change', () => {
    state.localAllowAutoTelegram = $('tg-local-device-allow').checked;
    saveMobileField('localAllowAutoTelegram', state.localAllowAutoTelegram);
    syncNativeAndroidAlarms(state);
    $('tg-status').className = 'status-msg';
    $('tg-status').textContent = state.localAllowAutoTelegram
      ? '✓ Đã bật tự gửi Telegram trên điện thoại này'
      : '✓ Đã tắt tự gửi Telegram riêng trên điện thoại này (PC vẫn gửi bình thường)';
  });

  // Holiday notification settings events
  const saveHolSettings = () => {
    const activeOffsets = [];
    $('set-notify-days').querySelectorAll('.pill.active').forEach((p) => activeOffsets.push(Number(p.dataset.offset)));
    state.settings = {
      ...state.settings,
      notificationsEnabled: $('set-notif-on').checked,
      remindMung1Ram: $('set-mung1-ram').checked,
      remindLunarHolidays: $('set-lunar-hol').checked,
      remindSolarHolidays: $('set-solar-hol').checked,
      notifyDaysBefore: activeOffsets.length > 0 ? activeOffsets.sort((a, b) => a - b) : [0],
      notifyHour: Number($('set-notify-hour').value) || 8
    };
    persistAndSync('settings', state.settings);
  };
  ['set-notif-on', 'set-mung1-ram', 'set-lunar-hol', 'set-solar-hol', 'set-notify-hour'].forEach((id) => $(id).addEventListener('change', saveHolSettings));
  $('set-notify-days').addEventListener('click', (e) => {
    const p = e.target.closest('.pill');
    if (!p) return;
    p.classList.toggle('active');
    saveHolSettings();
  });
  $('btn-tg-detect').addEventListener('click', async () => {
    saveTg();
    const res = await detectTelegramChatsApi($('tg-token').value.trim());
    const box = $('tg-chats-box');
    if (!res.ok) {
      $('tg-status').className = 'status-msg err';
      $('tg-status').textContent = res.error;
      return;
    }
    box.classList.remove('hidden');
    box.innerHTML = '';
    for (const c of res.chats) {
      const p = document.createElement('button');
      p.type = 'button';
      p.className = 'btn-chip tg';
      p.textContent = `${c.title} (${c.id})`;
      p.addEventListener('click', () => {
        $('tg-chat-id').value = c.id;
        saveTg();
        $('tg-status').className = 'status-msg';
        $('tg-status').textContent = `✓ Đã chọn nhóm: ${c.title}`;
      });
      box.appendChild(p);
    }
  });
  $('btn-tg-test').addEventListener('click', async () => {
    saveTg();
    const devLabel = typeof window.AndroidBridge?.getDeviceName === 'function' ? window.AndroidBridge.getDeviceName() : 'Android';
    await sendTgHtml(`🏮 <b>Lịch Âm Việt Nam (${devLabel} • v${APP_VERSION})</b>\n✅ Kết nối Telegram thành công!`, $('btn-tg-test'));
    const lockCheck = await testTelegramLockAccess(state.cloudSyncConfig);
    if (lockCheck.ok) {
      $('tg-status').className = 'status-msg';
      $('tg-status').textContent = '✓ Gửi thử OK & Khóa chống trùng Firebase hoạt động tốt!';
    } else if (!lockCheck.skipped) {
      $('tg-status').className = 'status-msg err';
      $('tg-status').textContent = `⚠️ Cảnh báo khóa chống trùng: ${lockCheck.message}`;
    }
  });

  // Notifications, ColorOS Battery & Backup
  $('btn-req-notif').addEventListener('click', async () => {
    if (isRunningInAndroidApk() && typeof window.AndroidBridge.requestNotificationPermission === 'function') {
      window.AndroidBridge.requestNotificationPermission();
      return;
    }
    if ('Notification' in window) {
      const p = await Notification.requestPermission();
      $('backup-status').textContent = p === 'granted' ? '✓ Đã bật quyền thông báo!' : 'Bạn cần cấp quyền thông báo trong cài đặt Chrome.';
    }
  });
  $('btn-test-notif').addEventListener('click', () => {
    if (!triggerNativeTestNotification()) {
      const devLabel = typeof window.AndroidBridge?.getDeviceName === 'function' ? window.AndroidBridge.getDeviceName() : 'Android';
    openAlarmModal({ kind: 'timed', title: 'Chuông báo thử — Lịch Âm VN', meta: devLabel, note: 'Hệ thống thông báo đang hoạt động tốt!' });
    }
  });
  $('btn-android-battery')?.addEventListener('click', () => openAndroidBatterySettings());
  $('btn-android-exact')?.addEventListener('click', () => requestAndroidExactAlarmPermission());

  $('btn-export-json').addEventListener('click', () => {
    const blob = new Blob([exportAllDataJson(state)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lich-am-vn-backup-${getTodayKey()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    $('backup-status').textContent = '✓ Đã tải xuống file sao lưu JSON!';
  });
  $('import-json-file').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const restored = importAllDataJson(await file.text());
      Object.assign(state, restored);
      syncNativeAndroidAlarms(state);
      initControls();
      renderAllCalendarViews();
      renderPrayers(true);
      renderHolidays();
      renderWater();
      $('backup-status').textContent = '✓ Đã khôi phục dữ liệu thành công!';
    } catch (err) {
      $('backup-status').className = 'status-msg err';
      $('backup-status').textContent = `Lỗi khôi phục: ${err.message}`;
    }
    e.target.value = '';
  });

  // Modal actions
  $('btn-modal-ok').addEventListener('click', () => {
    if (state.activeModalAlarm?.kind === 'water') {
      const k = getTodayKey();
      state.waterLog[k] = Number(state.waterLog[k] || 0) + 1;
      persistAndSync('waterLog', state.waterLog);
      renderWater();
    }
    $('alarm-modal').classList.add('hidden');
  });
  $('btn-modal-snooze').addEventListener('click', () => {
    const cur = state.activeModalAlarm;
    $('alarm-modal').classList.add('hidden');
    if (cur) {
      setTimeout(() => openAlarmModal(cur), 5 * 60 * 1000);
    }
  });

  // PWA Install Prompt (Android Chrome + iPhone 13 Safari Guide Modal)
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    state.deferredInstallPrompt = e;
    $('btn-install-pwa').classList.remove('hidden');
  });
  $('btn-install-pwa').addEventListener('click', async () => {
    const onIos = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    if (onIos && !state.deferredInstallPrompt) {
      $('ios-install-modal')?.classList.remove('hidden');
      return;
    }
    if (!state.deferredInstallPrompt) return;
    state.deferredInstallPrompt.prompt();
    await state.deferredInstallPrompt.userChoice;
    state.deferredInstallPrompt = null;
    $('btn-install-pwa').classList.add('hidden');
  });
  $('btn-close-ios-modal')?.addEventListener('click', () => {
    $('ios-install-modal')?.classList.add('hidden');
  });
  $('ios-install-modal')?.addEventListener('click', (e) => {
    if (e.target === $('ios-install-modal')) $('ios-install-modal').classList.add('hidden');
  });
}

// Register offline Service Worker (when served via HTTP/HTTPS PWA, skip on Android WebView AssetLoader if not needed)
if ('serviceWorker' in navigator && !isRunningInAndroidApk() && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

function openNotificationTarget(channel, dateKey) {
  const ch = String(channel || '').trim().toLowerCase();
  const parsed = parseDateParam(dateKey);
  if (parsed) {
    state.selectedDate = { ...parsed };
    state.viewYear = parsed.year;
    state.viewMonth = parsed.month;
    renderAllCalendarViews();
  }
  if (ch === 'water') {
    switchTab('water');
    return;
  }
  if (ch === 'reminders') {
    switchTab('reminders');
    switchRemSub('rem');
    return;
  }
  if (ch === 'holidays') {
    switchTab('more');
    return;
  }
  if (parsed) jumpToSolar(parsed);
}

// Expose hooks for Android native lifecycle
window.__openDateFromAndroid = (dateKey) => {
  openNotificationTarget('', dateKey);
};
window.__openNotificationTargetFromAndroid = (channel, dateKey) => {
  openNotificationTarget(channel, dateKey);
};
window.__triggerCloudPull = () => {
  if (state.cloudSyncConfig?.enabled) syncMobileCloudNow('pull', false);
};
window.__refreshAndroidHealth = () => {
  renderOppoHealthStatus();
};

/* ==================== BULK RECURRING SCHEDULER (MOBILE) ==================== */
let mBulkRemRows = [];

function createMobileBulkRow(overrides = {}) {
  return {
    enabled: true,
    title: '',
    repeat: 'monthly',
    dayOfMonth: new Date().getDate(),
    weekday: new Date().getDay(),
    lunarDay: 1,
    date: getTodayKey(),
    time: '09:00',
    sendTelegram: true,
    note: '',
    ...overrides
  };
}

function setMobileBulkStatus(msg, isErr = false) {
  const el = $('bulk-rem-status');
  if (!el) return;
  el.className = isErr ? 'status-msg err' : 'status-msg';
  el.textContent = msg || '';
}

function updateMobileBulkSaveLabel() {
  const btn = $('btn-bulk-save-all');
  if (!btn) return;
  const n = mBulkRemRows.filter((r) => r.enabled && String(r.title || '').trim()).length;
  btn.textContent = n > 0 ? `✅ Lưu tất cả (${n} lịch)` : '✅ Lưu tất cả';
}

function renderMobileBulkRows() {
  const box = $('bulk-rows-container');
  if (!box) return;
  box.innerHTML = '';

  if (mBulkRemRows.length === 0) {
    box.innerHTML = '<div class="empty-msg">Chạm <strong>☀️ Thức dậy</strong>, <strong>💳 Hóa đơn tháng</strong> hoặc <strong>+ Thêm dòng</strong> để đặt lịch hàng loạt.</div>';
    updateMobileBulkSaveLabel();
    return;
  }

  const weekdayOpts = [
    [1, 'Thứ 2'], [2, 'Thứ 3'], [3, 'Thứ 4'], [4, 'Thứ 5'],
    [5, 'Thứ 6'], [6, 'Thứ 7'], [0, 'Chủ nhật']
  ];

  mBulkRemRows.forEach((row, idx) => {
    const card = document.createElement('div');
    card.className = `bulk-row-card${row.enabled ? '' : ' unchecked'}`;

    const top = document.createElement('div');
    top.className = 'bulk-row-top';

    const chk = document.createElement('input');
    chk.type = 'checkbox';
    chk.checked = Boolean(row.enabled);
    chk.addEventListener('change', () => {
      row.enabled = chk.checked;
      card.classList.toggle('unchecked', !row.enabled);
      updateMobileBulkSaveLabel();
    });

    const titleInp = document.createElement('input');
    titleInp.type = 'text';
    titleInp.className = 'bulk-row-title';
    titleInp.placeholder = 'Tên lịch (VD: Thức dậy, Thanh toán thẻ tín dụng...)';
    titleInp.maxLength = 120;
    titleInp.value = row.title || '';
    titleInp.addEventListener('input', () => {
      row.title = titleInp.value;
      updateMobileBulkSaveLabel();
    });

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.className = 'bulk-row-del';
    delBtn.textContent = '🗑';
    delBtn.addEventListener('click', () => {
      mBulkRemRows.splice(idx, 1);
      renderMobileBulkRows();
    });

    top.append(chk, titleInp, delBtn);

    const ctrl = document.createElement('div');
    ctrl.className = 'bulk-row-controls';

    const repSel = document.createElement('select');
    [
      ['daily', 'Hàng ngày'],
      ['weekly', 'Hàng tuần'],
      ['monthly', 'Hàng tháng (DL)'],
      ['lunar-monthly', '🌙 Hàng tháng (ÂL)'],
      ['yearly', 'Hàng năm'],
      ['none', 'Một lần']
    ].forEach(([val, lbl]) => {
      const o = document.createElement('option');
      o.value = val;
      o.textContent = lbl;
      repSel.appendChild(o);
    });
    repSel.value = row.repeat || 'monthly';
    repSel.addEventListener('change', () => {
      row.repeat = repSel.value;
      renderMobileBulkRows();
    });
    ctrl.appendChild(repSel);

    if (row.repeat === 'daily') {
      const tag = document.createElement('span');
      tag.className = 'bulk-daily-tag';
      tag.textContent = 'Mỗi ngày';
      ctrl.appendChild(tag);
    } else if (row.repeat === 'weekly') {
      const wSel = document.createElement('select');
      weekdayOpts.forEach(([v, l]) => {
        const o = document.createElement('option');
        o.value = String(v);
        o.textContent = l;
        wSel.appendChild(o);
      });
      wSel.value = String(row.weekday ?? 1);
      wSel.addEventListener('change', () => { row.weekday = Number(wSel.value); });
      ctrl.appendChild(wSel);
    } else if (row.repeat === 'monthly') {
      const dSel = document.createElement('select');
      for (let d = 1; d <= 31; d++) {
        const o = document.createElement('option');
        o.value = String(d);
        o.textContent = `Ngày ${pad2(d)}`;
        dSel.appendChild(o);
      }
      dSel.value = String(row.dayOfMonth || 1);
      dSel.addEventListener('change', () => { row.dayOfMonth = Number(dSel.value); });
      ctrl.appendChild(dSel);
    } else if (row.repeat === 'lunar-monthly') {
      const lSel = document.createElement('select');
      for (let d = 1; d <= 30; d++) {
        const o = document.createElement('option');
        o.value = String(d);
        o.textContent = d === 1 ? 'Mùng 1 ÂL' : d === 15 ? 'Rằm 15 ÂL' : `Ngày ${d} ÂL`;
        lSel.appendChild(o);
      }
      lSel.value = String(row.lunarDay || 1);
      lSel.addEventListener('change', () => { row.lunarDay = Number(lSel.value); });
      ctrl.appendChild(lSel);
    } else {
      const dtInp = document.createElement('input');
      dtInp.type = 'date';
      dtInp.value = row.date || getTodayKey();
      dtInp.addEventListener('change', () => { row.date = dtInp.value; });
      ctrl.appendChild(dtInp);
    }

    const timeInp = document.createElement('input');
    timeInp.type = 'time';
    timeInp.value = row.time || '09:00';
    timeInp.addEventListener('change', () => { row.time = timeInp.value || '09:00'; });
    ctrl.appendChild(timeInp);

    const tgLbl = document.createElement('label');
    tgLbl.className = 'bulk-tg-lbl';
    const tgChk = document.createElement('input');
    tgChk.type = 'checkbox';
    tgChk.checked = row.sendTelegram !== false;
    tgChk.addEventListener('change', () => { row.sendTelegram = tgChk.checked; });
    tgLbl.append(tgChk, document.createTextNode('✈️ TG'));
    ctrl.appendChild(tgLbl);

    card.append(top, ctrl);
    box.appendChild(card);
  });

  updateMobileBulkSaveLabel();
}

function bindMobileBulkReminderEvents() {
  const panel = $('bulk-rem-panel');
  const toggleBtn = $('btn-toggle-bulk-rem');
  if (!panel || !toggleBtn) return;

  const openPanel = () => {
    resetMobileRemForm(true);
    panel.classList.remove('hidden');
    $('main-scroll')?.scrollTo({ top: 0, behavior: 'smooth' });
    setMobileBulkStatus('');
    if (mBulkRemRows.length === 0) {
      mBulkRemRows = [
        createMobileBulkRow({ ...BULK_REMINDER_PRESETS.daily[0] }),
        ...BULK_REMINDER_PRESETS.monthly_bills.map((p) => createMobileBulkRow({ ...p }))
      ];
    }
    renderMobileBulkRows();
    updateRemFabVisibility();
  };

  toggleBtn.addEventListener('click', () => {
    openPanel();
  });
  $('btn-close-bulk-rem')?.addEventListener('click', () => {
    panel.classList.add('hidden');
    updateRemFabVisibility();
  });

  panel.querySelectorAll('.bulk-preset-btn[data-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.preset;
      const list = BULK_REMINDER_PRESETS[key] || [];
      let added = 0;
      for (const item of list) {
        const exists = mBulkRemRows.some(
          (r) => r.title.trim().toLowerCase() === item.title.trim().toLowerCase() && r.repeat === item.repeat
        );
        if (!exists) {
          mBulkRemRows.push(createMobileBulkRow({ ...item }));
          added++;
        }
      }
      renderMobileBulkRows();
      setMobileBulkStatus(added > 0 ? `✓ Đã nạp ${added} mẫu (sửa ngày/giờ rồi bấm Lưu tất cả).` : 'Các mẫu này đã có sẵn trong bảng rồi.');
    });
  });

  $('btn-toggle-bulk-paste')?.addEventListener('click', () => {
    const box = $('bulk-paste-box');
    box?.classList.toggle('hidden');
    if (box && !box.classList.contains('hidden')) $('bulk-paste-input')?.focus();
  });
  $('btn-bulk-paste-clear')?.addEventListener('click', () => {
    if ($('bulk-paste-input')) $('bulk-paste-input').value = '';
  });
  $('btn-bulk-parse-lines')?.addEventListener('click', () => {
    const raw = $('bulk-paste-input')?.value || '';
    const parsed = parseBulkReminderLines(raw, new Date());
    if (parsed.length === 0) {
      setMobileBulkStatus('Hãy nhập ít nhất 1 dòng lịch (VD: "Mỗi ngày 6h thức dậy").', true);
      return;
    }
    parsed.forEach((p) => mBulkRemRows.push(createMobileBulkRow(p)));
    renderMobileBulkRows();
    setMobileBulkStatus(`✨ Đã tách ${parsed.length} lịch vào danh sách!`);
  });

  $('btn-bulk-add-row')?.addEventListener('click', () => {
    mBulkRemRows.push(createMobileBulkRow({ title: '', repeat: 'monthly', dayOfMonth: 15, time: '09:00', sendTelegram: true }));
    renderMobileBulkRows();
    const inputs = document.querySelectorAll('#bulk-rows-container .bulk-row-title');
    inputs[inputs.length - 1]?.focus();
  });
  $('btn-bulk-clear-rows')?.addEventListener('click', () => {
    mBulkRemRows = [];
    renderMobileBulkRows();
    setMobileBulkStatus('');
  });

  $('btn-bulk-save-all')?.addEventListener('click', () => {
    const valid = mBulkRemRows.filter((r) => r.enabled && String(r.title || '').trim());
    if (valid.length === 0) {
      setMobileBulkStatus('Chưa có dòng lịch hợp lệ nào được chọn!', true);
      return;
    }
    const now = new Date();
    let addedCount = 0;
    let skippedDup = 0;

    for (let i = 0; i < valid.length; i++) {
      const r = valid[i];
      const title = String(r.title).trim();
      const date = computeStartDateForBulkRow(r, now);
      const time = r.time || '09:00';
      const repeat = r.repeat || 'none';

      const dup = state.timedReminders.some(
        (ex) => !ex.done &&
          ex.title.trim().toLowerCase() === title.toLowerCase() &&
          (ex.repeat || 'none') === repeat &&
          ex.time === time &&
          (repeat === 'daily' || ex.date === date)
      );
      if (dup) {
        skippedDup++;
        continue;
      }

      state.timedReminders.push({
        id: `rem-bulk-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 5)}`,
        title,
        date,
        time,
        repeat,
        sound: true,
        sendTelegram: r.sendTelegram !== false,
        note: r.note || '',
        done: false,
        createdAt: Date.now()
      });
      addedCount++;
    }

    if (addedCount > 0) {
      persistAndSync('timedReminders', state.timedReminders);
      renderRemindersList();
      renderAllCalendarViews();
      renderHolidays();
      setMobileBulkStatus(`✅ Đã lưu ${addedCount} lịch định kỳ${skippedDup > 0 ? ` (bỏ qua ${skippedDup} lịch trùng)` : ''} & tự động đồng bộ!`);
      setTimeout(() => {
        panel.classList.add('hidden');
        updateRemFabVisibility();
      }, 1400);
    } else {
      setMobileBulkStatus(`Tất cả ${skippedDup} lịch này đã có sẵn trong danh sách rồi.`, true);
    }
  });
}

/* ==================== PC-LIKE DIRECT-TYPE VIETNAMESE DATE & TIME INPUTS ==================== */
function isoDateToVN(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || '').trim());
  if (!m) return '';
  return `${m[3]}/${m[2]}/${m[1]}`;
}

function parseVNDateToIso(raw) {
  const txt = String(raw || '').trim();
  if (!txt) return null;
  // Support DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY, or shorthand DD/MM
  const parts = txt.split(/[\/\-\.\s]+/).filter(Boolean);
  let d, m, y;
  if (parts.length === 3) {
    if (parts[0].length === 4) {
      y = Number(parts[0]); m = Number(parts[1]); d = Number(parts[2]);
    } else {
      d = Number(parts[0]); m = Number(parts[1]); y = Number(parts[2]);
      if (y < 100) y += 2000;
    }
  } else if (parts.length === 2) {
    d = Number(parts[0]); m = Number(parts[1]); y = new Date().getFullYear();
  } else if (/^\d{8}$/.test(txt)) {
    d = Number(txt.slice(0, 2)); m = Number(txt.slice(2, 4)); y = Number(txt.slice(4, 8));
  } else {
    return null;
  }
  if (!Number.isInteger(d) || !Number.isInteger(m) || !Number.isInteger(y) || y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) {
    return null;
  }
  const dt = new Date(y, m - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
  return formatDateKey(y, m, d);
}

function parseLooseTimeToHM(raw) {
  const txt = String(raw || '').trim().toLowerCase();
  if (!txt) return null;
  let hh, mm;
  const m1 = /^(\d{1,2})[:h\.\s](\d{1,2})$/.exec(txt);
  if (m1) {
    hh = Number(m1[1]); mm = Number(m1[2]);
  } else if (/^\d{3,4}$/.test(txt)) {
    const padded = txt.padStart(4, '0');
    hh = Number(padded.slice(0, 2)); mm = Number(padded.slice(2, 4));
  } else if (/^\d{1,2}h?$/.test(txt)) {
    hh = Number(txt.replace('h', '')); mm = 0;
  } else {
    return null;
  }
  if (!Number.isInteger(hh) || !Number.isInteger(mm) || hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return `${pad2(hh)}:${pad2(mm)}`;
}

let flushEditableDateTimeFields = () => {};

function setupEditableDateTimeFields() {
  const nativeValDesc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
  const flushers = [];

  const bindDatePair = (nativeId, textId, btnId) => {
    const nativeEl = $(nativeId);
    const textEl = $(textId);
    const btnEl = $(btnId);
    if (!nativeEl || !textEl) return;

    const syncToText = () => {
      textEl.value = isoDateToVN(nativeValDesc.get.call(nativeEl));
      textEl.classList.remove('dt-invalid');
    };

    // Intercept programmatic .value = 'YYYY-MM-DD' so text input ALWAYS stays in sync!
    Object.defineProperty(nativeEl, 'value', {
      configurable: true,
      get() { return nativeValDesc.get.call(this); },
      set(v) {
        nativeValDesc.set.call(this, v);
        syncToText();
      }
    });

    textEl.addEventListener('input', (e) => {
      // Auto-insert slashes when user types pure digits smoothly (e.g. 28112026 -> 28/11/2026)
      if (e.inputType && !e.inputType.startsWith('delete')) {
        const digits = textEl.value.replace(/\D/g, '');
        if (/^\d+$/.test(textEl.value.replace(/\//g, ''))) {
          if (digits.length === 2 && !textEl.value.includes('/')) {
            textEl.value = `${digits}/`;
          } else if (digits.length === 4 && textEl.value.split('/').length === 2 && !textEl.value.endsWith('/')) {
            textEl.value = `${digits.slice(0, 2)}/${digits.slice(2, 4)}/`;
          }
        }
      }
      const iso = parseVNDateToIso(textEl.value);
      if (iso) {
        nativeValDesc.set.call(nativeEl, iso);
        textEl.classList.remove('dt-invalid');
      } else {
        textEl.classList.toggle('dt-invalid', textEl.value.trim().length >= 8);
      }
    });

    const flush = () => {
      const iso = parseVNDateToIso(textEl.value);
      if (iso) {
        nativeValDesc.set.call(nativeEl, iso);
        textEl.value = isoDateToVN(iso);
        textEl.classList.remove('dt-invalid');
      } else {
        syncToText();
      }
    };
    textEl.addEventListener('blur', flush);
    flushers.push(flush);

    nativeEl.addEventListener('change', syncToText);
    btnEl?.addEventListener('click', () => {
      try {
        if (typeof nativeEl.showPicker === 'function') nativeEl.showPicker();
        else { nativeEl.focus(); nativeEl.click(); }
      } catch (_e) {
        nativeEl.focus();
        nativeEl.click();
      }
    });

    syncToText();
  };

  const bindTimePair = (nativeId, textId, btnId) => {
    const nativeEl = $(nativeId);
    const textEl = $(textId);
    const btnEl = $(btnId);
    if (!nativeEl || !textEl) return;

    const syncToText = () => {
      textEl.value = nativeValDesc.get.call(nativeEl) || '';
      textEl.classList.remove('dt-invalid');
    };

    Object.defineProperty(nativeEl, 'value', {
      configurable: true,
      get() { return nativeValDesc.get.call(this); },
      set(v) {
        nativeValDesc.set.call(this, v);
        syncToText();
      }
    });

    textEl.addEventListener('input', (e) => {
      if (e.inputType && !e.inputType.startsWith('delete')) {
        const digits = textEl.value.replace(/\D/g, '');
        if (/^\d{2}$/.test(textEl.value) && digits.length === 2) {
          textEl.value = `${digits}:`;
        }
      }
      const hm = parseLooseTimeToHM(textEl.value);
      if (hm) {
        nativeValDesc.set.call(nativeEl, hm);
        textEl.classList.remove('dt-invalid');
      } else {
        textEl.classList.toggle('dt-invalid', textEl.value.trim().length >= 4);
      }
    });

    const flush = () => {
      const hm = parseLooseTimeToHM(textEl.value);
      if (hm) {
        nativeValDesc.set.call(nativeEl, hm);
        textEl.value = hm;
        textEl.classList.remove('dt-invalid');
      } else {
        syncToText();
      }
    };
    textEl.addEventListener('blur', flush);
    flushers.push(flush);

    nativeEl.addEventListener('change', syncToText);
    btnEl?.addEventListener('click', () => {
      try {
        if (typeof nativeEl.showPicker === 'function') nativeEl.showPicker();
        else { nativeEl.focus(); nativeEl.click(); }
      } catch (_e) {
        nativeEl.focus();
        nativeEl.click();
      }
    });

    syncToText();
  };

  bindDatePair('rem-date', 'rem-date-text', 'btn-pick-rem-date');
  bindTimePair('rem-time', 'rem-time-text', 'btn-pick-rem-time');
  bindTimePair('rem-prev-eve-time', 'rem-prev-eve-time-text', 'btn-pick-prev-time');
  bindTimePair('ce-remind-time', 'ce-remind-time-text', 'btn-pick-ce-time');

  flushEditableDateTimeFields = () => flushers.forEach((fn) => fn());
}

/* ==================== GLOBAL SPOTLIGHT SEARCH (MOBILE) ==================== */
function closeMobileGlobalSearch() {
  $('global-search-modal')?.classList.add('hidden');
}

function executeMobileSearchAction(action) {
  closeMobileGlobalSearch();
  if (!action) return;

  if (action.type === 'date' && action.solar) {
    jumpToSolar(action.solar);
    return;
  }

  if (action.type === 'reminder') {
    const target = state.timedReminders.find((r) => r.id === action.id);
    switchTab('reminders');
    switchRemSub('rem');
    if (target) {
      openMobileRemEdit(target);
      updateRemFabVisibility();
    }
    return;
  }

  if (action.type === 'custom-event') {
    const target = state.customEvents.find((c) => c.id === action.id);
    switchTab('more');
    state.holidayFilter = 'custom';
    if ($('hol-filter-select')) $('hol-filter-select').value = 'custom';
    renderHolidays();
    if (target && typeof window.__openMobileCeEdit === 'function') {
      window.__openMobileCeEdit(target);
    }
    return;
  }

  if (action.type === 'prayer') {
    state.selectedPrayerId = action.id;
    switchTab('prayers');
    renderPrayers(false);
    $('prayer-reader-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    return;
  }

  if (action.type === 'auspicious') {
    if ($('ausp-task')) $('ausp-task').value = action.taskId;
    state.auspiciousPrefs.taskId = action.taskId;
    switchTab('auspicious');
    runAuspicious();
    return;
  }

  if (action.type === 'open-ai') {
    openMobileGeminiChat();
    return;
  }

  if (action.type === 'dream') {
    switchTab('dreams');
    const dm = DREAMS_CATALOG.find((x) => x.id === action.id);
    if (dm && $('dream-search')) {
      $('dream-search').value = dm.title.split('(')[0].trim();
      $('dream-search').dispatchEvent(new Event('input'));
    }
    return;
  }

  if (action.type === 'nav') {
    if (action.sub === 'hl') {
      switchTab('highlights');
      return;
    }
    switchTab(action.tab || 'calendar');
    if (action.sub && (action.tab === 'reminders' || !action.tab)) switchRemSub(action.sub);
    if (action.open === 'rem-form') {
      $('btn-toggle-rem')?.click();
    } else if (action.open === 'bulk-form') {
      $('btn-toggle-bulk-rem')?.click();
    } else if (action.focus === 'cloud') {
      expandMobileSettingsCard('cloud');
      $('cs-fb-url')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else if (action.focus === 'telegram') {
      expandMobileSettingsCard('telegram');
      $('tg-token')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else if (action.focus === 'zalo') {
      expandMobileSettingsCard('zalo');
      $('m-zalo-url')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else if (action.focus === 'autodel') {
      expandMobileSettingsCard('holidays');
      $('rem-auto-delete-select')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else if (action.focus === 'converter') {
      switchTab('converter');
    }
  }
}

function renderMobileGlobalSearchResults(query) {
  const box = $('gsearch-results');
  if (!box) return;
  const groups = runGlobalAppSearch(query, state, new Date());
  box.innerHTML = '';

  if (groups.length === 0) {
    box.innerHTML = `<div class="gsearch-empty">Không tìm thấy kết quả nào cho "<strong>${esc(query)}</strong>".<br/>Thử gõ: <em>tiền nhà, giỗ, văn khấn, 25/12, 15/10 âm, telegram...</em></div>`;
    return;
  }

  for (const g of groups) {
    const title = document.createElement('div');
    title.className = 'gsearch-group-title';
    title.textContent = g.label;
    box.appendChild(title);

    const list = document.createElement('div');
    list.className = 'gsearch-group-list';
    for (const item of g.items) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'gsearch-item';
      btn.innerHTML = `
        <span class="gsearch-item-ico">${item.icon || '🔎'}</span>
        <div class="gsearch-item-body">
          <div class="gsearch-item-title">${esc(item.title)}</div>
          <div class="gsearch-item-sub">${esc(item.sub || '')}</div>
        </div>
      `;
      btn.addEventListener('click', () => executeMobileSearchAction(item.action));
      list.appendChild(btn);
    }
    box.appendChild(list);
  }
}

function openMobileGlobalSearch() {
  const modal = $('global-search-modal');
  const inp = $('gsearch-input');
  if (!modal || !inp) return;
  modal.classList.remove('hidden');
  inp.value = '';
  $('btn-gsearch-clear')?.classList.add('hidden');
  renderMobileGlobalSearchResults('');
  syncMobileGeminiViewport();
  setTimeout(() => {
    inp.focus();
    syncMobileGeminiViewport();
  }, 80);
}

function bindMobileGlobalSearchEvents() {
  const modal = $('global-search-modal');
  const inp = $('gsearch-input');
  const clr = $('btn-gsearch-clear');
  if (!modal || !inp) return;

  inp.addEventListener('input', () => {
    clr?.classList.toggle('hidden', !inp.value);
    renderMobileGlobalSearchResults(inp.value);
  });
  clr?.addEventListener('click', () => {
    inp.value = '';
    clr.classList.add('hidden');
    renderMobileGlobalSearchResults('');
    inp.focus();
  });
  $('btn-gsearch-close')?.addEventListener('click', closeMobileGlobalSearch);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeMobileGlobalSearch();
  });
}

/* ==================== GEMINI AI CONTROLLER (OPPO FIND X9) ==================== */
let mobileGeminiChatHistory = [];
let mobileGeminiBusy = false;

function renderMobileGeminiSettings() {
  const gm = state.geminiSettings || DEFAULT_GEMINI_SETTINGS;
  if ($('gm-enabled')) $('gm-enabled').checked = Boolean(gm.enabled);
  if ($('gm-api-key')) $('gm-api-key').value = gm.apiKey || '';
  if ($('gm-proxy-url')) $('gm-proxy-url').value = gm.proxyUrl || '';
  if ($('gm-proxy-token')) $('gm-proxy-token').value = gm.proxyToken || '';
  if ($('gm-model')) {
    const mVal = gm.model || DEFAULT_GEMINI_SETTINGS.model;
    const sel = $('gm-model');
    const hasOpt = Array.from(sel.options).some((o) => o.value === mVal);
    if (!hasOpt && mVal && mVal !== 'auto') {
      const opt = document.createElement('option');
      opt.value = mVal;
      opt.textContent = `📡 ${mVal}`;
      sel.appendChild(opt);
    }
    sel.value = mVal || 'auto';
  }
  const banner = $('gm-chat-setup-banner');
  if (banner) banner.classList.toggle('hidden', isGeminiConfigured(state.geminiSettings));
}

function openMobileGeminiSettingsFocus() {
  $('gemini-chat-modal')?.classList.add('hidden');
  switchTab('settings');
  expandMobileSettingsCard('gemini');
  setTimeout(() => {
    $('gemini-settings-card')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    $('gm-api-key')?.focus();
  }, 180);
}

function formatMobileGeminiMd(raw) {
  const safe = esc(String(raw || ''));
  return safe
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*([^*\n]+)\*(?=$|[\s,.;:!?])/g, '$1<em>$2</em>')
    .replace(/^\s*---\s*$/gm, '<hr style="border:none;border-top:1px solid #E5E7EB;margin:6px 0;" />')
    .replace(/^\s*[\*\-]\s+/gm, '• ');
}

function renderMobileGeminiMessages() {
  const box = $('gm-chat-messages');
  if (!box) return;
  box.innerHTML = '';

  if (mobileGeminiChatHistory.length === 0) {
    const welcome = document.createElement('div');
    welcome.className = 'gm-msg assistant';
    welcome.textContent = 'Xin chào! Mình là Trợ lý Gemini AI của Lịch Âm Việt Nam.\nBạn có thể hỏi lịch tuần này, ngày giỗ sắp tới, xem ngày giờ tốt theo tuổi, hỏi lễ vật cúng bái, hoặc nhờ mình tạo nhắc nhở mới trực tiếp ngay tại đây!';
    box.appendChild(welcome);
    return;
  }

  for (const m of mobileGeminiChatHistory) {
    const div = document.createElement('div');
    div.className = `gm-msg ${m.role === 'user' ? 'user' : m.isError ? 'error' : 'assistant'}`;
    if (m.role === 'user' && Array.isArray(m.images) && m.images.length > 0) {
      const imgWrap = document.createElement('div');
      imgWrap.className = 'gm-msg-imgs';
      for (const im of m.images) {
        const imgEl = document.createElement('img');
        imgEl.src = im.dataUrl || `data:${im.mimeType || 'image/jpeg'};base64,${im.base64}`;
        imgEl.alt = 'Ảnh đính kèm';
        imgWrap.appendChild(imgEl);
      }
      div.appendChild(imgWrap);
    }
    if (m.role === 'assistant' && !m.isError) {
      div.innerHTML = formatMobileGeminiMd(m.text);
    } else {
      const txtEl = document.createElement('div');
      txtEl.style.whiteSpace = 'pre-wrap';
      txtEl.textContent = m.text;
      div.appendChild(txtEl);
      if (m.isError && (m.retryPrompt || (Array.isArray(m.retryImages) && m.retryImages.length > 0))) {
        const actions = document.createElement('div');
        actions.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;';
        const retryBtn = document.createElement('button');
        retryBtn.type = 'button';
        retryBtn.className = 'btn-chip primary';
        retryBtn.textContent = '🔄 Thử lại';
        retryBtn.addEventListener('click', () => sendMobileGeminiChatMessage(m.retryPrompt || '', m.retryImages || []));
        actions.appendChild(retryBtn);

        const appBtn = document.createElement('button');
        appBtn.type = 'button';
        appBtn.className = 'btn-chip';
        appBtn.textContent = '📱 Mở app Gemini trên máy';
        appBtn.addEventListener('click', () => {
          if (window.AndroidBridge?.openGeminiApp) {
            window.AndroidBridge.openGeminiApp(m.retryPrompt || '');
          } else {
            try { navigator.clipboard?.writeText(m.retryPrompt || ''); } catch (_e) {}
            window.open('https://gemini.google.com/app', '_blank', 'noopener');
          }
        });
        actions.appendChild(appBtn);
        div.appendChild(actions);
      }
    }

    if (Array.isArray(m.suggestedReminders) && m.suggestedReminders.length > 0) {
      for (const rem of m.suggestedReminders) {
        const card = document.createElement('div');
        card.className = 'gm-add-rem-card';
        const [y, mo, d] = (rem.date || '').split('-');
        const info = document.createElement('div');
        info.className = 'gm-add-rem-info';
        info.innerHTML = `<strong>⏰ ${esc(rem.title)}</strong><br/>📅 ${d}/${mo}/${y} lúc ${esc(rem.time)}${rem.repeat && rem.repeat !== 'none' ? ` • ${esc(REPEAT_LABELS[rem.repeat] || rem.repeat)}` : ''}`;

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'gm-add-rem-btn';
        btn.textContent = rem._added ? '✓ Đã thêm' : '+ Thêm lịch';
        btn.disabled = Boolean(rem._added);
        btn.addEventListener('click', () => {
          state.timedReminders.push({
            id: `rem-ai-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
            title: rem.title,
            date: rem.date,
            time: rem.time || '08:00',
            repeat: rem.repeat || 'none',
            sound: true,
            sendTelegram: true,
            note: rem.note || '',
            done: false,
            createdAt: Date.now()
          });
          rem._added = true;
          btn.disabled = true;
          btn.textContent = '✓ Đã thêm';
          persistAndSync('timedReminders', state.timedReminders);
          renderRemindersList();
          renderAllCalendarViews();
          renderHolidays();
        });

        card.appendChild(info);
        card.appendChild(btn);
        div.appendChild(card);
      }
    }
    box.appendChild(div);
  }
  box.scrollTop = box.scrollHeight;
}

let maxKnownViewportH = Math.max(window.innerHeight || 0, window.visualViewport?.height || 0);
let nativeAndroidImeOpen = false;

window.__onAndroidImeChange = (isOpen, _imePx) => {
  nativeAndroidImeOpen = Boolean(isOpen);
  syncMobileGeminiViewport();
};

function syncMobileGeminiViewport() {
  const vv = window.visualViewport;
  const curH = vv ? vv.height : window.innerHeight;
  if (curH > maxKnownViewportH) maxKnownViewportH = curH;

  const activeEl = document.activeElement;
  const isTextFocused = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA') && !['checkbox', 'radio', 'button', 'submit', 'file'].includes((activeEl.type || '').toLowerCase());
  const heightShrunk = maxKnownViewportH - curH > 120;
  const inApk = isRunningInAndroidApk();
  const kbdOpen = inApk
    ? Boolean(nativeAndroidImeOpen || heightShrunk)
    : Boolean(heightShrunk || (isTextFocused && state.activeTab === 'ai' && (maxKnownViewportH - curH > 60)));

  document.body.classList.toggle('kbd-open', kbdOpen);
  const shell = document.querySelector('.app-shell');
  if (shell) {
    // Inside Android APK, MainActivity's FrameLayout physically resizes the WebView to sit cleanly above the keyboard!
    // Never fight native resize with position:fixed; only use visualViewport fallback in mobile browsers/PWA.
    if (!inApk && kbdOpen && vv) {
      shell.style.height = `${Math.round(vv.height)}px`;
      shell.style.top = `${Math.max(0, Math.round(vv.offsetTop))}px`;
      shell.style.position = 'fixed';
      shell.style.left = '0';
      shell.style.right = '0';
    } else {
      shell.style.height = '';
      shell.style.top = '';
      shell.style.position = '';
      shell.style.left = '';
      shell.style.right = '';
    }
  }

  const searchModal = $('global-search-modal');
  if (searchModal && !searchModal.classList.contains('hidden') && vv && !inApk) {
    searchModal.style.top = `${Math.max(0, vv.offsetTop)}px`;
    searchModal.style.height = `${vv.height}px`;
    searchModal.style.bottom = 'auto';
  }
  const box = $('gm-chat-messages');
  if (box && state.activeTab === 'ai') {
    box.scrollTop = box.scrollHeight;
    if (kbdOpen) {
      setTimeout(() => { box.scrollTop = box.scrollHeight; }, 70);
    }
  } else if (kbdOpen && isTextFocused && activeEl && typeof activeEl.scrollIntoView === 'function') {
    setTimeout(() => {
      try { activeEl.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (_e) {}
    }, 80);
  }
}

document.addEventListener('focusin', () => setTimeout(syncMobileGeminiViewport, 80));
document.addEventListener('focusout', () => setTimeout(syncMobileGeminiViewport, 120));
window.addEventListener('resize', syncMobileGeminiViewport);

function openMobileGeminiChat() {
  switchTab('ai');
}

let mobilePendingChatImages = [];

function renderMobileChatImgPreviews() {
  const bar = $('gm-img-preview-bar');
  if (!bar) return;
  bar.innerHTML = '';
  if (mobilePendingChatImages.length === 0) {
    bar.classList.add('hidden');
    return;
  }
  bar.classList.remove('hidden');
  mobilePendingChatImages.forEach((im, idx) => {
    const wrap = document.createElement('div');
    wrap.className = 'gm-img-thumb-wrap';
    wrap.innerHTML = `<img src="${im.dataUrl}" alt="Ảnh ${idx + 1}" /><button type="button" class="gm-img-thumb-del" title="Gỡ ảnh">✕</button>`;
    wrap.querySelector('.gm-img-thumb-del')?.addEventListener('click', () => {
      mobilePendingChatImages.splice(idx, 1);
      renderMobileChatImgPreviews();
    });
    bar.appendChild(wrap);
  });
}

function attachFilesToMobileChat(fileList) {
  const files = Array.from(fileList || []).filter((f) => f && f.type && f.type.startsWith('image/'));
  if (files.length === 0) return;
  for (const f of files) {
    if (mobilePendingChatImages.length >= 4) break;
    const img = new Image();
    const u = URL.createObjectURL(f);
    img.onload = () => {
      try {
        const { base64, dataUrl } = compressImageSourceToBase64(img, 1024, 0.82, false);
        if (mobilePendingChatImages.length < 4) {
          mobilePendingChatImages.push({ base64, mimeType: 'image/jpeg', dataUrl });
          renderMobileChatImgPreviews();
        }
      } finally {
        URL.revokeObjectURL(u);
      }
    };
    img.onerror = () => URL.revokeObjectURL(u);
    img.src = u;
  }
}

async function sendMobileGeminiChatMessage(rawText, explicitImages = null) {
  const text = String(rawText || '').trim();
  const attachedImages = Array.isArray(explicitImages)
    ? explicitImages.slice(0, 4)
    : mobilePendingChatImages.slice(0, 4);
  if ((!text && attachedImages.length === 0) || mobileGeminiBusy) return;
  if (!isGeminiConfigured(state.geminiSettings)) {
    renderMobileGeminiSettings();
    mobileGeminiChatHistory.push({
      role: 'assistant',
      isError: true,
      text: '⚠️ Bạn chưa nhập Gemini API Key miễn phí. Bấm "⚙️ Nhập Key" ở trên để kích hoạt nhé!'
    });
    renderMobileGeminiMessages();
    return;
  }

  if (!Array.isArray(explicitImages)) {
    mobilePendingChatImages = [];
    renderMobileChatImgPreviews();
  }

  const displayMsg = text || `📷 Đã gửi ${attachedImages.length} hình ảnh — hãy phân tích giúp tôi`;
  const prevHistory = mobileGeminiChatHistory.filter((m) => !m.isError && !m.failed);
  const userTurn = { role: 'user', text: displayMsg, images: attachedImages };
  mobileGeminiChatHistory.push(userTurn);
  const thinking = { role: 'assistant', text: attachedImages.length > 0 ? '✨ Gemini Vision đang xem hình ảnh...' : '✨ Gemini đang suy nghĩ...' };
  mobileGeminiChatHistory.push(thinking);
  renderMobileGeminiMessages();

  mobileGeminiBusy = true;
  if ($('btn-gm-chat-send')) $('btn-gm-chat-send').disabled = true;

  try {
    const res = await chatWithLunarAssistant(state.geminiSettings, prevHistory, text, state, new Date(), (partial) => {
      if (partial) {
        thinking.text = partial;
        const box = $('gm-chat-messages');
        const lastEl = box?.lastElementChild;
        if (lastEl && lastEl.classList.contains('assistant')) {
          lastEl.innerHTML = formatMobileGeminiMd(partial);
          box.scrollTop = box.scrollHeight;
        }
      }
    }, attachedImages);
    thinking.text = res.text;
    thinking.suggestedReminders = res.suggestedReminders || [];
    const meta = getLastGeminiMeta();
    const subEl = $('gm-chat-sub');
    if (subEl && meta?.model) {
      subEl.textContent = `⚡ ${meta.model} • ${(meta.ms / 1000).toFixed(1)}s`;
    }
  } catch (err) {
    userTurn.failed = true;
    thinking.isError = true;
    thinking.retryPrompt = text;
    thinking.retryImages = attachedImages;
    thinking.text = `⚠️ ${err?.message || 'Không thể kết nối Gemini AI.'}`;
  } finally {
    mobileGeminiBusy = false;
    if ($('btn-gm-chat-send')) $('btn-gm-chat-send').disabled = false;
    renderMobileGeminiMessages();
  }
}

function bindMobileGeminiAiEvents() {
  $('btn-gm-open-chat')?.addEventListener('click', openMobileGeminiChat);
  $('btn-gm-goto-settings')?.addEventListener('click', openMobileGeminiSettingsFocus);
  $('btn-gm-chat-clear')?.addEventListener('click', () => {
    mobileGeminiChatHistory = [];
    mobilePendingChatImages = [];
    renderMobileChatImgPreviews();
    renderMobileGeminiMessages();
  });
  $('btn-gm-chat-img')?.addEventListener('click', () => {
    $('gm-chat-img-file')?.click();
  });
  $('gm-chat-img-file')?.addEventListener('change', (e) => {
    attachFilesToMobileChat(e.target.files);
    e.target.value = '';
  });
  $('gm-chat-input')?.addEventListener('paste', (e) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    const imgFiles = [];
    for (const it of items) {
      if (it.type && it.type.startsWith('image/')) {
        const f = it.getAsFile();
        if (f) imgFiles.push(f);
      }
    }
    if (imgFiles.length > 0) {
      e.preventDefault();
      attachFilesToMobileChat(imgFiles);
    }
  });
  $('gm-quick-chips')?.addEventListener('click', (e) => {
    const chip = e.target.closest('.gm-chip');
    if (!chip) return;
    sendMobileGeminiChatMessage(chip.dataset.prompt || chip.textContent);
  });
  const gmInputEl = $('gm-chat-input');
  if (gmInputEl) {
    gmInputEl.addEventListener('input', () => autoResizeMobileGmInput(gmInputEl));
    gmInputEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        $('gm-chat-form')?.requestSubmit();
      }
    });
  }
  $('gm-chat-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const inp = $('gm-chat-input');
    if (!inp) return;
    const msg = inp.value.trim();
    if (!msg && mobilePendingChatImages.length === 0) return;
    inp.value = '';
    autoResizeMobileGmInput(inp);
    sendMobileGeminiChatMessage(msg);
  });

  // Keep Gemini Chat modal pinned cleanly between status bar & soft keyboard on OPPO Find X9
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', syncMobileGeminiViewport);
    window.visualViewport.addEventListener('scroll', syncMobileGeminiViewport);
  }

  // Voice input (🎙️) directly inside Gemini AI Chat (Native Android SpeechRecognizer + Web Speech fallback)
  let gmWebRec = null;
  $('btn-gm-chat-voice')?.addEventListener('click', () => {
    const vBtn = $('btn-gm-chat-voice');
    const gmInp = $('gm-chat-input');
    if (!vBtn || !gmInp) return;

    mobileVoiceTarget = 'gm-chat';
    if (isRunningInAndroidApk() && typeof window.AndroidBridge.startVoiceInput === 'function') {
      const wasListening = vBtn.classList.contains('listening');
      setMobileGmVoiceUi(!wasListening);
      window.AndroidBridge.startVoiceInput();
      return;
    }

    if (gmWebRec) {
      try { gmWebRec.stop(); } catch (_e) {}
      return;
    }
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      mobileGeminiChatHistory.push({
        role: 'assistant',
        isError: true,
        text: '⚠️ Thiết bị chưa hỗ trợ Micro trực tiếp trong trình duyệt. Hãy dùng ứng dụng APK Android.'
      });
      renderMobileGeminiMessages();
      return;
    }
    const rec = new SpeechRec();
    gmWebRec = rec;
    rec.lang = 'vi-VN';
    rec.interimResults = true;
    rec.continuous = true;
    let spoken = '';
    let gmSilTimer = null;

    rec.onstart = () => setMobileGmVoiceUi(true);
    rec.onresult = (ev) => {
      let t = '';
      for (let i = 0; i < ev.results.length; i++) t += ev.results[i][0].transcript;
      spoken = t.trim();
      if (spoken) {
        gmInp.value = spoken;
        autoResizeMobileGmInput(gmInp);
        if (gmSilTimer) clearTimeout(gmSilTimer);
        gmSilTimer = setTimeout(() => { try { rec.stop(); } catch (_e) {} }, 3500);
      }
    };
    rec.onerror = () => {
      if (gmSilTimer) clearTimeout(gmSilTimer);
      gmWebRec = null;
      setMobileGmVoiceUi(false);
    };
    rec.onend = () => {
      if (gmSilTimer) clearTimeout(gmSilTimer);
      gmWebRec = null;
      setMobileGmVoiceUi(false);
      if (spoken && !mobileGeminiBusy) {
        const toSend = spoken;
        gmInp.value = '';
        autoResizeMobileGmInput(gmInp);
        sendMobileGeminiChatMessage(toSend);
      }
    };
    try { rec.start(); } catch (_e) { gmWebRec = null; setMobileGmVoiceUi(false); }
  });

  // Settings card
  const setGmStatus = (msg, isErr = false) => {
    const el = $('gm-status');
    if (!el) return;
    el.className = isErr ? 'status-msg err' : 'status-msg';
    el.textContent = msg;
  };
  const syncGmSettings = (autoEnable = false) => {
    const keyVal = ($('gm-api-key')?.value || '').trim();
    const proxyVal = ($('gm-proxy-url')?.value || '').trim();
    const proxyTok = ($('gm-proxy-token')?.value || '').trim();
    if (autoEnable && (keyVal.length > 10 || proxyVal.length > 10) && $('gm-enabled') && !$('gm-enabled').checked) {
      $('gm-enabled').checked = true;
    }
    state.geminiSettings = {
      enabled: Boolean($('gm-enabled')?.checked),
      apiKey: keyVal,
      proxyUrl: proxyVal,
      proxyToken: proxyTok,
      model: $('gm-model')?.value || DEFAULT_GEMINI_SETTINGS.model
    };
    persistAndSync('geminiSettings', state.geminiSettings);
    renderMobileGeminiSettings();
    setGmStatus(proxyVal ? '✓ Đã lưu Cầu nối Proxy AI & tự đồng bộ' : '✓ Đã lưu cấu hình Gemini AI & tự đồng bộ');
  };
  $('gm-enabled')?.addEventListener('change', () => syncGmSettings(false));
  $('gm-api-key')?.addEventListener('change', () => syncGmSettings(true));
  $('gm-proxy-url')?.addEventListener('change', () => syncGmSettings(true));
  $('gm-proxy-token')?.addEventListener('change', () => syncGmSettings(false));
  $('gm-model')?.addEventListener('change', () => syncGmSettings(false));
  $('btn-gm-toggle-key')?.addEventListener('click', () => {
    const inp = $('gm-api-key');
    if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
  });
  const mergeMobileLiveModels = (liveModels) => {
    const sel = $('gm-model');
    if (!sel || !Array.isArray(liveModels) || liveModels.length === 0) return;
    const currentVal = sel.value;
    sel.querySelector('optgroup[data-live-group="1"]')?.remove();
    const existing = new Set(Array.from(sel.options).map((o) => o.value));
    const extras = liveModels.filter((m) => !existing.has(m));
    if (extras.length > 0) {
      const grp = document.createElement('optgroup');
      grp.label = '📡 Model khác khả dụng từ API Key';
      grp.dataset.liveGroup = '1';
      for (const m of extras) {
        const opt = document.createElement('option');
        opt.value = m;
        opt.textContent = `📡 ${m}`;
        grp.appendChild(opt);
      }
      sel.appendChild(grp);
    }
    if (currentVal && Array.from(sel.options).some((o) => o.value === currentVal)) {
      sel.value = currentVal;
    }
  };
  $('btn-gm-refresh-models')?.addEventListener('click', async () => {
    syncGmSettings(true);
    const btn = $('btn-gm-refresh-models');
    if (btn) btn.disabled = true;
    setGmStatus('⏳ Đang quét model Gemini mới nhất từ API Key...');
    const res = await listAvailableGeminiModels(state.geminiSettings);
    if (btn) btn.disabled = false;
    if (res.ok) {
      mergeMobileLiveModels(res.models);
      setGmStatus(`✅ ${res.message}`);
    } else {
      setGmStatus(`⚠️ ${res.message}`, true);
    }
  });
  $('btn-gm-test')?.addEventListener('click', async () => {
    syncGmSettings(true);
    const btn = $('btn-gm-test');
    if (btn) btn.disabled = true;
    setGmStatus('⏳ Đang kiểm tra kết nối Gemini...');
    const res = await testGeminiConnection(state.geminiSettings);
    if (btn) btn.disabled = false;
    if (res.ok && Array.isArray(res.liveModels) && res.liveModels.length > 0) {
      mergeMobileLiveModels(res.liveModels);
    }
    setGmStatus(res.ok ? `✅ ${res.message}` : `⚠️ ${res.message}`, !res.ok);
  });

  // Feature 2A: Single Reminder ✨ AI parse button
  $('btn-rem-ai-parse')?.addEventListener('click', async () => {
    const raw = ($('rem-title')?.value || '').trim();
    const prev = $('rem-nlp-preview');
    if (!raw) {
      if (prev) {
        prev.classList.remove('hidden');
        prev.textContent = '✨ Hãy nhập hoặc nói nội dung nhắc nhở (kể cả ngày Âm lịch hoặc tin nhắn Zalo) rồi bấm ✨ AI!';
      }
      $('rem-title')?.focus();
      return;
    }
    if (!isGeminiConfigured(state.geminiSettings)) {
      if (prev) {
        prev.classList.remove('hidden');
        prev.innerHTML = '🔑 Chưa cài Gemini API Key. <button type="button" class="btn-ai-inline" id="btn-m-inline-gm-cfg" style="padding:3px 8px;font-size:11.5px;">Nhập Key</button>';
        $('btn-m-inline-gm-cfg')?.addEventListener('click', openMobileGeminiSettingsFocus);
      }
      return;
    }
    const btn = $('btn-rem-ai-parse');
    if (btn) btn.disabled = true;
    if (prev) {
      prev.classList.remove('hidden');
      prev.textContent = '✨ Gemini AI đang phân tích câu nhắc nhở của bạn...';
    }
    try {
      const list = await parseRemindersWithGemini(state.geminiSettings, raw, new Date());
      if (list.length === 0) {
        if (prev) prev.textContent = '⚠️ Gemini không tìm thấy lịch hẹn rõ ràng trong câu này.';
      } else {
        const first = list[0];
        if ($('rem-title')) $('rem-title').value = first.title;
        if ($('rem-date')) $('rem-date').value = first.date;
        if ($('rem-date-text')) $('rem-date-text').value = isoDateToVN(first.date);
        if ($('rem-time')) $('rem-time').value = first.time;
        if ($('rem-time-text')) $('rem-time-text').value = first.time;
        if ($('rem-repeat')) $('rem-repeat').value = first.repeat || 'none';
        if ($('rem-note') && first.note) $('rem-note').value = first.note;
        if ($('rem-prev-eve')) $('rem-prev-eve').checked = Boolean(first.prevEve);
        if ($('rem-prev-eve-time') && first.prevEveTime) $('rem-prev-eve-time').value = first.prevEveTime;
        if ($('rem-prev-eve-time-text') && first.prevEveTime) $('rem-prev-eve-time-text').value = first.prevEveTime;
        if (prev) {
          prev.textContent = `✨ Gemini AI đã tách: "${first.title}" • ${isoDateToVN(first.date)} lúc ${first.time}${first.repeat !== 'none' ? ` (${REPEAT_LABELS[first.repeat] || first.repeat})` : ''}${first.prevEve ? ` • Nhắc từ hôm trước ${first.prevEveTime}` : ''}`;
        }
      }
    } catch (err) {
      if (prev) prev.textContent = `⚠️ ${err?.message || 'Lỗi phân tích Gemini AI'}`;
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  // Feature 2B: Bulk Paste 🤖 AI parse button
  $('btn-bulk-ai-parse')?.addEventListener('click', async () => {
    const raw = ($('bulk-paste-input')?.value || '').trim();
    if (!raw) {
      setMobileBulkStatus('Hãy dán đoạn tin nhắn Zalo / Email hoặc nhiều câu nhắc nhở vào ô trên trước.', true);
      return;
    }
    if (!isGeminiConfigured(state.geminiSettings)) {
      setMobileBulkStatus('🔑 Bạn chưa nhập Gemini API Key. Vào ⚙️ Cài đặt → ✨ Trợ lý Gemini AI để nhập Key miễn phí.', true);
      return;
    }
    const btn = $('btn-bulk-ai-parse');
    if (btn) btn.disabled = true;
    setMobileBulkStatus('🤖 Gemini AI đang đọc và tách toàn bộ lịch hẹn...');
    try {
      const list = await parseRemindersWithGemini(state.geminiSettings, raw, new Date());
      if (list.length === 0) {
        setMobileBulkStatus('Không tìm thấy lịch hẹn nào trong đoạn văn bản vừa dán.', true);
      } else {
        list.forEach((item) => {
          const [, , dd] = (item.date || '').split('-').map(Number);
          mBulkRemRows.push(createMobileBulkRow({
            title: item.title,
            repeat: item.repeat || 'none',
            dayOfMonth: dd || new Date().getDate(),
            date: item.date,
            time: item.time || '09:00',
            note: item.note || '',
            sendTelegram: true
          }));
        });
        renderMobileBulkRows();
        setMobileBulkStatus(`🤖 Gemini AI đã tách thành công ${list.length} lịch hẹn! Kiểm tra rồi bấm "Lưu tất cả".`);
      }
    } catch (err) {
      setMobileBulkStatus(`⚠️ ${err?.message || 'Lỗi Gemini AI'}`, true);
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  // Feature 3: Custom Prayer composer with Gemini AI
  $('btn-prayer-ai-gen')?.addEventListener('click', async () => {
    const promptInp = $('prayer-ai-prompt');
    const statusEl = $('prayer-ai-status');
    const promptText = (promptInp?.value || '').trim();
    if (!promptText) {
      if (statusEl) {
        statusEl.className = 'status-msg err';
        statusEl.textContent = 'Hãy nhập dịp cúng cần soạn (VD: Cúng sửa bếp, cầu thi cử, cúng khai trương quán...).';
      }
      promptInp?.focus();
      return;
    }
    if (!isGeminiConfigured(state.geminiSettings)) {
      if (statusEl) {
        statusEl.className = 'status-msg err';
        statusEl.innerHTML = '🔑 Bạn chưa nhập Gemini API Key. <button type="button" class="btn-ai-inline" id="btn-m-prayer-gm-cfg" style="padding:3px 8px;font-size:11.5px;">Nhập Key</button>';
        $('btn-m-prayer-gm-cfg')?.addEventListener('click', openMobileGeminiSettingsFocus);
      }
      return;
    }
    const btn = $('btn-prayer-ai-gen');
    if (btn) btn.disabled = true;
    if (statusEl) {
      statusEl.className = 'status-msg';
      statusEl.textContent = '✨ Gemini AI đang soạn bài văn khấn chuẩn phong tục theo ngày đang chọn...';
    }
    try {
      const solar = state.selectedDate;
      const lunar = convertSolar2Lunar(solar.day, solar.month, solar.year, TIMEZONE_VN);
      const applyMobPrayer = (p) => {
        if ($('p-view-title')) $('p-view-title').textContent = `✨ ${p.title}`;
        if ($('p-view-occasion')) $('p-view-occasion').textContent = `${p.occasion} • Soạn bởi Gemini AI`;
        if ($('p-view-offerings')) {
          $('p-view-offerings').innerHTML = `<strong>🍎 Lễ vật gợi ý:</strong> ${esc(p.offerings)}`;
        }
        if ($('p-view-text')) {
          $('p-view-text').textContent = p.content || '✨ Đang viết lời khấn...';
          $('p-view-text').style.fontSize = `${state.prayerPrefs.fontSize || 15}px`;
        }
      };
      $('prayer-reader-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      const prayer = await generateCustomPrayerWithGemini(
        state.geminiSettings,
        promptText,
        solar,
        lunar,
        state.prayerPrefs,
        (partial) => applyMobPrayer(partial)
      );
      applyMobPrayer(prayer);
      if (statusEl) {
        statusEl.className = 'status-msg';
        statusEl.textContent = '✅ Đã soạn xong bài văn khấn! Bấm 🔊 Đọc AI, Sao chép hoặc gửi Zalo/Telegram ngay.';
      }
    } catch (err) {
      if (statusEl) {
        statusEl.className = 'status-msg err';
        statusEl.textContent = `⚠️ ${err?.message || 'Lỗi tạo văn khấn bằng Gemini AI'}`;
      }
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  // Feature 4: Read Văn khấn aloud using Gemini AI Native TTS (with instant prefetch, caching & Android native TTS fallback!)
  const mTtsBar = $('prayer-tts-bar');
  const mTtsVoiceSel = $('prayer-tts-voice');
  const mTtsRateSel = $('prayer-tts-rate');
  const mTtsPlayBtn = $('btn-prayer-tts-play');
  const mTtsStopBtn = $('btn-prayer-tts-stop');
  const mTtsStatusEl = $('prayer-tts-status');
  const mTtsOpenBtn = $('btn-p-ai-read');

  const mTtsCache = new Map();
  let mTtsSessionId = 0;
  let mTtsAudio = null;
  let mTtsUsingNative = false;
  let mTtsState = 'idle';

  const setMobTtsStatus = (msg, isErr = false) => {
    if (!mTtsStatusEl) return;
    mTtsStatusEl.textContent = msg;
    mTtsStatusEl.style.color = isErr ? '#DC2626' : '#5B21B6';
  };

  const updateMobTtsBtns = () => {
    if (!mTtsPlayBtn) return;
    if (mTtsState === 'loading') {
      mTtsPlayBtn.textContent = '⏳ Đang tạo giọng AI...';
      mTtsPlayBtn.disabled = true;
    } else if (mTtsState === 'playing') {
      mTtsPlayBtn.textContent = '⏸ Tạm dừng';
      mTtsPlayBtn.disabled = false;
    } else if (mTtsState === 'paused') {
      mTtsPlayBtn.textContent = '▶ Tiếp tục';
      mTtsPlayBtn.disabled = false;
    } else {
      mTtsPlayBtn.textContent = '▶ Đọc bài khấn';
      mTtsPlayBtn.disabled = false;
    }
  };

  const stopMobPrayerTts = (clearStatus = false) => {
    mTtsSessionId++;
    if (mTtsAudio) {
      try {
        mTtsAudio.pause();
        mTtsAudio.src = '';
      } catch (_e) {}
      mTtsAudio = null;
    }
    if (mTtsUsingNative) {
      if (isRunningInAndroidApk() && typeof window.AndroidBridge.stopSpeaking === 'function') {
        try { window.AndroidBridge.stopSpeaking(); } catch (_e) {}
      } else if ('speechSynthesis' in window) {
        try { window.speechSynthesis.cancel(); } catch (_e) {}
      }
    }
    mTtsUsingNative = false;
    mTtsState = 'idle';
    updateMobTtsBtns();
    if (clearStatus) setMobTtsStatus('');
  };

  const playMobSystemFallback = (fullText, reasonMsg) => {
    const spokenText = expandPrayerForSpeech(fullText) || fullText;
    const rate = Number(mTtsRateSel?.value || 0.9);
    if (isRunningInAndroidApk() && typeof window.AndroidBridge.speakText === 'function') {
      mTtsUsingNative = true;
      mTtsState = 'playing';
      updateMobTtsBtns();
      setMobTtsStatus(`🔊 ${reasonMsg} — đang đọc bằng giọng tiếng Việt Android (bấm ⏹ Dừng để tắt).`);
      window.AndroidBridge.speakText(spokenText, rate);
      return;
    }
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance(spokenText);
        utt.lang = 'vi-VN';
        utt.rate = rate;
        mTtsUsingNative = true;
        mTtsState = 'playing';
        updateMobTtsBtns();
        setMobTtsStatus(`🔊 ${reasonMsg} — đang đọc bằng giọng tiếng Việt trên máy...`);
        utt.onend = () => {
          mTtsUsingNative = false;
          mTtsState = 'idle';
          updateMobTtsBtns();
          setMobTtsStatus('✅ Đã đọc xong bài văn khấn.');
        };
        window.speechSynthesis.speak(utt);
        return;
      } catch (_e) {}
    }
    mTtsState = 'idle';
    updateMobTtsBtns();
    setMobTtsStatus(`⚠️ ${reasonMsg}.`, true);
  };

  const startMobPrayerTts = async () => {
    const rawText = ($('p-view-text')?.textContent || '').trim();
    if (!rawText) {
      setMobTtsStatus('Chưa có nội dung bài văn khấn để đọc.', true);
      return;
    }
    stopMobPrayerTts(false);
    const mySession = mTtsSessionId;
    const mode = mTtsVoiceSel?.value || 'google-vi';

    if (mode === 'system-vi') {
      playMobSystemFallback(rawText, 'Giọng ngoại tuyến');
      return;
    }

    // Mode 1 (DEFAULT): Instant (<0.5s), 100% authentic Northern Vietnamese voice via Google TTS!
    if (mode === 'google-vi') {
      const sentences = splitPrayerIntoFastVnSentences(rawText, 170);
      if (sentences.length === 0) return;
      mTtsState = 'loading';
      updateMobTtsBtns();

      const getSentUrl = async (idx) => {
        const key = `gvi::${sentences[idx]}`;
        if (mTtsCache.has(key)) return mTtsCache.get(key);
        const u = await synthesizeFastVnVoiceChunk(sentences[idx]);
        mTtsCache.set(key, u);
        return u;
      };

      try {
        const prefetched = new Map();
        const ensurePrefetch = (idx) => {
          if (idx < sentences.length && !prefetched.has(idx)) {
            prefetched.set(idx, getSentUrl(idx));
          }
        };
        ensurePrefetch(0);
        ensurePrefetch(1);

        for (let i = 0; i < sentences.length; i++) {
          if (mySession !== mTtsSessionId) return;
          setMobTtsStatus(`⚡ Đang đọc câu ${i + 1}/${sentences.length} (Giọng Việt Chuẩn)...`);
          const url = await prefetched.get(i);
          if (mySession !== mTtsSessionId) return;
          ensurePrefetch(i + 2);

          const audio = new Audio(url);
          audio.playbackRate = Number(mTtsRateSel?.value || 1);
          mTtsAudio = audio;
          mTtsState = 'playing';
          updateMobTtsBtns();

          await new Promise((resolve, reject) => {
            audio.onended = resolve;
            audio.onerror = () => reject(new Error('Không phát được âm thanh'));
            audio.play().catch(reject);
          });
        }
        if (mySession === mTtsSessionId) {
          mTtsAudio = null;
          mTtsState = 'idle';
          updateMobTtsBtns();
          setMobTtsStatus('✅ Đã đọc xong toàn bộ bài văn khấn!');
        }
      } catch (err) {
        if (mySession !== mTtsSessionId) return;
        playMobSystemFallback(rawText, 'Đang chuyển sang giọng Việt Android');
      }
      return;
    }

    // Mode 2: Optional Gemini AI Native TTS voice (Kore / Charon)
    const voiceName = mode.replace(/^gemini:/, '') || 'Kore';
    const chunks = splitPrayerIntoSpeechChunks(rawText, 300);
    if (chunks.length === 0) return;

    if (!isGeminiConfigured(state.geminiSettings)) {
      if (mTtsVoiceSel) mTtsVoiceSel.value = 'google-vi';
      startMobPrayerTts();
      return;
    }

    mTtsState = 'loading';
    updateMobTtsBtns();

    const getChunkAudioUrl = async (idx) => {
      const key = `${voiceName}::${chunks[idx]}`;
      if (mTtsCache.has(key)) return mTtsCache.get(key);
      const res = await synthesizePrayerChunkWithGemini(state.geminiSettings, chunks[idx], voiceName);
      mTtsCache.set(key, res.url);
      return res.url;
    };

    try {
      let nextPromise = getChunkAudioUrl(0);
      for (let i = 0; i < chunks.length; i++) {
        if (mySession !== mTtsSessionId) return;
        setMobTtsStatus(`⏳ Gemini AI đang tạo đoạn ${i + 1}/${chunks.length} (mất ~5–10s)...`);
        const url = await nextPromise;
        if (mySession !== mTtsSessionId) return;

        if (i + 1 < chunks.length) {
          nextPromise = getChunkAudioUrl(i + 1).catch((err) => ({ __err: err }));
        }

        const audio = new Audio(url);
        audio.playbackRate = Number(mTtsRateSel?.value || 1);
        mTtsAudio = audio;
        mTtsState = 'playing';
        updateMobTtsBtns();
        setMobTtsStatus(`🔊 Đang đọc bằng giọng Gemini AI (${voiceName} • Đoạn ${i + 1}/${chunks.length})`);

        await new Promise((resolve, reject) => {
          audio.onended = resolve;
          audio.onerror = () => reject(new Error('Không phát được tệp âm thanh WAV'));
          audio.play().catch(reject);
        });

        if (i + 1 < chunks.length) {
          const peek = await nextPromise;
          if (peek && peek.__err) throw peek.__err;
          nextPromise = Promise.resolve(peek);
        }
      }
      if (mySession === mTtsSessionId) {
        mTtsAudio = null;
        mTtsState = 'idle';
        updateMobTtsBtns();
        setMobTtsStatus('✅ Đã đọc xong bài văn khấn bằng giọng Gemini AI!');
      }
    } catch (err) {
      if (mySession !== mTtsSessionId) return;
      if (mTtsVoiceSel) mTtsVoiceSel.value = 'google-vi';
      setMobTtsStatus('⚠️ Gemini TTS đang bận — tự chuyển sang ⚡ Giọng Việt Chuẩn...');
      startMobPrayerTts();
    }
  };

  mTtsOpenBtn?.addEventListener('click', () => {
    if (!mTtsBar) return;
    const wasHidden = mTtsBar.classList.contains('hidden');
    mTtsBar.classList.remove('hidden');
    if (wasHidden || mTtsState === 'idle') {
      startMobPrayerTts();
    }
  });

  mTtsPlayBtn?.addEventListener('click', () => {
    if (mTtsState === 'playing') {
      if (mTtsAudio) {
        mTtsAudio.pause();
        mTtsState = 'paused';
        updateMobTtsBtns();
        setMobTtsStatus('⏸ Đã tạm dừng đọc văn khấn.');
      } else {
        stopMobPrayerTts(true);
      }
    } else if (mTtsState === 'paused' && mTtsAudio) {
      mTtsAudio.play().catch(() => {});
      mTtsState = 'playing';
      updateMobTtsBtns();
      setMobTtsStatus(`🔊 Tiếp tục đọc bằng giọng Gemini AI (${mTtsVoiceSel?.value || 'Kore'})...`);
    } else {
      startMobPrayerTts();
    }
  });

  mTtsStopBtn?.addEventListener('click', () => stopMobPrayerTts(true));
  mTtsRateSel?.addEventListener('change', () => {
    if (mTtsAudio) mTtsAudio.playbackRate = Number(mTtsRateSel.value || 1);
  });
  mTtsVoiceSel?.addEventListener('change', () => {
    if (mTtsState === 'playing' || mTtsState === 'paused') startMobPrayerTts();
  });
  $('p-list')?.addEventListener('click', () => {
    if (mTtsState !== 'idle') stopMobPrayerTts(true);
  });
}

/* ==================== TAB GIẢI MÃ GIẤC MƠ (MOBILE v2.8.0) ==================== */
const MOB_DREAM_HIST_KEY = 'lich_am_dream_history_v1';
let mobDreamCat = 'all';
let mobDreamBusy = false;

function loadMobDreamHistory() {
  try {
    const arr = JSON.parse(localStorage.getItem(MOB_DREAM_HIST_KEY) || '[]');
    return Array.isArray(arr) ? arr : [];
  } catch (_e) {
    return [];
  }
}

function saveMobDreamHistory(list) {
  try {
    localStorage.setItem(MOB_DREAM_HIST_KEY, JSON.stringify((list || []).slice(0, 10)));
  } catch (_e) {}
}

function bindMobileDreamTabEvents() {
  const dreamInp = $('dream-input');
  const aiBtn = $('btn-dream-ai');
  const voiceBtn = $('btn-dream-voice');
  const clearBtn = $('btn-dream-clear');
  const quickBox = $('dream-quick-chips');
  const statusEl = $('dream-ai-status');
  const resCard = $('dream-ai-result-card');
  const resTitle = $('dream-result-title');
  const resBody = $('dream-ai-result-body');
  const searchInp = $('dream-search');
  const catPills = $('dream-cat-pills');
  const catalogList = $('dream-catalog-list');
  const histCard = $('dream-history-card');
  const histList = $('dream-history-list');

  if (!dreamInp || !catalogList) return;

  let lastDreamPlain = '';

  const showDreamResult = (title, mdText) => {
    lastDreamPlain = `🌙 ${title}\n\n${mdText}`;
    if (resTitle) resTitle.textContent = title;
    if (resBody) resBody.innerHTML = formatMobileGeminiMd(mdText);
    resCard?.classList.remove('hidden');
  };

  const renderDreamHistory = () => {
    const hist = loadMobDreamHistory();
    if (!histCard || !histList) return;
    histCard.classList.toggle('hidden', hist.length === 0);
    histList.innerHTML = '';
    for (const item of hist) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'dream-hist-row';
      btn.innerHTML = `<div style="font-weight:700;font-size:13px;color:#4C1D95;">🌙 ${esc(item.query)}</div><div class="muted-xs" style="margin-top:2px;">${esc(item.dateStr || '')}</div>`;
      btn.addEventListener('click', () => {
        dreamInp.value = item.query;
        showDreamResult(`✨ Giải mã: ${item.query}`, item.answer);
        resCard?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
      histList.appendChild(btn);
    }
  };

  const runMobileDreamDecode = async (overrideText = '') => {
    const txt = String(overrideText || dreamInp.value || '').trim();
    if (!txt || mobDreamBusy) {
      if (!txt && statusEl) {
        statusEl.className = 'status-msg err';
        statusEl.textContent = 'Hãy kể lại giấc mơ của bạn (hoặc bấm 🎙️ nói) trước khi giải mã!';
      }
      return;
    }
    dreamInp.value = txt;

    if (!isGeminiConfigured(state.geminiSettings)) {
      if (statusEl) {
        statusEl.className = 'status-msg err';
        statusEl.innerHTML = '🔑 Chưa nhập Gemini API Key để giải mã AI (vẫn tra được Sổ Mơ ngoại tuyến bên dưới). <button type="button" class="btn-ai-inline" id="btn-m-dream-cfg" style="padding:3px 8px;font-size:11.5px;">Nhập Key</button>';
        $('btn-m-dream-cfg')?.addEventListener('click', openMobileGeminiSettingsFocus);
      }
      return;
    }

    mobDreamBusy = true;
    if (aiBtn) { aiBtn.disabled = true; aiBtn.textContent = '⏳ Gemini đang giải mộng...'; }
    if (statusEl) { statusEl.className = 'status-msg'; statusEl.textContent = '✨ Đang luận giải giấc mơ theo Sổ Mơ Việt Nam & tâm lý học...'; }
    showDreamResult(`✨ Giải mã: ${txt.slice(0, 60)}${txt.length > 60 ? '…' : ''}`, '✨ Gemini AI đang luận giải...');

    try {
      const fullAns = await decodeDreamWithGemini(state.geminiSettings, txt, state, new Date(), (partial) => {
        if (partial && resBody) {
          resBody.innerHTML = formatMobileGeminiMd(partial);
        }
      });
      showDreamResult(`✨ Giải mã: ${txt.slice(0, 60)}${txt.length > 60 ? '…' : ''}`, fullAns);
      if (statusEl) { statusEl.className = 'status-msg'; statusEl.textContent = '✅ Đã giải mã xong giấc mơ!'; }
      const now = new Date();
      const hist = loadMobDreamHistory().filter((h) => h.query !== txt);
      hist.unshift({ query: txt, answer: fullAns, dateStr: `${pad2(now.getDate())}/${pad2(now.getMonth() + 1)}/${now.getFullYear()} ${pad2(now.getHours())}:${pad2(now.getMinutes())}` });
      saveMobDreamHistory(hist);
      renderDreamHistory();
    } catch (err) {
      if (statusEl) { statusEl.className = 'status-msg err'; statusEl.textContent = `⚠️ ${err?.message || 'Lỗi kết nối Gemini AI'}`; }
    } finally {
      mobDreamBusy = false;
      if (aiBtn) { aiBtn.disabled = false; aiBtn.textContent = '✨ Giải mã ngay bằng AI'; }
    }
  };
  window.__runMobileDreamDecode = runMobileDreamDecode;

  if (quickBox) {
    quickBox.innerHTML = '';
    for (const q of DREAM_QUICK_PROMPTS) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'gm-chip';
      b.textContent = q.label;
      b.addEventListener('click', () => {
        dreamInp.value = q.query;
        if (isGeminiConfigured(state.geminiSettings)) {
          runMobileDreamDecode(q.query);
        } else if (searchInp) {
          searchInp.value = q.label.replace(/^[^\s]+\s+mơ\s+(?:thấy\s+)?/i, '');
          renderDreamCatalog();
        }
      });
      quickBox.appendChild(b);
    }
  }

  if (catPills) {
    catPills.innerHTML = '';
    for (const c of DREAM_CATEGORIES) {
      const p = document.createElement('button');
      p.type = 'button';
      p.className = `pill${c.id === mobDreamCat ? ' active' : ''}`;
      p.textContent = c.label;
      p.addEventListener('click', () => {
        mobDreamCat = c.id;
        catPills.querySelectorAll('.pill').forEach((x) => x.classList.toggle('active', x === p));
        renderDreamCatalog();
      });
      catPills.appendChild(p);
    }
  }

  const renderDreamCatalog = () => {
    const q = normalizeVnSearch(searchInp?.value || '');
    const tokens = q ? q.split(' ').filter(Boolean) : [];
    const items = DREAMS_CATALOG.filter((d) => {
      if (mobDreamCat !== 'all' && d.cat !== mobDreamCat) return false;
      if (tokens.length === 0) return true;
      const hay = normalizeVnSearch(`${d.title} ${d.keywords} ${d.meaning}`);
      return tokens.every((t) => hay.includes(t));
    });

    catalogList.innerHTML = '';
    if (items.length === 0) {
      catalogList.innerHTML = '<div class="empty-msg">Chưa có trong sổ mơ ngoại tuyến — hãy gõ giấc mơ vào ô trên rồi bấm <strong>✨ Giải mã ngay bằng AI</strong> nhé!</div>';
      return;
    }

    for (const d of items) {
      const card = document.createElement('div');
      card.className = `dream-item-card ${d.omen || ''}`;
      card.innerHTML = `
        <div class="dream-item-head">
          <div class="dream-item-title">${esc(d.title)}</div>
          <span class="dream-omen-badge ${d.omen || ''}">${esc(d.omenLabel)}</span>
        </div>
        <div class="dream-item-meaning">${esc(d.meaning)}</div>
        <div class="dream-item-meaning" style="color:#047857;font-size:12px;">💡 <strong>Lời khuyên:</strong> ${esc(d.advice)}</div>
        <div class="dream-item-foot">
          <span class="dream-lucky-pill">🍀 Số tham khảo: ${esc(d.luckyNums)}</span>
          <button type="button" class="btn-chip primary btn-ask-ai-dream">✨ Hỏi AI sâu hơn</button>
        </div>
      `;
      card.querySelector('.btn-ask-ai-dream')?.addEventListener('click', () => {
        dreamInp.value = d.title;
        dreamInp.scrollIntoView({ behavior: 'smooth', block: 'center' });
        runMobileDreamDecode(d.title);
      });
      catalogList.appendChild(card);
    }
  };

  aiBtn?.addEventListener('click', () => runMobileDreamDecode());
  clearBtn?.addEventListener('click', () => {
    dreamInp.value = '';
    if (statusEl) statusEl.textContent = '';
    dreamInp.focus();
  });
  searchInp?.addEventListener('input', renderDreamCatalog);
  $('btn-dream-clear-hist')?.addEventListener('click', () => {
    saveMobDreamHistory([]);
    renderDreamHistory();
  });

  $('btn-dream-copy')?.addEventListener('click', async () => {
    if (!lastDreamPlain) return;
    try { await navigator.clipboard.writeText(lastDreamPlain); } catch (_e) {}
    if (statusEl) { statusEl.className = 'status-msg'; statusEl.textContent = '✓ Đã sao chép luận giải giấc mơ!'; }
  });
  $('btn-dream-zalo')?.addEventListener('click', async (e) => {
    if (!lastDreamPlain) return;
    const b = e.currentTarget;
    const orig = b.textContent;
    b.textContent = '⏳...';
    await shareToZaloQuick(lastDreamPlain);
    b.textContent = '✓ Zalo';
    setTimeout(() => { b.textContent = orig; }, 1600);
  });
  $('btn-dream-tg')?.addEventListener('click', (e) => {
    if (!lastDreamPlain) return;
    sendTgHtml(esc(lastDreamPlain), e.currentTarget);
  });

  // Voice input for describing dreams (Native Android SpeechRecognizer + Web Speech fallback)
  let mobDreamRec = null;
  voiceBtn?.addEventListener('click', () => {
    mobileVoiceTarget = 'dream';
    if (isRunningInAndroidApk() && typeof window.AndroidBridge.startVoiceInput === 'function') {
      const wasOn = voiceBtn.classList.contains('listening');
      voiceBtn.classList.toggle('listening', !wasOn);
      voiceBtn.textContent = !wasOn ? '🔴' : '🎙️';
      window.AndroidBridge.startVoiceInput();
      return;
    }
    if (mobDreamRec) { try { mobDreamRec.stop(); } catch (_e) {} return; }
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) return;
    const rec = new SpeechRec();
    mobDreamRec = rec;
    rec.lang = 'vi-VN';
    rec.interimResults = true;
    rec.continuous = true;
    let spoken = '';
    let drSilTimer = null;
    rec.onstart = () => { voiceBtn.classList.add('listening'); voiceBtn.textContent = '🔴'; };
    rec.onresult = (ev) => {
      let t = '';
      for (let i = 0; i < ev.results.length; i++) t += ev.results[i][0].transcript;
      spoken = t.trim();
      if (spoken) {
        dreamInp.value = spoken;
        if (drSilTimer) clearTimeout(drSilTimer);
        drSilTimer = setTimeout(() => { try { rec.stop(); } catch (_e) {} }, 3500);
      }
    };
    rec.onerror = () => { if (drSilTimer) clearTimeout(drSilTimer); mobDreamRec = null; voiceBtn.classList.remove('listening'); voiceBtn.textContent = '🎙️'; };
    rec.onend = () => {
      if (drSilTimer) clearTimeout(drSilTimer);
      mobDreamRec = null;
      voiceBtn.classList.remove('listening');
      voiceBtn.textContent = '🎙️';
      if (spoken) runMobileDreamDecode(spoken);
    };
    try { rec.start(); } catch (_e) { mobDreamRec = null; }
  });

  renderDreamCatalog();
  renderDreamHistory();
}

/* ==================== QUÉT KHUÔN MẶT & XEM NỐT RUỒI (AI CAMERA + BẢN ĐỒ NHÂN TƯỚNG) ==================== */
function bindMobileMolesTabEvents() {
  const videoEl = $('mole-video');
  const photoWrap = $('mole-photo-wrap');
  const previewEl = $('mole-preview');
  const photoPinsEl = $('mole-photo-pins');
  const pinToolbar = $('mole-pin-toolbar');
  const pinCard = $('mole-pin-card');
  const togglePinsBtn = $('btn-mole-toggle-pins');
  const clearPinsBtn = $('btn-mole-clear-pins');
  const guideEl = $('mole-face-guide');
  const guideLbl = $('mole-cam-guide-lbl');
  const emptyEl = $('mole-empty-placeholder');
  const camFrontBtn = $('btn-mole-cam-front');
  const camBackBtn = $('btn-mole-cam-back');
  const switchCamBtn = $('btn-mole-switch-cam');
  const snapBtn = $('btn-mole-snap');
  const stopCamBtn = $('btn-mole-stop-cam');
  const fileInp = $('mole-file-input');
  const camFallbackInp = $('mole-cam-fallback');
  const analyzeBtn = $('btn-mole-analyze');
  const noteInp = $('mole-extra-note');
  const statusEl = $('mole-ai-status');
  const resCard = $('mole-ai-result-card');
  const resBody = $('mole-ai-result-body');
  const genderPills = $('mole-gender-pills');
  const svgSpots = $('mole-svg-spots');
  const detailBox = $('mole-spot-detail');
  const pillsBox = $('mole-spot-pills');
  if (!svgSpots || !detailBox) return;

  let moleGender = 'male';
  let activeSpotId = FACE_MOLE_SPOTS[0].id;
  let activeStream = null;
  let activeFacing = 'user'; // 'user' = cam trước (tự lật), 'environment' = cam sau (giữ nguyên)
  let capturedBase64 = '';
  let lastMolePlain = '';
  let moleBusy = false;
  let photoMoles = [];
  let activePinIdx = -1;
  let showPhotoPins = true;

  const setStatus = (txt, isErr = false) => {
    if (!statusEl) return;
    statusEl.className = isErr ? 'status-msg err' : 'status-msg';
    statusEl.textContent = txt || '';
  };

  const renderPhotoPins = () => {
    if (!photoPinsEl) return;
    photoPinsEl.innerHTML = '';
    photoPinsEl.classList.toggle('hidden', !showPhotoPins);
    if (togglePinsBtn) {
      togglePinsBtn.textContent = showPhotoPins ? `👁 Ẩn chấm (${photoMoles.length})` : `👁 Hiện chấm (${photoMoles.length})`;
    }
    const manualCount = photoMoles.filter((p) => p.source === 'manual').length;
    if (analyzeBtn && !moleBusy && capturedBase64) {
      analyzeBtn.textContent = manualCount > 0 ? `✨ Luận giải ${photoMoles.length} vị trí đã chấm` : '✨ Quét lại AI';
    }

    if (showPhotoPins) {
      photoMoles.forEach((m, idx) => {
        const pin = document.createElement('button');
        pin.type = 'button';
        pin.className = `mole-photo-pin${m.color === 'red' ? ' is-red' : ''}${m.source === 'manual' ? ' is-manual' : ''}${idx === activePinIdx ? ' active' : ''}`;
        pin.style.left = `${m.x}%`;
        pin.style.top = `${m.y}%`;
        pin.innerHTML = `<span class="mole-pin-num">${idx + 1}</span>`;
        pin.title = m.label || `Nốt ruồi #${idx + 1}`;
        pin.addEventListener('click', (ev) => {
          ev.stopPropagation();
          activePinIdx = idx;
          if (m.spotId && FACE_MOLE_SPOTS.some((s) => s.id === m.spotId)) {
            activeSpotId = m.spotId;
            renderMoleMap();
          }
          renderPhotoPins();
        });
        photoPinsEl.appendChild(pin);
      });
    }

    if (!pinCard) return;
    if (activePinIdx < 0 || activePinIdx >= photoMoles.length) {
      pinCard.classList.add('hidden');
      pinCard.innerHTML = '';
      return;
    }
    const cur = photoMoles[activePinIdx];
    const typeTag = cur.source === 'manual'
      ? '📌 Bạn tự chấm'
      : (cur.color === 'red' ? '🔴 Nốt ruồi son' : '⚫ Nốt ruồi đen/nâu');
    pinCard.classList.remove('hidden');
    pinCard.innerHTML = `
      <div class="mole-pin-card-head">
        <strong>📍 #${activePinIdx + 1} ${esc(cur.label || 'Vị trí trên mặt')} <span style="font-weight:600;color:#9D174D;">(${typeTag})</span></strong>
        <button type="button" id="btn-mole-del-pin" class="btn-chip" style="padding:3px 7px;font-size:11px;">✕ Xóa</button>
      </div>
      <div>${cur.summary ? esc(cur.summary) : 'Chạm <strong>"✨ Luận giải vị trí đã chấm"</strong> để Gemini AI phân tích đúng vị trí này trên khuôn mặt bạn.'}</div>
    `;
    $('btn-mole-del-pin')?.addEventListener('click', () => {
      photoMoles.splice(activePinIdx, 1);
      activePinIdx = photoMoles.length > 0 ? Math.min(activePinIdx, photoMoles.length - 1) : -1;
      renderPhotoPins();
    });
  };

  const stopCamera = () => {
    if (activeStream) {
      activeStream.getTracks().forEach((tr) => { try { tr.stop(); } catch (_e) {} });
      activeStream = null;
    }
    if (videoEl) {
      videoEl.srcObject = null;
      videoEl.classList.add('hidden');
      videoEl.classList.remove('is-mirrored');
    }
    removeCameraControlBar($('palm-stage'));
    removeCameraControlBar($('mole-stage'));
    guideEl?.classList.add('hidden');
    snapBtn?.classList.add('hidden');
    switchCamBtn?.classList.add('hidden');
    stopCamBtn?.classList.add('hidden');
    camFrontBtn?.classList.remove('hidden');
    camBackBtn?.classList.remove('hidden');
    if (!capturedBase64) emptyEl?.classList.remove('hidden');
  };

  const runAiFaceScan = async (useExistingManualPins = false) => {
    if (!capturedBase64 || moleBusy) return;
    if (!isGeminiConfigured(state.geminiSettings)) {
      if (statusEl) {
        statusEl.className = 'status-msg err';
        statusEl.innerHTML = '🔑 Chưa nhập Gemini API Key để quét mặt AI (vẫn xem được sổ tay 18 vị trí mẫu bên dưới). <button type="button" class="btn-ai-inline" id="btn-m-mole-cfg" style="padding:3px 8px;font-size:11.5px;">Nhập Key</button>';
        $('btn-m-mole-cfg')?.addEventListener('click', openMobileGeminiSettingsFocus);
      }
      return;
    }

    const pinsForAi = useExistingManualPins
      ? photoMoles.map((p) => ({ x: p.x, y: p.y, label: p.source === 'manual' ? '' : p.label }))
      : [];

    moleBusy = true;
    if (analyzeBtn) { analyzeBtn.disabled = true; analyzeBtn.textContent = '⏳ AI đang quét khuôn mặt...'; }
    setStatus(pinsForAi.length > 0
      ? `✨ Gemini Vision đang luận giải ${pinsForAi.length} vị trí bạn đã chấm trên ảnh...`
      : '✨ Gemini Vision AI đang quét vị trí nốt ruồi và chấm trực tiếp lên khuôn mặt chụp...');
    resCard?.classList.remove('hidden');
    if (resBody) resBody.innerHTML = '✨ Đang phân tích khuôn mặt & tọa độ nốt ruồi...';

    try {
      const scanRes = await analyzeFaceMolesWithGemini(
        state.geminiSettings,
        capturedBase64,
        moleGender,
        noteInp?.value || '',
        state,
        (partial) => {
          if (partial && resBody) resBody.innerHTML = formatMobileGeminiMd(partial);
        },
        pinsForAi
      );
      const fullAns = typeof scanRes === 'string' ? scanRes : (scanRes?.text || '');
      const aiMoles = Array.isArray(scanRes?.moles) ? scanRes.moles : [];

      if (aiMoles.length > 0) {
        photoMoles = aiMoles;
        activePinIdx = 0;
        showPhotoPins = true;
        const firstSpot = aiMoles.find((m) => m.spotId && FACE_MOLE_SPOTS.some((s) => s.id === m.spotId));
        if (firstSpot) {
          activeSpotId = firstSpot.spotId;
          renderMoleMap();
        }
      } else if (!useExistingManualPins) {
        photoMoles = [];
        activePinIdx = -1;
      }
      renderPhotoPins();

      lastMolePlain = `🪞 Quét khuôn mặt & Xem nốt ruồi (${moleGender === 'female' ? 'Nữ' : 'Nam'})\n\n${fullAns}`;
      if (resBody) resBody.innerHTML = formatMobileGeminiMd(fullAns);
      setStatus(photoMoles.length > 0
        ? `✅ Đã chấm ${photoMoles.length} vị trí trực tiếp lên ảnh mặt! Chạm từng số trên ảnh để xem nhanh (hoặc chạm thêm lên ảnh để tự chấm).`
        : '✅ Đã quét xong! Nếu có nốt ruồi nhỏ, bạn chạm thẳng lên vị trí đó trên ảnh rồi bấm "✨ Luận giải".');
    } catch (err) {
      setStatus(`⚠️ ${err?.message || 'Lỗi phân tích ảnh bằng Gemini AI'}`, true);
    } finally {
      moleBusy = false;
      renderPhotoPins();
      if (analyzeBtn) analyzeBtn.disabled = false;
    }
  };

  const showCapturedPhoto = (dataUrl, base64) => {
    capturedBase64 = base64;
    photoMoles = [];
    activePinIdx = -1;
    showPhotoPins = true;
    stopCamera();
    if (previewEl) previewEl.src = dataUrl;
    photoWrap?.classList.remove('hidden');
    pinToolbar?.classList.remove('hidden');
    emptyEl?.classList.add('hidden');
    analyzeBtn?.classList.remove('hidden');
    renderPhotoPins();
    runAiFaceScan(false);
  };

  photoWrap?.addEventListener('click', (ev) => {
    if (!capturedBase64 || ev.target.closest('.mole-photo-pin')) return;
    const rect = photoWrap.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const x = Math.max(2, Math.min(98, ((ev.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(2, Math.min(98, ((ev.clientY - rect.top) / rect.height) * 100));
    showPhotoPins = true;
    photoMoles.push({
      num: photoMoles.length + 1,
      label: `Vị trí tự chấm #${photoMoles.length + 1}`,
      x,
      y,
      color: 'black',
      omen: 'good',
      spotId: '',
      summary: '',
      source: 'manual'
    });
    activePinIdx = photoMoles.length - 1;
    renderPhotoPins();
    setStatus(`📌 Đã chấm vị trí #${photoMoles.length} lên ảnh! Chạm "✨ Luận giải ${photoMoles.length} vị trí đã chấm" để AI phân tích chuẩn.`);
  });

  togglePinsBtn?.addEventListener('click', () => {
    showPhotoPins = !showPhotoPins;
    renderPhotoPins();
  });
  clearPinsBtn?.addEventListener('click', () => {
    photoMoles = [];
    activePinIdx = -1;
    renderPhotoPins();
    setStatus('🧹 Đã xóa các chấm trên ảnh. Chạm trực tiếp lên mặt ảnh để chấm lại hoặc bấm "✨ Quét lại AI".');
  });

  const handleSelectedFile = (file, mirrorX = false) => {
    if (!file) return;
    stopCamera();
    const img = new Image();
    const objUrl = URL.createObjectURL(file);
    img.onload = () => {
      const { dataUrl, base64 } = compressImageSourceToBase64(img, 1280, 0.92, mirrorX);
      URL.revokeObjectURL(objUrl);
      showCapturedPhoto(dataUrl, base64);
    };
    img.onerror = () => {
      URL.revokeObjectURL(objUrl);
      setStatus('⚠️ Không đọc được file ảnh này. Hãy chọn ảnh JPG/PNG khác.', true);
    };
    img.src = objUrl;
  };

  const startFaceCamera = async (facing = 'user', preferredDeviceId = null) => {
    activeFacing = facing;
    const isFront = facing === 'user';
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      if (camFallbackInp) {
        camFallbackInp.setAttribute('capture', isFront ? 'user' : 'environment');
        camFallbackInp.click();
      }
      return;
    }
    try {
      stopCamera();
      const ctrl = await openSmartCamera(facing, { preferredDeviceId });
      activeStream = ctrl.stream;
      if (videoEl) {
        videoEl.srcObject = ctrl.stream;
        videoEl.classList.toggle('is-mirrored', isFront);
        videoEl.classList.remove('hidden');
        try { await videoEl.play(); } catch (_e) {}
      }
      photoWrap?.classList.add('hidden');
      pinToolbar?.classList.add('hidden');
      pinCard?.classList.add('hidden');
      emptyEl?.classList.add('hidden');
      guideEl?.classList.remove('hidden');
      if (guideLbl) guideLbl.textContent = isFront ? 'Cam trước (tự lật ảnh) — đưa mặt vào giữa khung' : 'Cam sau 1x (giữ nguyên) — đưa mặt vào giữa khung';
      snapBtn?.classList.remove('hidden');
      switchCamBtn?.classList.remove('hidden');
      stopCamBtn?.classList.remove('hidden');
      camFrontBtn?.classList.add('hidden');
      camBackBtn?.classList.add('hidden');
      attachCameraControlBar($('mole-stage'), ctrl, {
        onSwitchRearLens: !isFront ? (devId) => startFaceCamera('environment', devId) : null,
        onOpenNativeCamera: camFallbackInp ? () => { stopCamera(); camFallbackInp.setAttribute('capture', isFront ? 'user' : 'environment'); camFallbackInp.click(); } : null
      });
      setStatus(isFront ? '🤳 Đang mở Cam trước (tự lật ảnh) — chạm "✨ Chụp & Quét ngay".' : '📷 Đang mở Cam sau 1x (giữ nguyên ảnh) — chạm "✨ Chụp & Quét ngay".');
    } catch (_err) {
      setStatus('📸 Chuyển sang chụp bằng Camera máy (hoặc chạm "📁 Tải ảnh lên").');
      if (camFallbackInp) {
        camFallbackInp.setAttribute('capture', isFront ? 'user' : 'environment');
        camFallbackInp.click();
      }
    }
  };

  camFrontBtn?.addEventListener('click', () => startFaceCamera('user'));
  camBackBtn?.addEventListener('click', () => startFaceCamera('environment'));
  switchCamBtn?.addEventListener('click', () => startFaceCamera(activeFacing === 'user' ? 'environment' : 'user'));
  stopCamBtn?.addEventListener('click', stopCamera);

  snapBtn?.addEventListener('click', () => {
    if (!videoEl || !videoEl.videoWidth) return;
    const shouldFlip = activeFacing === 'user';
    const { dataUrl, base64 } = compressImageSourceToBase64(videoEl, 1280, 0.92, shouldFlip);
    showCapturedPhoto(dataUrl, base64);
  });

  fileInp?.addEventListener('change', (e) => {
    handleSelectedFile(e.target.files?.[0], false);
    e.target.value = '';
  });
  camFallbackInp?.addEventListener('change', (e) => {
    handleSelectedFile(e.target.files?.[0], activeFacing === 'user');
    e.target.value = '';
  });

  analyzeBtn?.addEventListener('click', () => {
    const hasManual = photoMoles.some((p) => p.source === 'manual');
    runAiFaceScan(hasManual);
  });

  $('btn-mole-copy')?.addEventListener('click', async () => {
    if (!lastMolePlain) return;
    try { await navigator.clipboard.writeText(lastMolePlain); } catch (_e) {}
    setStatus('✓ Đã sao chép kết quả xem nốt ruồi!');
  });
  $('btn-mole-zalo')?.addEventListener('click', async (e) => {
    if (!lastMolePlain) return;
    const b = e.currentTarget;
    const orig = b.textContent;
    b.textContent = '⏳...';
    await shareToZaloQuick(lastMolePlain);
    b.textContent = '✓ Zalo';
    setTimeout(() => { b.textContent = orig; }, 1600);
  });
  $('btn-mole-tg')?.addEventListener('click', (e) => {
    if (!lastMolePlain) return;
    sendTgHtml(esc(lastMolePlain), e.currentTarget);
  });

  // Interactive 18-spot SVG face map
  const renderMoleMap = () => {
    svgSpots.innerHTML = '';
    if (pillsBox) pillsBox.innerHTML = '';
    const ns = 'http://www.w3.org/2000/svg';

    for (const sp of FACE_MOLE_SPOTS) {
      const g = document.createElementNS(ns, 'g');
      g.setAttribute('class', `mole-dot${sp.id === activeSpotId ? ' active' : ''}`);
      g.setAttribute('transform', `translate(${sp.x}, ${sp.y})`);
      const c = document.createElementNS(ns, 'circle');
      c.setAttribute('r', sp.id === activeSpotId ? '9.5' : '7.6');
      const t = document.createElementNS(ns, 'text');
      t.textContent = String(sp.num);
      g.appendChild(c);
      g.appendChild(t);
      g.addEventListener('click', () => {
        activeSpotId = sp.id;
        renderMoleMap();
      });
      svgSpots.appendChild(g);

      if (pillsBox) {
        const p = document.createElement('button');
        p.type = 'button';
        p.className = `mole-spot-pill${sp.id === activeSpotId ? ' active' : ''}`;
        p.textContent = `${sp.num}. ${sp.name.split('(')[0].trim()}`;
        p.addEventListener('click', () => {
          activeSpotId = sp.id;
          renderMoleMap();
        });
        pillsBox.appendChild(p);
      }
    }

    const cur = FACE_MOLE_SPOTS.find((s) => s.id === activeSpotId) || FACE_MOLE_SPOTS[0];
    const desc = moleGender === 'female' ? cur.female : cur.male;
    detailBox.innerHTML = `
      <div class="dream-item-head" style="margin-bottom:5px;">
        <div class="dream-item-title">📍 #${cur.num} ${esc(cur.name)}</div>
        <span class="dream-omen-badge ${cur.omen || ''}">${esc(cur.omenLabel)}</span>
      </div>
      <div class="dream-item-meaning" style="margin-bottom:0;"><strong>${moleGender === 'female' ? '👩 Nữ giới:' : '👨 Nam giới:'}</strong> ${esc(desc)}</div>
    `;
  };

  genderPills?.addEventListener('click', (e) => {
    const p = e.target.closest('.pill');
    if (!p) return;
    moleGender = p.dataset.gender || 'male';
    genderPills.querySelectorAll('.pill').forEach((x) => x.classList.toggle('active', x === p));
    renderMoleMap();
  });

  // Stop live camera when navigating away
  document.querySelectorAll('.bnav-btn, .btn-back-discover').forEach((b) => {
    b.addEventListener('click', stopCamera);
  });

  renderMoleMap();
}

/* ==================== XEM CHỈ TAY (CAM SAU / TẢI ẢNH + GEMINI VISION AI) ==================== */
function bindMobilePalmistryTabEvents() {
  const videoEl = $('palm-video');
  const previewEl = $('palm-preview');
  const guideEl = $('palm-guide');
  const guideLbl = $('palm-cam-guide-lbl');
  const emptyEl = $('palm-empty-placeholder');
  const camBackBtn = $('btn-palm-cam-back');
  const switchCamBtn = $('btn-palm-switch-cam');
  const snapBtn = $('btn-palm-snap');
  const stopCamBtn = $('btn-palm-stop-cam');
  const fileInp = $('palm-file-input');
  const camFallbackInp = $('palm-cam-fallback');
  const analyzeBtn = $('btn-palm-analyze');
  const noteInp = $('palm-extra-note');
  const statusEl = $('palm-ai-status');
  const resCard = $('palm-ai-result-card');
  const resBody = $('palm-ai-result-body');
  const handPills = $('palm-hand-pills');
  const genderPills = $('palm-gender-pills');
  const svgSpots = $('palm-svg-spots');
  const detailBox = $('palm-spot-detail');
  const pillsBox = $('palm-spot-pills');
  if (!svgSpots || !detailBox) return;

  let palmHand = 'left';
  let palmGender = 'male';
  let activeSpotId = PALM_FEATURES[0].id;
  let activeStream = null;
  let activeFacing = 'environment'; // Mặc định Cam sau (giữ nguyên)
  let capturedBase64 = '';
  let capturedEnhancedBase64 = '';
  let lastPalmPlain = '';
  let palmBusy = false;

  const setStatus = (txt, isErr = false) => {
    if (!statusEl) return;
    statusEl.className = isErr ? 'status-msg err' : 'status-msg';
    statusEl.textContent = txt || '';
  };

  const stopCamera = () => {
    if (activeStream) {
      activeStream.getTracks().forEach((tr) => { try { tr.stop(); } catch (_e) {} });
      activeStream = null;
    }
    if (videoEl) {
      videoEl.srcObject = null;
      videoEl.classList.add('hidden');
      videoEl.classList.remove('is-mirrored');
    }
    removeCameraControlBar($('palm-stage'));
    removeCameraControlBar($('mole-stage'));
    guideEl?.classList.add('hidden');
    snapBtn?.classList.add('hidden');
    switchCamBtn?.classList.add('hidden');
    stopCamBtn?.classList.add('hidden');
    camBackBtn?.classList.remove('hidden');
    if (!capturedBase64) emptyEl?.classList.remove('hidden');
  };

  const runAiPalmScan = async () => {
    if (!capturedBase64 || palmBusy) return;
    if (!isGeminiConfigured(state.geminiSettings)) {
      if (statusEl) {
        statusEl.className = 'status-msg err';
        statusEl.innerHTML = '🔑 Chưa nhập Gemini API Key để xem chỉ tay AI (vẫn tra được bản đồ 10 đường chỉ tay bên dưới). <button type="button" class="btn-ai-inline" id="btn-m-palm-cfg" style="padding:3px 8px;font-size:11.5px;">Nhập Key</button>';
        $('btn-m-palm-cfg')?.addEventListener('click', openMobileGeminiSettingsFocus);
      }
      return;
    }

    palmBusy = true;
    if (analyzeBtn) { analyzeBtn.disabled = true; analyzeBtn.textContent = '⏳ AI đang soi chi tiết từng đường vân...'; }
    setStatus('✨ Gemini Vision HD đang soi kỹ từng vết đứt mạch, nối gối, nhánh rẽ & gò bàn tay...');
    resCard?.classList.remove('hidden');
    if (resBody) resBody.innerHTML = '✨ Đang phân tích ảnh gốc độ nét cao + bản tăng tương phản đường chỉ tay...';

    try {
      const palmImgs = capturedEnhancedBase64 ? [capturedBase64, capturedEnhancedBase64] : [capturedBase64];
      const fullAns = await analyzePalmLinesWithGemini(
        state.geminiSettings,
        palmImgs,
        palmHand,
        palmGender,
        noteInp?.value || '',
        state,
        (partial) => {
          if (partial && resBody) resBody.innerHTML = formatMobileGeminiMd(partial);
        }
      );
      lastPalmPlain = `🖐️ Xem Chỉ Tay (${palmHand === 'right' ? 'Tay phải' : 'Tay trái'} • ${palmGender === 'female' ? 'Nữ' : 'Nam'})\n\n${fullAns}`;
      if (resBody) resBody.innerHTML = formatMobileGeminiMd(fullAns);
      setStatus('✅ Đã luận giải xong các đường chỉ tay!');
    } catch (err) {
      setStatus(`⚠️ ${err?.message || 'Lỗi phân tích ảnh chỉ tay bằng Gemini AI'}`, true);
    } finally {
      palmBusy = false;
      if (analyzeBtn) { analyzeBtn.disabled = false; analyzeBtn.textContent = '✨ Xem lại AI'; }
    }
  };

  const handleSelectedFile = (file, mirrorX = false) => {
    if (!file) return;
    stopCamera();
    const img = new Image();
    const objUrl = URL.createObjectURL(file);
    img.onload = () => {
      const { dataUrl, base64, enhancedBase64 } = buildEnhancedPalmImages(img, mirrorX);
      URL.revokeObjectURL(objUrl);
      capturedBase64 = base64;
      capturedEnhancedBase64 = enhancedBase64;
      if (previewEl) {
        previewEl.src = dataUrl;
        previewEl.classList.remove('hidden');
      }
      emptyEl?.classList.add('hidden');
      analyzeBtn?.classList.remove('hidden');
      runAiPalmScan();
    };
    img.onerror = () => {
      URL.revokeObjectURL(objUrl);
      setStatus('⚠️ Không đọc được file ảnh này. Hãy chọn ảnh JPG/PNG khác.', true);
    };
    img.src = objUrl;
  };

  const startPalmCamera = async (facing = 'environment', preferredDeviceId = null) => {
    activeFacing = facing;
    const isFront = facing === 'user';
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      if (camFallbackInp) {
        camFallbackInp.setAttribute('capture', isFront ? 'user' : 'environment');
        camFallbackInp.click();
      }
      return;
    }
    try {
      stopCamera();
      const ctrl = await openSmartCamera(facing, { preferredDeviceId });
      activeStream = ctrl.stream;
      if (videoEl) {
        videoEl.srcObject = ctrl.stream;
        videoEl.classList.toggle('is-mirrored', isFront);
        videoEl.classList.remove('hidden');
        try { await videoEl.play(); } catch (_e) {}
      }
      previewEl?.classList.add('hidden');
      emptyEl?.classList.add('hidden');
      guideEl?.classList.remove('hidden');
      if (guideLbl) guideLbl.textContent = isFront ? 'Cam trước — xòe lòng bàn tay đủ sáng vào khung' : 'Cam sau 1x (giữ nguyên) — xòe lòng bàn tay đủ sáng';
      snapBtn?.classList.remove('hidden');
      switchCamBtn?.classList.remove('hidden');
      stopCamBtn?.classList.remove('hidden');
      camBackBtn?.classList.add('hidden');
      attachCameraControlBar($('palm-stage'), ctrl, {
        onSwitchRearLens: !isFront ? (devId) => startPalmCamera('environment', devId) : null,
        onOpenNativeCamera: camFallbackInp ? () => { stopCamera(); camFallbackInp.setAttribute('capture', isFront ? 'user' : 'environment'); camFallbackInp.click(); } : null
      });
      setStatus('📷 Đưa lòng bàn tay phẳng, đủ sáng rồi chạm "✨ Chụp & Xem chỉ tay".');
    } catch (_err) {
      setStatus('📷 Chuyển sang chụp bằng ứng dụng Camera sau (hoặc chạm "📁 Tải ảnh lên").');
      if (camFallbackInp) {
        camFallbackInp.setAttribute('capture', isFront ? 'user' : 'environment');
        camFallbackInp.click();
      }
    }
  };

  camBackBtn?.addEventListener('click', () => startPalmCamera('environment'));
  switchCamBtn?.addEventListener('click', () => startPalmCamera(activeFacing === 'environment' ? 'user' : 'environment'));
  stopCamBtn?.addEventListener('click', stopCamera);

  snapBtn?.addEventListener('click', () => {
    if (!videoEl || !videoEl.videoWidth) return;
    const shouldFlip = activeFacing === 'user';
    const { dataUrl, base64, enhancedBase64 } = buildEnhancedPalmImages(videoEl, shouldFlip);
    capturedBase64 = base64;
    capturedEnhancedBase64 = enhancedBase64;
    stopCamera();
    if (previewEl) {
      previewEl.src = dataUrl;
      previewEl.classList.remove('hidden');
    }
    emptyEl?.classList.add('hidden');
    analyzeBtn?.classList.remove('hidden');
    runAiPalmScan();
  });

  fileInp?.addEventListener('change', (e) => {
    handleSelectedFile(e.target.files?.[0], false);
    e.target.value = '';
  });
  camFallbackInp?.addEventListener('change', (e) => {
    handleSelectedFile(e.target.files?.[0], activeFacing === 'user');
    e.target.value = '';
  });

  analyzeBtn?.addEventListener('click', runAiPalmScan);

  $('btn-palm-copy')?.addEventListener('click', async () => {
    if (!lastPalmPlain) return;
    try { await navigator.clipboard.writeText(lastPalmPlain); } catch (_e) {}
    setStatus('✓ Đã sao chép kết quả xem chỉ tay!');
  });
  $('btn-palm-zalo')?.addEventListener('click', async (e) => {
    if (!lastPalmPlain) return;
    const b = e.currentTarget;
    const orig = b.textContent;
    b.textContent = '⏳...';
    await shareToZaloQuick(lastPalmPlain);
    b.textContent = '✓ Zalo';
    setTimeout(() => { b.textContent = orig; }, 1600);
  });
  $('btn-palm-tg')?.addEventListener('click', (e) => {
    if (!lastPalmPlain) return;
    sendTgHtml(esc(lastPalmPlain), e.currentTarget);
  });

  const renderPalmMap = () => {
    svgSpots.innerHTML = '';
    if (pillsBox) pillsBox.innerHTML = '';
    const ns = 'http://www.w3.org/2000/svg';

    for (const sp of PALM_FEATURES) {
      const g = document.createElementNS(ns, 'g');
      g.setAttribute('class', `mole-dot${sp.id === activeSpotId ? ' active' : ''}`);
      g.setAttribute('transform', `translate(${sp.x}, ${sp.y})`);
      const c = document.createElementNS(ns, 'circle');
      c.setAttribute('r', sp.id === activeSpotId ? '9.8' : '7.8');
      if (sp.id !== activeSpotId && sp.color) c.style.fill = sp.color;
      const t = document.createElementNS(ns, 'text');
      t.textContent = String(sp.num);
      g.appendChild(c);
      g.appendChild(t);
      g.addEventListener('click', () => { activeSpotId = sp.id; renderPalmMap(); });
      svgSpots.appendChild(g);

      if (pillsBox) {
        const p = document.createElement('button');
        p.type = 'button';
        p.className = `mole-spot-pill${sp.id === activeSpotId ? ' active' : ''}`;
        p.textContent = `${sp.num}. ${sp.name.split('(')[0].trim()}`;
        p.addEventListener('click', () => { activeSpotId = sp.id; renderPalmMap(); });
        pillsBox.appendChild(p);
      }
    }

    const cur = PALM_FEATURES.find((s) => s.id === activeSpotId) || PALM_FEATURES[0];
    detailBox.innerHTML = `
      <div class="dream-item-head" style="margin-bottom:5px;">
        <div class="dream-item-title">🖐️ #${cur.num} ${esc(cur.name)}</div>
        <span class="dream-omen-badge ${cur.omen || ''}">${esc(cur.omenLabel)}</span>
      </div>
      <div class="dream-item-meaning">${esc(cur.summary)}</div>
      <div class="dream-item-meaning"><strong>✨ Tướng tốt:</strong> ${esc(cur.goodSign)}</div>
      <div class="dream-item-meaning" style="margin-bottom:0;color:#047857;"><strong>💡 Lời khuyên:</strong> ${esc(cur.advice)}</div>
    `;
  };

  handPills?.addEventListener('click', (e) => {
    const p = e.target.closest('.pill');
    if (!p) return;
    palmHand = p.dataset.hand || 'left';
    handPills.querySelectorAll('.pill').forEach((x) => x.classList.toggle('active', x === p));
  });

  genderPills?.addEventListener('click', (e) => {
    const p = e.target.closest('.pill');
    if (!p) return;
    palmGender = p.dataset.gender || 'male';
    genderPills.querySelectorAll('.pill').forEach((x) => x.classList.toggle('active', x === p));
  });

  document.querySelectorAll('.bnav-btn, .btn-back-discover').forEach((b) => {
    b.addEventListener('click', stopCamera);
  });

  renderPalmMap();
}

function updateMobileLiveCalendarIcon() {
  const now = new Date();
  const mEl = $('nav-cal-month');
  const dEl = $('nav-cal-day');
  if (mEl) mEl.textContent = `T${now.getMonth() + 1}`;
  if (dEl) dEl.textContent = String(now.getDate());

  const dayRolledOver =
    now.getDate() !== today.getDate() ||
    now.getMonth() !== today.getMonth() ||
    now.getFullYear() !== today.getFullYear();

  if (dayRolledOver) {
    const wasViewingPrevToday =
      state.selectedDate.day === today.getDate() &&
      state.selectedDate.month === today.getMonth() + 1 &&
      state.selectedDate.year === today.getFullYear();

    today = now;
    if (wasViewingPrevToday) {
      state.selectedDate = {
        day: now.getDate(),
        month: now.getMonth() + 1,
        year: now.getFullYear()
      };
      state.viewMonth = now.getMonth() + 1;
      state.viewYear = now.getFullYear();
    }
    renderAllCalendarViews();
    renderHolidays();
    renderWater();
  }
}

// Bootstrap
if ($('app-version')) $('app-version').textContent = `v${APP_VERSION}`;
if ($('footer-app-version')) $('footer-app-version').textContent = `v${APP_VERSION}`;
updateMobileLiveCalendarIcon();
setupEditableDateTimeFields();
initControls();
populateWeatherCities();
bindEvents();
bindMobileGlobalSearchEvents();
bindMobileGeminiAiEvents();
bindMobileDreamTabEvents();
bindMobileMolesTabEvents();
bindMobilePalmistryTabEvents();
mountConverterHub($('mob-converter-hub-mount'), {
  onJumpDate: (solar) => jumpToSolar(solar),
  onBack: () => switchTab('discover')
});
const mobSharedOpts = {
  isMobile: true,
  getState: () => state,
  onBack: () => switchTab('discover'),
  onOpenGeminiSettings: () => openMobileGeminiSettingsFocus(),
  onSendTelegram: (html, btn) => sendTgHtml(html, btn)
};
const mobFortuneCtrl = mountFortuneModule($('mob-fortune-mount'), mobSharedOpts);
mountTuViModule($('mob-tuvi-mount'), mobSharedOpts);
const mobFsCtrl = mountFengShuiSpaceModule($('mob-fengshui-mount'), mobSharedOpts);
const mobSpCtrl = mountSimPlateModule($('mob-simplate-mount'), mobSharedOpts);
mountCompatibilityModule($('mob-compat-mount'), mobSharedOpts);
mountTarotNumerologyModule($('mob-tarot-mount'), mobSharedOpts);
const mobIcCtrl = mountIChingXamModule($('mob-iching-mount'), mobSharedOpts);
mobExpenseCtrl = mountExpenseAiModule($('mob-expense-mount'), {
  ...mobSharedOpts,
  onFinanceChange: (kind, arr, deletedIds = []) => {
    state[kind] = Array.isArray(arr) ? arr : [];
    saveMobileField(kind, state[kind]);
    for (const delId of deletedIds) recordMobileDeletedId(delId);
    scheduleMobileCloudPush();
  }
});
mountMedicineModule($('mob-medicine-mount'), {
  ...mobSharedOpts,
  onAddReminder: (rem) => {
    state.timedReminders.push({
      id: `rem-med-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      title: rem.title,
      date: rem.date,
      time: rem.time,
      repeat: rem.repeat || 'daily',
      sound: true,
      sendTelegram: true,
      note: rem.note || '',
      done: false,
      createdAt: Date.now()
    });
    persistAndSync('timedReminders', state.timedReminders);
    renderRemindersList();
    renderAllCalendarViews();
  }
});
mountMealPlannerModule($('mob-meal-mount'), {
  ...mobSharedOpts,
  onOpenDiet: () => switchTab('diet')
});
mountDietGuideModule($('mob-diet-mount'), mobSharedOpts);
const mobDocScanCtrl = mountDocScannerModule($('mob-docscan-mount'), mobSharedOpts);
const stopAllMobileSubMedia = () => {
  mobFortuneCtrl?.stopCamera?.();
  mobFortuneCtrl?.stopSpeech?.();
  mobFsCtrl?.stopCamera?.();
  mobSpCtrl?.stopCamera?.();
  mobIcCtrl?.stopShake?.();
  mobDocScanCtrl?.stopCamera?.();
};
document.querySelectorAll('.bnav-btn').forEach((b) => {
  b.addEventListener('click', stopAllMobileSubMedia);
});

// Add convenient "← Quay lại mục Thêm" + "↑ Đầu trang" footer bar at the bottom of every sub-screen
[...DISCOVER_SUB_TABS, 'settings'].forEach((tabId) => {
  const sec = $(`tab-${tabId}`);
  if (!sec || sec.querySelector('.sf-bottom-back-bar')) return;
  const isSettings = tabId === 'settings';
  const bar = document.createElement('div');
  bar.className = 'sf-bottom-back-bar';
  bar.innerHTML = `
    <button type="button" class="sf-bottom-back-btn">${isSettings ? '← Quay lại' : '← Quay lại mục Thêm'}</button>
    <button type="button" class="sf-bottom-top-btn" title="Cuộn lên đầu trang">↑ Đầu trang</button>
  `;
  bar.querySelector('.sf-bottom-back-btn').addEventListener('click', () => {
    stopAllMobileSubMedia();
    switchTab(isSettings ? (state.prevTab || 'calendar') : 'discover', -1);
    $('main-scroll')?.scrollTo({ top: 0, behavior: 'smooth' });
  });
  bar.querySelector('.sf-bottom-top-btn').addEventListener('click', () => {
    $('main-scroll')?.scrollTo({ top: 0, behavior: 'smooth' });
  });
  sec.appendChild(bar);
});
/* ==================== COLLAPSIBLE 1-LINE MOBILE SETTINGS ACCORDION (v3.4.3) ==================== */
const mobileSettingsAccCards = new Map();

function getMobileSettingsCardStatus(key) {
  if (key === 'ota') {
    const info = readNativeOtaStatus();
    const cfg = loadOtaPrefs();
    const freqLabels = { daily: 'Theo ngày', weekly: 'Theo tuần', monthly: 'Theo tháng', off: 'Tắt' };
    const fLbl = freqLabels[cfg.autoFreq] || 'Theo ngày';
    if (cfg.autoFreq === 'off') {
      return { text: info?.otaActive && info.otaVersion ? `⚪ v${info.otaVersion} • Tắt` : '⚪ Tắt tự động', cls: '' };
    }
    if (info?.otaActive && info.otaVersion) return { text: `🟢 OTA v${info.otaVersion}`, cls: 'is-on' };
    const hasSrc = Boolean(cfg.manifestUrl || state.cloudSyncConfig?.firebaseUrl);
    if (hasSrc) return { text: `🟢 ${fLbl}`, cls: 'is-on' };
    return { text: '⚙️ Thiết lập', cls: '' };
  }
  if (key === 'cloud') {
    const cfg = state.cloudSyncConfig || {};
    const on = Boolean($('cs-enabled')?.checked || cfg.enabled);
    const hasAuth = Boolean(
      cfg.cfToken ||
      ($('cs-fb-url')?.value || cfg.firebaseUrl || '').trim() ||
      ($('cs-gh-token')?.value || cfg.githubToken || '').trim()
    );
    if (on && hasAuth) {
      return { text: cfg.provider === 'cloudflare' && cfg.cfUsername ? `🟢 ${cfg.cfUsername}` : '🟢 Đã bật', cls: 'is-on' };
    }
    if (on) return { text: '🟡 Chưa đăng nhập', cls: 'is-setup' };
    return { text: '⚪ Tắt', cls: '' };
  }
  if (key === 'telegram') {
    const on = Boolean($('tg-enabled')?.checked || state.telegramSettings?.enabled);
    const ready = Boolean(($('tg-token')?.value || state.telegramSettings?.botToken || '').trim() && ($('tg-chat-id')?.value || state.telegramSettings?.chatId || '').trim());
    if (on && ready) return { text: '🟢 Đã bật', cls: 'is-on' };
    if (ready) return { text: '🟡 Đã lưu', cls: 'is-setup' };
    return { text: '⚪ Tắt', cls: '' };
  }
  if (key === 'gemini') {
    if (isGeminiConfigured(state.geminiSettings)) return { text: '🟢 Đã bật', cls: 'is-on' };
    const hasKey = Boolean(($('gm-api-key')?.value || state.geminiSettings?.apiKey || $('gm-proxy-url')?.value || state.geminiSettings?.proxyUrl || '').trim());
    if (hasKey) return { text: '🟡 Đã lưu cấu hình', cls: 'is-setup' };
    return { text: '⚪ Tắt', cls: '' };
  }
  if (key === 'zalo') {
    const on = Boolean($('m-zalo-en')?.checked || state.zaloSettings?.enabled);
    return on ? { text: '🟢 Bật', cls: 'is-on' } : { text: '⚪ Tắt', cls: '' };
  }
  if (key === 'holidays') {
    const on = Boolean($('set-notif-on')?.checked);
    return on ? { text: '🟢 Bật', cls: 'is-on' } : { text: '⚪ Tắt', cls: '' };
  }
  return { text: '⚙️ Mở', cls: '' };
}

function refreshMobileSettingsSummaryPills() {
  mobileSettingsAccCards.forEach((card, key) => {
    const pill = card.querySelector('.set-acc-pill');
    if (!pill) return;
    const st = getMobileSettingsCardStatus(key);
    pill.textContent = st.text;
    pill.className = `set-acc-pill${st.cls ? ' ' + st.cls : ''}`;
  });
  updateMobileSettingsToggleAllBtn();
}

function updateMobileSettingsToggleAllBtn() {
  const btn = $('btn-settings-toggle-all');
  if (!btn || mobileSettingsAccCards.size === 0) return;
  const connCards = Array.from(mobileSettingsAccCards.entries())
    .filter(([k]) => k !== 'holidays')
    .map(([, c]) => c);
  const anyConnExpanded = connCards.some((c) => !c.classList.contains('is-collapsed'));
  btn.textContent = anyConnExpanded ? '📥 Thu gọn hết' : '📂 Mở hết';
}

function expandMobileSettingsCard(keyOrEl) {
  const card = typeof keyOrEl === 'string' ? mobileSettingsAccCards.get(keyOrEl) : keyOrEl;
  if (!card) return;
  card.classList.remove('is-collapsed');
  const trig = card.querySelector('.set-acc-trigger');
  if (trig) trig.setAttribute('aria-expanded', 'true');
  updateMobileSettingsToggleAllBtn();
}

function initMobileCollapsibleSettings() {
  const sec = $('tab-settings');
  if (!sec || sec.dataset.accInit === '1') return;
  sec.dataset.accInit = '1';

  const topBar = sec.querySelector('.settings-top-bar');
  if (topBar && !$('btn-settings-toggle-all')) {
    const btnAll = document.createElement('button');
    btnAll.type = 'button';
    btnAll.id = 'btn-settings-toggle-all';
    btnAll.className = 'set-toggle-all-btn';
    btnAll.textContent = '📂 Mở hết';
    btnAll.addEventListener('click', () => {
      const connEntries = Array.from(mobileSettingsAccCards.entries()).filter(([k]) => k !== 'holidays');
      const anyConnExpanded = connEntries.some(([, c]) => !c.classList.contains('is-collapsed'));
      connEntries.forEach(([, c]) => {
        c.classList.toggle('is-collapsed', anyConnExpanded);
        c.querySelector('.set-acc-trigger')?.setAttribute('aria-expanded', String(!anyConnExpanded));
      });
      updateMobileSettingsToggleAllBtn();
    });
    topBar.appendChild(btnAll);
  }

  const cards = Array.from(sec.children).filter((el) => el.classList.contains('card') && !el.classList.contains('settings-top-bar'));
  cards.forEach((card, idx) => {
    let key = `card-${idx}`;
    let shortTitle = '';
    let titleColor = '#1F2937';

    if (card.id === 'ota-settings-card' || card.classList.contains('ota-card')) {
      key = 'ota';
      shortTitle = '🚀 Cập nhật Online (OTA — Không cần cài APK)';
      titleColor = '#0F766E';
    } else if (card.classList.contains('cloud-sync-card')) {
      key = 'cloud';
      shortTitle = '☁️ Đồng bộ tự động';
      titleColor = '#047857';
    } else if (card.classList.contains('tg-card')) {
      key = 'telegram';
      shortTitle = '✈️ Kết nối nhóm Telegram';
      titleColor = '#0369A1';
    } else if (card.id === 'gemini-settings-card' || card.classList.contains('gemini-card')) {
      key = 'gemini';
      shortTitle = '✨ Kết nối Trợ lý Gemini AI';
      titleColor = '#5B21B6';
    } else if (card.querySelector('#m-zalo-en')) {
      key = 'zalo';
      shortTitle = '💬 Chia sẻ Zalo & Webhook';
      titleColor = '#0068FF';
    } else if (card.querySelector('#set-notif-on')) {
      key = 'holidays';
      shortTitle = '🔔 Nhắc Lễ Tết, Mùng 1 & Rằm';
      titleColor = '#991B1B';
    } else if (card.querySelector('#btn-export-json')) {
      key = 'oppo';
      shortTitle = '📱 Thông báo Android & Sao lưu';
      titleColor = '#334155';
    } else {
      const h2 = card.querySelector('h2.card-title');
      shortTitle = h2 ? h2.textContent.trim() : `⚙️ Cài đặt ${idx + 1}`;
      if (h2?.style?.color) titleColor = h2.style.color;
    }

    const body = document.createElement('div');
    body.className = 'set-acc-body';
    while (card.firstChild) {
      body.appendChild(card.firstChild);
    }

    const startCollapsed = key !== 'holidays';
    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'set-acc-trigger';
    trigger.setAttribute('aria-expanded', String(!startCollapsed));
    trigger.innerHTML = `
      <span class="set-acc-title" style="color: ${titleColor};">${esc(shortTitle)}</span>
      <span class="set-acc-pill">⚪ Tắt</span>
      <span class="set-acc-chev" aria-hidden="true">▸</span>
    `;
    trigger.addEventListener('click', () => {
      const willCollapse = !card.classList.contains('is-collapsed');
      card.classList.toggle('is-collapsed', willCollapse);
      trigger.setAttribute('aria-expanded', String(!willCollapse));
      updateMobileSettingsToggleAllBtn();
    });

    card.classList.add('set-acc-card');
    if (startCollapsed) card.classList.add('is-collapsed');
    card.dataset.accKey = key;
    card.appendChild(trigger);
    card.appendChild(body);
    mobileSettingsAccCards.set(key, card);
  });

  ['cs-enabled', 'cs-fb-url', 'cs-gh-token', 'tg-enabled', 'tg-token', 'tg-chat-id', 'gm-enabled', 'gm-api-key', 'm-zalo-en', 'set-notif-on'].forEach((id) => {
    $(id)?.addEventListener('change', refreshMobileSettingsSummaryPills);
  });
  refreshMobileSettingsSummaryPills();
}

bindMobileReminderTabEvents();
bindMobileBulkReminderEvents();
bindMobileCloudSyncEvents();
renderMobileCloudSyncUI();
renderMobileGeminiSettings();
/* ==================== ONLINE OTA AUTO-UPDATE CONTROLLER (VPS / GITHUB / FIREBASE — v3.6.3) ==================== */
const OTA_PREFS_LS_KEY = 'lich_am_ota_prefs_v1';
const DEFAULT_OTA_MANIFEST_URL = 'https://raw.githubusercontent.com/mrquynh91-cyber/lich-am-ota/refs/heads/main/ota-manifest.json';
const OTA_FREQ_INTERVAL_MS = {
  daily: 24 * 60 * 60 * 1000,
  weekly: 7 * 24 * 60 * 60 * 1000,
  monthly: 30 * 24 * 60 * 60 * 1000,
  off: Infinity
};
let pendingOtaManifest = null;
let otaReadyToReload = false;
let otaBusy = false;

function normalizeOtaFreq(val, legacyAutoCheck) {
  if (val && Object.prototype.hasOwnProperty.call(OTA_FREQ_INTERVAL_MS, val)) return val;
  if (legacyAutoCheck === false) return 'off';
  return 'daily';
}

function loadOtaPrefs() {
  try {
    const raw = localStorage.getItem(OTA_PREFS_LS_KEY);
    const obj = raw ? JSON.parse(raw) : {};
    const savedUrl = String(obj.manifestUrl || '').trim();
    const autoFreq = normalizeOtaFreq(obj.autoFreq, obj.autoCheck);
    return {
      source: obj.source || 'auto',
      manifestUrl: savedUrl || DEFAULT_OTA_MANIFEST_URL,
      autoFreq,
      autoCheck: autoFreq !== 'off',
      lastAutoCheckAt: Number(obj.lastAutoCheckAt) || 0
    };
  } catch (_e) {
    return { source: 'auto', manifestUrl: DEFAULT_OTA_MANIFEST_URL, autoFreq: 'daily', autoCheck: true, lastAutoCheckAt: 0 };
  }
}

function saveOtaPrefs(prefs) {
  try { localStorage.setItem(OTA_PREFS_LS_KEY, JSON.stringify(prefs)); } catch (_e) {}
}

function isOtaAutoCheckDue(prefs) {
  if (!prefs || prefs.autoFreq === 'off') return false;
  const interval = OTA_FREQ_INTERVAL_MS[prefs.autoFreq] || OTA_FREQ_INTERVAL_MS.daily;
  const lastAt = Number(prefs.lastAutoCheckAt) || 0;
  if (!lastAt) return true;
  return (Date.now() - lastAt) >= interval;
}

function formatOtaTimestamp(ms) {
  if (!ms) return '';
  const d = new Date(ms);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(d.getHours())}:${pad(d.getMinutes())} ${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

async function resolveFreshGithubRawUrl(rawUrl) {
  try {
    const m = String(rawUrl || '').match(/^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/(?:refs\/heads\/)?([^/]+)\/(.+?)(?:\?.*)?$/i);
    if (!m) return rawUrl;
    const [, owner, repo, branch, filePath] = m;
    // Skip if already pinned to a 40-char commit SHA
    if (/^[0-9a-f]{40}$/i.test(branch)) return rawUrl;
    const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), 4000) : null;
    try {
      const apiResp = await fetch(`https://api.github.com/repos/${owner}/${repo}/commits/${encodeURIComponent(branch)}?per_page=1&_t=${Date.now()}`, {
        cache: 'no-store',
        headers: { Accept: 'application/vnd.github+json' },
        signal: ctrl?.signal
      });
      if (apiResp.ok) {
        const info = await apiResp.json();
        const sha = String(info?.sha || '').trim();
        if (/^[0-9a-f]{40}$/i.test(sha)) {
          return `https://raw.githubusercontent.com/${owner}/${repo}/${sha}/${filePath}`;
        }
      }
    } finally {
      if (timer) clearTimeout(timer);
    }
  } catch (_e) {}
  return rawUrl;
}

function readNativeOtaStatus() {
  try {
    if (window.AndroidBridge?.getOtaStatus) {
      return JSON.parse(window.AndroidBridge.getOtaStatus());
    }
  } catch (_e) {}
  return null;
}

function compareSemver(a, b) {
  const pa = String(a || '0').replace(/^v/i, '').split('.').map((x) => parseInt(x, 10) || 0);
  const pb = String(b || '0').replace(/^v/i, '').split('.').map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length, 3);
  for (let i = 0; i < len; i++) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da > db) return 1;
    if (da < db) return -1;
  }
  return 0;
}

function resolveOtaManifestEndpoint(prefs) {
  const src = prefs?.source || 'auto';
  const customUrl = String(prefs?.manifestUrl || '').trim();
  const fbUrl = String(state.cloudSyncConfig?.firebaseUrl || '').trim().replace(/\/+$/, '');
  if (src === 'url') return customUrl ? { url: customUrl, mode: 'url' } : null;
  if (src === 'firebase') return fbUrl ? { url: `${fbUrl}/ota_release.json`, mode: 'firebase' } : null;
  if (customUrl) return { url: customUrl, mode: 'url' };
  if (fbUrl) return { url: `${fbUrl}/ota_release.json`, mode: 'firebase' };
  return null;
}

function renderOtaSettingsUI() {
  const prefs = loadOtaPrefs();
  if ($('ota-source')) $('ota-source').value = prefs.source;
  if ($('ota-manifest-url')) $('ota-manifest-url').value = prefs.manifestUrl;
  if ($('ota-auto-freq')) $('ota-auto-freq').value = prefs.autoFreq;
  if ($('ota-url-field')) $('ota-url-field').classList.toggle('hidden', prefs.source === 'firebase');

  const schedEl = $('ota-schedule-note');
  if (schedEl) {
    if (prefs.autoFreq === 'off') {
      schedEl.textContent = '🔕 Đang tắt tự động kiểm tra. Bạn vẫn có thể bấm "🔍 Kiểm tra cập nhật" bất cứ lúc nào.';
    } else {
      const interval = OTA_FREQ_INTERVAL_MS[prefs.autoFreq] || OTA_FREQ_INTERVAL_MS.daily;
      const lastTxt = prefs.lastAutoCheckAt ? `Kiểm tra gần nhất: ${formatOtaTimestamp(prefs.lastAutoCheckAt)}` : 'Chưa kiểm tra lần nào';
      const nextAt = prefs.lastAutoCheckAt ? (prefs.lastAutoCheckAt + interval) : Date.now();
      const nextTxt = nextAt <= Date.now() ? 'Sẽ kiểm tra ngay' : `Lần tới: ${formatOtaTimestamp(nextAt)}`;
      schedEl.textContent = `${lastTxt} • ${nextTxt}`;
    }
  }

  const nativeSt = readNativeOtaStatus();
  const infoEl = $('ota-ver-info');
  if (infoEl) {
    if (nativeSt) {
      const otaTag = nativeSt.otaActive
        ? ` • 🚀 Đang chạy bản OTA v${nativeSt.otaVersion}`
        : ' • 📦 Đang chạy bản gốc trong APK';
      infoEl.textContent = `Phiên bản hiện tại: v${APP_VERSION} (APK #${nativeSt.apkVersionCode})${otaTag}`;
    } else {
      infoEl.textContent = `Phiên bản hiện tại: v${APP_VERSION} (Chế độ trình duyệt web)`;
    }
  }
  $('btn-ota-rollback')?.classList.toggle('hidden', !(nativeSt && nativeSt.otaActive));
}

function showOtaBanner(text, btnLabel = '🔄 Cập nhật ngay', onAction = null) {
  const bar = $('ota-update-banner');
  const txt = $('ota-banner-text');
  const btn = $('btn-ota-banner-apply');
  if (!bar || !txt || !btn) return;
  txt.textContent = text;
  btn.textContent = btnLabel;
  btn.onclick = onAction;
  bar.classList.remove('hidden');
}

function applyPendingOtaUpdate(silent = false) {
  if (!pendingOtaManifest || otaBusy) return;
  const m = pendingOtaManifest;
  const stEl = $('ota-status');
  const progWrap = $('ota-progress-wrap');
  const progFill = $('ota-progress-fill');

  if (!window.AndroidBridge) {
    if (m.apkUrl) window.open(m.apkUrl, '_blank', 'noopener');
    else location.reload();
    return;
  }

  const nativeSt = readNativeOtaStatus();
  const needApk = Boolean(m.apkUrl && Number(m.apkVersionCode || 0) > Number(nativeSt?.apkVersionCode || 0) && m.requireApk);

  otaBusy = true;
  if (!silent && progWrap) {
    progWrap.classList.remove('hidden');
    if (progFill) progFill.style.width = '12%';
  }
  if (stEl) {
    stEl.className = 'status-msg';
    stEl.textContent = `⏳ Đang tải bản v${m.version}...`;
  }

  if (needApk && window.AndroidBridge.downloadAndInstallApk) {
    window.AndroidBridge.downloadAndInstallApk(m.apkUrl);
  } else if (m.bundleBase64 && window.AndroidBridge.installOtaFromBase64) {
    window.AndroidBridge.installOtaFromBase64(m.bundleBase64, String(m.version));
  } else if (m.resolvedBundleUrl && window.AndroidBridge.installOtaFromUrl) {
    window.AndroidBridge.installOtaFromUrl(m.resolvedBundleUrl, String(m.version));
  } else if (m.apkUrl && window.AndroidBridge.downloadAndInstallApk) {
    window.AndroidBridge.downloadAndInstallApk(m.apkUrl);
  } else {
    otaBusy = false;
    if (stEl) {
      stEl.className = 'status-msg err';
      stEl.textContent = '⚠️ File manifest chưa có đường dẫn gói cập nhật (bundleUrl / bundleBase64).';
    }
  }
}

window.__onNativeOtaEvent = (ev) => {
  if (!ev) return;
  const stEl = $('ota-status');
  const progWrap = $('ota-progress-wrap');
  const progFill = $('ota-progress-fill');

  if (ev.stage === 'progress' || ev.stage === 'apk_progress') {
    if (progWrap) progWrap.classList.remove('hidden');
    if (progFill) progFill.style.width = `${Math.max(5, Math.min(100, Number(ev.pct) || 10))}%`;
    if (stEl) {
      stEl.className = 'status-msg';
      stEl.textContent = `⏳ ${ev.message || 'Đang tải cập nhật...'}`;
    }
    return;
  }

  otaBusy = false;
  if (ev.stage === 'ready') {
    otaReadyToReload = true;
    if (progFill) progFill.style.width = '100%';
    if (stEl) {
      stEl.className = 'status-msg';
      stEl.textContent = `✅ ${ev.message} Bấm "🔄 Áp dụng ngay" để dùng bản mới (không cần cài lại APK)!`;
    }
    const applyBtn = $('btn-ota-apply-now');
    if (applyBtn) {
      applyBtn.textContent = `🔄 Áp dụng v${ev.version} ngay`;
      applyBtn.classList.remove('hidden');
    }
    renderOtaSettingsUI();
    refreshMobileSettingsSummaryPills();
    showOtaBanner(`🎉 Đã tải xong bản mới v${ev.version}! Chạm để dùng ngay:`, '🔄 Áp dụng ngay', () => {
      window.AndroidBridge?.reloadApp?.();
    });
    return;
  }

  if (ev.stage === 'apk_launched') {
    if (progWrap) progWrap.classList.add('hidden');
    if (stEl) {
      stEl.className = 'status-msg';
      stEl.textContent = '✅ Đã tải xong APK và mở trình cài đặt Android!';
    }
    return;
  }

  if (ev.stage === 'error') {
    if (progWrap) progWrap.classList.add('hidden');
    if (stEl) {
      stEl.className = 'status-msg err';
      stEl.textContent = `⚠️ ${ev.message || 'Cập nhật thất bại.'}`;
    }
  }
};

async function checkMobileOnlineUpdate(manual = false) {
  const stEl = $('ota-status');
  const prefs = loadOtaPrefs();
  const target = resolveOtaManifestEndpoint(prefs);
  if (!target) {
    if (manual && stEl) {
      stEl.className = 'status-msg err';
      stEl.textContent = '⚠️ Chưa có nguồn cập nhật. Hãy dán link VPS/GitHub hoặc bật Đồng bộ Firebase!';
    }
    return;
  }

  if (manual && stEl) {
    stEl.className = 'status-msg';
    stEl.textContent = '🔍 Đang kiểm tra bản cập nhật mới...';
  }

  try {
    const fetchBaseUrl = target.mode === 'url' ? await resolveFreshGithubRawUrl(target.url) : target.url;
    const sep = fetchBaseUrl.includes('?') ? '&' : '?';
    const resp = await fetch(`${fetchBaseUrl}${sep}_t=${Date.now()}`, { cache: 'no-store' });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();

    // Persist last successful check time so daily/weekly/monthly schedule works across restarts
    const updatedPrefs = { ...prefs, lastAutoCheckAt: Date.now() };
    saveOtaPrefs(updatedPrefs);
    renderOtaSettingsUI();

    if (!data || !data.version) {
      if (manual && stEl) {
        stEl.className = 'status-msg';
        stEl.textContent = `✅ Bạn đang dùng bản mới nhất (v${APP_VERSION}).`;
      }
      return;
    }

    const nativeSt = readNativeOtaStatus();
    const effectiveVer = nativeSt?.otaActive && compareSemver(nativeSt.otaVersion, APP_VERSION) > 0
      ? nativeSt.otaVersion
      : APP_VERSION;
    const hasNewWeb = compareSemver(data.version, effectiveVer) > 0;
    const hasNewApk = Boolean(data.apkUrl && Number(data.apkVersionCode || 0) > Number(nativeSt?.apkVersionCode || 0));

    if (!hasNewWeb && !hasNewApk) {
      if (manual && stEl) {
        stEl.className = 'status-msg';
        stEl.textContent = `✅ Ứng dụng đã là bản mới nhất (v${effectiveVer})!`;
      }
      return;
    }

    let resolvedBundleUrl = '';
    if (data.bundleUrl) {
      try { resolvedBundleUrl = new URL(data.bundleUrl, fetchBaseUrl).toString(); } catch (_e) { resolvedBundleUrl = data.bundleUrl; }
    }
    pendingOtaManifest = { ...data, resolvedBundleUrl };

    const applyBtn = $('btn-ota-apply-now');
    if (applyBtn) {
      applyBtn.textContent = `🚀 Cập nhật lên v${data.version}`;
      applyBtn.classList.remove('hidden');
    }

    const noteTxt = data.notes ? ` — ${String(data.notes).slice(0, 80)}` : '';
    if (stEl) {
      stEl.className = 'status-msg';
      stEl.textContent = `✨ Đã có bản mới v${data.version}${noteTxt}`;
    }

    // If running inside OPPO APK and it's a fast OTA web bundle, auto-download silently so Mom just taps 1 button!
    if (!manual && prefs.autoFreq !== 'off' && window.AndroidBridge && (data.bundleBase64 || resolvedBundleUrl) && !data.requireApk) {
      applyPendingOtaUpdate(true);
    } else {
      showOtaBanner(`✨ Có bản mới v${data.version}${noteTxt}`, '🚀 Cập nhật ngay', () => {
        if (otaReadyToReload) window.AndroidBridge?.reloadApp?.();
        else applyPendingOtaUpdate(false);
      });
    }
  } catch (err) {
    if (manual && stEl) {
      stEl.className = 'status-msg err';
      stEl.textContent = `⚠️ Không kiểm tra được bản mới (${err?.message || 'Lỗi mạng'}).`;
    }
  }
}

function initMobileOtaUpdater() {
  renderOtaSettingsUI();
  const persist = () => {
    const prev = loadOtaPrefs();
    const autoFreq = normalizeOtaFreq($('ota-auto-freq')?.value, true);
    const prefs = {
      source: $('ota-source')?.value || 'auto',
      manifestUrl: ($('ota-manifest-url')?.value || '').trim() || DEFAULT_OTA_MANIFEST_URL,
      autoFreq,
      autoCheck: autoFreq !== 'off',
      lastAutoCheckAt: prev.lastAutoCheckAt || 0
    };
    saveOtaPrefs(prefs);
    renderOtaSettingsUI();
    refreshMobileSettingsSummaryPills();
  };
  ['ota-source', 'ota-manifest-url', 'ota-auto-freq'].forEach((id) => {
    $(id)?.addEventListener('change', persist);
  });
  $('btn-ota-check')?.addEventListener('click', () => {
    persist();
    checkMobileOnlineUpdate(true);
  });
  $('btn-ota-apply-now')?.addEventListener('click', () => {
    if (otaReadyToReload) window.AndroidBridge?.reloadApp?.();
    else applyPendingOtaUpdate(false);
  });
  $('btn-ota-rollback')?.addEventListener('click', () => {
    if (window.AndroidBridge?.rollbackOta?.()) {
      window.AndroidBridge.reloadApp();
    }
  });
  $('btn-ota-banner-dismiss')?.addEventListener('click', () => {
    $('ota-update-banner')?.classList.add('hidden');
  });

  // Silent background check 3.5s after launch if due per selected schedule (daily / weekly / monthly)
  const prefs = loadOtaPrefs();
  if (isOtaAutoCheckDue(prefs)) {
    setTimeout(() => checkMobileOnlineUpdate(false), 3500);
  }
}

initMobileCollapsibleSettings();
initMobileOtaUpdater();
updateMobileBnavSlider(state.activeTab || 'calendar', true);
const initialNotifChannel = urlParams.get('channel');
if (initialNotifChannel) {
  openNotificationTarget(initialNotifChannel, urlParams.get('date'));
}
renderAllCalendarViews();
renderPrayers(true);
runAuspicious();
renderRemindersList();
renderHighlightsList();
renderWater();
renderHolidays();
runMobileAutoPruneExpired(false);
updateRemFabVisibility();
loadWeather(false);
setTimeout(() => maybeAutoRefreshMovingGps(), 2500);
syncNativeAndroidAlarms(state);
setInterval(checkForegroundAlarms, 15000);

// Live 2-way Cloud Sync auto-pull (startup + every 12s + on app resume)
if (state.cloudSyncConfig?.enabled) {
  syncMobileCloudNow('pull', false);
}
setInterval(() => {
  if (state.cloudSyncConfig?.enabled && document.visibilityState === 'visible') {
    syncMobileCloudNow('pull', false);
  }
}, 12000);
setInterval(updateMobileLiveCalendarIcon, 30000);
window.addEventListener('focus', updateMobileLiveCalendarIcon);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    updateMobileLiveCalendarIcon();
    if (state.cloudSyncConfig?.enabled) {
      syncMobileCloudNow('pull', false);
    }
    maybeAutoRefreshMovingGps();
    // Also check OTA silently on app resume if due per selected schedule (daily / weekly / monthly)
    const otaPrefs = loadOtaPrefs();
    if (isOtaAutoCheckDue(otaPrefs) && !otaBusy && !otaReadyToReload) {
      setTimeout(() => checkMobileOnlineUpdate(false), 2000);
    }
  }
});
