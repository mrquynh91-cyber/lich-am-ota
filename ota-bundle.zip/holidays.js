import {
  convertSolar2Lunar,
  convertLunar2Solar,
  getTetEveSolarDate,
  jdFromDate,
  jdToDate,
  TIMEZONE_VN
} from './lunar.js';

export const DEFAULT_SETTINGS = {
  notificationsEnabled: true,
  notifyDaysBefore: [0, 1, 3], // Nhắc đúng ngày, trước 1 ngày, trước 3 ngày
  notifyHour: 8,               // 8:00 sáng
  remindMung1Ram: true,        // Nhắc Mùng 1 và Ngày Rằm hàng tháng
  remindSolarHolidays: true,   // Nhắc ngày lễ Dương lịch
  remindLunarHolidays: true,   // Nhắc ngày lễ Tết Âm lịch
  showBadge: true,             // Hiện ngày âm lịch trên icon Chrome
  autoScanGmail: true,         // Tự động thêm lịch họp/vé bay khi mở email trên Gmail
  dailyGmailScanEnabled: true, // Tự động quét Gmail hằng ngày sau 19h
  dailyGmailScanHour: 19,      // Giờ bắt đầu quét Gmail hằng ngày (mặc định 19:00)
  autoDeleteExpiredDays: 0     // Tự động xóa nhắc nhở đã xong/hết hạn sau X ngày (0 = Tắt, 7/30/90/180/365)
};

/**
 * Vietnamese Lunar Holidays (month 1..12, day 1..30)
 * priority: 'major' | 'normal'
 */
export const LUNAR_HOLIDAYS = [
  { id: 'tet-1', day: 1, month: 1, name: 'Mùng 1 Tết Nguyên Đán', priority: 'major', desc: 'Chúc Mừng Năm Mới - Tết Cổ Truyền Việt Nam' },
  { id: 'tet-2', day: 2, month: 1, name: 'Mùng 2 Tết Nguyên Đán', priority: 'major', desc: 'Tết Cổ Truyền - Chúc Tết họ hàng' },
  { id: 'tet-3', day: 3, month: 1, name: 'Mùng 3 Tết Nguyên Đán', priority: 'major', desc: 'Tết Thầy - Hóa vàng đầu xuân' },
  { id: 'nguyen-tieu', day: 15, month: 1, name: 'Tết Nguyên Tiêu (Rằm tháng Giêng)', priority: 'major', desc: 'Lễ Thượng Nguyên - Cúng Rằm tháng Giêng' },
  { id: 'han-thuc', day: 3, month: 3, name: 'Tết Hàn Thực', priority: 'normal', desc: 'Ngày bánh trôi, bánh chay' },
  { id: 'gio-to', day: 10, month: 3, name: 'Giỗ Tổ Hùng Vương', priority: 'major', desc: 'Quốc lễ Giỗ Tổ Hùng Vương (Nghỉ lễ)' },
  { id: 'phat-dan', day: 15, month: 4, name: 'Lễ Phật Đản', priority: 'normal', desc: 'Đại lễ Phật Đản (Vesak)' },
  { id: 'doan-ngo', day: 5, month: 5, name: 'Tết Đoan Ngọ', priority: 'normal', desc: 'Tết diệt sâu bọ giữa năm' },
  { id: 'vu-lan', day: 15, month: 7, name: 'Lễ Vu Lan (Rằm tháng 7)', priority: 'major', desc: 'Mùa Vu Lan báo hiếu - Xá tội vong nhân' },
  { id: 'trung-thu', day: 15, month: 8, name: 'Tết Trung Thu', priority: 'major', desc: 'Tết Đoàn Viên - Rằm tháng Tám' },
  { id: 'trung-cuu', day: 9, month: 9, name: 'Tết Trùng Cửu', priority: 'normal', desc: 'Ngày Trùng Dương (9/9 Âm lịch)' },
  { id: 'ha-nguyen', day: 15, month: 10, name: 'Tết Hạ Nguyên', priority: 'normal', desc: 'Tết cơm mới - Rằm tháng Mười' },
  { id: 'ong-tao', day: 23, month: 12, name: 'Ngày Ông Công Ông Táo', priority: 'major', desc: 'Tiễn Táo Quân chầu trời' }
];

/**
 * Vietnamese Solar Holidays
 */
export const SOLAR_HOLIDAYS = [
  { id: 'tet-duong', day: 1, month: 1, name: 'Tết Dương Lịch', priority: 'major', desc: 'Chúc mừng năm mới Dương lịch (Nghỉ lễ)' },
  { id: 'valentine', day: 14, month: 2, name: 'Lễ Tình Nhân (Valentine)', priority: 'normal', desc: 'Ngày lễ tình yêu 14/2' },
  { id: 'qtpn', day: 8, month: 3, name: 'Quốc tế Phụ nữ', priority: 'normal', desc: 'Ngày Quốc tế Phụ nữ 8/3' },
  { id: 'gpmn', day: 30, month: 4, name: 'Ngày Giải phóng miền Nam', priority: 'major', desc: 'Kỷ niệm thống nhất đất nước 30/4 (Nghỉ lễ)' },
  { id: 'qtld', day: 1, month: 5, name: 'Quốc tế Lao động', priority: 'major', desc: 'Ngày Quốc tế Lao động 1/5 (Nghỉ lễ)' },
  { id: 'qttn', day: 1, month: 6, name: 'Quốc tế Thiếu nhi', priority: 'normal', desc: 'Ngày Tết Thiếu nhi 1/6' },
  { id: 'gia-dinh', day: 28, month: 6, name: 'Ngày Gia đình Việt Nam', priority: 'normal', desc: 'Tôn vinh giá trị gia đình Việt Nam' },
  { id: 'tbls', day: 27, month: 7, name: 'Ngày Thương binh Liệt sĩ', priority: 'normal', desc: 'Uống nước nhớ nguồn 27/7' },
  { id: 'cmtt', day: 19, month: 8, name: 'Cách mạng tháng Tám', priority: 'normal', desc: 'Kỷ niệm Cách mạng tháng Tám thành công' },
  { id: 'quoc-khanh', day: 2, month: 9, name: 'Quốc khánh Việt Nam', priority: 'major', desc: 'Lễ Quốc khánh nước CHXHCN Việt Nam (Nghỉ lễ)' },
  { id: 'pnvn', day: 20, month: 10, name: 'Ngày Phụ nữ Việt Nam', priority: 'normal', desc: 'Chúc mừng Ngày Phụ nữ Việt Nam 20/10' },
  { id: 'nha-giao', day: 20, month: 11, name: 'Ngày Nhà giáo Việt Nam', priority: 'normal', desc: 'Tri ân thầy cô giáo 20/11' },
  { id: 'giang-sinh', day: 25, month: 12, name: 'Lễ Giáng Sinh (Noel)', priority: 'normal', desc: 'Chúc mừng Giáng Sinh an lành' }
];

/**
 * Get all events/holidays occurring on a given solar date (dd/mm/yyyy)
 */
export function getEventsForDate(dd, mm, yy, customEvents = [], options = {}) {
  const {
    includeSolar = true,
    includeLunar = true,
    includeMung1Ram = false
  } = options;

  const lunar = convertSolar2Lunar(dd, mm, yy, TIMEZONE_VN);
  const events = [];

  // 1. Lunar holidays (only on non-leap months)
  if (includeLunar && !lunar.leap) {
    for (const h of LUNAR_HOLIDAYS) {
      if (h.day === lunar.day && h.month === lunar.month) {
        events.push({
          ...h,
          type: 'lunar',
          dateText: `${lunar.day}/${lunar.month} ÂL`
        });
      }
    }

    // Dynamic Tất Niên / Giao Thừa (last day of lunar month 12: 29 or 30)
    if (lunar.month === 12 && lunar.day === lunar.monthLength) {
      events.push({
        id: 'tat-nien',
        day: lunar.day,
        month: 12,
        name: `Tất Niên / Giao Thừa (${lunar.day} Tết)`,
        priority: 'major',
        desc: 'Đêm Giao Thừa đón năm mới Âm lịch',
        type: 'lunar',
        dateText: `${lunar.day}/12 ÂL`
      });
    }
  }

  // 2. Solar holidays
  if (includeSolar) {
    for (const h of SOLAR_HOLIDAYS) {
      if (h.day === dd && h.month === mm) {
        events.push({
          ...h,
          type: 'solar',
          dateText: `${dd}/${mm} DL`
        });
      }
    }
  }

  // 3. Custom user events (Ngày giỗ, Sinh nhật Âm lịch, Sự kiện cá nhân)
  for (const ce of customEvents) {
    const kindPrefix = ce.kind === 'gio' ? '🕯 ' : ce.kind === 'sinhnhat' ? '🎂 ' : '';
    const refYear = ce.calendar === 'lunar' ? lunar.year : yy;
    let milestone = '';
    if (ce.originYear && Number(ce.originYear) > 1900 && refYear >= Number(ce.originYear)) {
      const diff = refYear - Number(ce.originYear);
      if (ce.kind === 'gio' && diff > 0) milestone = ` (Giỗ lần thứ ${diff})`;
      else if (ce.kind === 'sinhnhat' && diff > 0) milestone = ` (Tròn ${diff} tuổi)`;
    }
    const kindDefaultDesc = ce.kind === 'gio'
      ? 'Ngày giỗ lặp lại hàng năm theo Âm lịch'
      : ce.kind === 'sinhnhat'
        ? (ce.calendar === 'lunar' ? 'Sinh nhật Âm lịch hàng năm' : 'Sinh nhật Dương lịch hàng năm')
        : (ce.calendar === 'lunar' ? 'Sự kiện Âm lịch cá nhân' : 'Sự kiện Dương lịch cá nhân');

    if (ce.calendar === 'lunar') {
      const matchMonth = ce.month === lunar.month && Boolean(ce.leap) === lunar.leap;
      // Handle user setting day 30 in a 29-day lunar month -> trigger on 29th if monthLength === 29
      const matchDay = ce.day === lunar.day || (ce.day === 30 && lunar.monthLength === 29 && lunar.day === 29);
      if (matchMonth && matchDay) {
        events.push({
          id: ce.id,
          name: `${kindPrefix}${ce.name}${milestone}`,
          desc: ce.note || kindDefaultDesc,
          priority: 'custom',
          type: 'custom-lunar',
          kind: ce.kind || 'le',
          remindBeforeDays: Number(ce.remindBeforeDays) || 0,
          remindTime: ce.remindTime || '',
          dateText: `${ce.day}/${ce.month}${ce.leap ? 'N' : ''} ÂL`
        });
      }
    } else if (ce.calendar === 'solar') {
      if (ce.day === dd && ce.month === mm) {
        events.push({
          id: ce.id,
          name: `${kindPrefix}${ce.name}${milestone}`,
          desc: ce.note || kindDefaultDesc,
          priority: 'custom',
          type: 'custom-solar',
          kind: ce.kind || 'le',
          remindBeforeDays: Number(ce.remindBeforeDays) || 0,
          remindTime: ce.remindTime || '',
          dateText: `${ce.day}/${ce.month} DL`
        });
      }
    }
  }

  // 4. Optional Mùng 1 / Ngày Rằm (avoid duplicating Tết 1/1, Rằm tháng Giêng, Phật Đản, Vu Lan, Trung Thu, Hạ Nguyên if already added)
  if (includeMung1Ram) {
    const hasMajorLunar = events.some((e) => e.type === 'lunar');
    if (lunar.day === 1 && !hasMajorLunar) {
      events.push({
        id: `mung1-${lunar.month}${lunar.leap ? 'n' : ''}`,
        name: `Mùng 1 tháng ${lunar.month}${lunar.leap ? ' nhuận' : ''} Âm lịch`,
        desc: 'Ngày sóc đầu tháng Âm lịch',
        priority: 'mung1ram',
        type: 'mung1ram',
        dateText: `1/${lunar.month}${lunar.leap ? 'N' : ''} ÂL`
      });
    } else if (lunar.day === 15 && !hasMajorLunar) {
      events.push({
        id: `ram-${lunar.month}${lunar.leap ? 'n' : ''}`,
        name: `Ngày Rằm tháng ${lunar.month}${lunar.leap ? ' nhuận' : ''} Âm lịch`,
        desc: 'Ngày Rằm (15 Âm lịch)',
        priority: 'mung1ram',
        type: 'mung1ram',
        dateText: `15/${lunar.month}${lunar.leap ? 'N' : ''} ÂL`
      });
    }
  }

  return events;
}

/**
 * Get upcoming events within the next `windowDays` starting from `fromDate` (JS Date)
 */
export function getUpcomingEvents(fromDate, windowDays = 180, customEvents = [], options = {}) {
  const startJd = jdFromDate(fromDate.getDate(), fromDate.getMonth() + 1, fromDate.getFullYear());
  const results = [];

  for (let offset = 0; offset <= windowDays; offset++) {
    const jd = startJd + offset;
    const solar = jdToDate(jd);
    const events = getEventsForDate(solar.day, solar.month, solar.year, customEvents, options);
    for (const ev of events) {
      const lunar = convertSolar2Lunar(solar.day, solar.month, solar.year, TIMEZONE_VN);
      results.push({
        ...ev,
        daysUntil: offset,
        solar,
        lunar,
        jd
      });
    }
  }

  return results;
}

/**
 * Find the next Tết Nguyên Đán (Mùng 1 tháng 1 ÂL) from a given JS Date
 */
export function getNextTetCountdown(fromDate) {
  const todayJd = jdFromDate(fromDate.getDate(), fromDate.getMonth() + 1, fromDate.getFullYear());
  const currentLunar = convertSolar2Lunar(fromDate.getDate(), fromDate.getMonth() + 1, fromDate.getFullYear(), TIMEZONE_VN);

  let targetLunarYear = currentLunar.year;
  let tetSolar = convertLunar2Solar(1, 1, targetLunarYear, false, TIMEZONE_VN);
  let tetJd = jdFromDate(tetSolar.day, tetSolar.month, tetSolar.year);

  if (tetJd < todayJd) {
    targetLunarYear += 1;
    tetSolar = convertLunar2Solar(1, 1, targetLunarYear, false, TIMEZONE_VN);
    tetJd = jdFromDate(tetSolar.day, tetSolar.month, tetSolar.year);
  }

  const eveInfo = getTetEveSolarDate(targetLunarYear - 1, TIMEZONE_VN);

  return {
    lunarYear: targetLunarYear,
    tetSolar,
    eveSolar: eveInfo.solar,
    eveLunarDay: eveInfo.lunarDay,
    daysUntil: tetJd - todayJd
  };
}

/**
 * Find the next Solar New Year (Tết Dương lịch - 01/01) from a given JS Date
 */
export function getNextSolarNewYearCountdown(fromDate) {
  const todayJd = jdFromDate(fromDate.getDate(), fromDate.getMonth() + 1, fromDate.getFullYear());
  let targetYear = fromDate.getFullYear();
  let newYearJd = jdFromDate(1, 1, targetYear);

  if (newYearJd < todayJd) {
    targetYear += 1;
    newYearJd = jdFromDate(1, 1, targetYear);
  }

  const lunar = convertSolar2Lunar(1, 1, targetYear, TIMEZONE_VN);
  return {
    targetYear,
    solar: { day: 1, month: 1, year: targetYear },
    lunar,
    daysUntil: newYearJd - todayJd
  };
}
