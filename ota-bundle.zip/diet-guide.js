/**
 * Family Diet & Nutrition Guide Module (v3.3.0 — PC & OPPO Find X9)
 *  - Collapsible multi-select checkbox dropdown ("Sổ list tích / bỏ tích bệnh lý & thể trạng")
 *  - Allows 0 selections (healthy / no underlying disease) OR multi-select merging (e.g. Bà: Tiểu đường + Cao huyết áp)
 *  - Works both standalone (tab:diet) and embedded inside Tab 2 of "🍲 Hôm nay ăn gì?" (zero DOM ID collision)
 *  - Offline Instant Vietnamese Food Checker (40+ foods) + Gemini AI Nutritionist + Voice + Zalo/Telegram
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import { isGeminiConfigured, askGeminiGeneral } from './gemini-ai.js';
import { shareToZaloQuick } from './zalo.js';

const DIET_PROFILES_KEY = 'lich_am_diet_profiles_v1';

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function fmtMd(raw) {
  return escHtml(raw)
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*([^*\n]+)\*(?=$|[\s,.;:!?])/g, '$1<em>$2</em>')
    .replace(/^\s*---\s*$/gm, '<hr style="border:none;border-top:1px solid #E5E7EB;margin:6px 0;" />')
    .replace(/^\s*[\*\-]\s+/gm, '• ');
}

function normVn(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .trim();
}

export const DIET_CONDITIONS = [
  {
    id: 'tieu-duong',
    icon: '🩸',
    name: 'Tiểu đường',
    shortName: 'Tiểu đường',
    subtitle: 'Ổn định đường huyết (GI thấp), tránh tăng đường đột ngột — rất cần cho Ông/Bà',
    eat: [
      { cat: '🥬 Rau xanh & Củ ít tinh bột', items: 'Bông cải xanh, rau muống, cải bó xôi, mướp đắng (khổ qua), đậu bắp, bí đao, dưa chuột, rau ngót' },
      { cat: '🐟 Đạm lành mạnh', items: 'Cá (cá hồi, cá thu, cá lóc, cá rô phi), ức gà bỏ da, thịt thăn nạc, trứng gà, đậu phụ, các loại đậu' },
      { cat: '🍚 Tinh bột chậm (GI thấp)', items: 'Gạo lứt, yến mạch nguyên hạt, bánh mì nguyên cám, khoai lang luộc (lượng vừa), bún gạo lứt' },
      { cat: '🍐 Trái cây ít ngọt', items: 'Ổi, bưởi, táo xanh, thanh long trắng, dâu tây, bơ, cam tươi (ăn nguyên múi, KHÔNG ép nước)' },
      { cat: '🍵 Đồ uống tốt', items: 'Nước lọc, trà xanh nhạt, nước lá ổi/mướp đắng nhạt, sữa hạt không đường, sữa chuyên biệt cho người tiểu đường' }
    ],
    limit: [
      'Cơm trắng: tối đa ½ – ⅔ bát con mỗi bữa (ăn SAU khi đã ăn rau & thức ăn)',
      'Phở / Bún / Miến: chỉ ăn ½ lượng bánh phở, thêm nhiều rau & thịt nạc, không húp hết nước béo',
      'Chuối chín vừa, xoài chín vừa, đu đủ: chỉ 1 miếng nhỏ giữa bữa (không ăn ngay sau cơm no)'
    ],
    avoid: [
      'Đường trắng, mật ong nhiều, bánh kẹo, chè, kem, mứt, bánh ngọt, bánh trung thu',
      'Nước ngọt có gas, trà sữa, nước trái cây đóng hộp, nước ép quả ngọt, cà phê sữa đặc',
      'Xôi nếp, bánh chưng, cháo trắng nấu nhừ, cơm cháy, khoai tây chiên (GI rất cao làm vọt đường huyết)',
      'Trái cây quá ngọt: sầu riêng, mít chín, nhãn, vải, nho ngọt, xoài chín rục, hoa quả sấy khô',
      'Đồ chiên rán nhiều dầu, mỡ động vật, nội tạng, rượu bia khi đói (dễ gây tụt đường huyết nguy hiểm)'
    ],
    tips: [
      'Áp dụng "Quy tắc thứ tự ăn": Ăn Rau trước (5 phút) → Thịt/Cá/Đậu → Cơm cuối cùng giúp giảm vọt đường huyết tới 30–40%!',
      'Chia nhỏ bữa: 3 bữa chính vừa phải + 1–2 bữa phụ nhẹ (nửa quả ổi / nắm hạt hạnh nhân / sữa chua không đường).',
      'Đi bộ nhẹ nhàng 15–20 phút sau bữa ăn tối khoảng 30 phút.'
    ]
  },
  {
    id: 'bung-to',
    icon: '🫃',
    name: 'Bụng to / Giảm mỡ bụng',
    shortName: 'Bụng to (Mỡ bụng)',
    subtitle: 'Giảm mỡ nội tạng, cắt bụng bia cho Bố / dân văn phòng mà vẫn đủ sức làm việc',
    eat: [
      { cat: '🥩 Đạm nạc no lâu đốt mỡ', items: 'Ức gà áp chảo/luộc, cá hấp/nướng (cá thu, cá hồi, cá basa ít béo), thịt bò nạc, tôm mực hấp, trứng luộc, đậu hũ' },
      { cat: '🥦 Rau giàu xơ (chiếm ½ đĩa)', items: 'Bông cải xanh, cải thìa, rau muống luộc, bí xanh, măng tây, salad dưa chuột cà chua, cần tây' },
      { cat: '🍠 Tinh bột tốt vừa đủ', items: 'Khoai lang luộc, gạo lứt, yến mạch, ngô luộc (ưu tiên ăn vào bữa sáng & trưa)' },
      { cat: '🥑 Chất béo tốt & Trái cây', items: 'Quả bơ, dầu ô liu, các loại hạt không muối (óc chó, hạnh nhân), bưởi, ổi, táo, thanh long' },
      { cat: '🍵 Đồ uống hỗ trợ giảm mỡ', items: 'Nước lọc (2–2.5 lít/ngày), trà xanh không đường, cà phê đen không đường (sáng), nước chanh ấm nhạt' }
    ],
    limit: [
      'Cơm trắng: giảm xuống ½ – 1 bát nhỏ bữa trưa; bữa tối chỉ ăn ½ bát hoặc thay bằng khoai/rau + đạm',
      'Dầu ăn khi xào nấu: chuyển sang luộc, hấp, nướng nồi chiên không dầu thay vì chiên ngập dầu',
      'Khi buộc phải đi tiếp khách: uống nhiều nước lọc xen kẽ, chọn món hấp/luộc/nộm thay đồ chiên béo'
    ],
    avoid: [
      'Bia, rượu mạnh, rượu pha ngọt ("thủ phạm số 1" tích mỡ nội tạng & bụng bia!)',
      'Nước ngọt, trà sữa, nước tăng lực, cà phê sữa đặc nhiều đường, sinh tố thêm sữa đặc',
      'Đồ nhậu chiên rán (chân gà chiên, đậu chiên dầu cũ, da heo chiên, khoai tây chiên), thịt ba chỉ nhiều mỡ, nội tạng',
      'Ăn khuya sau 20h30 (mì tôm, bánh mì pate bơ, xôi đêm, đồ ngọt)',
      'Tinh bột tinh chế nhiều: ăn 2–3 bát cơm trắng đầy mỗi bữa, bánh ngọt, bún phở nhiều nước béo'
    ],
    tips: [
      'Nguyên tắc "Đĩa ăn 1/2 – 1/4 – 1/4": ½ đĩa Rau xanh, ¼ đĩa Thịt nạc/Cá/Trứng, ¼ đĩa Cơm/Khoai.',
      'Ăn tối xong trước 19h30–20h00; cắt hoàn toàn đồ uống có đường & hạn chế bia tối đa trong 4 tuần sẽ thấy vòng bụng gọn rõ!',
      'Kết hợp đi bộ nhanh 30 phút/ngày + ngủ đủ 7 tiếng (thiếu ngủ làm tăng hormone cortisol tích mỡ bụng).'
    ]
  },
  {
    id: 'huyet-ap',
    icon: '❤️',
    name: 'Cao huyết áp / Tim mạch',
    shortName: 'Cao huyết áp',
    subtitle: 'Chế độ ăn nhạt chuẩn DASH, giàu Kali–Magie bảo vệ mạch máu & trái tim',
    eat: [
      { cat: '🥬 Rau củ giàu Kali hạ áp', items: 'Rau cần tây, cải bó xôi, rau dền, bí đỏ, cà chua, mướp đắng, khoai lang, củ dền' },
      { cat: '🐟 Đạm tốt cho tim', items: 'Cá giàu Omega-3 (cá hồi, cá thu, cá trích — 2–3 bữa/tuần), ức gà, đậu phụ, đậu đen/đậu xanh' },
      { cat: '🍌 Trái cây giàu Kali', items: 'Chuối, bơ, cam, quýt, bưởi (hỏi bác sĩ nếu đang uống thuốc nhóm Statin), dưa hấu, táo' },
      { cat: '🌾 Ngũ cốc & Hạt', items: 'Yến mạch, gạo lứt, hạt óc chó, hạt chia, mè đen, sữa tách béo không đường' }
    ],
    limit: [
      'Muối & nước mắm: dưới 5g muối/ngày (~1 thìa cà phê gạt ngang cho cả ngày, chấm loãng hoặc bỏ bát nước chấm)',
      'Thịt đỏ (bò, heo): ăn nạc, lượng vừa 2–3 bữa/tuần',
      'Cà phê, trà đặc: tối đa 1 ly nhạt buổi sáng nếu huyết áp đang ổn định'
    ],
    avoid: [
      'Dưa muối, cà pháo muối, kim chi, cá khô, tôm khô, mắm tôm, mắm ruốc, nước mắm nguyên chất chấm đậm',
      'Mì ăn liền (1 gói mì chứa gần hết lượng muối cả ngày!), xúc xích, giò chả mặn, thịt nguội, đồ hộp',
      'Mỡ động vật, da gà/vịt, óc, lòng, gan, tim động vật, đồ chiên rán nhiều dầu',
      'Rượu bia, thuốc lá, nước tăng lực'
    ],
    tips: [
      'Nêm nhạt bằng tỏi, gừng, hành, chanh, tiêu, rau thơm để món ăn vẫn đậm đà mà không cần nhiều muối/mì chính.',
      'Đo huyết áp sáng/tối đúng giờ và KHÔNG tự ý bỏ thuốc huyết áp khi thấy người khỏe.'
    ]
  },
  {
    id: 'mo-mau',
    icon: '🧈',
    name: 'Mỡ máu cao / Gan nhiễm mỡ',
    shortName: 'Mỡ máu / Gan nhiễm mỡ',
    subtitle: 'Giảm Cholesterol xấu (LDL) & Triglyceride, giải độc và phục hồi tế bào gan',
    eat: [
      { cat: '🐟 Cá giàu Omega-3', items: 'Cá hồi, cá thu, cá ngừ, cá mòi, đậu nành/đậu phụ, thịt ức gà bỏ da' },
      { cat: '🥣 Xơ hòa tan hút mỡ', items: 'Yến mạch, gạo lứt, các loại đậu (đậu xanh, đậu đỏ, đậu lăng), hạt chia, táo, lê, bưởi' },
      { cat: '🥦 Rau giải độc gan', items: 'Bông cải xanh, cải xoăn, rau má, atiso, mướp đắng, tỏi, nghệ, nấm hương, mộc nhĩ đen' },
      { cat: '🫒 Dầu thực vật tốt', items: 'Dầu ô liu, dầu hạt cải, dầu mè lượng nhỏ; quả bơ, hạt óc chó' }
    ],
    limit: [
      'Lòng đỏ trứng: tối đa 2–3 quả/tuần (lòng trắng ăn thoải mái hơn)',
      'Tinh bột trắng & trái cây quá ngọt — đường thừa chuyển hóa thành mỡ Triglyceride trong máu & gan!'
    ],
    avoid: [
      'Nội tạng động vật (gan, lòng, mề, óc, tim, bầu dục), tiết canh, trứng vịt lộn nhiều',
      'Da gia cầm (da gà, da vịt), thịt ba chỉ mỡ, chân giò, sườn nhiều mỡ, bơ động vật',
      'Đồ chiên rán ngập dầu, thức ăn nhanh (gà rán, pizza, bánh rán, quẩy nóng)',
      'Rượu bia (tàn phá gan nhiễm mỡ cực nhanh!), nước ngọt, trà sữa, bánh kẹo ngọt'
    ],
    tips: [
      'Đường ngọt, nước ngọt và bia rượu làm tăng mỡ máu Triglyceride mạnh không kém ăn mỡ!',
      'Mộc nhĩ đen + nấm hương + yến mạch là bộ 3 thực phẩm dân dã hỗ trợ giảm mỡ máu rất tốt.'
    ]
  },
  {
    id: 'gout',
    icon: '🦴',
    name: 'Gout (Gút) / Acid Uric cao',
    shortName: 'Bệnh Gout',
    subtitle: 'Kiêng thực phẩm giàu Purine, tăng đào thải Acid Uric phòng cơn đau khớp cấp',
    eat: [
      { cat: '💧 Nước & Đồ uống kiềm hóa', items: 'Uống 2.5 – 3 lít nước lọc/ngày (cực kỳ quan trọng!), nước khoáng kiềm, nước chanh loãng không đường, trà lá tía tô' },
      { cat: '🥚 Đạm ít Purine', items: 'Trứng gà, sữa tươi/sữa chua ít béo không đường, đậu phụ (lượng vừa an toàn), thịt trắng ức gà (≤100g/ngày)' },
      { cat: '🥬 Rau củ thanh mát', items: 'Bí xanh, cải bẹ xanh, dưa chuột, cà rốt, khoai tây, cà tím, súp lơ, rau cần' },
      { cat: '🍒 Trái cây giàu Vitamin C', items: 'Anh đào (cherry), dâu tây, cam, ổi, bưởi, dứa — giúp hạ Acid Uric tự nhiên' }
    ],
    limit: [
      'Thịt heo nạc, thịt gà, cá đồng (cá chép, cá rô phi): tối đa 100–120g/ngày, nên luộc bỏ nước đầu',
      'Măng tây, nấm, cải bó xôi, giá đỗ: ăn lượng vừa khi không đang lên cơn đau cấp'
    ],
    avoid: [
      'Bia (kể cả bia không cồn chứa men bia!), rượu mạnh — làm tắc đào thải Acid Uric ngay lập tức',
      'Nội tạng động vật (gan, thận, tim, lòng, tiết canh), nước hầm xương, nước lẩu ninh lâu',
      'Hải sản giàu Purine: tôm hùm, cua, ghẹ, sò huyết, hàu, nghêu, cá trích, cá cơm, cá mòi, cá thu',
      'Thịt đỏ nhiều: thịt bò, thịt dê, thịt chó, thịt trâu, thịt vịt/ngan',
      'Nước ngọt có đường Fructose cao, trà sữa, bánh kẹo ngọt'
    ],
    tips: [
      'Luộc sơ thịt rồi bỏ nước đầu giúp loại bớt một phần Purine tan trong nước.',
      'Uống đủ nước mỗi giờ và tuyệt đối không uống bia kèm hải sản/lẩu nội tạng.'
    ]
  },
  {
    id: 'da-day',
    icon: '🤕',
    name: 'Đau dạ dày / Trào ngược',
    shortName: 'Đau dạ dày',
    subtitle: 'Bảo vệ niêm mạc dạ dày, trung hòa acid, tránh ợ chua & đau thượng vị',
    eat: [
      { cat: '🍚 Tinh bột mềm thấm acid', items: 'Cơm mềm, cháo trắng/cháo thịt bằm, bánh mì nướng giòn, khoai lang, khoai tây hầm, yến mạch' },
      { cat: '🥬 Rau củ lành tính', items: 'Bắp cải (giàu Vitamin U lành vết loét!), bí đỏ, cà rốt, đậu bắp (chất nhầy bảo vệ niêm mạc), mồng tơi, rau ngót' },
      { cat: '🐟 Đạm dễ tiêu', items: 'Thịt nạc băm, cá hấp, ức gà luộc, trứng hấp/luộc chín, đậu phụ non' },
      { cat: '🍌 Trái cây & Hỗ trợ', items: 'Chuối chín, đu đủ chín, táo chín, bơ, tinh bột nghệ mật ong ấm (uống lượng nhỏ trước ăn 30p)' }
    ],
    limit: [
      'Sữa tươi đặc uống lúc bụng rỗng, nên dùng sữa chua ăn SAU bữa chính',
      'Canh quá nhiều nước chan ngập cơm (làm loãng dịch vị, khó nhai kỹ)'
    ],
    avoid: [
      'Đồ chua gắt lúc đói: chanh, giấm, xoài xanh, cóc, me, khế, dưa muối chua, cà muối, cam/dứa chua',
      'Đồ cay nóng: ớt, tiêu nhiều, sa tế, mù tạt, tỏi sống nhiều, lẩu Thái cay nồng',
      'Cà phê đen đặc, trà đặc lúc đói, nước ngọt có gas, bia rượu, thuốc lá',
      'Đồ chiên rán nhiều dầu mỡ, đồ ăn quá cứng/dai, sô-cô-la & bạc hà (gây trào ngược)'
    ],
    tips: [
      'Ăn đúng giờ, nhai kỹ nuốt chậm, không để bụng quá đói hoặc ăn quá no.',
      'KHÔNG nằm ngay sau ăn — đợi ít nhất 2–3 tiếng mới nằm ngủ và kê cao đầu giường 15cm nếu hay trào ngược.'
    ]
  },
  {
    id: 'than',
    icon: '🫘',
    name: 'Bệnh Thận / Sỏi thận',
    shortName: 'Bệnh Thận / Sỏi',
    subtitle: 'Giảm gánh nặng lọc muối, đạm dư & Oxalate cho thận (luôn theo chỉ định bác sĩ)',
    eat: [
      { cat: '🥬 Rau củ ít Kali & Oxalate', items: 'Bắp cải, súp lơ trắng, bí đao, su su, dưa chuột, ớt chuông đỏ, hành tây, tỏi' },
      { cat: '🥚 Đạm chất lượng cao (vừa phải)', items: 'Lòng trắng trứng, cá tươi hấp, thịt gà nạc lượng kiểm soát theo giai đoạn bệnh' },
      { cat: '🍎 Trái cây an toàn hơn', items: 'Táo, lê, nho, dứa, việt quất, dưa hấu (lượng vừa — suy thận nặng hỏi bác sĩ về lượng nước)' },
      { cat: '💧 Người bị Sỏi thận (không suy thận)', items: 'Uống 2.5L nước lọc/ngày + nước chanh tươi loãng giúp ngăn kết tinh sỏi Canxi-Oxalate' }
    ],
    limit: [
      'Lượng đạm (thịt, cá, đậu) vừa đủ — ăn quá nhiều đạm bắt thận làm việc quá tải',
      'Nếu suy thận độ 3–5: hạn chế chuối, cam, bơ, khoai tây, cà chua (giàu Kali) và đậu/hạt (giàu Phốt pho)'
    ],
    avoid: [
      'Ăn mặn: muối, nước mắm, bột canh, dưa cà muối, mì ăn liền, đồ hộp, xúc xích, chả lụa mặn',
      'Nước ngọt có gas màu đậm (chứa nhiều axit photphoric hại thận!), trà đặc, nước tăng lực',
      'Người sỏi thận Oxalate: tránh ăn quá nhiều cải bó xôi, khế chua, sô-cô-la, củ dền, đậu phộng rang',
      'Tự ý uống thuốc giảm đau bừa bãi hoặc thuốc lá cây không rõ nguồn gốc'
    ],
    tips: [
      'Người Sỏi thận cần uống nhiều nước; ngược lại người Suy thận nặng/phù cần tuân thủ định mức nước bác sĩ kê.',
      'Luộc rau với nhiều nước rồi chắt bỏ nước luộc giúp giảm đáng kể lượng Kali trong rau củ.'
    ]
  },
  {
    id: 'xuong-khop',
    icon: '🦴',
    name: 'Xương khớp / Loãng xương',
    shortName: 'Xương khớp',
    subtitle: 'Bổ sung Canxi, Vitamin D, Collagen & thực phẩm chống viêm khớp cho người lớn tuổi',
    eat: [
      { cat: '🐟 Giàu Canxi & Omega-3', items: 'Cá nhỏ ăn cả xương (cá cơm, cá mòi), tôm tép đồng, cá hồi, cá thu, sữa/sữa chua ít đường giàu Canxi' },
      { cat: '🥬 Rau xanh giàu Canxi & K', items: 'Bông cải xanh, cải chíp, cải xoăn, rau dền, đậu phụ, mè đen (vừng đen), hạnh nhân' },
      { cat: '🍲 Chống viêm tự nhiên', items: 'Nghệ tươi, gừng, tỏi, dầu ô liu, nấm, quả bơ, quả mọng, nước hầm xương vừa phải bỏ váng mỡ' }
    ],
    limit: [
      'Cà phê, trà đặc (quá 2 ly/ngày làm tăng thải Canxi qua nước tiểu)',
      'Đồ ăn mặn (ăn nhiều muối khiến cơ thể mất Canxi nhanh hơn)'
    ],
    avoid: [
      'Nước ngọt có gas (acid photphoric làm giảm hấp thu Canxi & gây loãng xương)',
      'Đồ chiên rán nhiều dầu công nghiệp, thức ăn nhanh, đường ngọt nhiều (tăng phản ứng viêm đau khớp)',
      'Rượu bia, thuốc lá; người đang viêm khớp nặng hạn chế thịt đỏ nhiều mỡ & nội tạng'
    ],
    tips: [
      'Tắm nắng nhẹ 15 phút buổi sáng (7h–8h30) giúp tự tổng hợp Vitamin D hấp thu Canxi vào xương!',
      'Giữ cân nặng hợp lý để giảm áp lực trực tiếp lên khớp gối và cột sống.'
    ]
  },
  {
    id: 'me-bau',
    icon: '🤰',
    name: 'Mẹ bầu / Sau sinh',
    shortName: 'Mẹ bầu / Sau sinh',
    subtitle: 'Đủ Sắt, Acid Folic, Canxi, DHA cho mẹ khỏe – bé thông minh, lợi sữa ít tăng cân thừa',
    eat: [
      { cat: '🥩 Giàu Sắt & Đạm sạch', items: 'Thịt bò nạc nấu chín kỹ, trứng gà chín kỹ, cá hồi/cá chép/cá quả, tôm, đậu phụ' },
      { cat: '🥬 Giàu Acid Folic & Xơ', items: 'Bông cải xanh, rau bó xôi, rau ngót (tốt sau sinh; bầu 3 tháng đầu tránh rau ngót!), măng tây, bơ' },
      { cat: '🥛 Canxi & Lợi sữa', items: 'Sữa tươi tiệt trùng ít đường, sữa chua, hạt óc chó, hạnh nhân, mè đen, chè vằng/nước ấm (sau sinh)' },
      { cat: '🍊 Trái cây tươi', items: 'Cam, bưởi, ổi, chuối, táo, thanh long, dâu tây, nước dừa (từ tháng thứ 4 trở đi)' }
    ],
    limit: [
      'Đường, cơm trắng quá nhiều & bánh ngọt (phòng tiểu đường thai kỳ!)',
      'Trà, cà phê (dưới 1 ly nhạt/ngày hoặc bỏ hẳn khi mang thai)'
    ],
    avoid: [
      'Đồ sống/tái: gỏi cá sống, sushi sống, thịt bò tái, trứng lòng đào, tiết canh, sữa chưa tiệt trùng',
      'Cá biển lớn nhiều thủy ngân: cá kiếm, cá mập, cá thu vua (chỉ ăn cá hồi, cá chép, cá thu nhỏ)',
      'Rượu bia, thuốc lá, nước tăng lực, nước ngọt có gas',
      'Mẹ bầu 3 tháng đầu tránh: đu đủ xanh, dứa xanh nhiều, rau ngót nhiều, rau răm, ngải cứu nhiều'
    ],
    tips: [
      'Ăn "chất" thay vì "ăn cho 2 người" để vào con nhiều, mẹ ít bị tiểu đường thai kỳ.',
      'Uống 2.5–3 lít nước ấm/ngày (nhất là mẹ đang cho con bú để sữa về dồi dào).'
    ]
  },
  {
    id: 'tre-nho',
    icon: '👶',
    name: 'Trẻ nhỏ / Tăng chiều cao',
    shortName: 'Trẻ nhỏ',
    subtitle: 'Đủ Canxi, Kẽm, Protein, Vitamin A–D giúp bé ăn ngon, cao lớn, tăng đề kháng',
    eat: [
      { cat: '🥛 Giàu Canxi & Đạm tăng cao', items: 'Sữa tươi không/ít đường, phô mai, sữa chua, trứng gà, cá hồi/cá lóc gỡ kỹ xương, thịt bò, tôm, đậu phụ' },
      { cat: '🥦 Rau củ nhiều màu sắc', items: 'Bông cải xanh, cà rốt, bí đỏ, rau ngót, mồng tơi, khoai lang, quả bơ' },
      { cat: '🍓 Trái cây tươi nguyên miếng', items: 'Chuối, cam, đu đủ, táo, dâu tây, thanh long (ăn miếng mềm tốt hơn uống nước ép)' }
    ],
    limit: [
      'Bánh kẹo, kem, đồ ăn vặt trước bữa cơm chính (làm bé ngang bụng, biếng ăn bữa chính)',
      'Muối & gia vị mặn cho bé dưới 2 tuổi (nêm cực nhạt để bảo vệ thận non nớt của bé)'
    ],
    avoid: [
      'Nước ngọt có gas, trà sữa, cà phê, trà đặc, nước tăng lực',
      'Đồ ăn nhanh chiên rán nhiều dầu mỡ, xúc xích công nghiệp, snack quá mặn nhiều phẩm màu',
      'Trẻ dưới 1 tuổi: TUYỆT ĐỐI KHÔNG cho ăn mật ong, sữa bò tươi nguyên chất và các loại hạt dễ hóc!'
    ],
    tips: [
      'Cho bé ngủ sớm trước 21h30–22h00 — hormone tăng trưởng chiều cao tiết mạnh nhất lúc ngủ sâu 22h–2h sáng!',
      'Tắt TV/điện thoại khi ăn, trình bày đĩa cơm đẹp mắt và không ép bé ăn trong căng thẳng.'
    ]
  },
  {
    id: 'giam-can',
    icon: '💪',
    name: 'Giảm cân / Tập Gym',
    shortName: 'Giảm cân / Gym',
    subtitle: 'Thâm hụt Calo lành mạnh, giàu Protein giữ cơ – đốt mỡ, không bị mệt mỏi',
    eat: [
      { cat: '🍗 Protein cao ít béo', items: 'Ức gà, trứng, cá ngừ/cá hồi/cá basa, thịt bò thăn, tôm, đậu phụ, sữa chua Hy Lạp' },
      { cat: '🍠 Tinh bột sạch đủ năng lượng', items: 'Khoai lang, yến mạch, gạo lứt, bánh mì nguyên cám, ngô luộc' },
      { cat: '🥗 Rau xanh ăn thoải mái', items: 'Xà lách, bông cải, dưa leo, cà chua bi, măng tây, cải thìa, nấm các loại' },
      { cat: '🥑 Chất béo lành mạnh', items: 'Quả bơ, hạt hạnh nhân, hạt chia, dầu ô liu (1 thìa nhỏ/bữa)' }
    ],
    limit: [
      'Sốt trộn salad đóng chai (mayonnaise, mè rang béo — rất nhiều calo ẩn!)',
      'Trái cây quá nhiều đường (sầu riêng, mít, xoài chín ngọt) ăn ít lại'
    ],
    avoid: [
      'Trà sữa full topping, nước ngọt, nước ép đóng chai, cà phê sữa nhiều đường, bia rượu',
      'Đồ chiên rán ngập dầu, bánh ngọt, bánh rán, snack, mì tôm đêm',
      'Nhịn ăn cực đoan bỏ bữa hoàn toàn (gây mất cơ, tụt huyết áp và dễ tăng cân lại!)'
    ],
    tips: [
      'Uống 1 ly nước lọc trước bữa ăn 15 phút và ăn đủ Protein (~1.2–1.6g/kg) để no lâu.',
      'Ăn 1 quả chuối hoặc 1 lát bánh mì nguyên cám trước tập 45 phút; bổ sung đạm + rau sau tập.'
    ]
  },
  {
    id: 'dang-om',
    icon: '🤒',
    name: 'Đang ốm / Cảm sốt / Hồi phục',
    shortName: 'Đang ốm / Sốt',
    subtitle: 'Mềm ấm dễ tiêu, bù nước điện giải & tăng Vitamin C giúp nhanh lại sức',
    eat: [
      { cat: '🥣 Món nước ấm dễ tiêu', items: 'Cháo gà gừng hành tía tô, cháo thịt bằm cà rốt, súp gà nấm, phở gà ít béo, canh rau ngót thịt băm' },
      { cat: '🍊 Bù nước & Vitamin C', items: 'Nước ấm, oresol đúng tỷ lệ, nước cam/chanh ấm mật ong (trẻ >1 tuổi), nước dừa tươi, ổi, bưởi' },
      { cat: '🥚 Đạm nhẹ hồi sức', items: 'Trứng hấp mềm, cá hấp gừng, đậu phụ non, sữa ấm/sữa chua (khi không tiêu chảy)' }
    ],
    limit: [
      'Đồ ăn quá nhiều chất xơ cứng hoặc khó tiêu lúc đang đau bụng/tiêu chảy'
    ],
    avoid: [
      'Đồ chiên rán nhiều dầu mỡ, thịt mỡ, đồ nướng khó tiêu',
      'Nước đá lạnh, kem, nước ngọt có gas (kích thích cổ họng ho nặng hơn)',
      'Đồ cay nóng, rượu bia, cà phê (gây mất nước & cản trở giấc ngủ hồi phục)'
    ],
    tips: [
      'Chia thành 4–5 bữa nhỏ mềm ấm trong ngày để người ốm dễ nuốt mà vẫn đủ năng lượng chống virus.',
      'Bù nước liên tục từng ngụm nhỏ nếu đang sốt cao.'
    ]
  }
];

const FOOD_DB = [
  { name: 'Cơm trắng', kw: 'com trang com te', def: 'ok', map: { 'tieu-duong': 'limit', 'bung-to': 'limit', 'giam-can': 'limit', 'mo-mau': 'limit' }, note: 'Chỉ số đường huyết cao; người tiểu đường & bụng to nên ăn ½ bát nhỏ và ăn SAU rau + thịt.' },
  { name: 'Gạo lứt / Cơm gạo lứt', kw: 'gao lut com lut', def: 'ok', map: { 'da-day': 'limit', 'than': 'limit', 'dang-om': 'limit' }, note: 'Giàu chất xơ, GI thấp, cực tốt cho tiểu đường, giảm mỡ bụng & mỡ máu (người đau dạ dày cần nấu thật mềm).' },
  { name: 'Xôi / Bánh chưng / Đồ nếp', kw: 'xoi banh chung banh tet do nep', def: 'limit', map: { 'tieu-duong': 'avoid', 'bung-to': 'avoid', 'giam-can': 'avoid', 'da-day': 'avoid', 'mo-mau': 'avoid' }, note: 'Giàu tinh bột nhanh & calo, dễ làm vọt đường huyết, tích mỡ bụng và gây đầy bụng ợ chua.' },
  { name: 'Phở bò / Phở gà', kw: 'pho bo pho ga', def: 'ok', map: { 'tieu-duong': 'limit', 'bung-to': 'limit', 'huyet-ap': 'limit', 'gout': 'limit', 'mo-mau': 'limit' }, note: 'Giảm ½ bánh phở, bỏ nước béo, không húp hết nước dùng mặn & tránh bò tái (mẹ bầu/Gout).' },
  { name: 'Bún bò Huế / Bún riêu', kw: 'bun bo hue bun rieu', def: 'limit', map: { 'tieu-duong': 'limit', 'bung-to': 'avoid', 'huyet-ap': 'avoid', 'gout': 'avoid', 'da-day': 'avoid', 'mo-mau': 'avoid' }, note: 'Nước dùng nhiều mắm ruốc mặn, váng mỡ, sa tế cay & ninh xương nhiều purine.' },
  { name: 'Khoai lang luộc', kw: 'khoai lang', def: 'ok', map: { 'tieu-duong': 'limit', 'than': 'limit' }, note: 'Tinh bột chậm tuyệt vời thay cơm trắng để giảm mỡ bụng; người tiểu đường ăn ½–1 củ nhỏ luộc.' },
  { name: 'Yến mạch', kw: 'yen mach', def: 'ok', map: { 'than': 'limit' }, note: 'Siêu thực phẩm số 1 cho tiểu đường, giảm mỡ bụng, mỡ máu và tim mạch.' },
  { name: 'Bánh mì trắng / Bánh mì pate', kw: 'banh mi pate', def: 'limit', map: { 'tieu-duong': 'avoid', 'bung-to': 'avoid', 'mo-mau': 'avoid', 'giam-can': 'avoid', 'huyet-ap': 'limit' }, note: 'Bánh mì trắng GI cao, pate gan nhiều cholesterol & muối; nên đổi sang bánh mì nguyên cám + ức gà/trứng.' },
  { name: 'Mì tôm / Mì ăn liền', kw: 'mi tom mi goi mi an lien', def: 'avoid', map: {}, note: 'Chiên dầu bão hòa, cực kỳ nhiều muối & tinh bột rỗng — nên hạn chế tối đa kể cả người khỏe.' },
  { name: 'Sầu riêng', kw: 'sau rieng', def: 'limit', map: { 'tieu-duong': 'avoid', 'bung-to': 'avoid', 'giam-can': 'avoid', 'mo-mau': 'avoid', 'huyet-ap': 'limit', 'than': 'avoid' }, note: 'Rất giàu đường & calo (1 múi lớn ~300–400 kcal), làm tăng đường huyết & mỡ bụng rất nhanh.' },
  { name: 'Xoài chín', kw: 'xoai chin xoai', def: 'ok', map: { 'tieu-duong': 'avoid', 'bung-to': 'limit', 'giam-can': 'limit', 'da-day': 'limit' }, note: 'Xoài chín ngọt có đường cao (tiểu đường nên tránh hoặc chỉ 1 miếng nhỏ); xoài xanh chua tránh khi đau dạ dày.' },
  { name: 'Nhãn / Vải / Mít chín', kw: 'nhan vai mit chin', def: 'limit', map: { 'tieu-duong': 'avoid', 'bung-to': 'avoid', 'giam-can': 'avoid', 'mo-mau': 'limit' }, note: 'Hàm lượng đường rất cao, dễ gây tăng đường huyết đột ngột và nóng trong.' },
  { name: 'Ổi / Bưởi / Táo xanh', kw: 'oi buoi tao xanh thanh long', def: 'ok', map: { 'da-day': 'limit', 'huyet-ap': 'ok' }, note: 'Trái cây vàng ít đường, nhiều xơ & Vitamin C — rất hợp người tiểu đường & giảm mỡ bụng!' },
  { name: 'Chuối chín', kw: 'chuoi chin chuoi', def: 'ok', map: { 'tieu-duong': 'limit', 'than': 'avoid' }, note: 'Giàu Kali tốt cho huyết áp, dạ dày & tập Gym; tiểu đường chỉ ăn ½ quả chín tới; suy thận nặng cần tránh.' },
  { name: 'Dưa hấu', kw: 'dua hau', def: 'ok', map: { 'tieu-duong': 'limit', 'than': 'limit' }, note: 'Thanh mát ít calo nhưng GI khá cao — người tiểu đường chỉ ăn 1–2 miếng nhỏ.' },
  { name: 'Quả bơ', kw: 'qua bo trai bo', def: 'ok', map: { 'than': 'limit', 'giam-can': 'limit' }, note: 'Giàu chất béo tốt hạ mỡ máu, cực tốt cho tiểu đường, tim mạch & mẹ bầu.' },
  { name: 'Thịt ba chỉ / Thịt mỡ', kw: 'thit ba chi thit mo chan gio', def: 'limit', map: { 'tieu-duong': 'avoid', 'bung-to': 'avoid', 'huyet-ap': 'avoid', 'mo-mau': 'avoid', 'gout': 'avoid', 'giam-can': 'avoid' }, note: 'Nhiều chất béo bão hòa & calo — gây tích mỡ bụng, tăng mỡ máu, hại tim mạch & gan nhiễm mỡ.' },
  { name: 'Ức gà / Thịt nạc thăn', kw: 'uc ga thit nac than', def: 'ok', map: { 'gout': 'limit', 'than': 'limit' }, note: 'Nguồn đạm sạch tuyệt vời cho giảm mỡ bụng, tiểu đường, Gym & mỡ máu.' },
  { name: 'Thịt bò', kw: 'thit bo', def: 'ok', map: { 'gout': 'avoid', 'mo-mau': 'limit', 'huyet-ap': 'limit', 'than': 'limit' }, note: 'Giàu sắt tốt cho mẹ bầu & trẻ nhỏ (nấu chín kỹ); người Gout cần kiêng vì nhiều Purine.' },
  { name: 'Cá hồi / Cá thu / Cá đồng', kw: 'ca hoi ca thu ca loc ca chep ca dong', def: 'ok', map: { 'gout': 'limit', 'than': 'limit' }, note: 'Giàu Omega-3 cực tốt cho tim mạch, tiểu đường, mỡ máu, xương khớp & giảm mỡ bụng.' },
  { name: 'Tôm / Cua / Hải sản / Ốc', kw: 'tom cua ghe hai san oc hau so muc', def: 'ok', map: { 'gout': 'avoid', 'mo-mau': 'limit', 'than': 'limit' }, note: 'Giàu đạm & Canxi (tốt cho xương khớp, bụng to nếu hấp/luộc), NHƯNG người bị Gout phải KIÊNG!' },
  { name: 'Lòng heo / Gan / Nội tạng', kw: 'long heo noi tang gan tim bau duc tiet canh', def: 'avoid', map: {}, note: 'Cực kỳ nhiều Cholesterol & Purine — đại kỵ với Gout, mỡ máu, gan nhiễm mỡ, tim mạch & bụng to.' },
  { name: 'Trứng gà', kw: 'trung ga trung luoc', def: 'ok', map: { 'mo-mau': 'limit', 'than': 'limit' }, note: 'Đạm chuẩn dễ tiêu, rất tốt cho tiểu đường, bụng to, Gout & trẻ nhỏ.' },
  { name: 'Trứng vịt lộn', kw: 'trung vit lon hot vit lon', def: 'limit', map: { 'mo-mau': 'avoid', 'huyet-ap': 'avoid', 'gout': 'avoid', 'tieu-duong': 'limit', 'bung-to': 'limit' }, note: 'Rất giàu Cholesterol & đạm — người mỡ máu, cao huyết áp, Gout nên tránh.' },
  { name: 'Đậu phụ / Đậu nành', kw: 'dau phu dau hu dau nanh', def: 'ok', map: { 'than': 'limit' }, note: 'Đạm thực vật lành mạnh, tốt cho tiểu đường, tim mạch, mỡ máu & giảm cân.' },
  { name: 'Rau xanh / Bông cải / Mướp đắng', kw: 'rau xanh bong cai muop dang kho qua rau muong bap cai', def: 'ok', map: { 'than': 'limit' }, note: 'Món vàng cho mọi người! Mướp đắng hỗ trợ tiểu đường; bắp cải tốt cho dạ dày.' },
  { name: 'Dưa muối / Cà pháo / Kim chi', kw: 'dua muoi ca phao kim chi mam tom', def: 'limit', map: { 'huyet-ap': 'avoid', 'than': 'avoid', 'da-day': 'avoid', 'xuong-khop': 'avoid' }, note: 'Rất mặn & chua — đại kỵ cho cao huyết áp, bệnh thận, đau dạ dày & loãng xương.' },
  { name: 'Bia / Rượu', kw: 'bia ruou nhau', def: 'avoid', map: {}, note: 'Gây tích mỡ bụng nội tạng cực nhanh, kích phát cơn đau Gout, phá gan nhiễm mỡ & tăng huyết áp.' },
  { name: 'Nước ngọt / Trà sữa', kw: 'nuoc ngot coca pepsi tra sua', def: 'avoid', map: {}, note: 'Bom đường lỏng & calo rỗng — làm vọt đường huyết, béo bụng, gan nhiễm mỡ & loãng xương.' },
  { name: 'Cà phê sữa đá', kw: 'ca phe sua da bac xiu', def: 'limit', map: { 'tieu-duong': 'avoid', 'bung-to': 'avoid', 'giam-can': 'avoid', 'da-day': 'avoid', 'huyet-ap': 'limit', 'mo-mau': 'avoid' }, note: 'Nhiều sữa đặc có đường & chất béo. Nên đổi sang cà phê đen ít/không đường sau ăn sáng.' },
  { name: 'Cà phê đen không đường', kw: 'ca phe den khong duong', def: 'ok', map: { 'da-day': 'avoid', 'huyet-ap': 'limit', 'me-bau': 'avoid', 'tre-nho': 'avoid', 'xuong-khop': 'limit', 'dang-om': 'avoid' }, note: 'Hỗ trợ đốt mỡ cho người bụng to/Gym & không làm tăng đường huyết.' },
  { name: 'Trà xanh / Nước lọc', kw: 'tra xanh nuoc loc nuoc am', def: 'ok', map: { 'da-day': 'limit', 'me-bau': 'limit' }, note: 'Đồ uống tốt nhất! Người đau dạ dày & mẹ bầu không uống trà đặc lúc đói.' },
  { name: 'Nước dừa tươi', kw: 'nuoc dua', def: 'ok', map: { 'tieu-duong': 'limit', 'than': 'avoid', 'me-bau': 'ok' }, note: 'Giải nhiệt giàu Kali; người tiểu đường uống ít (½ quả), người suy thận nặng cần tránh.' },
  { name: 'Sữa chua không đường', kw: 'sua chua khong duong', def: 'ok', map: { 'than': 'limit' }, note: 'Rất tốt cho tiêu hóa, tiểu đường, giảm mỡ bụng, xương khớp, Gout & trẻ nhỏ.' },
  { name: 'Đồ chiên rán / Gà rán', kw: 'do chien ran ga ran khoai tay chien quay', def: 'avoid', map: {}, note: 'Nhiều dầu mỡ chuyển hóa & calo — tăng mỡ bụng, mỡ máu, viêm khớp và hại dạ dày.' },
  { name: 'Lẩu cay / Lẩu Thái', kw: 'lau thai lau cay', def: 'limit', map: { 'da-day': 'avoid', 'gout': 'avoid', 'huyet-ap': 'avoid', 'bung-to': 'limit', 'tieu-duong': 'limit' }, note: 'Nước lẩu mặn, cay, nhiều purine; nên ưu tiên lẩu nấm/lẩu rau thanh đạm, nhúng nhiều rau + cá/thịt nạc.' },
  { name: 'Cháo gà / Súp nóng', kw: 'chao ga chao thit sup', def: 'ok', map: { 'tieu-duong': 'avoid', 'bung-to': 'limit' }, note: 'Tuyệt vời cho người ốm & đau dạ dày, NHƯNG người tiểu đường cần tránh cháo trắng nấu nhừ!' },
  { name: 'Hạt óc chó / Hạnh nhân (không muối)', kw: 'hat oc cho hanh nhan hat dieu', def: 'ok', map: { 'than': 'limit', 'tre-nho': 'limit' }, note: 'Bữa phụ vàng cho tiểu đường, bụng to, tim mạch, mẹ bầu & xương khớp (~25–30g/ngày).' }
];

const QUICK_AI_PROMPTS = [
  '👵 Bà 70 tuổi bị tiểu đường nên ăn gì, kiêng gì? Gợi ý thực đơn 1 ngày dễ nhai',
  '👨 Bố bụng to, hay phải đi nhậu nên ăn gì & kiêng gì để giảm mỡ bụng?',
  '🏠 Nhà có bà tiểu đường + bố bụng to + con nhỏ, lên mâm cơm tối cả nhà cùng ăn được',
  '🥭 Bà bị tiểu đường ăn xoài, sầu riêng, phở bò, cháo trắng có được không?'
];

function loadSavedProfiles() {
  try {
    const arr = JSON.parse(localStorage.getItem(DIET_PROFILES_KEY) || '[]');
    return Array.isArray(arr) ? arr : [];
  } catch (_e) { return []; }
}

function saveProfiles(arr) {
  try { localStorage.setItem(DIET_PROFILES_KEY, JSON.stringify((arr || []).slice(0, 12))); } catch (_e) {}
}

export function mountDietGuideModule(mountEl, opts = {}) {
  if (!mountEl) return;
  const {
    embedded = false,
    getState = () => ({}),
    onBack = () => {},
    onOpenGeminiSettings = () => {},
    onSendTelegram = null
  } = opts;

  // Default: start with NO forced illness (or user picks from dropdown checklist freely!)
  let selectedIds = new Set(['tieu-duong']);
  let memberRole = '👵 Bà';
  let dropdownOpen = false;
  let savedProfiles = loadSavedProfiles();
  let lastAiText = '';
  let busy = false;
  let dietVoiceRec = null;

  mountEl.innerHTML = `
    <div class="sf-wrap">
      ${embedded ? '' : `
      <div class="sf-hero theme-emerald">
        <div>
          <h2 class="sf-hero-title">🥗 Ăn Kiêng &amp; Dinh Dưỡng Gia Đình</h2>
          <div class="sf-hero-sub">Sổ danh sách tích chọn bệnh lý / thể trạng (hoặc bỏ tích nếu không bệnh nền) — Tra Nên ăn / Kiêng ăn &amp; AI lên thực đơn.</div>
        </div>
        <button type="button" class="sf-back-btn" data-el="btn-back">← Thêm</button>
      </div>`}

      <!-- Family Member + Collapsible Checkbox Dropdown -->
      <div class="sf-card">
        <div class="sf-btn-row" style="justify-content:space-between;margin-bottom:6px;">
          <strong style="font-size:13px;color:#065F46;">👨‍👩‍👧‍👦 Chọn người ăn &amp; Tình trạng sức khỏe</strong>
          <button type="button" data-el="btn-save-profile" class="sf-btn emerald" style="padding:4px 9px;font-size:11px;">💾 Lưu hồ sơ</button>
        </div>

        <div class="sf-pills" data-el="member-pills" style="margin-bottom:8px;">
          <button type="button" class="sf-pill active" data-mem="👵 Bà">👵 Bà</button>
          <button type="button" class="sf-pill" data-mem="👴 Ông">👴 Ông</button>
          <button type="button" class="sf-pill" data-mem="👨 Bố">👨 Bố</button>
          <button type="button" class="sf-pill" data-mem="👩 Mẹ">👩 Mẹ</button>
          <button type="button" class="sf-pill" data-mem="👶 Con nhỏ">👶 Con nhỏ</button>
          <button type="button" class="sf-pill" data-mem="💑 Vợ/Chồng">💑 Vợ/Chồng</button>
          <button type="button" class="sf-pill" data-mem="👤 Bản thân">👤 Bản thân</button>
        </div>

        <!-- Collapsible Multi-Select Checkbox Dropdown -->
        <div class="diet-dd-wrap">
          <button type="button" class="diet-dd-trigger" data-el="dd-trigger">
            <div style="min-width:0;flex:1;text-align:left;">
              <div style="font-size:11px;font-weight:700;color:#047857;">🩺 Bệnh lý / Mục tiêu kiêng cữ (chạm để sổ list tích hoặc bỏ tích):</div>
              <div data-el="dd-summary" style="font-size:12.5px;font-weight:800;color:#111827;margin-top:2px;"></div>
            </div>
            <span data-el="dd-arrow" style="font-size:13px;font-weight:900;color:#047857;">▼</span>
          </button>

          <div class="diet-dd-panel hidden" data-el="dd-panel">
            <div class="diet-dd-actions">
              <span style="font-size:11.5px;font-weight:700;color:#475569;">Tích chọn 1, nhiều hoặc bỏ trống hết nếu không có bệnh nền:</span>
              <div style="display:flex;gap:5px;">
                <button type="button" class="sf-btn" data-el="btn-clear-all" style="padding:3px 8px;font-size:11px;color:#DC2626;">🧹 Bỏ tích hết</button>
                <button type="button" class="sf-btn emerald" data-el="btn-dd-done" style="padding:3px 9px;font-size:11px;">✓ Xong</button>
              </div>
            </div>
            <div class="diet-check-grid" data-el="check-grid">
              ${DIET_CONDITIONS.map((c) => `
                <label class="diet-check-item">
                  <input type="checkbox" value="${c.id}" ${selectedIds.has(c.id) ? 'checked' : ''} />
                  <span>${c.icon} ${escHtml(c.shortName)}</span>
                </label>
              `).join('')}
            </div>
          </div>
        </div>

        <div data-el="saved-list" class="diet-saved-list" style="margin-top:8px;"></div>
      </div>

      <!-- Instant Food Checker ("Món này ăn được không?") -->
      <div class="sf-card diet-checker-card">
        <h3 class="sf-card-title" style="color:#065F46;">🔍 Kiểm tra nhanh: "Món này ăn được không?"</h3>
        <div class="sf-btn-row" style="flex-wrap:nowrap;margin-bottom:6px;">
          <input data-el="food-search" type="text" placeholder="Gõ tên món ăn, trái cây (VD: sầu riêng, phở bò, bia, cơm trắng, ổi, tôm...)" style="flex:1;min-width:0;padding:8px 10px;border:1px solid #A7F3D0;border-radius:9px;font-size:13px;" />
          <button type="button" data-el="btn-food-ai" class="sf-btn ai" style="white-space:nowrap;">✨ Hỏi AI</button>
        </div>
        <div class="sf-pills" data-el="food-quick" style="margin-bottom:6px;">
          <button type="button" class="sf-pill" data-fq="Cơm trắng">🍚 Cơm trắng</button>
          <button type="button" class="sf-pill" data-fq="Sầu riêng">🍈 Sầu riêng</button>
          <button type="button" class="sf-pill" data-fq="Phở bò">🍜 Phở bò</button>
          <button type="button" class="sf-pill" data-fq="Bia">🍺 Bia/Rượu</button>
          <button type="button" class="sf-pill" data-fq="Thịt ba chỉ">🥓 Thịt ba chỉ</button>
          <button type="button" class="sf-pill" data-fq="Ổi">🍐 Ổi/Bưởi</button>
          <button type="button" class="sf-pill" data-fq="Tôm">🦐 Hải sản</button>
          <button type="button" class="sf-pill" data-fq="Cà phê sữa">☕ Cà phê sữa</button>
        </div>
        <div data-el="food-result"></div>
      </div>

      <!-- Offline Eat / Limit / Avoid Guide -->
      <div class="sf-card">
        <div class="sf-btn-row" style="justify-content:space-between;margin-bottom:8px;">
          <strong data-el="board-title" style="font-size:13.5px;color:#065F46;">📋 Cẩm nang Nên ăn &amp; Kiêng ăn</strong>
          <button type="button" data-el="btn-share-offline" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Gửi Zalo bảng này</button>
        </div>
        <div data-el="guide-body"></div>
      </div>

      <!-- Gemini AI Custom Dietician & 1-Day Menu -->
      <div class="sf-card" style="border-color:#DDD6FE;background:linear-gradient(180deg,#FAF5FF 0%,#FFFFFF 100%);">
        <h3 class="sf-card-title" style="color:#5B21B6;">✨ Chuyên gia Dinh dưỡng AI — Tư vấn &amp; Lên Thực đơn</h3>
        <div class="sf-field">
          <label>💬 Nhập chi tiết tình trạng / tuổi / sở thích (hoặc bấm 🎙️ để nói):</label>
          <div class="sf-btn-row" style="flex-wrap:nowrap;">
            <input data-el="ai-inp" type="text" placeholder='VD: "Bà 72 tuổi tiểu đường răng yếu thích ăn cá" hoặc "Bố 45 tuổi bụng bia"...' maxlength="260" style="flex:1;min-width:0;" />
            <button type="button" data-el="btn-voice" class="sf-btn" title="Nói yêu cầu tiếng Việt">🎙️</button>
          </div>
        </div>
        <div class="sf-pills" data-el="ai-chips">
          ${QUICK_AI_PROMPTS.map((p, idx) => `<button type="button" class="sf-pill" data-qp="${idx}">${escHtml(p.slice(0, 42))}${p.length > 42 ? '…' : ''}</button>`).join('')}
        </div>
        <div class="sf-btn-row">
          <button type="button" data-el="btn-ai-menu" class="sf-btn ai" style="flex:1;">✨ AI Lên Thực Đơn 1 Ngày &amp; Danh Sách Kiêng</button>
        </div>
        <div data-el="status" class="sf-status"></div>
      </div>

      <div data-el="ai-card" class="dream-result-card hidden">
        <div class="dream-result-head">
          <strong data-el="ai-title">✨ Tư vấn Dinh dưỡng &amp; Thực đơn AI</strong>
          <div class="sf-btn-row">
            <button type="button" data-el="btn-copy" class="sf-btn" style="padding:4px 8px;font-size:11px;">📋 Chép</button>
            <button type="button" data-el="btn-zalo" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0068FF;">💬 Zalo</button>
            <button type="button" data-el="btn-tg" class="sf-btn" style="padding:4px 8px;font-size:11px;color:#0369A1;">✈️ TG</button>
          </div>
        </div>
        <div data-el="ai-body" class="dream-result-body"></div>
      </div>

      <div class="diet-disclaimer">
        ⚕️ <strong>Lưu ý y khoa:</strong> Thông tin dinh dưỡng mang tính tham khảo khoa học phổ thông hỗ trợ bữa ăn gia đình. Với người có bệnh nền nặng hoặc đang dùng thuốc kê đơn, vui lòng tuân theo hướng dẫn trực tiếp của bác sĩ điều trị.
      </div>
    </div>
  `;

  const el = (name) => mountEl.querySelector(`[data-el="${name}"]`);
  const getSelectedConds = () => DIET_CONDITIONS.filter((c) => selectedIds.has(c.id));

  const setStatus = (msg, err = false) => {
    const s = el('status');
    if (!s) return;
    s.className = err ? 'sf-status err' : 'sf-status';
    s.textContent = msg || '';
  };

  const syncCheckboxesAndSummary = () => {
    el('member-pills')?.querySelectorAll('.sf-pill').forEach((b) => {
      b.classList.toggle('active', b.dataset.mem === memberRole);
    });
    el('check-grid')?.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
      cb.checked = selectedIds.has(cb.value);
      cb.closest('.diet-check-item')?.classList.toggle('checked', cb.checked);
    });
    const conds = getSelectedConds();
    const sumEl = el('dd-summary');
    if (sumEl) {
      sumEl.textContent = conds.length === 0
        ? '✅ Không có bệnh nền (Ăn uống cân bằng khỏe mạnh)'
        : conds.map((c) => `${c.icon} ${c.shortName}`).join('  •  ');
    }
    el('dd-panel')?.classList.toggle('hidden', !dropdownOpen);
    if (el('dd-arrow')) el('dd-arrow').textContent = dropdownOpen ? '▲' : '▼';
  };

  const renderSavedProfiles = () => {
    const box = el('saved-list');
    if (!box) return;
    if (savedProfiles.length === 0) {
      box.innerHTML = '<div style="font-size:11px;color:#6B7280;">💡 Bấm <strong>💾 Lưu hồ sơ</strong> để lưu riêng cho từng người (VD: 👵 Bà: Tiểu đường, 👨 Bố: Bụng to, 👤 Bản thân: Không bệnh nền).</div>';
      return;
    }
    box.innerHTML = '';
    savedProfiles.forEach((pf) => {
      const chip = document.createElement('div');
      chip.className = 'diet-saved-chip';
      const labels = (pf.condIds || []).length === 0
        ? 'Không bệnh nền'
        : pf.condIds.map((id) => DIET_CONDITIONS.find((c) => c.id === id)?.shortName || id).join(' + ');
      chip.innerHTML = `
        <button type="button" class="diet-saved-load"><strong>${escHtml(pf.member)}</strong>: ${escHtml(labels)}</button>
        <button type="button" class="diet-saved-del" title="Xóa hồ sơ">✕</button>
      `;
      chip.querySelector('.diet-saved-load')?.addEventListener('click', () => {
        memberRole = pf.member;
        selectedIds = new Set((pf.condIds || []).filter((id) => DIET_CONDITIONS.some((c) => c.id === id)));
        syncCheckboxesAndSummary();
        renderGuideBoard();
        renderFoodCheck();
        setStatus(`✓ Đã mở hồ sơ ${pf.member} (${labels})`);
      });
      chip.querySelector('.diet-saved-del')?.addEventListener('click', () => {
        savedProfiles = savedProfiles.filter((x) => x.id !== pf.id);
        saveProfiles(savedProfiles);
        renderSavedProfiles();
      });
      box.appendChild(chip);
    });
  };

  const buildOfflineShareText = () => {
    const conds = getSelectedConds();
    if (conds.length === 0) {
      return `🥗 DINH DƯỠNG CÂN BẰNG (${memberRole} — Không bệnh nền)\n\n✅ Ăn đủ 4 nhóm: Tinh bột vừa đủ + Đạm sạch (cá/thịt nạc/trứng/đậu) + Nhiều rau xanh & trái cây tươi + Uống 2L nước/ngày.\n🚫 Hạn chế: Nước ngọt, đồ chiên dầu cũ, ăn quá mặn, rượu bia quá mức.`;
    }
    const title = `${memberRole} — ${conds.map((c) => `${c.icon} ${c.name}`).join(' + ')}`;
    const lines = [`🥗 CHẾ ĐỘ ĂN KIÊNG & DINH DƯỠNG: ${title}`, ''];
    lines.push('✅ NÊN ĂN:');
    conds.forEach((c) => {
      if (conds.length > 1) lines.push(`[${c.shortName}]`);
      c.eat.forEach((e) => lines.push(`• ${e.cat}: ${e.items}`));
    });
    lines.push('', '🚫 KHÔNG NÊN ĂN / KIÊNG:');
    conds.forEach((c) => c.avoid.forEach((a) => lines.push(`• ${a}${conds.length > 1 ? ` (${c.shortName})` : ''}`)));
    lines.push('', '⚠️ ĂN HẠN CHẾ:');
    conds.forEach((c) => c.limit.forEach((l) => lines.push(`• ${l}`)));
    lines.push('', '💡 MẸO HAY:');
    conds.forEach((c) => c.tips.forEach((t) => lines.push(`• ${t}`)));
    return lines.join('\n');
  };

  const renderGuideBoard = () => {
    const conds = getSelectedConds();
    if (conds.length === 0) {
      el('board-title').textContent = `📋 ${memberRole}: Không có bệnh nền (Dinh dưỡng cân bằng)`;
      el('guide-body').innerHTML = `
        <div class="diet-section-box good">
          <div class="diet-section-head">✅ NGUYÊN TẮC ĂN UỐNG KHỎE MẠNH (Không cần kiêng bệnh lý)</div>
          <div class="diet-section-content">
            <div class="diet-row-item"><strong>🥦 Rau củ &amp; Trái cây tươi:</strong> Chiếm ½ khẩu phần mỗi bữa giúp đẹp da, khỏe tiêu hóa, phòng bệnh mạn tính.</div>
            <div class="diet-row-item"><strong>🐟 Đạm đa dạng:</strong> Luân phiên cá (2–3 bữa/tuần), thịt nạc, gia cầm bỏ da, trứng, đậu phụ &amp; sữa chua.</div>
            <div class="diet-row-item"><strong>🍚 Tinh bột vừa phải:</strong> Cơm, khoai, ngô, bún phở cân đối theo mức vận động; ăn tối nhẹ hơn bữa trưa.</div>
          </div>
        </div>
        <div class="diet-section-box warn">
          <div class="diet-section-head">⚠️ NÊN HẠN CHẾ ĐỂ PHÒNG BỆNH LÂU DÀI</div>
          <ul class="diet-ul">
            <li>Nước ngọt có gas, trà sữa nhiều đường, đồ chiên ngập dầu cũ, mì ăn liền, đồ muối quá mặn &amp; rượu bia quá mức.</li>
            <li>Nếu muốn xem kiêng cữ cho một bệnh cụ thể (Tiểu đường, Bụng to, Gout...), chạm ô <strong>"🩺 Bệnh lý / Mục tiêu kiêng cữ ▼"</strong> ở trên để tích chọn!</li>
          </ul>
        </div>
      `;
      return;
    }

    el('board-title').textContent = `📋 ${memberRole}: ${conds.map((c) => c.shortName).join(' + ')}`;
    const multi = conds.length > 1;
    const eatHtml = conds.map((c) => `
      ${multi ? `<div class="diet-sub-tag good">${c.icon} Nhóm tốt cho ${escHtml(c.shortName)}:</div>` : ''}
      ${c.eat.map((e) => `<div class="diet-row-item"><strong>${escHtml(e.cat)}:</strong> ${escHtml(e.items)}</div>`).join('')}
    `).join('');
    const limitHtml = conds.flatMap((c) => c.limit.map((l) => `<li>${escHtml(l)}${multi ? ` <span class="diet-mini-lbl">(${escHtml(c.shortName)})</span>` : ''}</li>`)).join('');
    const avoidHtml = conds.flatMap((c) => c.avoid.map((a) => `<li>${escHtml(a)}${multi ? ` <span class="diet-mini-lbl bad">(${escHtml(c.shortName)})</span>` : ''}</li>`)).join('');
    const tipsHtml = conds.flatMap((c) => c.tips.map((t) => `<li>${escHtml(t)}</li>`)).join('');

    el('guide-body').innerHTML = `
      <div class="diet-section-box good">
        <div class="diet-section-head">✅ NÊN ĂN (Thực phẩm vàng)</div>
        <div class="diet-section-content">${eatHtml}</div>
      </div>
      <div class="diet-section-box bad">
        <div class="diet-section-head">🚫 KHÔNG NÊN ĂN / KIÊNG</div>
        <ul class="diet-ul">${avoidHtml}</ul>
      </div>
      <div class="diet-section-box warn">
        <div class="diet-section-head">⚠️ ĂN HẠN CHẾ (Lượng ít / Có điều kiện)</div>
        <ul class="diet-ul">${limitHtml}</ul>
      </div>
      <div class="diet-section-box tip">
        <div class="diet-section-head">💡 Mẹo ăn uống &amp; sinh hoạt hiệu quả</div>
        <ul class="diet-ul">${tipsHtml}</ul>
      </div>
    `;
  };

  const evaluateFoodForSelected = (food) => {
    const conds = getSelectedConds();
    if (conds.length === 0) return { worst: food.def || 'ok', perCond: [] };
    const rank = { ok: 0, limit: 1, avoid: 2 };
    let worst = 'ok';
    const perCond = conds.map((c) => {
      const r = food.map?.[c.id] || food.def || 'ok';
      if (rank[r] > rank[worst]) worst = r;
      return { cond: c, rating: r };
    });
    return { worst, perCond };
  };

  const renderFoodCheck = () => {
    const box = el('food-result');
    if (!box) return;
    const raw = (el('food-search')?.value || '').trim();
    if (!raw) {
      box.innerHTML = '<div style="font-size:11.5px;color:#6B7280;">Chạm chip món ăn phía trên hoặc gõ tên món (VD: <em>xoài, bia, cơm trắng, sầu riêng, tôm...</em>) để kiểm tra ngay!</div>';
      return;
    }
    const qn = normVn(raw);
    const matches = FOOD_DB.filter((f) => {
      const hay = normVn(`${f.name} ${f.kw}`);
      return hay.includes(qn) || qn.split(/\s+/).filter((w) => w.length >= 2).some((w) => hay.includes(w));
    }).slice(0, 6);

    if (matches.length === 0) {
      box.innerHTML = `
        <div class="diet-food-empty">
          Chưa có <strong>"${escHtml(raw)}"</strong> trong từ điển ngoại tuyến — bấm <strong>✨ Hỏi AI</strong> bên cạnh để Chuyên gia Dinh dưỡng AI đánh giá chi tiết cho ${escHtml(memberRole)}!
        </div>
      `;
      return;
    }

    const badgeMap = {
      ok: { cls: 'good', txt: '🟢 NÊN ĂN' },
      limit: { cls: 'warn', txt: '🟡 ĂN ÍT / HẠN CHẾ' },
      avoid: { cls: 'bad', txt: '🔴 KHÔNG NÊN / KIÊNG' }
    };

    box.innerHTML = matches.map((f) => {
      const { worst, perCond } = evaluateFoodForSelected(f);
      const b = badgeMap[worst];
      const condBadges = perCond.length > 1
        ? `<div class="diet-food-subbadges">${perCond.map((p) => `<span class="sf-badge ${badgeMap[p.rating].cls}">${p.cond.icon} ${escHtml(p.cond.shortName)}: ${p.rating === 'ok' ? 'Được' : p.rating === 'limit' ? 'Ít' : 'Kiêng'}</span>`).join(' ')}</div>`
        : '';
      return `
        <div class="diet-food-item ${b.cls}">
          <div class="sf-kv-head">
            <strong>${escHtml(f.name)}</strong>
            <span class="sf-badge ${b.cls}">${b.txt}</span>
          </div>
          ${condBadges}
          <div style="font-size:11.5px;color:#374151;line-height:1.45;margin-top:3px;">${escHtml(f.note)}</div>
        </div>
      `;
    }).join('');
  };

  const askDietAi = async (customQuestion = '') => {
    if (busy) return;
    const st = getState();
    if (!isGeminiConfigured(st?.geminiSettings)) {
      el('status').className = 'sf-status err';
      el('status').innerHTML = '🔑 Chưa nhập Gemini API Key. <button type="button" class="sf-btn ai" style="padding:3px 8px;font-size:11px;" data-el="btn-cfg">Nhập Key</button>';
      el('btn-cfg')?.addEventListener('click', onOpenGeminiSettings);
      return;
    }

    const conds = getSelectedConds();
    const condText = conds.length > 0
      ? conds.map((c) => `${c.name} (${c.subtitle})`).join('; ')
      : 'Không có bệnh nền (ăn uống cân bằng khỏe mạnh)';
    const userNote = (customQuestion || el('ai-inp')?.value || '').trim();

    busy = true;
    el('btn-ai-menu').disabled = true;
    el('btn-food-ai').disabled = true;
    setStatus('✨ Chuyên gia Dinh dưỡng AI đang phân tích thực phẩm Nên ăn / Kiêng ăn & lên thực đơn...');
    el('ai-card').classList.remove('hidden');
    el('ai-body').innerHTML = '✨ Đang soạn hướng dẫn dinh dưỡng chuẩn Việt Nam...';

    try {
      const prompt = `${userNote ? `🎯 CÂU HỎI / HOÀN CẢNH CỤ THỂ CỦA GIA ĐÌNH (ƯU TIÊN TRẢ LỜI TRỰC DIỆN SỐ 1):\n"${userNote}"\n\n` : ''}Hồ sơ đang chọn tham khảo thêm:
- Thành viên: ${memberRole}
- Tình trạng / Mục tiêu dinh dưỡng: ${condText}

YÊU CẦU TRÌNH BÀY (bằng tiếng Việt thân thiện, dễ đọc cho cả người lớn tuổi, món ăn quen thuộc dễ mua ở chợ Việt Nam):
- Nếu hỏi cụ thể **"Món X ăn được không?"**: Chốt ngay đầu câu **🟢 ĐƯỢC / 🟡 ĂN ÍT (rõ liều lượng) / 🔴 NÊN KIÊNG**, giải thích ngắn gọn & gợi ý **2–3 món thay thế ngon hơn**.
- Nếu tư vấn tổng thể / lên thực đơn ăn kiêng, trình bày đủ 4 phần rõ ràng:
**1. ✅ Nhóm thực phẩm NÊN ĂN (ưu tiên hàng đầu):**
**2. 🚫 Nhóm thực phẩm KHÔNG NÊN ĂN / CẦN KIÊNG (kèm lý do dễ hiểu):**
**3. 🍽️ Gợi ý Thực đơn mẫu 1 ngày (Sáng – Trưa – Bữa phụ – Tối) món Việt dễ nấu:**
**4. 💡 3 Mẹo ăn uống & sinh hoạt thực tế dễ áp dụng ngay:**`;

      const ans = await askGeminiGeneral(st.geminiSettings, {
        systemInstruction: 'Bạn là chuyên gia dinh dưỡng lâm sàng & ẩm thực Việt Nam cực kỳ tận tâm. Luôn đưa lời khuyên khoa học, an toàn, thực tế với mâm cơm gia đình Việt Nam.',
        userPrompt: prompt,
        temperature: 0.45
      }, (p) => { if (p) el('ai-body').innerHTML = fmtMd(p); });

      const condLabel = conds.length ? conds.map((c) => c.shortName).join(' + ') : 'Không bệnh nền';
      lastAiText = `🥗 Tư vấn Ăn kiêng (${memberRole} • ${condLabel})${userNote ? `\nHỏi: ${userNote}` : ''}\n\n${ans}`;
      el('ai-body').innerHTML = fmtMd(ans);
      setStatus('✅ Đã tư vấn xong! Bấm 💬 Zalo để gửi ngay cho người nhà cùng xem nhé!');
    } catch (err) {
      setStatus(`⚠️ ${err?.message || 'Lỗi AI'}`, true);
      el('ai-body').textContent = `⚠️ ${err?.message || 'Không kết nối được AI'}`;
    } finally {
      busy = false;
      el('btn-ai-menu').disabled = false;
      el('btn-food-ai').disabled = false;
    }
  };

  // Event bindings
  el('btn-back')?.addEventListener('click', onBack);

  el('dd-trigger')?.addEventListener('click', () => {
    dropdownOpen = !dropdownOpen;
    syncCheckboxesAndSummary();
  });

  el('btn-dd-done')?.addEventListener('click', () => {
    dropdownOpen = false;
    syncCheckboxesAndSummary();
  });

  el('btn-clear-all')?.addEventListener('click', () => {
    selectedIds.clear();
    syncCheckboxesAndSummary();
    renderGuideBoard();
    renderFoodCheck();
    setStatus('✓ Đã bỏ tích tất cả — chuyển sang chế độ Người không có bệnh nền!');
  });

  el('check-grid')?.addEventListener('change', (e) => {
    const cb = e.target;
    if (!cb || cb.type !== 'checkbox') return;
    if (cb.checked) selectedIds.add(cb.value);
    else selectedIds.delete(cb.value);
    syncCheckboxesAndSummary();
    renderGuideBoard();
    renderFoodCheck();
  });

  el('member-pills')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-pill');
    if (!b) return;
    memberRole = b.dataset.mem || '👵 Bà';
    syncCheckboxesAndSummary();
    renderGuideBoard();
    renderFoodCheck();
  });

  el('btn-save-profile')?.addEventListener('click', () => {
    const condIds = Array.from(selectedIds);
    const existingIdx = savedProfiles.findIndex((p) => p.member === memberRole);
    const item = { id: `dp-${Date.now()}`, member: memberRole, condIds };
    if (existingIdx >= 0) savedProfiles[existingIdx] = item;
    else savedProfiles.unshift(item);
    saveProfiles(savedProfiles);
    renderSavedProfiles();
    setStatus(`💾 Đã lưu hồ sơ dinh dưỡng cho ${memberRole}!`);
  });

  el('food-search')?.addEventListener('input', renderFoodCheck);
  el('food-search')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const val = el('food-search').value.trim();
      if (val) {
        const condLbl = getSelectedConds().map((c) => c.shortName).join(' + ') || 'người khỏe không bệnh nền';
        askDietAi(`${memberRole} (${condLbl}) ăn "${val}" có được không? Nếu ăn được thì liều lượng bao nhiêu, nếu kiêng thì thay bằng món gì?`);
      }
    }
  });

  el('food-quick')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-pill');
    if (!b) return;
    el('food-search').value = b.dataset.fq || '';
    renderFoodCheck();
  });

  el('btn-food-ai')?.addEventListener('click', () => {
    const val = el('food-search').value.trim();
    if (!val) {
      setStatus('Hãy nhập tên 1 món ăn/trái cây (VD: sầu riêng, phở bò, bia...) vào ô tra cứu trước nhé!', true);
      return;
    }
    const condLbl = getSelectedConds().map((c) => c.shortName).join(' + ') || 'người khỏe không bệnh nền';
    askDietAi(`${memberRole} (${condLbl}) ăn "${val}" có được không? Giải thích rõ nên ăn hay kiêng, liều lượng an toàn và món thay thế.`);
  });

  el('ai-chips')?.addEventListener('click', (e) => {
    const b = e.target.closest('.sf-pill');
    if (!b) return;
    const idx = Number(b.dataset.qp);
    const promptTxt = QUICK_AI_PROMPTS[idx] || '';
    if (promptTxt) {
      el('ai-inp').value = promptTxt;
      askDietAi(promptTxt);
    }
  });

  el('ai-inp')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      askDietAi();
    }
  });

  el('btn-ai-menu')?.addEventListener('click', () => askDietAi());

  el('btn-voice')?.addEventListener('click', () => {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      setStatus('⚠️ Thiết bị chưa hỗ trợ Micro trực tiếp ở đây — bạn gõ thẳng vào ô trên rồi bấm AI nhé!', true);
      return;
    }
    if (dietVoiceRec) { try { dietVoiceRec.stop(); } catch (_e) {} return; }
    const rec = new SpeechRec();
    dietVoiceRec = rec;
    rec.lang = 'vi-VN';
    rec.onstart = () => { el('btn-voice').textContent = '🔴'; setStatus('🎙️ Đang nghe... Nói VD: "Bà bị tiểu đường ăn xoài được không?"'); };
    rec.onresult = (ev) => {
      const sp = Array.from(ev.results).map((r) => r[0].transcript).join(' ').trim();
      if (sp) el('ai-inp').value = sp;
    };
    rec.onerror = () => { dietVoiceRec = null; el('btn-voice').textContent = '🎙️'; };
    rec.onend = () => {
      dietVoiceRec = null;
      el('btn-voice').textContent = '🎙️';
      const val = el('ai-inp').value.trim();
      if (val) askDietAi(val);
    };
    try { rec.start(); } catch (_e) { dietVoiceRec = null; }
  });

  el('btn-share-offline')?.addEventListener('click', () => {
    shareToZaloQuick(buildOfflineShareText());
    setStatus('💬 Đã sao chép bảng Nên ăn / Kiêng ăn để gửi Zalo!');
  });

  el('btn-copy')?.addEventListener('click', async () => {
    if (lastAiText) {
      try { await navigator.clipboard.writeText(lastAiText); } catch (_e) {}
      setStatus('✓ Đã sao chép tư vấn dinh dưỡng!');
    }
  });
  el('btn-zalo')?.addEventListener('click', () => { if (lastAiText) shareToZaloQuick(lastAiText); });
  el('btn-tg')?.addEventListener('click', (e) => { if (lastAiText && onSendTelegram) onSendTelegram(escHtml(lastAiText), e.currentTarget); });

  syncCheckboxesAndSummary();
  renderSavedProfiles();
  renderGuideBoard();
  renderFoodCheck();
}
