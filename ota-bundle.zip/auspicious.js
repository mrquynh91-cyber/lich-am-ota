import {
  CAN,
  CHI,
  CON_GIAP,
  TIMEZONE_VN,
  jdFromDate,
  jdToDate,
  getFullDayDetails
} from './lunar.js';
import { formatDateKey } from './reminders.js';

/**
 * 30 Nap Am elements (matching 60-year sexagenary cycle: index 0 = Giap Ty / At Suu)
 */
const NAP_AM_LIST = [
  { name: 'Hải Trung Kim', element: 'Kim' },
  { name: 'Lư Trung Hỏa', element: 'Hỏa' },
  { name: 'Đại Lâm Mộc', element: 'Mộc' },
  { name: 'Lộ Bàng Thổ', element: 'Thổ' },
  { name: 'Kiếm Phong Kim', element: 'Kim' },
  { name: 'Sơn Đầu Hỏa', element: 'Hỏa' },
  { name: 'Giản Hạ Thủy', element: 'Thủy' },
  { name: 'Thành Đầu Thổ', element: 'Thổ' },
  { name: 'Bạch Lạp Kim', element: 'Kim' },
  { name: 'Dương Liễu Mộc', element: 'Mộc' },
  { name: 'Tuyền Trung Thủy', element: 'Thủy' },
  { name: 'Ốc Thượng Thổ', element: 'Thổ' },
  { name: 'Tích Lịch Hỏa', element: 'Hỏa' },
  { name: 'Tùng Bách Mộc', element: 'Mộc' },
  { name: 'Trường Lưu Thủy', element: 'Thủy' },
  { name: 'Sa Trung Kim', element: 'Kim' },
  { name: 'Sơn Hạ Hỏa', element: 'Hỏa' },
  { name: 'Bình Địa Mộc', element: 'Mộc' },
  { name: 'Bích Thượng Thổ', element: 'Thổ' },
  { name: 'Kim Bạch Kim', element: 'Kim' },
  { name: 'Phú Đăng Hỏa', element: 'Hỏa' },
  { name: 'Thiên Hà Thủy', element: 'Thủy' },
  { name: 'Đại Trạch Thổ', element: 'Thổ' },
  { name: 'Thoa Xuyến Kim', element: 'Kim' },
  { name: 'Tang Đố Mộc', element: 'Mộc' },
  { name: 'Đại Khê Thủy', element: 'Thủy' },
  { name: 'Sa Trung Thổ', element: 'Thổ' },
  { name: 'Thiên Thượng Hỏa', element: 'Hỏa' },
  { name: 'Thạch Lựu Mộc', element: 'Mộc' },
  { name: 'Đại Hải Thủy', element: 'Thủy' }
];

// Lục Hợp pairs for Địa Chi (0=Tý..11=Hợi)
const LUC_HOP = {
  0: 1, 1: 0,   // Tý - Sửu
  2: 11, 11: 2, // Dần - Hợi
  3: 10, 10: 3, // Mão - Tuất
  4: 9, 9: 4,   // Thìn - Dậu
  5: 8, 8: 5,   // Tỵ - Thân
  6: 7, 7: 6    // Ngọ - Mùi
};

// Ngũ Hành Tương Sinh: key generates value
const TUONG_SINH = {
  Kim: 'Thủy',
  Thủy: 'Mộc',
  Mộc: 'Hỏa',
  Hỏa: 'Thổ',
  Thổ: 'Kim'
};

// Ngũ Hành Tương Khắc: key overcomes value
const TUONG_KHAC = {
  Kim: 'Mộc',
  Mộc: 'Thổ',
  Thổ: 'Thủy',
  Thủy: 'Hỏa',
  Hỏa: 'Kim'
};

const TAM_NUONG_DAYS = new Set([3, 7, 13, 18, 22, 27]);
const NGUYET_KY_DAYS = new Set([5, 14, 23]);

export const TASK_CATALOG = [
  {
    id: 'khai_truong',
    label: 'Khai trương / Mở cửa hàng / Ra mắt',
    goodTruc: ['Trực Khai', 'Trực Thành', 'Trực Mãn', 'Trực Định'],
    badTruc: ['Trực Phá', 'Trực Bế', 'Trực Nguy', 'Trực Trừ']
  },
  {
    id: 'xuat_hanh',
    label: 'Xuất hành / Đi xa / Công tác / Du lịch',
    goodTruc: ['Trực Kiến', 'Trực Khai', 'Trực Thành', 'Trực Mãn', 'Trực Trừ'],
    badTruc: ['Trực Phá', 'Trực Bế', 'Trực Thu']
  },
  {
    id: 'ky_ket',
    label: 'Ký hợp đồng / Giao dịch / Đầu tư',
    goodTruc: ['Trực Định', 'Trực Thành', 'Trực Khai', 'Trực Mãn', 'Trực Thu'],
    badTruc: ['Trực Phá', 'Trực Nguy', 'Trực Bế']
  },
  {
    id: 'cuoi_hoi',
    label: 'Cưới hỏi / Ăn hỏi / Dạm ngõ',
    goodTruc: ['Trực Thành', 'Trực Định', 'Trực Mãn', 'Trực Khai', 'Trực Bình'],
    badTruc: ['Trực Phá', 'Trực Bế', 'Trực Nguy', 'Trực Trừ']
  },
  {
    id: 'dong_tho',
    label: 'Động thổ / Xây dựng / Sửa chữa nhà',
    goodTruc: ['Trực Thành', 'Trực Khai', 'Trực Định', 'Trực Mãn', 'Trực Chấp', 'Trực Bình'],
    badTruc: ['Trực Kiến', 'Trực Phá', 'Trực Nguy']
  },
  {
    id: 'nhap_trach',
    label: 'Nhập trạch / Chuyển nhà / Chuyển văn phòng',
    goodTruc: ['Trực Mãn', 'Trực Thành', 'Trực Định', 'Trực Khai'],
    badTruc: ['Trực Phá', 'Trực Chấp', 'Trực Bế', 'Trực Nguy']
  },
  {
    id: 'mua_xe',
    label: 'Mua xe / Mua nhà / Mua tài sản lớn',
    goodTruc: ['Trực Thành', 'Trực Mãn', 'Trực Định', 'Trực Khai', 'Trực Thu'],
    badTruc: ['Trực Phá', 'Trực Nguy', 'Trực Bế']
  },
  {
    id: 'cai_tang',
    label: 'Cải táng / Sang cát / Cúng tế / Động mộ',
    goodTruc: ['Trực Trừ', 'Trực Mãn', 'Trực Định', 'Trực Thành', 'Trực Nguy'],
    badTruc: ['Trực Kiến', 'Trực Phá', 'Trực Thu', 'Trực Khai']
  },
  {
    id: 'nham_chuc',
    label: 'Nhận việc mới / Nhậm chức / Học hành',
    goodTruc: ['Trực Kiến', 'Trực Thành', 'Trực Khai', 'Trực Định'],
    badTruc: ['Trực Phá', 'Trực Bế', 'Trực Nguy']
  },
  {
    id: 'chung',
    label: 'Công việc chung (Tìm ngày đẹp mọi việc)',
    goodTruc: ['Trực Thành', 'Trực Khai', 'Trực Mãn', 'Trực Định', 'Trực Bình'],
    badTruc: ['Trực Phá', 'Trực Bế', 'Trực Nguy']
  }
];

/**
 * Compute birth-year profile (Can Chi, Con Giáp, Ngũ Hành Nạp Âm)
 */
export function getBirthProfile(birthYear) {
  const y = Number(birthYear);
  if (!Number.isFinite(y) || y < 1920 || y > 2050) return null;

  const canIndex = ((y + 6) % 10 + 10) % 10;
  const chiIndex = ((y + 8) % 12 + 12) % 12;
  // Sexagenary year index (0 = Giáp Tý, e.g., 1984 -> (1984-4)%60 = 0)
  const sexagenary = ((y - 4) % 60 + 60) % 60;
  const napAm = NAP_AM_LIST[Math.floor(sexagenary / 2)];

  return {
    year: y,
    canIndex,
    chiIndex,
    canChi: `${CAN[canIndex]} ${CHI[chiIndex]}`,
    animal: CON_GIAP[chiIndex],
    napAmName: napAm.name,
    element: napAm.element
  };
}

/**
 * Extract element of a Julian Day Number's Nạp Âm
 */
function getDayElement(jd) {
  const sexagenary = ((jd + 49) % 60 + 60) % 60;
  return NAP_AM_LIST[Math.floor(sexagenary / 2)];
}

/**
 * Parse the start HH:mm of a Vietnamese hour range like "7-9h" or "23-1h"
 */
export function getHourRangeStartTime(rangeStr) {
  const m = String(rangeStr || '').match(/^(\d{1,2})-/);
  if (!m) return '09:00';
  const h = Number(m[1]);
  return `${String(h).padStart(2, '0')}:00`;
}

/**
 * Score a single solar date for a given birth profile and task
 */
export function evaluateDateForTask(dd, mm, yy, birthProfile, taskId = 'chung') {
  const task = TASK_CATALOG.find((t) => t.id === taskId) || TASK_CATALOG[TASK_CATALOG.length - 1];
  const details = getFullDayDetails(dd, mm, yy, TIMEZONE_VN);
  const { lunar, hoangDaoDay, truc, hours, xuatHanh } = details;
  const jd = lunar.jd;
  const dayCanIdx = ((jd + 9) % 10 + 10) % 10;
  const dayChiIdx = ((jd + 1) % 12 + 12) % 12;
  const dayNapAm = getDayElement(jd);

  let score = 50;
  const pros = [];
  const warnings = [];
  let isClashAge = false;
  let isTabooDay = false;

  // 1. Ngày Hoàng Đạo / Hắc Đạo
  if (hoangDaoDay.isGood) {
    score += 22;
    pros.push(`Ngày Hoàng Đạo (${hoangDaoDay.starName})`);
  } else {
    score -= 14;
    warnings.push(`Ngày Hắc Đạo (${hoangDaoDay.starName})`);
  }

  // 2. Thập Nhị Trực theo công việc
  if (task.goodTruc.includes(truc.name)) {
    score += 20;
    pros.push(`${truc.name} — rất hợp công việc này`);
  } else if (task.badTruc.includes(truc.name)) {
    score -= 20;
    warnings.push(`${truc.name} — nên hạn chế cho việc này`);
  } else {
    score += 4;
    pros.push(`${truc.name} — mức trung bình`);
  }

  // 3. Hợp / Xung theo tuổi năm sinh
  if (birthProfile) {
    const bChi = birthProfile.chiIndex;
    const bCan = birthProfile.canIndex;

    if ((dayChiIdx + 6) % 12 === bChi) {
      score -= 36;
      isClashAge = true;
      warnings.push(`Xung trực tiếp với tuổi ${birthProfile.canChi} (${CHI[dayChiIdx]} xung ${CHI[bChi]})`);
    } else if ((dayChiIdx + 4) % 12 === bChi || (dayChiIdx + 8) % 12 === bChi) {
      score += 15;
      pros.push(`Ngày Tam Hợp với tuổi ${CHI[bChi]}`);
    } else if (LUC_HOP[bChi] === dayChiIdx) {
      score += 14;
      pros.push(`Ngày Lục Hợp với tuổi ${CHI[bChi]}`);
    }

    if ((dayCanIdx + 5) % 10 === bCan) {
      score += 6;
      pros.push(`Thiên Can tương hợp (${CAN[dayCanIdx]} – ${CAN[bCan]})`);
    }

    // 4. Ngũ Hành Nạp Âm (Ngày vs Mệnh tuổi)
    if (TUONG_SINH[dayNapAm.element] === birthProfile.element) {
      score += 12;
      pros.push(`Hành ngày (${dayNapAm.element}) tương sinh mệnh ${birthProfile.element}`);
    } else if (dayNapAm.element === birthProfile.element) {
      score += 6;
      pros.push(`Hành ngày (${dayNapAm.element}) bình hòa mệnh ${birthProfile.element}`);
    } else if (TUONG_KHAC[dayNapAm.element] === birthProfile.element) {
      score -= 14;
      warnings.push(`Hành ngày (${dayNapAm.element}) khắc mệnh ${birthProfile.element}`);
    }
  }

  // 5. Ngày kỵ dân gian (Tam Nương, Nguyệt Kỵ)
  if (TAM_NUONG_DAYS.has(lunar.day)) {
    score -= 18;
    isTabooDay = true;
    warnings.push(`Ngày Tam Nương (mùng ${lunar.day} ÂL)`);
  }
  if (NGUYET_KY_DAYS.has(lunar.day)) {
    score -= 18;
    isTabooDay = true;
    warnings.push(`Ngày Nguyệt Kỵ (mùng ${lunar.day} ÂL)`);
  }

  score = Math.max(5, Math.min(100, Math.round(score)));

  // 6. Lọc Giờ Hoàng Đạo hợp tuổi
  const recommendedHours = hours.hoangDao
    .map((h) => {
      const hChiIdx = CHI.indexOf(h.chi);
      const clashesAge = birthProfile ? (hChiIdx + 6) % 12 === birthProfile.chiIndex : false;
      const superGood = birthProfile
        ? (hChiIdx + 4) % 12 === birthProfile.chiIndex ||
          (hChiIdx + 8) % 12 === birthProfile.chiIndex ||
          LUC_HOP[birthProfile.chiIndex] === hChiIdx
        : false;
      return { ...h, clashesAge, superGood, startTime: getHourRangeStartTime(h.range) };
    })
    .filter((h) => !h.clashesAge);

  // Pick a practical daytime hour (prefer 07:00..19:00, superGood first) for 1-click reminder
  const daytimeHours = recommendedHours.filter((h) => {
    const startH = Number(h.startTime.split(':')[0]);
    return startH >= 7 && startH <= 19;
  });
  const bestHour =
    daytimeHours.find((h) => h.superGood) ||
    daytimeHours[0] ||
    recommendedHours.find((h) => h.superGood) ||
    recommendedHours[0] ||
    hours.hoangDao[0];

  let rating = 'Trung bình';
  let ratingKey = 'medium';
  if (score >= 82 && !isClashAge) {
    rating = 'Rất tốt';
    ratingKey = 'excellent';
  } else if (score >= 68 && !isClashAge) {
    rating = 'Tốt';
    ratingKey = 'good';
  } else if (score < 50 || isClashAge) {
    rating = 'Nên tránh';
    ratingKey = 'avoid';
  }

  return {
    dateKey: formatDateKey(yy, mm, dd),
    solar: details.solar,
    lunar,
    lunarFormatted: details.lunarFormatted,
    canChi: details.canChi,
    truc,
    hoangDaoDay,
    xuatHanh,
    dayNapAm,
    score,
    rating,
    ratingKey,
    isClashAge,
    isTabooDay,
    pros,
    warnings,
    recommendedHours,
    bestHour
  };
}

/**
 * Search a solar date range [fromDateKey..toDateKey] and return auspicious candidates
 */
export function findAuspiciousDays({
  birthYear,
  taskId = 'chung',
  fromDateKey,
  toDateKey,
  onlyGood = true,
  sortBy = 'score' // 'score' | 'date'
}) {
  const birthProfile = getBirthProfile(birthYear);
  const [fy, fm, fd] = fromDateKey.split('-').map(Number);
  const [ty, tm, td] = toDateKey.split('-').map(Number);
  const startJd = jdFromDate(fd, fm, fy);
  const endJd = jdFromDate(td, tm, ty);

  if (endJd < startJd) {
    return { birthProfile, results: [], error: 'Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.' };
  }

  // Cap search window at 180 days so UI stays instant
  const cappedEndJd = Math.min(endJd, startJd + 180);
  const results = [];

  for (let jd = startJd; jd <= cappedEndJd; jd++) {
    const s = jdToDate(jd);
    const evaluated = evaluateDateForTask(s.day, s.month, s.year, birthProfile, taskId);
    if (onlyGood) {
      if (evaluated.isClashAge || evaluated.score < 65) continue;
    }
    results.push(evaluated);
  }

  if (sortBy === 'score') {
    results.sort((a, b) => b.score - a.score || a.dateKey.localeCompare(b.dateKey));
  } else {
    results.sort((a, b) => a.dateKey.localeCompare(b.dateKey));
  }

  return { birthProfile, results, capped: endJd > cappedEndJd };
}
