/**
 * Bản đồ Chỉ Tay Nhân Tướng Học Việt Nam (10 đường & gò bàn tay kinh điển)
 * Dùng kèm tính năng Quét Chỉ Tay bằng Camera sau / Tải ảnh lên + Gemini Vision AI.
 */

export const PALM_FEATURES = [
  {
    id: 'sinh-dao',
    num: 1,
    x: 84,
    y: 175,
    color: '#DC2626',
    name: 'Đường Sinh Đạo (Đường Đời)',
    omen: 'good',
    omenLabel: '❤️ Sức khỏe & Sinh lực',
    summary: 'Vòng cung ôm lấy gốc ngón cái (gò Kim Tinh), thể hiện sức sống, thể lực, khả năng phục hồi và các cột mốc lớn trong đời.',
    goodSign: 'Rõ nét, sâu đều, vòng cung rộng và liền mạch: sinh lực dồi dào, sức bền tốt, sống lạc quan và vững vàng vượt qua biến cố.',
    advice: 'Chú trọng rèn luyện thể thao đều đặn và ngủ đủ giấc để nuôi dưỡng khí sắc & năng lượng bền bỉ.'
  },
  {
    id: 'tri-dao',
    num: 2,
    x: 112,
    y: 147,
    color: '#2563EB',
    name: 'Đường Trí Đạo (Học vấn & Tư duy)',
    omen: 'good',
    omenLabel: '🧠 Trí tuệ & Sự nghiệp',
    summary: 'Chạy ngang qua giữa lòng bàn tay, phản ánh tư duy logic, khả năng sáng tạo, cách ra quyết định và định hướng nghề nghiệp.',
    goodSign: 'Đường thẳng rõ: tư duy thực tế, quyết đoán, hợp quản lý & tài chính. Đường hơi cong mềm xuống gò Thái Âm: giàu sáng tạo, nghệ thuật & trực giác.',
    advice: 'Phát huy điểm mạnh tư duy cốt lõi, kết hợp học hỏi kỹ năng mới để bứt phá sự nghiệp.'
  },
  {
    id: 'tam-dao',
    num: 3,
    x: 120,
    y: 118,
    color: '#DB2777',
    name: 'Đường Tâm Đạo (Tình duyên & Cảm xúc)',
    omen: 'good',
    omenLabel: '💞 Tình cảm & Gia đạo',
    summary: 'Nằm phía trên cùng lòng bàn tay (dưới các ngón tay), nói lên đời sống nội tâm, cách yêu thương và độ bền vững của hôn nhân.',
    goodSign: 'Sâu, rõ, hướng lên giữa ngón trỏ và ngón giữa: sống chân thành, chung thủy, gia đạo hòa thuận và dễ gặp người bạn đời thấu hiểu.',
    advice: 'Giữ sự cởi mở, chia sẻ nhẹ nhàng với người thân để tình cảm ngày càng gắn kết.'
  },
  {
    id: 'van-menh',
    num: 4,
    x: 105,
    y: 186,
    color: '#7C3AED',
    name: 'Đường Vận Mệnh (Công danh / Định mệnh)',
    omen: 'good',
    omenLabel: '🚀 Công danh & Quý nhân',
    summary: 'Chạy dọc từ cổ tay hướng lên phía ngón giữa, biểu thị sự ổn định nghề nghiệp, ý chí tự lập và vận may quý nhân hỗ trợ.',
    goodSign: 'Thẳng, rõ và kéo dài lên gò Thổ Tinh: có định hướng rõ ràng, dễ thăng tiến và đạt thành tựu lớn từ tuổi trung niên.',
    advice: 'Kiên định với mục tiêu dài hạn; ngay cả khi đường này mờ vẫn là dấu hiệu của người linh hoạt, tự do làm chủ nhiều cơ hội.'
  },
  {
    id: 'tai-loc',
    num: 5,
    x: 130,
    y: 158,
    color: '#D97706',
    name: 'Đường Thái Dương (Tài lộc & Danh tiếng)',
    omen: 'good',
    omenLabel: '💰 Tài vận & Uy tín',
    summary: 'Chạy dọc hướng lên dưới ngón áp út, tượng trưng cho vận tài lộc, sức hút cá nhân, danh tiếng và khả năng tụ tài.',
    goodSign: 'Rõ nét, không đứt đoạn: có duyên với tiền bạc, dễ được công nhận tài năng và gặp nhiều may mắn bất ngờ trong làm ăn.',
    advice: 'Quản lý tài chính có kỷ luật và tích lũy dài hạn để lộc lá bền vững.'
  },
  {
    id: 'hon-nhan',
    num: 6,
    x: 156,
    y: 112,
    color: '#E11D48',
    name: 'Đường Hôn Nhân',
    omen: 'neutral',
    omenLabel: '💍 Nhân duyên & Hạnh phúc',
    summary: 'Các nét ngang ngắn ở cạnh ngoài lòng bàn tay (dưới ngón út, trên đường Tâm Đạo), cho thấy các mối nhân duyên sâu đậm.',
    goodSign: 'Nét thẳng, rõ, cân đối: hôn nhân ổn định, vợ chồng đồng lòng cùng xây dựng kinh tế và chăm lo gia đình.',
    advice: 'Trân trọng đối phương và dành thời gian chất lượng cho gia đình là chìa khóa giữ lửa hạnh phúc.'
  },
  {
    id: 'go-kim-tinh',
    num: 7,
    x: 68,
    y: 188,
    color: '#059669',
    name: 'Gò Kim Tinh (Gốc ngón cái)',
    omen: 'good',
    omenLabel: '🌿 Phúc khí & Tình thân',
    summary: 'Phần thịt đầy đặn ở gốc ngón cái, đại diện cho lòng nhân hậu, sức khỏe nền tảng, tình cảm gia đình và năng lượng sống.',
    goodSign: 'Đầy đặn, hồng hào, đàn hồi tốt: người sống trọng tình nghĩa, giàu lòng trắc ẩn, vượng gia đạo và phúc đức.',
    advice: 'Tiếp tục lan tỏa năng lượng ấm áp và giữ thói quen sinh hoạt lành mạnh.'
  },
  {
    id: 'go-moc-tinh',
    num: 8,
    x: 78,
    y: 112,
    color: '#0284C7',
    name: 'Gò Mộc Tinh (Dưới ngón trỏ)',
    omen: 'good',
    omenLabel: '👑 Lãnh đạo & Hoài bão',
    summary: 'Vùng dưới ngón trỏ, biểu trưng cho sự tự tin, tố chất lãnh đạo, tinh thần cầu tiến và khát vọng thành công.',
    goodSign: 'Nổi cao vừa phải, đầy đặn: có uy tín trong tập thể, biết tổ chức công việc và dễ giữ vị trí chủ chốt.',
    advice: 'Kết hợp sự tự tin với tinh thần lắng nghe để thu phục lòng người bền lâu.'
  },
  {
    id: 'go-thuy-tinh',
    num: 9,
    x: 148,
    y: 126,
    color: '#0D9488',
    name: 'Gò Thủy Tinh (Dưới ngón út)',
    omen: 'good',
    omenLabel: '💼 Giao tiếp & Kinh doanh',
    summary: 'Vùng dưới ngón út, phản ánh khả năng ăn nói thuyết phục, đầu óc nhạy bén thương trường và óc hài hước.',
    goodSign: 'Đầy đặn, có đường Tài Vận hướng lên: có duyên buôn bán, đàm phán khéo léo và dễ xoay xở sinh lời.',
    advice: 'Tận dụng lợi thế giao tiếp và xây dựng mạng lưới quan hệ uy tín.'
  },
  {
    id: 'chu-m',
    num: 10,
    x: 105,
    y: 145,
    color: '#B45309',
    name: 'Chỉ tay Chữ M / Chữ Nhất (Đặc biệt)',
    omen: 'good',
    omenLabel: '🌟 Quý tướng hiếm gặp',
    summary: 'Chỉ tay chữ M tạo bởi 4 đường chính giao hòa (Sinh – Trí – Tâm – Vận Mệnh); chữ Nhất là Trí Đạo và Tâm Đạo nhập làm một.',
    goodSign: 'Người sở hữu chữ M thường có trực giác sắc bén, giàu nghị lực và hậu vận phú quý; người có chữ Nhất cực kỳ quyết đoán, tập trung cao độ.',
    advice: 'Biết cân bằng giữa công việc và cảm xúc để biến tố chất hiếm thành thành công bền vững.'
  }
];

/**
 * Generates TWO high-resolution palm images for Gemini Vision Palmistry:
 *  1) `base64` (up to 1600px, quality 0.93): true-color high-res photo preserving skin tone & mounds.
 *  2) `enhancedBase64` (up to 1350px, quality 0.91): local-contrast crease-relief map (green-weighted
 *     high-pass via integral image) so fine creases, breaks ("đứt mạch"), overlaps ("nối gối"),
 *     islands ("cù lao"), and forks stand out sharply for accurate forensic palm reading.
 */
export function buildEnhancedPalmImages(source, mirrorX = false) {
  const srcW = source.videoWidth || source.naturalWidth || source.width || 1200;
  const srcH = source.videoHeight || source.naturalHeight || source.height || 1200;

  // 1. High-res true-color image (max 1600px)
  const scale1 = Math.min(1, 1600 / Math.max(srcW, srcH));
  const w1 = Math.max(1, Math.round(srcW * scale1));
  const h1 = Math.max(1, Math.round(srcH * scale1));
  const c1 = document.createElement('canvas');
  c1.width = w1;
  c1.height = h1;
  const ctx1 = c1.getContext('2d');
  if (mirrorX) {
    ctx1.translate(w1, 0);
    ctx1.scale(-1, 1);
  }
  ctx1.drawImage(source, 0, 0, w1, h1);
  const dataUrl = c1.toDataURL('image/jpeg', 0.93);
  const base64 = dataUrl.split(',')[1] || '';

  // 2. Crease-enhanced local-contrast relief map (max 1350px)
  let enhancedBase64 = '';
  try {
    const scale2 = Math.min(1, 1350 / Math.max(w1, h1));
    const w2 = Math.max(1, Math.round(w1 * scale2));
    const h2 = Math.max(1, Math.round(h1 * scale2));
    const c2 = document.createElement('canvas');
    c2.width = w2;
    c2.height = h2;
    const ctx2 = c2.getContext('2d', { willReadFrequently: true });
    ctx2.drawImage(c1, 0, 0, w2, h2);
    const imgData = ctx2.getImageData(0, 0, w2, h2);
    const d = imgData.data;
    const total = w2 * h2;
    const lum = new Float32Array(total);
    for (let i = 0, p = 0; i < total; i++, p += 4) {
      // Green channel carries strongest palm crease vs skin contrast
      lum[i] = d[p] * 0.22 + d[p + 1] * 0.65 + d[p + 2] * 0.13;
    }

    // Integral image for O(N) local-mean illumination estimation
    const stride = w2 + 1;
    const integ = new Float64Array((h2 + 1) * stride);
    for (let y = 0; y < h2; y++) {
      let rowSum = 0;
      const yOff = y * w2;
      const iCur = (y + 1) * stride;
      const iPrev = y * stride;
      for (let x = 0; x < w2; x++) {
        rowSum += lum[yOff + x];
        integ[iCur + x + 1] = integ[iPrev + x + 1] + rowSum;
      }
    }

    const rad = Math.max(10, Math.round(Math.min(w2, h2) * 0.022));
    for (let y = 0; y < h2; y++) {
      const y0 = Math.max(0, y - rad);
      const y1 = Math.min(h2 - 1, y + rad);
      const rowA = y0 * stride;
      const rowB = (y1 + 1) * stride;
      for (let x = 0; x < w2; x++) {
        const x0 = Math.max(0, x - rad);
        const x1 = Math.min(w2 - 1, x + rad);
        const area = (x1 - x0 + 1) * (y1 - y0 + 1);
        const localMean = (integ[rowB + x1 + 1] - integ[rowA + x1 + 1] - integ[rowB + x0] + integ[rowA + x0]) / area;
        const idx = y * w2 + x;
        const diff = lum[idx] - localMean;
        // Amplify dark creases cleanly while suppressing flat skin shading
        const boosted = Math.max(0, Math.min(255, Math.round(lum[idx] * 0.35 + 148 + diff * 4.2)));
        const p = idx * 4;
        d[p] = boosted;
        d[p + 1] = boosted;
        d[p + 2] = boosted;
      }
    }
    ctx2.putImageData(imgData, 0, 0);
    enhancedBase64 = (c2.toDataURL('image/jpeg', 0.91).split(',')[1]) || '';
  } catch (_e) {
    enhancedBase64 = '';
  }

  return { dataUrl, base64, enhancedBase64 };
}
