/**
 * Real-Time 2-Way Cloud Sync Engine (PC Chrome Extension <-> OPPO Find X9)
 * Supports two 100% FREE, pure-fetch private backends (no paid server needed):
 *  1. Firebase Realtime Database (Google Spark free tier — 1 URL + private Sync Key)
 *  2. GitHub Secret Gist (GitHub free account — 1 Personal Access Token with 'gist' scope)
 *
 * Syncs ALL 11 personal data domains automatically on every change + periodic live pull,
 * with deletion tombstones (deletedIds) so add / edit / tick / delete mirror cleanly 2-way!
 */

export const DEFAULT_CLOUD_SYNC_CONFIG = {
  enabled: false,
  provider: 'firebase', // 'firebase' | 'github'
  firebaseUrl: '',
  roomKey: '',
  githubToken: '',
  gistId: '',
  deviceId: '',
  lastSyncedAt: 0,
  lastRemoteUpdatedAt: 0
};

export const SYNCABLE_DATA_KEYS = [
  'settings',
  'customEvents',
  'waterSettings',
  'waterLog',
  'timedReminders',
  'highlightedRanges',
  'auspiciousPrefs',
  'telegramSettings',
  'prayerPrefs',
  'weatherPrefs',
  'zaloSettings',
  'geminiSettings'
];

export function generateRandomKey(prefix = 'licham') {
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  let out = '';
  for (let i = 0; i < 10; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return `${prefix}-${out}`;
}

export function normalizeFirebaseEndpoint(firebaseUrl, roomKey) {
  let base = String(firebaseUrl || '').trim().replace(/\/+$/, '');
  if (!base) return '';
  if (!/^https?:\/\//i.test(base)) {
    base = `https://${base}`;
  }
  // If user pasted a direct .json URL, use it directly
  if (/\.json(\?.*)?$/i.test(base)) {
    return base;
  }
  const safeRoom = String(roomKey || 'default').trim().replace(/[^a-zA-Z0-9_-]/g, '') || 'default';
  return `${base}/licham_sync/${safeRoom}.json`;
}

/**
 * Build a per-event Firebase dedupe URL so PC & OPPO Find X9 NEVER double-send the same Telegram alert,
 * while still letting OPPO automatically send if PC is turned off!
 */
export function buildTelegramLockUrl(cfg, dedupeKey) {
  if (!cfg || !cfg.enabled || (cfg.provider || 'firebase') !== 'firebase') return '';
  let base = String(cfg.firebaseUrl || '').trim().replace(/\/+$/, '');
  if (!base) return '';
  if (!/^https?:\/\//i.test(base)) base = `https://${base}`;
  if (/\.json(\?.*)?$/i.test(base)) {
    try {
      base = new URL(base).origin;
    } catch (_e) {
      base = base.replace(/\/[^/]+\.json(\?.*)?$/i, '');
    }
  }
  const safeRoom = String(cfg.roomKey || 'default').trim().replace(/[^a-zA-Z0-9_-]/g, '') || 'default';
  const safeKey = String(dedupeKey || '').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 110);
  if (!safeKey) return '';
  return `${base}/licham_sync/${safeRoom}_tg_locks/${safeKey}/claims.json`;
}

/**
 * Race-Free Distributed Leader Election via Firebase Server-Ordered Push Keys (GET -> POST -> GET):
 * 1. Fast pre-check GET: if another device already claimed this event, skip immediately.
 * 2. Device POSTs a claim to `.../claims.json` -> Firebase atomically assigns a globally unique,
 *    server-ordered push key (`myKey`, e.g. "-O..."). Pure Content-Type: application/json (zero CORS issues).
 * 3. Waits 700ms so any simultaneous concurrent POSTs from other devices finish landing.
 * 4. GETs `.../claims.json` and sorts all push keys lexicographically.
 * 5. ONLY the single device whose `myKey === sortedKeys[0]` wins and sends Telegram!
 * Guaranteed to elect EXACTLY 1 winner across 2, 3, or 100 devices even with clock skew!
 */
export async function claimTelegramSendSlotDetailed(cfg, dedupeKey, delayMs = 0) {
  const claimsUrl = buildTelegramLockUrl(cfg, dedupeKey);
  if (!claimsUrl) return { allowed: true, reason: 'no-cloud-sync' };
  if (delayMs > 0) {
    await new Promise((r) => setTimeout(r, delayMs));
  }
  try {
    const preResp = await fetch(claimsUrl, { method: 'GET', cache: 'no-store' });
    if (preResp.ok) {
      const existing = await preResp.json();
      if (existing && typeof existing === 'object' && Object.keys(existing).length > 0) {
        return { allowed: false, reason: 'already-claimed' };
      }
    }

    const postResp = await fetch(claimsUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sentBy: cfg.deviceId || 'device', sentAt: Date.now() })
    });
    if (!postResp.ok) return { allowed: true, reason: `post-http-${postResp.status}` };
    const postData = await postResp.json();
    const myKey = postData && typeof postData.name === 'string' ? postData.name : '';
    if (!myKey) return { allowed: true, reason: 'no-push-key' };

    await new Promise((r) => setTimeout(r, 700));

    const getResp = await fetch(claimsUrl, { method: 'GET', cache: 'no-store' });
    if (!getResp.ok) return { allowed: true, reason: `get-http-${getResp.status}` };
    const allClaims = await getResp.json();
    if (!allClaims || typeof allClaims !== 'object') return { allowed: true, reason: 'empty-get' };

    const sortedKeys = Object.keys(allClaims).sort();
    const won = sortedKeys.length > 0 && sortedKeys[0] === myKey;
    return { allowed: won, reason: won ? 'won' : 'lost-election' };
  } catch (err) {
    return { allowed: true, reason: `err-${err?.message || 'network'}` };
  }
}

export async function claimTelegramSendSlot(cfg, dedupeKey, delayMs = 0) {
  const res = await claimTelegramSendSlotDetailed(cfg, dedupeKey, delayMs);
  return res.allowed;
}

/**
 * Live diagnostic check for the Telegram dedupe lock path on Firebase
 */
export async function testTelegramLockAccess(cfg) {
  const claimsUrl = buildTelegramLockUrl(cfg, '_selftest_probe');
  if (!claimsUrl) {
    return { ok: false, skipped: true, message: 'Chưa bật đồng bộ Firebase' };
  }
  try {
    const postResp = await fetch(claimsUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ probeBy: cfg.deviceId || 'probe', at: Date.now() })
    });
    if (!postResp.ok) {
      return { ok: false, message: `Firebase từ chối ghi khóa (HTTP ${postResp.status})` };
    }
    const postData = await postResp.json();
    const myKey = postData?.name || '';
    const getResp = await fetch(claimsUrl, { method: 'GET', cache: 'no-store' });
    if (!getResp.ok) {
      return { ok: false, message: `Firebase từ chối đọc khóa (HTTP ${getResp.status})` };
    }
    const all = await getResp.json();
    await fetch(claimsUrl, { method: 'DELETE' }).catch(() => {});
    if (myKey && all && all[myKey]) {
      return { ok: true, message: 'Khóa chống trùng Firebase hoạt động tốt' };
    }
    return { ok: false, message: 'Không đọc lại được khóa trên Firebase' };
  } catch (err) {
    return { ok: false, message: `Lỗi mạng Firebase: ${err?.message || 'unknown'}` };
  }
}

/**
 * Encode/Decode compact Pairing Code (LICHAM-SYNC:...) so user sets up ONCE on PC
 * and pastes 1 code on OPPO Find X9 to pair instantly!
 */
export function encodePairingCode(cfg) {
  const payload = {
    v: 1,
    provider: cfg.provider || 'firebase',
    firebaseUrl: (cfg.firebaseUrl || '').trim(),
    roomKey: (cfg.roomKey || '').trim(),
    githubToken: (cfg.githubToken || '').trim(),
    gistId: (cfg.gistId || '').trim()
  };
  const json = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(json);
  let bin = '';
  bytes.forEach((b) => { bin += String.fromCharCode(b); });
  return `LICHAM-SYNC:${btoa(bin)}`;
}

export function decodePairingCode(raw) {
  const txt = String(raw || '').trim();
  const body = txt.startsWith('LICHAM-SYNC:') ? txt.slice('LICHAM-SYNC:'.length).trim() : txt;
  const bin = atob(body);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const json = new TextDecoder().decode(bytes);
  const parsed = JSON.parse(json);
  if (!parsed || typeof parsed !== 'object' || !parsed.provider) {
    throw new Error('Mã kết nối không hợp lệ.');
  }
  return {
    enabled: true,
    provider: parsed.provider === 'github' ? 'github' : 'firebase',
    firebaseUrl: String(parsed.firebaseUrl || '').trim(),
    roomKey: String(parsed.roomKey || '').trim(),
    githubToken: String(parsed.githubToken || '').trim(),
    gistId: String(parsed.gistId || '').trim()
  };
}

/**
 * Build a complete serializable snapshot from app state
 */
export function buildSyncSnapshot(state, deletedIds = {}, deviceId = '') {
  const now = Date.now();
  const prunedDeleted = {};
  const cutoff = now - 30 * 24 * 60 * 60 * 1000;
  for (const [id, ts] of Object.entries(deletedIds || {})) {
    if (typeof ts === 'number' && ts >= cutoff) {
      prunedDeleted[id] = ts;
    }
  }
  const data = {};
  for (const k of SYNCABLE_DATA_KEYS) {
    if (state[k] !== undefined) {
      data[k] = state[k];
    }
  }
  return {
    app: 'LichAmVietNam',
    schema: 2,
    updatedAt: now,
    updatedBy: deviceId || 'device',
    deletedIds: prunedDeleted,
    data
  };
}

function mergeById(localArr = [], remoteArr = [], deletedIds = {}, remoteWinsOnTie = true) {
  const map = new Map();
  const put = (item, isRemote) => {
    if (!item || !item.id) return;
    const delTs = Number(deletedIds[item.id] || 0);
    const itemTs = Number(item.updatedAt || item.createdAt || 0);
    if (delTs > 0 && delTs >= itemTs) return;

    const prev = map.get(item.id);
    if (!prev) {
      map.set(item.id, { item, isRemote, ts: itemTs });
      return;
    }
    if (itemTs > prev.ts || (itemTs === prev.ts && isRemote === remoteWinsOnTie)) {
      map.set(item.id, { item, isRemote, ts: itemTs });
    }
  };

  for (const it of Array.isArray(localArr) ? localArr : []) put(it, false);
  for (const it of Array.isArray(remoteArr) ? remoteArr : []) put(it, true);
  return Array.from(map.values()).map((x) => x.item);
}

/**
 * CRDT-style Conflict-Free Merge of remote snapshot into local state.
 * - ALWAYS merges arrays (timedReminders, highlightedRanges, customEvents) by `id` + `deletedIds` tombstones
 *   so adding on PC and clicking Sync on OPPO (or vice versa) NEVER loses a newly created item!
 * - Explicit deletes are tracked in `deletedIds` so deleting on either device cleanly deletes on both.
 * - Daily `waterLog` always takes Math.max so no logged glasses are lost.
 * - Scalar settings objects use the newer snapshot (remote wins if remote is newer and local isn't dirty).
 */
export function mergeCloudSnapshot(localState, localDeletedIds, remoteSnap, localDirty = false) {
  if (!remoteSnap || typeof remoteSnap !== 'object' || !remoteSnap.data) {
    return null;
  }
  const rData = remoteSnap.data;
  const mergedDeleted = { ...(localDeletedIds || {}) };
  for (const [id, ts] of Object.entries(remoteSnap.deletedIds || {})) {
    if (typeof ts === 'number' && ts > Number(mergedDeleted[id] || 0)) {
      mergedDeleted[id] = ts;
    }
  }

  const next = {};
  for (const k of SYNCABLE_DATA_KEYS) {
    if (k === 'timedReminders' || k === 'highlightedRanges' || k === 'customEvents') {
      next[k] = mergeById(localState[k], rData[k], mergedDeleted, !localDirty);
    } else if (k === 'waterLog') {
      const wLog = { ...(localState.waterLog || {}) };
      for (const [day, cnt] of Object.entries(rData.waterLog || {})) {
        wLog[day] = Math.max(Number(wLog[day] || 0), Number(cnt || 0));
      }
      next.waterLog = wLog;
    } else if (!localDirty && rData[k] !== undefined) {
      next[k] = rData[k];
    } else if (localState[k] !== undefined) {
      next[k] = localState[k];
    } else if (rData[k] !== undefined) {
      next[k] = rData[k];
    }
  }

  // Detect whether merged arrays contain items or tombstones that remote doesn't have yet (so caller pushes union back)
  const arrayChangedFromRemote = (key) => {
    const mArr = Array.isArray(next[key]) ? next[key] : [];
    const rArr = Array.isArray(rData[key]) ? rData[key] : [];
    if (mArr.length !== rArr.length) return true;
    const rMap = new Map(rArr.map((x) => [x?.id, Number(x?.updatedAt || x?.createdAt || 0)]));
    for (const it of mArr) {
      if (!rMap.has(it.id)) return true;
      if (Number(it.updatedAt || it.createdAt || 0) > rMap.get(it.id)) return true;
    }
    return false;
  };
  const needsPushBack =
    arrayChangedFromRemote('timedReminders') ||
    arrayChangedFromRemote('highlightedRanges') ||
    arrayChangedFromRemote('customEvents') ||
    Object.keys(mergedDeleted).length > Object.keys(remoteSnap.deletedIds || {}).length;

  return {
    mergedData: next,
    mergedDeletedIds: mergedDeleted,
    remoteUpdatedAt: Number(remoteSnap.updatedAt || Date.now()),
    needsPushBack
  };
}

/**
 * Create a brand-new private GitHub Gist for syncing (1-click helper)
 */
export async function createGitHubSyncGist(token, initialSnapshot) {
  const cleanToken = String(token || '').trim();
  if (!cleanToken) return { ok: false, error: 'Vui lòng nhập GitHub Personal Access Token (quyền gist).' };
  try {
    const resp = await fetch('https://api.github.com/gists', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${cleanToken}`,
        Accept: 'application/vnd.github+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description: 'Lịch Âm Việt Nam — Cloud Sync (Private)',
        public: false,
        files: {
          'lich-am-vn-sync.json': {
            content: JSON.stringify(initialSnapshot, null, 2)
          }
        }
      })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.id) {
      return { ok: false, error: data.message || `GitHub trả về lỗi HTTP ${resp.status}` };
    }
    return { ok: true, gistId: data.id };
  } catch (err) {
    return { ok: false, error: `Lỗi kết nối GitHub: ${err?.message || 'kiểm tra mạng'}` };
  }
}

/**
 * Pull latest JSON snapshot from Cloud (Firebase or GitHub Gist)
 */
export async function pullCloudSnapshot(cfg) {
  if (!cfg || !cfg.enabled) return { ok: false, skipped: true };

  if (cfg.provider === 'github') {
    const token = String(cfg.githubToken || '').trim();
    const gistId = String(cfg.gistId || '').trim();
    if (!token || !gistId) return { ok: false, error: 'Thiếu GitHub Token hoặc Gist ID.' };
    try {
      const resp = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json'
        },
        cache: 'no-store'
      });
      if (!resp.ok) return { ok: false, error: `GitHub lỗi HTTP ${resp.status}` };
      const gist = await resp.json();
      const file = gist?.files?.['lich-am-vn-sync.json'] || Object.values(gist?.files || {})[0];
      if (!file || !file.content) return { ok: true, snapshot: null };
      const parsed = JSON.parse(file.content);
      return { ok: true, snapshot: parsed };
    } catch (err) {
      return { ok: false, error: `Lỗi tải GitHub Gist: ${err?.message || 'kiểm tra mạng'}` };
    }
  }

  // Default: Firebase Realtime Database REST API
  const url = normalizeFirebaseEndpoint(cfg.firebaseUrl, cfg.roomKey);
  if (!url) return { ok: false, error: 'Thiếu đường dẫn Firebase Realtime Database.' };
  try {
    const resp = await fetch(url, { method: 'GET', cache: 'no-store' });
    if (!resp.ok) {
      return { ok: false, error: `Firebase trả về lỗi HTTP ${resp.status} (kiểm tra Rules read/write = true)` };
    }
    const parsed = await resp.json();
    return { ok: true, snapshot: parsed && typeof parsed === 'object' ? parsed : null };
  } catch (err) {
    return { ok: false, error: `Lỗi tải Firebase: ${err?.message || 'kiểm tra URL hoặc mạng'}` };
  }
}

/**
 * Push JSON snapshot to Cloud (Firebase or GitHub Gist)
 */
export async function pushCloudSnapshot(cfg, snapshot) {
  if (!cfg || !cfg.enabled) return { ok: false, skipped: true };

  if (cfg.provider === 'github') {
    const token = String(cfg.githubToken || '').trim();
    const gistId = String(cfg.gistId || '').trim();
    if (!token || !gistId) return { ok: false, error: 'Thiếu GitHub Token hoặc Gist ID.' };
    try {
      const resp = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          files: {
            'lich-am-vn-sync.json': {
              content: JSON.stringify(snapshot, null, 2)
            }
          }
        })
      });
      if (!resp.ok) return { ok: false, error: `GitHub lỗi HTTP ${resp.status}` };
      return { ok: true, updatedAt: snapshot.updatedAt };
    } catch (err) {
      return { ok: false, error: `Lỗi đẩy GitHub Gist: ${err?.message || 'kiểm tra mạng'}` };
    }
  }

  // Default: Firebase Realtime Database REST API
  const url = normalizeFirebaseEndpoint(cfg.firebaseUrl, cfg.roomKey);
  if (!url) return { ok: false, error: 'Thiếu đường dẫn Firebase Realtime Database.' };
  try {
    const resp = await fetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(snapshot)
    });
    if (!resp.ok) {
      return { ok: false, error: `Firebase trả về lỗi HTTP ${resp.status} (kiểm tra Rules read/write = true)` };
    }
    return { ok: true, updatedAt: snapshot.updatedAt };
  } catch (err) {
    return { ok: false, error: `Lỗi đẩy Firebase: ${err?.message || 'kiểm tra URL hoặc mạng'}` };
  }
}
