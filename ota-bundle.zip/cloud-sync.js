/**
 * Real-Time 2-Way Cloud Sync Engine (PC Chrome Extension <-> PC Tray <-> Android APK)
 * Supports three 100% FREE private backends (no paid server needed):
 *  1. Cloudflare Worker + D1 Account Sync (0đ — 5 GB, SĐT/Tên + Mật khẩu riêng tư từng người dùng!)
 *  2. Firebase Realtime Database (Google Spark free tier — 1 URL + private Sync Key)
 *  3. GitHub Secret Gist (GitHub free account — 1 Personal Access Token with 'gist' scope)
 *
 * Syncs 100% of ALL personal app data (20 domains including calendar, alarms, water, prayers,
 * weather, expenses, loans, medicine schedules & Rx photos, diet profiles, dream & fortune history)
 * with CRDT-style id merging + deletion tombstones (deletedIds).
 */

export const DEFAULT_CLOUDFLARE_SYNC_URL = 'https://lich-am-sync.mr-quynh91.workers.dev';

export const DEFAULT_CLOUD_SYNC_CONFIG = {
  enabled: false,
  provider: 'cloudflare', // 'cloudflare' | 'firebase' | 'github'
  cfSyncUrl: DEFAULT_CLOUDFLARE_SYNC_URL,
  cfToken: '',
  cfUsername: '',
  cfDisplayName: '',
  firebaseUrl: '',
  roomKey: '',
  githubToken: '',
  gistId: '',
  deviceId: '',
  lastSyncedAt: 0,
  lastRemoteUpdatedAt: 0
};

export const SYNCABLE_DATA_KEYS = [
  'settings',
  'customEvents',
  'waterSettings',
  'waterLog',
  'timedReminders',
  'highlightedRanges',
  'auspiciousPrefs',
  'telegramSettings',
  'prayerPrefs',
  'weatherPrefs',
  'zaloSettings',
  'geminiSettings',
  'expenseBook',
  'loanBook'
];

export const EXTRA_LOCAL_DATA_KEYS = [
  'medicineBook',
  'medicineLog',
  'dietProfiles',
  'dreamHistory',
  'fortuneHistory',
  'expenseOwner'
];

export function normalizeCloudflareSyncUrl(rawUrl) {
  let u = String(rawUrl || '').trim().replace(/\/+$/, '');
  if (!u) return DEFAULT_CLOUDFLARE_SYNC_URL;
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  return u;
}

export function generateRandomKey(prefix = 'licham') {
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  let out = '';
  for (let i = 0; i < 10; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return `${prefix}-${out}`;
}

export function normalizeFirebaseEndpoint(firebaseUrl, roomKey) {
  let base = String(firebaseUrl || '').trim().replace(/\/+$/, '');
  if (!base) return '';
  if (!/^https?:\/\//i.test(base)) {
    base = `https://${base}`;
  }
  if (/\.json(\?.*)?$/i.test(base)) {
    return base;
  }
  const safeRoom = String(roomKey || 'default').trim().replace(/[^a-zA-Z0-9_-]/g, '') || 'default';
  return `${base}/licham_sync/${safeRoom}.json`;
}

/**
 * Safely collect extra localStorage domains (medicine, diet profiles, dream/fortune history, expense owner)
 * so 100% of user data is included in both Cloud Sync and JSON Backup.
 */
export function collectLocalExtraData() {
  if (typeof localStorage === 'undefined') return {};
  const readJson = (k, fb) => {
    try {
      const r = localStorage.getItem(k);
      return r ? JSON.parse(r) : fb;
    } catch (_e) { return fb; }
  };
  const medRaw = readJson('lich_am_medicine_v1', null);
  const medicineBook = medRaw && typeof medRaw === 'object'
    ? {
        items: Array.isArray(medRaw.items) ? medRaw.items : [],
        rxPhotos: Array.isArray(medRaw.rxPhotos) ? medRaw.rxPhotos : []
      }
    : { items: [], rxPhotos: [] };
  const medicineLog = readJson('lich_am_medicine_log_v1', {}) || {};
  const dietProfiles = readJson('lich_am_diet_profiles_v1', []);
  const dreamPc = readJson('lich_am_dream_history_v1', []);
  const dreamMob = readJson('lich_am_mob_dream_hist_v1', []);
  const dreamHistory = Array.isArray(dreamMob) && dreamMob.length >= (Array.isArray(dreamPc) ? dreamPc.length : 0)
    ? dreamMob
    : (Array.isArray(dreamPc) ? dreamPc : []);
  const fortuneHistory = readJson('lich_am_fortune_history_v1', []);
  let expenseOwner = '';
  try { expenseOwner = String(localStorage.getItem('lich_am_expense_owner_v1') || '').trim(); } catch (_e) {}

  return {
    medicineBook,
    medicineLog: typeof medicineLog === 'object' ? medicineLog : {},
    dietProfiles: Array.isArray(dietProfiles) ? dietProfiles : [],
    dreamHistory: Array.isArray(dreamHistory) ? dreamHistory : [],
    fortuneHistory: Array.isArray(fortuneHistory) ? fortuneHistory : [],
    expenseOwner
  };
}

/**
 * Persist merged extra domains back into localStorage & notify mounted modules to live-refresh UI.
 */
export function applyLocalExtraData(data) {
  if (typeof localStorage === 'undefined' || !data || typeof data !== 'object') return;
  try {
    if (data.medicineBook && typeof data.medicineBook === 'object') {
      localStorage.setItem('lich_am_medicine_v1', JSON.stringify({
        items: Array.isArray(data.medicineBook.items) ? data.medicineBook.items : [],
        rxPhotos: Array.isArray(data.medicineBook.rxPhotos) ? data.medicineBook.rxPhotos.slice(0, 6) : []
      }));
    }
    if (data.medicineLog && typeof data.medicineLog === 'object') {
      localStorage.setItem('lich_am_medicine_log_v1', JSON.stringify(data.medicineLog));
    }
    if (Array.isArray(data.dietProfiles)) {
      localStorage.setItem('lich_am_diet_profiles_v1', JSON.stringify(data.dietProfiles.slice(0, 12)));
    }
    if (Array.isArray(data.dreamHistory)) {
      const sliced = data.dreamHistory.slice(0, 10);
      localStorage.setItem('lich_am_dream_history_v1', JSON.stringify(sliced));
      localStorage.setItem('lich_am_mob_dream_hist_v1', JSON.stringify(sliced));
    }
    if (Array.isArray(data.fortuneHistory)) {
      localStorage.setItem('lich_am_fortune_history_v1', JSON.stringify(data.fortuneHistory.slice(0, 15)));
    }
    if (typeof data.expenseOwner === 'string' && data.expenseOwner.trim()) {
      localStorage.setItem('lich_am_expense_owner_v1', data.expenseOwner.trim().slice(0, 120));
    }
  } catch (_e) { /* quota or private mode */ }
  if (typeof window !== 'undefined' && typeof CustomEvent !== 'undefined') {
    try { window.dispatchEvent(new CustomEvent('licham-cloud-extra-applied')); } catch (_e) {}
  }
}

/**
 * Build deterministic non-secret scope shared by ALL devices sending to the same Telegram Bot + Chat ID,
 * so even devices without Cloud Sync enabled (or using different sync providers) STILL dedupe cleanly!
 */
export function buildTelegramLockScope(cfg, tgSettings = null) {
  const botId = String(tgSettings?.botToken || '').trim().split(':')[0].replace(/[^a-zA-Z0-9_-]/g, '');
  const chatId = String(tgSettings?.chatId || '').trim().replace(/[^a-zA-Z0-9_-]/g, '');
  if (botId && chatId) return `tg_${botId}_${chatId}`;
  const cfUser = String(cfg?.cfUsername || '').trim().replace(/[^a-zA-Z0-9@._-]/g, '');
  if (cfUser) return `cf_${cfUser}`;
  const room = String(cfg?.roomKey || '').trim().replace(/[^a-zA-Z0-9_-]/g, '');
  if (room) return `rm_${room}`;
  return '';
}

/**
 * Build a per-event distributed dedupe URL so PC Chrome, PC Tray & multiple Android phones
 * NEVER double-send the same Telegram alert — while still guaranteeing 1 device sends if others are off!
 * Supports BOTH atomic Cloudflare D1 (/api/tg-lock — default!) AND legacy Firebase Realtime DB.
 */
export function buildTelegramLockUrl(cfg, dedupeKey, tgSettings = null) {
  const safeKey = String(dedupeKey || '').replace(/[^a-zA-Z0-9_:\-]/g, '_').slice(0, 120);
  if (!safeKey) return '';

  // Legacy Firebase mode if explicitly enabled with Firebase URL
  if (cfg && cfg.enabled && cfg.provider === 'firebase' && String(cfg.firebaseUrl || '').trim()) {
    let base = String(cfg.firebaseUrl || '').trim().replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(base)) base = `https://${base}`;
    if (/\.json(\?.*)?$/i.test(base)) {
      try { base = new URL(base).origin; } catch (_e) { base = base.replace(/\/[^/]+\.json(\?.*)?$/i, ''); }
    }
    const safeRoom = String(cfg.roomKey || 'default').trim().replace(/[^a-zA-Z0-9_-]/g, '') || 'default';
    return `${base}/licham_sync/${safeRoom}_tg_locks/${safeKey}/claims.json`;
  }

  // Atomic Cloudflare D1 Lock (works across ALL devices sharing the same Telegram Bot + Chat ID or Cloudflare account!)
  const scope = buildTelegramLockScope(cfg, tgSettings);
  if (!scope) return '';
  const cfBase = normalizeCloudflareSyncUrl(cfg?.cfSyncUrl);
  const dev = String(cfg?.deviceId || 'device').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48) || 'device';
  return `${cfBase}/api/tg-lock?scope=${encodeURIComponent(scope)}&key=${encodeURIComponent(safeKey)}&device=${encodeURIComponent(dev)}`;
}

export async function claimTelegramSendSlotDetailed(cfg, dedupeKey, delayMs = 0, tgSettings = null) {
  const lockUrl = buildTelegramLockUrl(cfg, dedupeKey, tgSettings);
  if (!lockUrl) return { allowed: true, reason: 'no-cloud-sync' };
  if (delayMs > 0) {
    await new Promise((r) => setTimeout(r, delayMs));
  }

  // 1. Atomic Cloudflare D1 Lock (single-RTT SQLite PRIMARY KEY — zero race condition!)
  if (lockUrl.includes('/api/tg-lock')) {
    try {
      const resp = await fetch(lockUrl, { method: 'GET', cache: 'no-store' });
      if (!resp.ok) return { allowed: true, reason: `d1-http-${resp.status}` };
      const data = await resp.json().catch(() => ({}));
      if (data && typeof data.allowed === 'boolean') {
        return { allowed: data.allowed, reason: data.reason || (data.allowed ? 'won-d1' : 'already-claimed') };
      }
      return { allowed: true, reason: 'd1-bad-json' };
    } catch (err) {
      return { allowed: true, reason: `d1-err-${err?.message || 'network'}` };
    }
  }

  // 2. Legacy Firebase leader election
  try {
    const preResp = await fetch(lockUrl, { method: 'GET', cache: 'no-store' });
    if (preResp.ok) {
      const existing = await preResp.json();
      if (existing && typeof existing === 'object' && Object.keys(existing).length > 0) {
        return { allowed: false, reason: 'already-claimed' };
      }
    }

    const postResp = await fetch(lockUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sentBy: cfg.deviceId || 'device', sentAt: Date.now() })
    });
    if (!postResp.ok) return { allowed: true, reason: `post-http-${postResp.status}` };
    const postData = await postResp.json();
    const myKey = postData && typeof postData.name === 'string' ? postData.name : '';
    if (!myKey) return { allowed: true, reason: 'no-push-key' };

    await new Promise((r) => setTimeout(r, 700));

    const getResp = await fetch(lockUrl, { method: 'GET', cache: 'no-store' });
    if (!getResp.ok) return { allowed: true, reason: `get-http-${getResp.status}` };
    const allClaims = await getResp.json();
    if (!allClaims || typeof allClaims !== 'object') return { allowed: true, reason: 'empty-get' };

    const sortedKeys = Object.keys(allClaims).sort();
    const won = sortedKeys.length > 0 && sortedKeys[0] === myKey;
    return { allowed: won, reason: won ? 'won' : 'lost-election' };
  } catch (err) {
    return { allowed: true, reason: `err-${err?.message || 'network'}` };
  }
}

export async function claimTelegramSendSlot(cfg, dedupeKey, delayMs = 0, tgSettings = null) {
  const res = await claimTelegramSendSlotDetailed(cfg, dedupeKey, delayMs, tgSettings);
  return res.allowed;
}

export async function testTelegramLockAccess(cfg, tgSettings = null) {
  const lockUrl = buildTelegramLockUrl(cfg, '_selftest_probe', tgSettings);
  if (!lockUrl) {
    return { ok: false, skipped: true, message: 'Chưa cấu hình Telegram hoặc Đồng bộ đám mây' };
  }
  if (lockUrl.includes('/api/tg-lock')) {
    try {
      const resp = await fetch(lockUrl, { method: 'GET', cache: 'no-store' });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && data.ok) {
        return { ok: true, message: 'Khóa chống gửi trùng Telegram (Cloudflare D1) hoạt động chuẩn 100%!' };
      }
      return { ok: false, message: data.error || `Cloudflare D1 trả về HTTP ${resp.status}` };
    } catch (err) {
      return { ok: false, message: `Lỗi kết nối khóa Cloudflare D1: ${err?.message || 'unknown'}` };
    }
  }
  try {
    const postResp = await fetch(lockUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ probeBy: cfg.deviceId || 'probe', at: Date.now() })
    });
    if (!postResp.ok) {
      return { ok: false, message: `Firebase từ chối ghi khóa (HTTP ${postResp.status})` };
    }
    const postData = await postResp.json();
    const myKey = postData?.name || '';
    const getResp = await fetch(lockUrl, { method: 'GET', cache: 'no-store' });
    if (!getResp.ok) {
      return { ok: false, message: `Firebase từ chối đọc khóa (HTTP ${getResp.status})` };
    }
    const all = await getResp.json();
    await fetch(lockUrl, { method: 'DELETE' }).catch(() => {});
    if (myKey && all && all[myKey]) {
      return { ok: true, message: 'Khóa chống trùng Firebase hoạt động tốt' };
    }
    return { ok: false, message: 'Không đọc lại được khóa trên Firebase' };
  } catch (err) {
    return { ok: false, message: `Lỗi mạng Firebase: ${err?.message || 'unknown'}` };
  }
}

/* ==================== CLOUDFLARE D1 ACCOUNT SYNC AUTH API ==================== */

export async function registerCloudflareAccount(syncUrl, { username, password, displayName = '', deviceId = 'device' }) {
  const base = normalizeCloudflareSyncUrl(syncUrl);
  try {
    const resp = await fetch(`${base}/api/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, displayName, deviceId })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.ok) {
      return { ok: false, error: data.error || `Đăng ký thất bại (HTTP ${resp.status})` };
    }
    return { ok: true, ...data, syncUrl: base };
  } catch (err) {
    return { ok: false, error: `Không kết nối được máy chủ đồng bộ (${base}): ${err?.message || 'kiểm tra mạng'}` };
  }
}

export async function loginCloudflareAccount(syncUrl, { username, password, deviceId = 'device' }) {
  const base = normalizeCloudflareSyncUrl(syncUrl);
  try {
    const resp = await fetch(`${base}/api/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, deviceId })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.ok) {
      return { ok: false, error: data.error || `Đăng nhập thất bại (HTTP ${resp.status})` };
    }
    return { ok: true, ...data, syncUrl: base };
  } catch (err) {
    return { ok: false, error: `Không kết nối được máy chủ đồng bộ (${base}): ${err?.message || 'kiểm tra mạng'}` };
  }
}

export async function logoutCloudflareAccount(syncUrl, token) {
  const base = normalizeCloudflareSyncUrl(syncUrl);
  if (!token) return { ok: true };
  try {
    await fetch(`${base}/api/logout`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` }
    });
  } catch (_e) {}
  return { ok: true };
}

export async function changeCloudflarePassword(syncUrl, token, { oldPassword, newPassword }) {
  const base = normalizeCloudflareSyncUrl(syncUrl);
  try {
    const resp = await fetch(`${base}/api/change-password`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ oldPassword, newPassword })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.ok) {
      return { ok: false, error: data.error || `Đổi mật khẩu thất bại (HTTP ${resp.status})` };
    }
    return { ok: true, message: data.message || 'Đã đổi mật khẩu thành công!' };
  } catch (err) {
    return { ok: false, error: `Lỗi kết nối: ${err?.message || 'kiểm tra mạng'}` };
  }
}

/**
 * Encode/Decode compact Pairing Code (LICHAM-SYNC:...) so user sets up ONCE on PC
 * and pastes 1 code on OPPO Find X9 (or another phone) to pair instantly!
 */
export function encodePairingCode(cfg) {
  const prov = cfg.provider || 'cloudflare';
  const payload = {
    v: 2,
    provider: prov,
    cfSyncUrl: (cfg.cfSyncUrl || DEFAULT_CLOUDFLARE_SYNC_URL).trim(),
    cfToken: (cfg.cfToken || '').trim(),
    cfUsername: (cfg.cfUsername || '').trim(),
    cfDisplayName: (cfg.cfDisplayName || '').trim(),
    firebaseUrl: (cfg.firebaseUrl || '').trim(),
    roomKey: (cfg.roomKey || '').trim(),
    githubToken: (cfg.githubToken || '').trim(),
    gistId: (cfg.gistId || '').trim()
  };
  const json = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(json);
  let bin = '';
  bytes.forEach((b) => { bin += String.fromCharCode(b); });
  return `LICHAM-SYNC:${btoa(bin)}`;
}

export function decodePairingCode(raw) {
  const txt = String(raw || '').trim();
  const body = txt.startsWith('LICHAM-SYNC:') ? txt.slice('LICHAM-SYNC:'.length).trim() : txt;
  const bin = atob(body);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const json = new TextDecoder().decode(bytes);
  const parsed = JSON.parse(json);
  if (!parsed || typeof parsed !== 'object' || !parsed.provider) {
    throw new Error('Mã kết nối không hợp lệ.');
  }
  const prov = parsed.provider === 'github'
    ? 'github'
    : (parsed.provider === 'cloudflare' ? 'cloudflare' : 'firebase');
  return {
    enabled: true,
    provider: prov,
    cfSyncUrl: String(parsed.cfSyncUrl || DEFAULT_CLOUDFLARE_SYNC_URL).trim(),
    cfToken: String(parsed.cfToken || '').trim(),
    cfUsername: String(parsed.cfUsername || '').trim(),
    cfDisplayName: String(parsed.cfDisplayName || '').trim(),
    firebaseUrl: String(parsed.firebaseUrl || '').trim(),
    roomKey: String(parsed.roomKey || '').trim(),
    githubToken: String(parsed.githubToken || '').trim(),
    gistId: String(parsed.gistId || '').trim()
  };
}

/**
 * Build a complete 100%-data serializable snapshot from app state + localStorage extra domains
 */
export function buildSyncSnapshot(state, deletedIds = {}, deviceId = '') {
  const now = Date.now();
  const prunedDeleted = {};
  const cutoff = now - 30 * 24 * 60 * 60 * 1000;
  for (const [id, ts] of Object.entries(deletedIds || {})) {
    if (typeof ts === 'number' && ts >= cutoff) {
      prunedDeleted[id] = ts;
    }
  }
  const data = {};
  for (const k of SYNCABLE_DATA_KEYS) {
    if (state[k] !== undefined) {
      data[k] = state[k];
    }
  }
  const extras = collectLocalExtraData();
  for (const k of EXTRA_LOCAL_DATA_KEYS) {
    if (extras[k] !== undefined) {
      data[k] = extras[k];
    } else if (state[k] !== undefined) {
      data[k] = state[k];
    }
  }
  return {
    app: 'LichAmVietNam',
    schema: 3,
    updatedAt: now,
    updatedBy: deviceId || 'device',
    deletedIds: prunedDeleted,
    data
  };
}

function mergeById(localArr = [], remoteArr = [], deletedIds = {}, remoteWinsOnTie = true) {
  const map = new Map();
  const put = (item, isRemote) => {
    if (!item || !item.id) return;
    const delTs = Number(deletedIds[item.id] || 0);
    const itemTs = Number(item.updatedAt || item.createdAt || 0);
    if (delTs > 0 && delTs >= itemTs) return;

    const prev = map.get(item.id);
    if (!prev) {
      map.set(item.id, { item, isRemote, ts: itemTs });
      return;
    }
    if (itemTs > prev.ts || (itemTs === prev.ts && isRemote === remoteWinsOnTie)) {
      map.set(item.id, { item, isRemote, ts: itemTs });
    }
  };

  for (const it of Array.isArray(localArr) ? localArr : []) put(it, false);
  for (const it of Array.isArray(remoteArr) ? remoteArr : []) put(it, true);
  return Array.from(map.values()).map((x) => x.item);
}

function mergeUniqueList(localArr = [], remoteArr = [], limit = 15) {
  const seen = new Set();
  const out = [];
  const add = (item) => {
    if (item === null || item === undefined) return;
    const key = typeof item === 'object'
      ? (item.id || `${item.date || item.at || item.ts || ''}|${item.query || item.title || item.name || item.text || JSON.stringify(item).slice(0, 80)}`)
      : String(item);
    if (seen.has(key)) return;
    seen.add(key);
    out.push(item);
  };
  for (const it of Array.isArray(localArr) ? localArr : []) add(it);
  for (const it of Array.isArray(remoteArr) ? remoteArr : []) add(it);
  return out.slice(0, limit);
}

/**
 * CRDT-style Conflict-Free Merge of remote snapshot into local state (100% of all 20 domains).
 */
export function mergeCloudSnapshot(localState, localDeletedIds, remoteSnap, localDirty = false) {
  if (!remoteSnap || typeof remoteSnap !== 'object' || !remoteSnap.data) {
    return null;
  }
  const rData = remoteSnap.data;
  const localExtras = collectLocalExtraData();
  const mergedDeleted = { ...(localDeletedIds || {}) };
  for (const [id, ts] of Object.entries(remoteSnap.deletedIds || {})) {
    if (typeof ts === 'number' && ts > Number(mergedDeleted[id] || 0)) {
      mergedDeleted[id] = ts;
    }
  }

  const next = {};
  for (const k of SYNCABLE_DATA_KEYS) {
    if (k === 'timedReminders' || k === 'highlightedRanges' || k === 'customEvents' || k === 'expenseBook' || k === 'loanBook') {
      next[k] = mergeById(localState[k], rData[k], mergedDeleted, !localDirty);
    } else if (k === 'waterLog') {
      const wLog = { ...(localState.waterLog || {}) };
      for (const [day, cnt] of Object.entries(rData.waterLog || {})) {
        wLog[day] = Math.max(Number(wLog[day] || 0), Number(cnt || 0));
      }
      next.waterLog = wLog;
    } else if (!localDirty && rData[k] !== undefined) {
      next[k] = rData[k];
    } else if (localState[k] !== undefined) {
      next[k] = localState[k];
    } else if (rData[k] !== undefined) {
      next[k] = rData[k];
    }
  }

  // Merge extra 100%-data local domains
  const lMed = localExtras.medicineBook || localState.medicineBook || { items: [], rxPhotos: [] };
  const rMed = rData.medicineBook && typeof rData.medicineBook === 'object' ? rData.medicineBook : { items: [], rxPhotos: [] };
  next.medicineBook = {
    items: mergeById(lMed.items, rMed.items, mergedDeleted, !localDirty),
    rxPhotos: mergeById(lMed.rxPhotos, rMed.rxPhotos, mergedDeleted, !localDirty).slice(0, 6)
  };

  const lMedLog = localExtras.medicineLog || localState.medicineLog || {};
  const rMedLog = rData.medicineLog && typeof rData.medicineLog === 'object' ? rData.medicineLog : {};
  const mergedMedLog = { ...lMedLog };
  for (const [mk, val] of Object.entries(rMedLog)) {
    mergedMedLog[mk] = Boolean(mergedMedLog[mk] || val);
  }
  next.medicineLog = mergedMedLog;

  next.dietProfiles = mergeById(
    localExtras.dietProfiles || localState.dietProfiles || [],
    rData.dietProfiles || [],
    mergedDeleted,
    !localDirty
  ).slice(0, 12);

  next.dreamHistory = mergeUniqueList(
    localDirty ? (localExtras.dreamHistory || []) : (rData.dreamHistory || []),
    localDirty ? (rData.dreamHistory || []) : (localExtras.dreamHistory || []),
    10
  );
  next.fortuneHistory = mergeUniqueList(
    localDirty ? (localExtras.fortuneHistory || []) : (rData.fortuneHistory || []),
    localDirty ? (rData.fortuneHistory || []) : (localExtras.fortuneHistory || []),
    15
  );
  const lOwner = String(localExtras.expenseOwner || '').trim();
  const rOwner = String(rData.expenseOwner || '').trim();
  next.expenseOwner = (!localDirty && rOwner) ? rOwner : (lOwner || rOwner);

  const arrayChangedFromRemote = (key, mArrOpt = null, rArrOpt = null) => {
    const mArr = Array.isArray(mArrOpt ?? next[key]) ? (mArrOpt ?? next[key]) : [];
    const rArr = Array.isArray(rArrOpt ?? rData[key]) ? (rArrOpt ?? rData[key]) : [];
    if (mArr.length !== rArr.length) return true;
    const rMap = new Map(rArr.map((x) => [x?.id, Number(x?.updatedAt || x?.createdAt || 0)]));
    for (const it of mArr) {
      if (!rMap.has(it.id)) return true;
      if (Number(it.updatedAt || it.createdAt || 0) > rMap.get(it.id)) return true;
    }
    return false;
  };
  const needsPushBack =
    arrayChangedFromRemote('timedReminders') ||
    arrayChangedFromRemote('highlightedRanges') ||
    arrayChangedFromRemote('customEvents') ||
    arrayChangedFromRemote('expenseBook') ||
    arrayChangedFromRemote('loanBook') ||
    arrayChangedFromRemote('medicineItems', next.medicineBook.items, rMed.items) ||
    arrayChangedFromRemote('medicineRx', next.medicineBook.rxPhotos, rMed.rxPhotos) ||
    arrayChangedFromRemote('dietProfiles') ||
    Object.keys(mergedDeleted).length > Object.keys(remoteSnap.deletedIds || {}).length;

  return {
    mergedData: next,
    mergedDeletedIds: mergedDeleted,
    remoteUpdatedAt: Number(remoteSnap.updatedAt || Date.now()),
    needsPushBack
  };
}

/**
 * Create a brand-new private GitHub Gist for syncing (1-click helper)
 */
export async function createGitHubSyncGist(token, initialSnapshot) {
  const cleanToken = String(token || '').trim();
  if (!cleanToken) return { ok: false, error: 'Vui lòng nhập GitHub Personal Access Token (quyền gist).' };
  try {
    const resp = await fetch('https://api.github.com/gists', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${cleanToken}`,
        Accept: 'application/vnd.github+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description: 'Lịch Âm Việt Nam — Cloud Sync (Private)',
        public: false,
        files: {
          'lich-am-vn-sync.json': {
            content: JSON.stringify(initialSnapshot, null, 2)
          }
        }
      })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.id) {
      return { ok: false, error: data.message || `GitHub trả về lỗi HTTP ${resp.status}` };
    }
    return { ok: true, gistId: data.id };
  } catch (err) {
    return { ok: false, error: `Lỗi kết nối GitHub: ${err?.message || 'kiểm tra mạng'}` };
  }
}

/**
 * Pull latest JSON snapshot from Cloud (Cloudflare D1 Account, Firebase, or GitHub Gist)
 */
export async function pullCloudSnapshot(cfg) {
  if (!cfg || !cfg.enabled) return { ok: false, skipped: true };

  if (cfg.provider === 'cloudflare') {
    const base = normalizeCloudflareSyncUrl(cfg.cfSyncUrl);
    const token = String(cfg.cfToken || '').trim();
    if (!token) return { ok: false, error: 'Chưa đăng nhập tài khoản đồng bộ Cloudflare.' };
    try {
      const resp = await fetch(`${base}/api/sync`, {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
        cache: 'no-store'
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || !data.ok) {
        return { ok: false, authExpired: resp.status === 401, error: data.error || `Cloudflare Sync lỗi HTTP ${resp.status}` };
      }
      return { ok: true, snapshot: data.snapshot && typeof data.snapshot === 'object' ? data.snapshot : null };
    } catch (err) {
      return { ok: false, error: `Lỗi tải Cloudflare Sync: ${err?.message || 'kiểm tra mạng'}` };
    }
  }

  if (cfg.provider === 'github') {
    const token = String(cfg.githubToken || '').trim();
    const gistId = String(cfg.gistId || '').trim();
    if (!token || !gistId) return { ok: false, error: 'Thiếu GitHub Token hoặc Gist ID.' };
    try {
      const resp = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json'
        },
        cache: 'no-store'
      });
      if (!resp.ok) return { ok: false, error: `GitHub lỗi HTTP ${resp.status}` };
      const gist = await resp.json();
      const file = gist?.files?.['lich-am-vn-sync.json'] || Object.values(gist?.files || {})[0];
      if (!file || !file.content) return { ok: true, snapshot: null };
      const parsed = JSON.parse(file.content);
      return { ok: true, snapshot: parsed };
    } catch (err) {
      return { ok: false, error: `Lỗi tải GitHub Gist: ${err?.message || 'kiểm tra mạng'}` };
    }
  }

  // Firebase Realtime Database REST API
  const url = normalizeFirebaseEndpoint(cfg.firebaseUrl, cfg.roomKey);
  if (!url) return { ok: false, error: 'Thiếu đường dẫn Firebase Realtime Database.' };
  try {
    const resp = await fetch(url, { method: 'GET', cache: 'no-store' });
    if (!resp.ok) {
      return { ok: false, error: `Firebase trả về lỗi HTTP ${resp.status} (kiểm tra Rules read/write = true)` };
    }
    const parsed = await resp.json();
    return { ok: true, snapshot: parsed && typeof parsed === 'object' ? parsed : null };
  } catch (err) {
    return { ok: false, error: `Lỗi tải Firebase: ${err?.message || 'kiểm tra URL hoặc mạng'}` };
  }
}

/**
 * Push JSON snapshot to Cloud (Cloudflare D1 Account, Firebase, or GitHub Gist)
 */
export async function pushCloudSnapshot(cfg, snapshot) {
  if (!cfg || !cfg.enabled) return { ok: false, skipped: true };

  if (cfg.provider === 'cloudflare') {
    const base = normalizeCloudflareSyncUrl(cfg.cfSyncUrl);
    const token = String(cfg.cfToken || '').trim();
    if (!token) return { ok: false, error: 'Chưa đăng nhập tài khoản đồng bộ Cloudflare.' };
    try {
      const resp = await fetch(`${base}/api/sync`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ snapshot })
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || !data.ok) {
        return { ok: false, authExpired: resp.status === 401, error: data.error || `Cloudflare Sync lỗi HTTP ${resp.status}` };
      }
      return { ok: true, updatedAt: Number(data.updatedAt || snapshot.updatedAt), sizeBytes: Number(data.sizeBytes || 0) };
    } catch (err) {
      return { ok: false, error: `Lỗi đẩy Cloudflare Sync: ${err?.message || 'kiểm tra mạng'}` };
    }
  }

  if (cfg.provider === 'github') {
    const token = String(cfg.githubToken || '').trim();
    const gistId = String(cfg.gistId || '').trim();
    if (!token || !gistId) return { ok: false, error: 'Thiếu GitHub Token hoặc Gist ID.' };
    try {
      const resp = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          files: {
            'lich-am-vn-sync.json': {
              content: JSON.stringify(snapshot, null, 2)
            }
          }
        })
      });
      if (!resp.ok) return { ok: false, error: `GitHub lỗi HTTP ${resp.status}` };
      return { ok: true, updatedAt: snapshot.updatedAt };
    } catch (err) {
      return { ok: false, error: `Lỗi đẩy GitHub Gist: ${err?.message || 'kiểm tra mạng'}` };
    }
  }

  // Firebase Realtime Database REST API
  const url = normalizeFirebaseEndpoint(cfg.firebaseUrl, cfg.roomKey);
  if (!url) return { ok: false, error: 'Thiếu đường dẫn Firebase Realtime Database.' };
  try {
    const resp = await fetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(snapshot)
    });
    if (!resp.ok) {
      return { ok: false, error: `Firebase trả về lỗi HTTP ${resp.status} (kiểm tra Rules read/write = true)` };
    }
    return { ok: true, updatedAt: snapshot.updatedAt };
  } catch (err) {
    return { ok: false, error: `Lỗi đẩy Firebase: ${err?.message || 'kiểm tra URL hoặc mạng'}` };
  }
}
