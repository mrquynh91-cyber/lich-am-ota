const CACHE_NAME = 'lich-am-vn-mobile-v2.5.1';
const CORE_ASSETS = [
  './',
  './index.html',
  './app.css',
  './app.js',
  './storage-mobile.js',
  './lunar.js',
  './holidays.js',
  './reminders.js',
  './auspicious.js',
  './prayers.js',
  './weather.js',
  './ics-export.js',
  './zalo.js',
  './pdf-extract.js',
  './telegram.js',
  './sound.js',
  './manifest.webmanifest',
  './icons/apple-touch-icon-180.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon128.png',
  './icons/icon-512.svg'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  // Always use network for external APIs like Telegram Bot API / Open-Meteo
  if (url.origin !== self.location.origin) return;
  if (event.request.method !== 'GET') return;

  // Network-first with offline cache fallback so iPhone/Android PWA auto-updates seamlessly
  event.respondWith(
    fetch(event.request)
      .then((resp) => {
        if (resp && resp.status === 200) {
          const clone = resp.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return resp;
      })
      .catch(() => caches.match(event.request))
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      if (clients.length > 0) {
        clients[0].focus();
      } else {
        self.clients.openWindow('./index.html');
      }
    })
  );
});
