/**
 * Trung tâm Quy đổi Đa Năng (5 nhóm — 20+ công cụ quy đổi chuẩn Việt Nam & Quốc tế)
 * Dùng chung 100% giữa PC Chrome Extension, PC Tray App & OPPO Find X9 APK.
 * Copyright: DINH VAN QUYNH - 0868.00.2468
 */

import {
  THU_VN,
  TIMEZONE_VN,
  convertSolar2Lunar,
  convertLunar2Solar,
  getYearCanChi,
  getMonthCanChi,
  getDayCanChi,
  getFullDayDetails
} from './lunar.js';

const FX_CACHE_KEY = 'lich_am_fx_rates_v1';
const CRYPTO_CACHE_KEY = 'lich_am_crypto_rates_v1';

// Offline fallback rates (USD base) in case user has no internet
const DEFAULT_FX_RATES = {
  USD: 1,
  VND: 25450,
  EUR: 0.92,
  JPY: 153.5,
  CNY: 7.24,
  KRW: 1395,
  GBP: 0.785,
  AUD: 1.53,
  SGD: 1.34,
  THB: 34.4,
  TWD: 32.5,
  CAD: 1.39
};

const FX_LABELS = {
  VND: '🇻🇳 VND — Việt Nam Đồng',
  USD: '🇺🇸 USD — Đô la Mỹ',
  EUR: '🇪🇺 EUR — Euro',
  JPY: '🇯🇵 JPY — Yên Nhật',
  CNY: '🇨🇳 CNY — Nhân dân tệ',
  KRW: '🇰🇷 KRW — Won Hàn Quốc',
  GBP: '🇬🇧 GBP — Bảng Anh',
  AUD: '🇦🇺 AUD — Đô la Úc',
  SGD: '🇸🇬 SGD — Đô la Singapore',
  THB: '🇹🇭 THB — Baht Thái',
  TWD: '🇹🇼 TWD — Tân Đài tệ',
  CAD: '🇨🇦 CAD — Đô la Canada'
};

const DEFAULT_CRYPTO_PRICES = {
  bitcoin: { usd: 92000, vnd: 2340000000 },
  ethereum: { usd: 3200, vnd: 81400000 },
  tether: { usd: 1, vnd: 25450 },
  binancecoin: { usd: 620, vnd: 15780000 },
  solana: { usd: 210, vnd: 5345000 }
};

const CRYPTO_LIST = [
  { id: 'bitcoin', sym: 'BTC', name: 'Bitcoin (BTC)' },
  { id: 'ethereum', sym: 'ETH', name: 'Ethereum (ETH)' },
  { id: 'tether', sym: 'USDT', name: 'Tether (USDT)' },
  { id: 'binancecoin', sym: 'BNB', name: 'BNB (BNB)' },
  { id: 'solana', sym: 'SOL', name: 'Solana (SOL)' }
];

const WORLD_TIMEZONES = [
  { id: 'Asia/Ho_Chi_Minh', label: '🇻🇳 Việt Nam (GMT+7)' },
  { id: 'UTC', label: '🌐 Giờ Quốc tế (UTC / GMT+0)' },
  { id: 'Asia/Tokyo', label: '🇯🇵 Nhật Bản — Tokyo (GMT+9)' },
  { id: 'Asia/Seoul', label: '🇰🇷 Hàn Quốc — Seoul (GMT+9)' },
  { id: 'Asia/Singapore', label: '🇸🇬 Singapore / Trung Quốc (GMT+8)' },
  { id: 'Australia/Sydney', label: '🇦🇺 Úc — Sydney' },
  { id: 'Europe/London', label: '🇬🇧 Anh — London' },
  { id: 'Europe/Paris', label: '🇫🇷 Pháp / Đức — Paris (CET)' },
  { id: 'America/New_York', label: '🇺🇸 Mỹ — New York (Bờ Đông)' },
  { id: 'America/Los_Angeles', label: '🇺🇸 Mỹ — California (Bờ Tây)' }
];

const LINEAR_UNIT_CATALOG = {
  time: {
    title: '⏱ Đơn vị thời gian',
    units: [
      { id: 's', label: 'Giây (s)', factor: 1 },
      { id: 'min', label: 'Phút (min)', factor: 60 },
      { id: 'h', label: 'Giờ (h)', factor: 3600 },
      { id: 'd', label: 'Ngày', factor: 86400 },
      { id: 'wk', label: 'Tuần (7 ngày)', factor: 604800 },
      { id: 'mo', label: 'Tháng (30 ngày)', factor: 2592000 },
      { id: 'yr', label: 'Năm (365 ngày)', factor: 31536000 }
    ],
    defFrom: 'h',
    defTo: 'min'
  },
  length: {
    title: '📏 Độ dài (Hệ mét ↔ Anh/Mỹ & Hải lý)',
    units: [
      { id: 'mm', label: 'Milimet (mm)', factor: 0.001 },
      { id: 'cm', label: 'Centimet (cm)', factor: 0.01 },
      { id: 'm', label: 'Mét (m)', factor: 1 },
      { id: 'km', label: 'Kilomet (km)', factor: 1000 },
      { id: 'in', label: 'Inch (in)', factor: 0.0254 },
      { id: 'ft', label: 'Feet (ft)', factor: 0.3048 },
      { id: 'yd', label: 'Yard (yd)', factor: 0.9144 },
      { id: 'mi', label: 'Dặm (mile)', factor: 1609.344 },
      { id: 'nmi', label: 'Hải lý (nmi)', factor: 1852 }
    ],
    defFrom: 'm',
    defTo: 'cm'
  },
  mass: {
    title: '⚖️ Khối lượng & Đơn vị Vàng (Phân / Chỉ / Lượng)',
    units: [
      { id: 'mg', label: 'Miligram (mg)', factor: 0.001 },
      { id: 'g', label: 'Gram (g)', factor: 1 },
      { id: 'kg', label: 'Kilogram (kg)', factor: 1000 },
      { id: 'yen', label: 'Yến (10 kg)', factor: 10000 },
      { id: 'ta', label: 'Tạ (100 kg)', factor: 100000 },
      { id: 'tan', label: 'Tấn (1.000 kg)', factor: 1000000 },
      { id: 'lb', label: 'Pound (lb)', factor: 453.59237 },
      { id: 'oz', label: 'Ounce (oz — thường)', factor: 28.349523 },
      { id: 'ozt', label: 'Ounce vàng quốc tế (troy oz)', factor: 31.1034768 },
      { id: 'phan', label: 'Phân vàng VN (0,375 g)', factor: 0.375 },
      { id: 'chi', label: 'Chỉ vàng VN (3,75 g)', factor: 3.75 },
      { id: 'luong', label: 'Lượng / Cây vàng VN (37,5 g)', factor: 37.5 }
    ],
    defFrom: 'luong',
    defTo: 'g'
  },
  area: {
    title: '🗺 Diện tích (m², ha ↔ Sào / Mẫu 3 miền Bắc – Trung – Nam)',
    units: [
      { id: 'm2', label: 'Mét vuông (m²)', factor: 1 },
      { id: 'km2', label: 'Kilomet vuông (km²)', factor: 1000000 },
      { id: 'ha', label: 'Hecta (ha — 10.000 m²)', factor: 10000 },
      { id: 'sao_bac', label: 'Sào Bắc Bộ (360 m²)', factor: 360 },
      { id: 'mau_bac', label: 'Mẫu Bắc Bộ (3.600 m²)', factor: 3600 },
      { id: 'sao_trung', label: 'Sào Trung Bộ (500 m²)', factor: 500 },
      { id: 'mau_trung', label: 'Mẫu Trung Bộ (5.000 m²)', factor: 5000 },
      { id: 'sao_nam', label: 'Công / Sào Nam Bộ (1.000 m²)', factor: 1000 },
      { id: 'mau_nam', label: 'Mẫu Nam Bộ (10.000 m²)', factor: 10000 },
      { id: 'ft2', label: 'Feet vuông (ft²)', factor: 0.09290304 },
      { id: 'acre', label: 'Mẫu Anh (Acre)', factor: 4046.8564224 }
    ],
    defFrom: 'sao_bac',
    defTo: 'm2'
  },
  volume: {
    title: '🧪 Thể tích / Dung tích',
    units: [
      { id: 'ml', label: 'Mililít (ml / cc)', factor: 0.001 },
      { id: 'l', label: 'Lít (L)', factor: 1 },
      { id: 'm3', label: 'Mét khối (m³)', factor: 1000 },
      { id: 'gal', label: 'Gallon Mỹ (US gal)', factor: 3.785411784 },
      { id: 'pt', label: 'Pint Mỹ (US pt)', factor: 0.473176473 },
      { id: 'floz', label: 'Fluid Ounce Mỹ (fl oz)', factor: 0.0295735296 }
    ],
    defFrom: 'l',
    defTo: 'ml'
  },
  speed: {
    title: '🚀 Tốc độ (km/h ↔ m/s ↔ mph ↔ Knot)',
    units: [
      { id: 'kmh', label: 'km/h', factor: 1 / 3.6 },
      { id: 'ms', label: 'm/s', factor: 1 },
      { id: 'mph', label: 'Dặm/giờ (mph)', factor: 0.44704 },
      { id: 'knot', label: 'Hải lý/giờ (knot)', factor: 0.514444444 }
    ],
    defFrom: 'kmh',
    defTo: 'ms'
  },
  power: {
    title: '⚡ Công suất & Điện năng (W, kW ↔ HP ↔ BTU điều hòa)',
    units: [
      { id: 'w', label: 'Watt (W)', factor: 1 },
      { id: 'kw', label: 'Kilowatt (kW)', factor: 1000 },
      { id: 'hp', label: 'Mã lực / Ngựa (HP chuẩn — 745,7 W)', factor: 745.699872 },
      { id: 'hp_ac', label: 'Ngựa điều hòa VN (≈ 9.000 BTU/h)', factor: 2637.64 },
      { id: 'btu', label: 'BTU/h (công suất lạnh)', factor: 0.29307107 }
    ],
    defFrom: 'hp_ac',
    defTo: 'btu'
  },
  storage: {
    title: '💾 Dung lượng lưu trữ (Bit ↔ Byte ↔ KB/MB/GB/TB)',
    units: [
      { id: 'bit', label: 'Bit (b)', factor: 1 },
      { id: 'byte', label: 'Byte (B)', factor: 8 },
      { id: 'kb', label: 'KB (1.024 B)', factor: 8 * 1024 },
      { id: 'mb', label: 'MB (1.024 KB)', factor: 8 * 1024 ** 2 },
      { id: 'gb', label: 'GB (1.024 MB)', factor: 8 * 1024 ** 3 },
      { id: 'tb', label: 'TB (1.024 GB)', factor: 8 * 1024 ** 4 }
    ],
    defFrom: 'gb',
    defTo: 'mb'
  },
  network: {
    title: '🌐 Tốc độ mạng (Mbps nhà mạng ↔ MB/s tải thực tế)',
    units: [
      { id: 'mbps', label: 'Mbps (Megabit/giây — gói cước)', factor: 1000000 },
      { id: 'mbs', label: 'MB/s (Megabyte/giây — tốc độ tải)', factor: 8000000 },
      { id: 'gbps', label: 'Gbps (Gigabit/giây)', factor: 1000000000 },
      { id: 'kbs', label: 'KB/s (Kilobyte/giây)', factor: 8000 },
      { id: 'kbps', label: 'Kbps (Kilobit/giây)', factor: 1000 }
    ],
    defFrom: 'mbps',
    defTo: 'mbs'
  }
};

const KITCHEN_INGREDIENTS = [
  { id: 'water', label: '💧 Nước / Sữa tươi (1 g/ml)', density: 1.0 },
  { id: 'oil', label: '🫒 Dầu ăn (0,92 g/ml)', density: 0.92 },
  { id: 'sugar', label: '🍚 Đường trắng (0,85 g/ml)', density: 0.85 },
  { id: 'flour', label: '🌾 Bột mì đa dụng (0,53 g/ml)', density: 0.53 },
  { id: 'rice', label: '🥣 Gạo sống (0,82 g/ml)', density: 0.82 },
  { id: 'butter', label: '🧈 Bơ lạt (0,91 g/ml)', density: 0.91 },
  { id: 'honey', label: '🍯 Mật ong (1,42 g/ml)', density: 1.42 },
  { id: 'salt', label: '🧂 Muối tinh (1,22 g/ml)', density: 1.22 }
];

const SHOE_SIZE_TABLE = [
  { cm: 22.5, eu: 35, usM: 4, usW: 5.5, uk: 3 },
  { cm: 23.0, eu: 36, usM: 4.5, usW: 6, uk: 3.5 },
  { cm: 23.5, eu: 37, usM: 5, usW: 6.5, uk: 4 },
  { cm: 24.0, eu: 38, usM: 6, usW: 7.5, uk: 5 },
  { cm: 24.5, eu: 39, usM: 6.5, usW: 8, uk: 5.5 },
  { cm: 25.0, eu: 40, usM: 7, usW: 8.5, uk: 6 },
  { cm: 25.5, eu: 41, usM: 8, usW: 9.5, uk: 7 },
  { cm: 26.5, eu: 42, usM: 8.5, usW: 10, uk: 7.5 },
  { cm: 27.0, eu: 43, usM: 9.5, usW: 11, uk: 8.5 },
  { cm: 28.0, eu: 44, usM: 10, usW: 11.5, uk: 9 },
  { cm: 28.5, eu: 45, usM: 11, usW: 12.5, uk: 10 },
  { cm: 29.5, eu: 46, usM: 12, usW: 13.5, uk: 11 }
];

const CLOTHING_SIZE_TABLE = [
  { size: 'XS', height: '150–158 cm', weight: '42–48 kg', chest: '78–83 cm', eu: '32–34', us: '0–2' },
  { size: 'S', height: '155–165 cm', weight: '48–55 kg', chest: '84–89 cm', eu: '36', us: '4–6' },
  { size: 'M', height: '162–172 cm', weight: '55–64 kg', chest: '90–96 cm', eu: '38–40', us: '8–10' },
  { size: 'L', height: '168–178 cm', weight: '64–74 kg', chest: '97–103 cm', eu: '42–44', us: '12–14' },
  { size: 'XL', height: '173–183 cm', weight: '74–84 kg', chest: '104–110 cm', eu: '46–48', us: '16' },
  { size: 'XXL', height: '178–190 cm', weight: '84–96 kg', chest: '111–118 cm', eu: '50–52', us: '18–20' }
];

const LANG_CERT_TABLE = [
  { cefr: 'C2 (Thành thạo)', ielts: '8.5 – 9.0', toeic: '945 – 990', toefl: '115 – 120' },
  { cefr: 'C1 (Cao cấp)', ielts: '7.0 – 8.0', toeic: '850 – 940', toefl: '95 – 114' },
  { cefr: 'B2 (Trung cao cấp)', ielts: '5.5 – 6.5', toeic: '700 – 845', toefl: '72 – 94' },
  { cefr: 'B1 (Trung cấp)', ielts: '4.0 – 5.0', toeic: '500 – 695', toefl: '42 – 71' },
  { cefr: 'A2 (Sơ cấp)', ielts: '3.0 – 3.5', toeic: '255 – 495', toefl: '20 – 41' },
  { cefr: 'A1 (Cơ bản)', ielts: '1.0 – 2.5', toeic: '120 – 250', toefl: '0 – 19' }
];

function pad2(n) {
  return String(n).padStart(2, '0');
}

function esc(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function fmtNum(n, maxFrac = 6) {
  if (!Number.isFinite(n)) return '—';
  if (Math.abs(n) >= 1e12 || (Math.abs(n) > 0 && Math.abs(n) < 1e-6)) {
    return n.toExponential(4);
  }
  return new Intl.NumberFormat('vi-VN', { maximumFractionDigits: maxFrac }).format(n);
}

function fmtVnd(n) {
  if (!Number.isFinite(n)) return '0 ₫';
  return `${new Intl.NumberFormat('vi-VN', { maximumFractionDigits: 0 }).format(Math.round(n))} ₫`;
}

/* ==================== NUMBER TO VIETNAMESE & ENGLISH WORDS ==================== */
const VN_DIGITS = ['không', 'một', 'hai', 'ba', 'bốn', 'năm', 'sáu', 'bảy', 'tám', 'chín'];
const VN_UNITS = ['', ' nghìn', ' triệu', ' tỷ', ' nghìn tỷ', ' triệu tỷ'];

function readThreeDigitsVN(num, showZeroHundred) {
  const h = Math.floor(num / 100);
  const t = Math.floor((num % 100) / 10);
  const u = num % 10;
  let out = '';
  if (h > 0 || showZeroHundred) {
    out += `${VN_DIGITS[h]} trăm`;
    if (t === 0 && u > 0) out += ' linh';
  }
  if (t > 1) {
    out += (out ? ' ' : '') + `${VN_DIGITS[t]} mươi`;
    if (u === 1) out += ' mốt';
    else if (u === 4) out += ' tư';
    else if (u === 5) out += ' lăm';
    else if (u > 0) out += ` ${VN_DIGITS[u]}`;
  } else if (t === 1) {
    out += (out ? ' ' : '') + 'mười';
    if (u === 5) out += ' lăm';
    else if (u > 0) out += ` ${VN_DIGITS[u]}`;
  } else if (u > 0) {
    out += (out ? ' ' : '') + VN_DIGITS[u];
  }
  return out.trim();
}

export function numberToVietnameseWords(rawNum, currencySuffix = 'đồng') {
  const clean = String(rawNum || '').replace(/[^\d\-]/g, '');
  if (!clean || clean === '-') return '';
  const neg = clean.startsWith('-');
  const digits = neg ? clean.slice(1) : clean;
  if (/^0+$/.test(digits)) return `Không ${currencySuffix}`.trim();

  const groups = [];
  for (let i = digits.length; i > 0; i -= 3) {
    groups.unshift(Number(digits.slice(Math.max(0, i - 3), i)));
  }

  const parts = [];
  for (let i = 0; i < groups.length; i++) {
    const val = groups[i];
    const scaleIdx = groups.length - 1 - i;
    if (val === 0) continue;
    const chunk = readThreeDigitsVN(val, i > 0);
    parts.push(`${chunk}${VN_UNITS[scaleIdx] || ''}`);
  }
  let res = parts.join(' ').replace(/\s+/g, ' ').trim();
  if (neg) res = `âm ${res}`;
  if (currencySuffix) res = `${res} ${currencySuffix}`;
  return res.charAt(0).toUpperCase() + res.slice(1);
}

const EN_ONES = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
const EN_TENS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
const EN_SCALES = ['', ' thousand', ' million', ' billion', ' trillion', ' quadrillion'];

function readThreeDigitsEN(n) {
  const h = Math.floor(n / 100);
  const rem = n % 100;
  let out = '';
  if (h > 0) out += `${EN_ONES[h]} hundred`;
  if (rem > 0) {
    if (out) out += ' ';
    if (rem < 20) out += EN_ONES[rem];
    else {
      const t = Math.floor(rem / 10);
      const u = rem % 10;
      out += EN_TENS[t] + (u ? `-${EN_ONES[u]}` : '');
    }
  }
  return out;
}

export function numberToEnglishWords(rawNum, currencySuffix = 'dong') {
  const clean = String(rawNum || '').replace(/[^\d\-]/g, '');
  if (!clean || clean === '-') return '';
  const neg = clean.startsWith('-');
  const digits = neg ? clean.slice(1) : clean;
  if (/^0+$/.test(digits)) return `Zero ${currencySuffix}`.trim();

  const groups = [];
  for (let i = digits.length; i > 0; i -= 3) {
    groups.unshift(Number(digits.slice(Math.max(0, i - 3), i)));
  }
  const parts = [];
  for (let i = 0; i < groups.length; i++) {
    const val = groups[i];
    const scaleIdx = groups.length - 1 - i;
    if (val === 0) continue;
    parts.push(`${readThreeDigitsEN(val)}${EN_SCALES[scaleIdx] || ''}`);
  }
  let res = parts.join(' ').trim();
  if (neg) res = `minus ${res}`;
  if (currencySuffix) res = `${res} ${currencySuffix}`;
  return res.charAt(0).toUpperCase() + res.slice(1);
}

/* ==================== VIETNAM GROSS <-> NET SALARY CALCULATOR ==================== */
const REGION_MIN_WAGE = { 1: 4960000, 2: 4410000, 3: 3860000, 4: 3450000 };
const BASE_SALARY_CAP = 2340000 * 20; // 46,800,000 VND (BHXH / BHYT cap)

function computeVnPit(taxable) {
  if (taxable <= 0) return 0;
  const brackets = [
    { limit: 5000000, rate: 0.05 },
    { limit: 10000000, rate: 0.10 },
    { limit: 18000000, rate: 0.15 },
    { limit: 32000000, rate: 0.20 },
    { limit: 52000000, rate: 0.25 },
    { limit: 80000000, rate: 0.30 },
    { limit: Infinity, rate: 0.35 }
  ];
  let prev = 0;
  let tax = 0;
  for (const b of brackets) {
    if (taxable <= prev) break;
    const slice = Math.min(taxable, b.limit) - prev;
    tax += slice * b.rate;
    prev = b.limit;
  }
  return Math.round(tax);
}

function grossToNetVN(gross, dependents = 0, region = 1, policy = '2026') {
  const g = Math.max(0, Number(gross) || 0);
  const dep = Math.max(0, Math.floor(Number(dependents) || 0));
  const minW = REGION_MIN_WAGE[region] || REGION_MIN_WAGE[1];

  const bhxhBase = Math.min(g, BASE_SALARY_CAP);
  const bhtnBase = Math.min(g, minW * 20);
  const bhxh = Math.round(bhxhBase * 0.08);
  const bhyt = Math.round(bhxhBase * 0.015);
  const bhtn = Math.round(bhtnBase * 0.01);
  const totalIns = bhxh + bhyt + bhtn;

  const selfDed = policy === '2026' ? 15500000 : 11000000;
  const depDedEach = policy === '2026' ? 6200000 : 4400000;
  const depDed = dep * depDedEach;

  const beforeTax = Math.max(0, g - totalIns);
  const taxable = Math.max(0, beforeTax - selfDed - depDed);
  const pit = computeVnPit(taxable);
  const net = Math.max(0, beforeTax - pit);

  return { gross: g, bhxh, bhyt, bhtn, totalIns, beforeTax, selfDed, depDed, taxable, pit, net };
}

function netToGrossVN(targetNet, dependents = 0, region = 1, policy = '2026') {
  const n = Math.max(0, Number(targetNet) || 0);
  if (n === 0) return grossToNetVN(0, dependents, region, policy);
  let lo = n;
  let hi = n * 1.9 + 20000000;
  for (let i = 0; i < 45; i++) {
    const mid = (lo + hi) / 2;
    const res = grossToNetVN(mid, dependents, region, policy);
    if (res.net < n) lo = mid;
    else hi = mid;
  }
  return grossToNetVN(Math.round((lo + hi) / 2), dependents, region, policy);
}

/* ==================== ROMAN NUMERALS ==================== */
function intToRoman(num) {
  const n = Math.floor(Number(num));
  if (!Number.isInteger(n) || n < 1 || n > 3999) return '';
  const map = [
    [1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'],
    [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'],
    [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']
  ];
  let rem = n;
  let out = '';
  for (const [val, sym] of map) {
    while (rem >= val) { out += sym; rem -= val; }
  }
  return out;
}

function romanToInt(str) {
  const s = String(str || '').trim().toUpperCase();
  if (!/^[IVXLCDM]+$/.test(s)) return null;
  const map = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
  let total = 0;
  for (let i = 0; i < s.length; i++) {
    const cur = map[s[i]];
    const next = map[s[i + 1]] || 0;
    total += cur < next ? -cur : cur;
  }
  if (intToRoman(total) !== s) return null;
  return total;
}

/* ==================== COLOR CONVERSION (HEX <-> RGB <-> CMYK) ==================== */
function hexToRgb(hex) {
  const clean = String(hex || '').trim().replace(/^#/, '');
  const full = clean.length === 3 ? clean.split('').map((c) => c + c).join('') : clean;
  if (!/^[0-9a-fA-F]{6}$/.test(full)) return null;
  const n = parseInt(full, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgbToHex(r, g, b) {
  const c = (v) => Math.max(0, Math.min(255, Math.round(Number(v) || 0))).toString(16).padStart(2, '0').toUpperCase();
  return `#${c(r)}${c(g)}${c(b)}`;
}

function rgbToCmyk(r, g, b) {
  const rf = r / 255, gf = g / 255, bf = b / 255;
  const k = 1 - Math.max(rf, gf, bf);
  if (k >= 1) return { c: 0, m: 0, y: 0, k: 100 };
  return {
    c: Math.round(((1 - rf - k) / (1 - k)) * 100),
    m: Math.round(((1 - gf - k) / (1 - k)) * 100),
    y: Math.round(((1 - bf - k) / (1 - k)) * 100),
    k: Math.round(k * 100)
  };
}

function cmykToRgb(c, m, y, k) {
  const cf = Math.max(0, Math.min(100, Number(c) || 0)) / 100;
  const mf = Math.max(0, Math.min(100, Number(m) || 0)) / 100;
  const yf = Math.max(0, Math.min(100, Number(y) || 0)) / 100;
  const kf = Math.max(0, Math.min(100, Number(k) || 0)) / 100;
  return {
    r: Math.round(255 * (1 - cf) * (1 - kf)),
    g: Math.round(255 * (1 - mf) * (1 - kf)),
    b: Math.round(255 * (1 - yf) * (1 - kf))
  };
}

/* ==================== LIVE FX & CRYPTO RATE FETCHERS ==================== */
function loadCache(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (_e) {
    return fallback;
  }
}

async function fetchLiveFxRates() {
  const cached = loadCache(FX_CACHE_KEY, null);
  if (cached && cached.rates && (Date.now() - cached.ts) < 6 * 3600 * 1000) {
    return cached;
  }
  try {
    const resp = await fetch('https://open.er-api.com/v6/latest/USD');
    if (!resp.ok) throw new Error('FX_ERR');
    const data = await resp.json();
    if (data && data.rates && data.rates.VND) {
      const pack = { rates: data.rates, ts: Date.now(), live: true };
      try { localStorage.setItem(FX_CACHE_KEY, JSON.stringify(pack)); } catch (_e) {}
      return pack;
    }
  } catch (_e) { /* fallback */ }
  return cached || { rates: DEFAULT_FX_RATES, ts: 0, live: false };
}

async function fetchLiveCryptoPrices() {
  const cached = loadCache(CRYPTO_CACHE_KEY, null);
  if (cached && cached.prices && (Date.now() - cached.ts) < 10 * 60 * 1000) {
    return cached;
  }
  try {
    const resp = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether,binancecoin,solana&vs_currencies=usd,vnd');
    if (!resp.ok) throw new Error('CRYPTO_ERR');
    const data = await resp.json();
    if (data && data.bitcoin && data.bitcoin.usd) {
      const pack = { prices: data, ts: Date.now(), live: true };
      try { localStorage.setItem(CRYPTO_CACHE_KEY, JSON.stringify(pack)); } catch (_e) {}
      return pack;
    }
  } catch (_e) { /* fallback */ }
  return cached || { prices: DEFAULT_CRYPTO_PRICES, ts: 0, live: false };
}

/* ==================== MAIN HUB MOUNT & CONTROLLER ==================== */
const HUB_GROUPS = [
  {
    id: 'time',
    label: '📅 Thời gian',
    tools: [
      { id: 'lunar', label: '🏮 Âm ↔ Dương' },
      { id: 'timezone', label: '🌍 Múi giờ' },
      { id: 'time_unit', label: '⏱ Đơn vị TG' },
      { id: 'timestamp', label: '🕒 Timestamp' }
    ]
  },
  {
    id: 'measure',
    label: '📏 Đo lường',
    tools: [
      { id: 'length', label: '📏 Độ dài' },
      { id: 'mass', label: '⚖️ Khối lượng / Vàng' },
      { id: 'area', label: '🗺 Diện tích / Sào Mẫu' },
      { id: 'volume', label: '🧪 Thể tích' },
      { id: 'temp', label: '🌡 Nhiệt độ' },
      { id: 'speed', label: '🚀 Tốc độ' },
      { id: 'power', label: '⚡ Điện & Công suất' }
    ]
  },
  {
    id: 'finance',
    label: '💰 Tài chính',
    tools: [
      { id: 'fx', label: '💱 Ngoại tệ' },
      { id: 'crypto', label: '₿ Crypto' },
      { id: 'salary', label: '💼 Lương Gross↔Net' },
      { id: 'numwords', label: '📝 Số thành chữ' }
    ]
  },
  {
    id: 'tech',
    label: '💻 Công nghệ',
    tools: [
      { id: 'storage', label: '💾 Dung lượng' },
      { id: 'network', label: '🌐 Tốc độ mạng' },
      { id: 'radix', label: '🔢 Hệ cơ số' },
      { id: 'color', label: '🎨 Mã màu' },
      { id: 'imgconv', label: '🖼 Đổi định dạng ảnh' }
    ]
  },
  {
    id: 'life',
    label: '🏠 Đời sống',
    tools: [
      { id: 'sizes', label: '👟 Size Giày & Áo' },
      { id: 'cooking', label: '🍳 Nấu ăn (Cup/g/ml)' },
      { id: 'grades', label: '🎓 Điểm & IELTS/TOEIC' },
      { id: 'roman', label: '🏛 Số La Mã' }
    ]
  }
];

export function mountConverterHub(container, opts = {}) {
  if (!container) return null;
  const onJumpDate = typeof opts.onJumpDate === 'function' ? opts.onJumpDate : null;
  const onBack = typeof opts.onBack === 'function' ? opts.onBack : null;

  let activeGroup = 'time';
  let activeTool = 'lunar';
  let fxState = loadCache(FX_CACHE_KEY, { rates: DEFAULT_FX_RATES, ts: 0, live: false });
  let cryptoState = loadCache(CRYPTO_CACHE_KEY, { prices: DEFAULT_CRYPTO_PRICES, ts: 0, live: false });

  container.innerHTML = `
    <div class="chub-wrap">
      <div class="chub-head">
        <div>
          <div class="chub-title">🔄 Trung tâm Quy đổi Đa Năng</div>
          <div class="chub-sub">5 nhóm • 20+ công cụ quy đổi Lịch, Đo lường, Tài chính, Công nghệ &amp; Đời sống</div>
        </div>
        ${onBack ? '<button type="button" class="chub-back-btn" id="chub-btn-back">← Thêm</button>' : ''}
      </div>
      <div id="chub-group-tabs" class="chub-group-tabs"></div>
      <div id="chub-tool-pills" class="chub-tool-pills"></div>
      <div id="chub-stage" class="chub-stage"></div>
    </div>
  `;

  if (onBack) {
    container.querySelector('#chub-btn-back')?.addEventListener('click', onBack);
  }

  const groupTabsEl = container.querySelector('#chub-group-tabs');
  const toolPillsEl = container.querySelector('#chub-tool-pills');
  const stageEl = container.querySelector('#chub-stage');

  const renderGroupTabs = () => {
    groupTabsEl.innerHTML = '';
    for (const g of HUB_GROUPS) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `chub-gtab${g.id === activeGroup ? ' active' : ''}`;
      btn.textContent = g.label;
      btn.addEventListener('click', () => {
        activeGroup = g.id;
        activeTool = g.tools[0].id;
        renderGroupTabs();
        renderToolPills();
        renderActiveTool();
      });
      groupTabsEl.appendChild(btn);
    }
  };

  const renderToolPills = () => {
    const g = HUB_GROUPS.find((x) => x.id === activeGroup) || HUB_GROUPS[0];
    toolPillsEl.innerHTML = '';
    for (const t of g.tools) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `chub-tpill${t.id === activeTool ? ' active' : ''}`;
      btn.textContent = t.label;
      btn.addEventListener('click', () => {
        activeTool = t.id;
        renderToolPills();
        renderActiveTool();
      });
      toolPillsEl.appendChild(btn);
    }
  };

  const renderLinearTool = (catalogKey, extraHintFn = null) => {
    const def = LINEAR_UNIT_CATALOG[catalogKey];
    const optionsHtml = def.units.map((u) => `<option value="${u.id}">${esc(u.label)}</option>`).join('');
    stageEl.innerHTML = `
      <div class="chub-card">
        <div class="chub-card-title">${esc(def.title)}</div>
        <div class="chub-field">
          <label>Giá trị cần đổi</label>
          <input id="ch-lin-val" type="number" step="any" value="1" inputmode="decimal" />
        </div>
        <div class="chub-pair-row">
          <div class="chub-field">
            <label>Từ đơn vị</label>
            <select id="ch-lin-from">${optionsHtml}</select>
          </div>
          <button type="button" id="ch-lin-swap" class="chub-swap-btn" title="Đảo chiều">⇄</button>
          <div class="chub-field">
            <label>Sang đơn vị</label>
            <select id="ch-lin-to">${optionsHtml}</select>
          </div>
        </div>
        <div id="ch-lin-res" class="chub-result-box"></div>
        <div id="ch-lin-all" class="chub-mini-grid"></div>
      </div>
    `;

    const valInp = stageEl.querySelector('#ch-lin-val');
    const fromSel = stageEl.querySelector('#ch-lin-from');
    const toSel = stageEl.querySelector('#ch-lin-to');
    const resBox = stageEl.querySelector('#ch-lin-res');
    const allBox = stageEl.querySelector('#ch-lin-all');

    fromSel.value = def.defFrom;
    toSel.value = def.defTo;

    const recalc = () => {
      const v = Number(valInp.value);
      const uFrom = def.units.find((u) => u.id === fromSel.value) || def.units[0];
      const uTo = def.units.find((u) => u.id === toSel.value) || def.units[1];
      if (!Number.isFinite(v)) {
        resBox.innerHTML = '<div class="chub-muted">Nhập số hợp lệ để quy đổi.</div>';
        allBox.innerHTML = '';
        return;
      }
      const baseVal = v * uFrom.factor;
      const out = baseVal / uTo.factor;
      const extra = extraHintFn ? extraHintFn(baseVal, v, uFrom) : '';
      resBox.innerHTML = `
        <div class="chub-res-kicker">${fmtNum(v)} ${esc(uFrom.label)} =</div>
        <div class="chub-res-big">${fmtNum(out, 6)} <span>${esc(uTo.label.split('(')[0].trim())}</span></div>
        ${extra ? `<div class="chub-res-sub">${extra}</div>` : ''}
      `;
      allBox.innerHTML = def.units
        .filter((u) => u.id !== uFrom.id)
        .map((u) => `<div class="chub-mini-item"><span>${esc(u.label.split('(')[0].trim())}</span><strong>${fmtNum(baseVal / u.factor, 4)}</strong></div>`)
        .join('');
    };

    stageEl.querySelector('#ch-lin-swap').addEventListener('click', () => {
      const tmp = fromSel.value;
      fromSel.value = toSel.value;
      toSel.value = tmp;
      recalc();
    });
    valInp.addEventListener('input', recalc);
    fromSel.addEventListener('change', recalc);
    toSel.addEventListener('change', recalc);
    recalc();
  };

  const renderActiveTool = () => {
    if (activeTool === 'lunar') {
      const now = new Date();
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🏮 Đổi ngày Dương lịch ↔ Âm lịch (1900–2100)</div>
          <div class="chub-seg">
            <button type="button" class="chub-seg-btn active" data-m="s2l">Dương → Âm</button>
            <button type="button" class="chub-seg-btn" data-m="l2s">Âm → Dương</button>
          </div>
          <div class="chub-grid-3">
            <div class="chub-field"><label>Ngày</label><input id="ch-d" type="number" min="1" max="31" value="${now.getDate()}" /></div>
            <div class="chub-field"><label>Tháng</label><input id="ch-m" type="number" min="1" max="12" value="${now.getMonth() + 1}" /></div>
            <div class="chub-field"><label>Năm</label><input id="ch-y" type="number" min="1900" max="2100" value="${now.getFullYear()}" /></div>
          </div>
          <label id="ch-leap-row" class="chub-check hidden"><input type="checkbox" id="ch-leap" /> <span>Tháng nhuận (Âm lịch)</span></label>
          <div id="ch-lunar-res" class="chub-result-box"></div>
        </div>
      `;
      let mode = 's2l';
      const dInp = stageEl.querySelector('#ch-d');
      const mInp = stageEl.querySelector('#ch-m');
      const yInp = stageEl.querySelector('#ch-y');
      const leapRow = stageEl.querySelector('#ch-leap-row');
      const leapChk = stageEl.querySelector('#ch-leap');
      const resBox = stageEl.querySelector('#ch-lunar-res');

      const recalcLunar = () => {
        const d = Number(dInp.value), m = Number(mInp.value), y = Number(yInp.value);
        if (!d || !m || !y || y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) {
          resBox.innerHTML = '<div class="chub-muted">Nhập ngày/tháng/năm hợp lệ (1900–2100).</div>';
          return;
        }
        let solarObj = null;
        let lunarObj = null;
        if (mode === 's2l') {
          solarObj = { day: d, month: m, year: y };
          lunarObj = convertSolar2Lunar(d, m, y, TIMEZONE_VN);
        } else {
          const conv = convertLunar2Solar(d, m, y, leapChk.checked, TIMEZONE_VN);
          if (!conv || !conv.day) {
            resBox.innerHTML = '<div class="chub-muted">Ngày Âm lịch này không tồn tại (kiểm tra lại tháng nhuận hoặc ngày 30).</div>';
            return;
          }
          solarObj = conv;
          lunarObj = convertSolar2Lunar(conv.day, conv.month, conv.year, TIMEZONE_VN);
        }
        const dt = new Date(solarObj.year, solarObj.month - 1, solarObj.day);
        const dow = THU_VN[dt.getDay()];
        const details = getFullDayDetails(solarObj.day, solarObj.month, solarObj.year, TIMEZONE_VN);
        const hd = details?.hoangDaoDay?.type || '';
        const goodHrs = (details?.hours?.hoangDao || []).slice(0, 6).map((h) => `${h.chi} (${h.range})`).join(', ');

        resBox.innerHTML = `
          <div class="chub-res-kicker">${mode === 's2l' ? 'Kết quả Âm lịch:' : 'Kết quả Dương lịch:'}</div>
          <div class="chub-res-big">${mode === 's2l'
            ? `${pad2(lunarObj.day)}/${pad2(lunarObj.month)}${lunarObj.leap ? ' (Nhuận)' : ''}/${lunarObj.year} ÂL`
            : `${dow}, ${pad2(solarObj.day)}/${pad2(solarObj.month)}/${solarObj.year} DL`
          }</div>
          <div class="chub-res-sub">
            📅 ${dow}, ${pad2(solarObj.day)}/${pad2(solarObj.month)}/${solarObj.year} DL • Năm ${getYearCanChi(lunarObj.year)}, Tháng ${getMonthCanChi(lunarObj.month, lunarObj.year)}, Ngày ${getDayCanChi(lunarObj.jd).name} (${esc(hd)})<br/>
            ⏰ Giờ Hoàng Đạo: ${esc(goodHrs)}
          </div>
          ${onJumpDate ? '<button type="button" id="ch-jump-cal" class="chub-action-btn" style="margin-top:8px;">📅 Xem chi tiết ngày này trên Lịch</button>' : ''}
        `;
        resBox.querySelector('#ch-jump-cal')?.addEventListener('click', () => onJumpDate(solarObj));
      };

      stageEl.querySelectorAll('.chub-seg-btn').forEach((b) => {
        b.addEventListener('click', () => {
          mode = b.dataset.m;
          stageEl.querySelectorAll('.chub-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
          leapRow.classList.toggle('hidden', mode !== 'l2s');
          recalcLunar();
        });
      });
      [dInp, mInp, yInp, leapChk].forEach((el) => el.addEventListener('input', recalcLunar));
      leapChk.addEventListener('change', recalcLunar);
      recalcLunar();
      return;
    }

    if (activeTool === 'timezone') {
      const now = new Date();
      const localIso = `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}T${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🌍 Chuyển đổi Múi giờ Thế giới (Giờ VN GMT+7 ↔ Quốc tế)</div>
          <div class="chub-field">
            <label>Chọn ngày &amp; giờ Việt Nam (GMT+7)</label>
            <div style="display:flex;gap:6px;">
              <input id="ch-tz-dt" type="datetime-local" value="${localIso}" style="flex:1;" />
              <button type="button" id="ch-tz-now" class="chub-action-btn">Hiện tại</button>
            </div>
          </div>
          <div id="ch-tz-list" class="chub-tz-list"></div>
        </div>
      `;
      const dtInp = stageEl.querySelector('#ch-tz-dt');
      const listEl = stageEl.querySelector('#ch-tz-list');
      const renderTz = () => {
        const val = dtInp.value;
        const parsed = val ? new Date(`${val}:00+07:00`) : new Date();
        const base = Number.isNaN(parsed.getTime()) ? new Date() : parsed;
        listEl.innerHTML = WORLD_TIMEZONES.map((tz) => {
          let fmt = '';
          try {
            fmt = new Intl.DateTimeFormat('vi-VN', {
              timeZone: tz.id,
              weekday: 'short',
              day: '2-digit',
              month: '2-digit',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
              hour12: false
            }).format(base);
          } catch (_e) {
            fmt = base.toUTCString();
          }
          return `<div class="chub-tz-row"><span>${esc(tz.label)}</span><strong>${esc(fmt)}</strong></div>`;
        }).join('');
      };
      stageEl.querySelector('#ch-tz-now').addEventListener('click', () => {
        const n = new Date();
        dtInp.value = `${n.getFullYear()}-${pad2(n.getMonth() + 1)}-${pad2(n.getDate())}T${pad2(n.getHours())}:${pad2(n.getMinutes())}`;
        renderTz();
      });
      dtInp.addEventListener('input', renderTz);
      renderTz();
      return;
    }

    if (activeTool === 'time_unit') { renderLinearTool('time'); return; }

    if (activeTool === 'timestamp') {
      const nowSec = Math.floor(Date.now() / 1000);
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🕒 Chuyển đổi Unix Timestamp ↔ Ngày giờ</div>
          <div class="chub-field">
            <label>Unix Timestamp (tự nhận diện giây 10 số hoặc mili-giây 13 số)</label>
            <div style="display:flex;gap:6px;">
              <input id="ch-ts-inp" type="number" value="${nowSec}" style="flex:1;" />
              <button type="button" id="ch-ts-now" class="chub-action-btn">Lấy hiện tại</button>
            </div>
          </div>
          <div id="ch-ts-res" class="chub-result-box"></div>
          <div class="chub-field" style="margin-top:10px;">
            <label>Hoặc chọn Ngày giờ (VN GMT+7) → Timestamp</label>
            <input id="ch-ts-dt" type="datetime-local" />
          </div>
        </div>
      `;
      const tsInp = stageEl.querySelector('#ch-ts-inp');
      const dtInp = stageEl.querySelector('#ch-ts-dt');
      const resBox = stageEl.querySelector('#ch-ts-res');

      const fromTs = () => {
        const raw = Number(tsInp.value);
        if (!Number.isFinite(raw)) { resBox.innerHTML = '<div class="chub-muted">Nhập timestamp hợp lệ.</div>'; return; }
        const ms = Math.abs(raw) >= 1e12 ? raw : raw * 1000;
        const d = new Date(ms);
        if (Number.isNaN(d.getTime())) { resBox.innerHTML = '<div class="chub-muted">Timestamp ngoài phạm vi.</div>'; return; }
        const vnStr = new Intl.DateTimeFormat('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', dateStyle: 'full', timeStyle: 'medium' }).format(d);
        resBox.innerHTML = `
          <div class="chub-res-kicker">Giờ Việt Nam (GMT+7):</div>
          <div class="chub-res-big" style="font-size:16px;">${esc(vnStr)}</div>
          <div class="chub-res-sub">
            🌐 ISO / UTC: <code>${esc(d.toISOString())}</code><br/>
            ⏱ Giây (s): <strong>${Math.floor(ms / 1000)}</strong> • Mili-giây (ms): <strong>${Math.floor(ms)}</strong>
          </div>
        `;
      };
      tsInp.addEventListener('input', fromTs);
      dtInp.addEventListener('input', () => {
        if (!dtInp.value) return;
        const d = new Date(`${dtInp.value}:00+07:00`);
        if (!Number.isNaN(d.getTime())) {
          tsInp.value = String(Math.floor(d.getTime() / 1000));
          fromTs();
        }
      });
      stageEl.querySelector('#ch-ts-now').addEventListener('click', () => {
        tsInp.value = String(Math.floor(Date.now() / 1000));
        fromTs();
      });
      fromTs();
      return;
    }

    if (activeTool === 'length') { renderLinearTool('length'); return; }
    if (activeTool === 'mass') {
      renderLinearTool('mass', (grams) => `🥇 Vàng Việt Nam: <strong>${fmtNum(grams / 37.5, 4)}</strong> lượng = <strong>${fmtNum(grams / 3.75, 4)}</strong> chỉ = <strong>${fmtNum(grams / 0.375, 2)}</strong> phân`);
      return;
    }
    if (activeTool === 'area') {
      renderLinearTool('area', (m2) => `🌾 Bắc: <strong>${fmtNum(m2 / 360, 3)}</strong> sào • Trung: <strong>${fmtNum(m2 / 500, 3)}</strong> sào • Nam: <strong>${fmtNum(m2 / 1000, 3)}</strong> công`);
      return;
    }
    if (activeTool === 'volume') { renderLinearTool('volume'); return; }
    if (activeTool === 'speed') { renderLinearTool('speed'); return; }
    if (activeTool === 'power') {
      renderLinearTool('power', (watts) => {
        const kw = watts / 1000;
        return `💡 Nếu chạy 1 giờ tiêu thụ <strong>${fmtNum(kw, 3)} kWh (số điện)</strong> • Chạy 8 giờ/ngày ≈ <strong>${fmtNum(kw * 8 * 30, 1)} kWh/tháng</strong>`;
      });
      return;
    }

    if (activeTool === 'temp') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🌡 Quy đổi Nhiệt độ (°C ↔ °F ↔ Kelvin)</div>
          <div class="chub-grid-3">
            <div class="chub-field"><label>Độ C (°C)</label><input id="ch-tc" type="number" step="any" value="30" /></div>
            <div class="chub-field"><label>Độ F (°F)</label><input id="ch-tf" type="number" step="any" value="86" /></div>
            <div class="chub-field"><label>Kelvin (K)</label><input id="ch-tk" type="number" step="any" value="303.15" /></div>
          </div>
          <div id="ch-t-note" class="chub-result-box"></div>
        </div>
      `;
      const cI = stageEl.querySelector('#ch-tc');
      const fI = stageEl.querySelector('#ch-tf');
      const kI = stageEl.querySelector('#ch-tk');
      const note = stageEl.querySelector('#ch-t-note');
      const syncTemp = (src) => {
        let c = 0;
        if (src === 'c') c = Number(cI.value);
        else if (src === 'f') c = (Number(fI.value) - 32) * 5 / 9;
        else c = Number(kI.value) - 273.15;
        if (!Number.isFinite(c)) return;
        const f = c * 9 / 5 + 32;
        const k = c + 273.15;
        if (src !== 'c') cI.value = Number(c.toFixed(2));
        if (src !== 'f') fI.value = Number(f.toFixed(2));
        if (src !== 'k') kI.value = Number(k.toFixed(2));
        note.innerHTML = `<div class="chub-res-big">${fmtNum(c, 2)}°C = ${fmtNum(f, 2)}°F = ${fmtNum(k, 2)} K</div><div class="chub-res-sub">Điểm đóng băng nước: 0°C (32°F) • Thân nhiệt chuẩn: 37°C (98,6°F) • Nước sôi: 100°C (212°F)</div>`;
      };
      cI.addEventListener('input', () => syncTemp('c'));
      fI.addEventListener('input', () => syncTemp('f'));
      kI.addEventListener('input', () => syncTemp('k'));
      syncTemp('c');
      return;
    }

    if (activeTool === 'fx') {
      const optsHtml = Object.entries(FX_LABELS).map(([k, lbl]) => `<option value="${k}">${esc(lbl)}</option>`).join('');
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title" style="display:flex;justify-content:space-between;align-items:center;gap:6px;">
            <span>💱 Quy đổi Ngoại tệ (Tỷ giá thực tế)</span>
            <button type="button" id="ch-fx-refresh" class="chub-action-btn">🔄 Cập nhật</button>
          </div>
          <div class="chub-field">
            <label>Số tiền cần đổi</label>
            <input id="ch-fx-val" type="number" step="any" value="100" inputmode="decimal" />
          </div>
          <div class="chub-pair-row">
            <div class="chub-field"><label>Từ tiền tệ</label><select id="ch-fx-from">${optsHtml}</select></div>
            <button type="button" id="ch-fx-swap" class="chub-swap-btn">⇄</button>
            <div class="chub-field"><label>Sang tiền tệ</label><select id="ch-fx-to">${optsHtml}</select></div>
          </div>
          <div id="ch-fx-res" class="chub-result-box"></div>
          <div id="ch-fx-meta" class="chub-muted" style="margin-top:6px;"></div>
          <div id="ch-fx-all" class="chub-mini-grid"></div>
        </div>
      `;
      const valI = stageEl.querySelector('#ch-fx-val');
      const fromS = stageEl.querySelector('#ch-fx-from');
      const toS = stageEl.querySelector('#ch-fx-to');
      const resBox = stageEl.querySelector('#ch-fx-res');
      const metaBox = stageEl.querySelector('#ch-fx-meta');
      const allBox = stageEl.querySelector('#ch-fx-all');
      fromS.value = 'USD';
      toS.value = 'VND';

      const recalcFx = () => {
        const rates = fxState.rates || DEFAULT_FX_RATES;
        const v = Number(valI.value);
        const rFrom = rates[fromS.value] || DEFAULT_FX_RATES[fromS.value] || 1;
        const rTo = rates[toS.value] || DEFAULT_FX_RATES[toS.value] || 1;
        if (!Number.isFinite(v)) return;
        const usdAmt = v / rFrom;
        const out = usdAmt * rTo;
        const unitRate = rTo / rFrom;
        resBox.innerHTML = `
          <div class="chub-res-kicker">${fmtNum(v, 2)} ${fromS.value} =</div>
          <div class="chub-res-big">${fmtNum(out, toS.value === 'VND' || toS.value === 'JPY' || toS.value === 'KRW' ? 0 : 2)} <span>${toS.value}</span></div>
          <div class="chub-res-sub">Tỷ giá: 1 ${fromS.value} ≈ ${fmtNum(unitRate, unitRate > 100 ? 0 : 4)} ${toS.value}</div>
        `;
        metaBox.textContent = fxState.live && fxState.ts
          ? `🟢 Tỷ giá trực tuyến cập nhật lúc ${new Date(fxState.ts).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`
          : '🟡 Đang dùng tỷ giá tham khảo ngoại tuyến (bấm 🔄 Cập nhật khi có mạng).';
        allBox.innerHTML = ['VND', 'USD', 'EUR', 'JPY', 'CNY', 'KRW', 'GBP', 'SGD']
          .filter((c) => c !== fromS.value)
          .map((c) => {
            const rc = rates[c] || DEFAULT_FX_RATES[c] || 1;
            const d = (c === 'VND' || c === 'JPY' || c === 'KRW') ? 0 : 2;
            return `<div class="chub-mini-item"><span>${c}</span><strong>${fmtNum(usdAmt * rc, d)}</strong></div>`;
          }).join('');
      };

      stageEl.querySelector('#ch-fx-swap').addEventListener('click', () => {
        const t = fromS.value; fromS.value = toS.value; toS.value = t; recalcFx();
      });
      stageEl.querySelector('#ch-fx-refresh').addEventListener('click', async () => {
        try { localStorage.removeItem(FX_CACHE_KEY); } catch (_e) {}
        metaBox.textContent = '⏳ Đang lấy tỷ giá mới nhất...';
        fxState = await fetchLiveFxRates();
        recalcFx();
      });
      valI.addEventListener('input', recalcFx);
      fromS.addEventListener('change', recalcFx);
      toS.addEventListener('change', recalcFx);
      recalcFx();
      fetchLiveFxRates().then((p) => { fxState = p; if (activeTool === 'fx') recalcFx(); });
      return;
    }

    if (activeTool === 'crypto') {
      const cOpts = CRYPTO_LIST.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title" style="display:flex;justify-content:space-between;align-items:center;gap:6px;">
            <span>₿ Quy đổi Tiền mã hóa (Crypto ↔ VND / USD)</span>
            <button type="button" id="ch-cr-refresh" class="chub-action-btn">🔄 Cập nhật</button>
          </div>
          <div class="chub-grid-2">
            <div class="chub-field"><label>Đồng Crypto</label><select id="ch-cr-coin">${cOpts}</select></div>
            <div class="chub-field"><label>Số lượng</label><input id="ch-cr-amt" type="number" step="any" value="1" /></div>
          </div>
          <div id="ch-cr-res" class="chub-result-box"></div>
          <div id="ch-cr-meta" class="chub-muted" style="margin-top:6px;"></div>
          <div id="ch-cr-all" class="chub-mini-grid"></div>
        </div>
      `;
      const coinS = stageEl.querySelector('#ch-cr-coin');
      const amtI = stageEl.querySelector('#ch-cr-amt');
      const resBox = stageEl.querySelector('#ch-cr-res');
      const metaBox = stageEl.querySelector('#ch-cr-meta');
      const allBox = stageEl.querySelector('#ch-cr-all');

      const recalcCr = () => {
        const prices = cryptoState.prices || DEFAULT_CRYPTO_PRICES;
        const coin = CRYPTO_LIST.find((c) => c.id === coinS.value) || CRYPTO_LIST[0];
        const qty = Number(amtI.value);
        const p = prices[coin.id] || DEFAULT_CRYPTO_PRICES[coin.id];
        if (!Number.isFinite(qty) || !p) return;
        resBox.innerHTML = `
          <div class="chub-res-kicker">${fmtNum(qty, 6)} ${coin.sym} ≈</div>
          <div class="chub-res-big">${fmtVnd(qty * p.vnd)}</div>
          <div class="chub-res-sub">🇺🇸 Tương đương: <strong>$${fmtNum(qty * p.usd, 2)} USD</strong> (1 ${coin.sym} ≈ $${fmtNum(p.usd, 2)})</div>
        `;
        metaBox.textContent = cryptoState.live && cryptoState.ts
          ? `🟢 Giá thị trường CoinGecko cập nhật lúc ${new Date(cryptoState.ts).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`
          : '🟡 Đang dùng giá tham khảo ngoại tuyến (bấm 🔄 Cập nhật khi có mạng).';
        allBox.innerHTML = CRYPTO_LIST.map((c) => {
          const cp = prices[c.id] || DEFAULT_CRYPTO_PRICES[c.id];
          return `<div class="chub-mini-item"><span>1 ${c.sym}</span><strong>$${fmtNum(cp.usd, 2)}</strong></div>`;
        }).join('');
      };
      stageEl.querySelector('#ch-cr-refresh').addEventListener('click', async () => {
        try { localStorage.removeItem(CRYPTO_CACHE_KEY); } catch (_e) {}
        metaBox.textContent = '⏳ Đang cập nhật giá Crypto...';
        cryptoState = await fetchLiveCryptoPrices();
        recalcCr();
      });
      coinS.addEventListener('change', recalcCr);
      amtI.addEventListener('input', recalcCr);
      recalcCr();
      fetchLiveCryptoPrices().then((p) => { cryptoState = p; if (activeTool === 'crypto') recalcCr(); });
      return;
    }

    if (activeTool === 'salary') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">💼 Quy đổi Lương Gross ↔ Net &amp; Thuế TNCN Việt Nam</div>
          <div class="chub-seg">
            <button type="button" class="chub-seg-btn active" data-sm="g2n">Gross → Net</button>
            <button type="button" class="chub-seg-btn" data-sm="n2g">Net → Gross</button>
          </div>
          <div class="chub-field">
            <label id="ch-sal-lbl">Thu nhập Gross (VNĐ/tháng)</label>
            <input id="ch-sal-amt" type="number" step="500000" value="25000000" inputmode="numeric" />
          </div>
          <div class="chub-grid-3">
            <div class="chub-field"><label>Người phụ thuộc</label><input id="ch-sal-dep" type="number" min="0" max="20" value="0" /></div>
            <div class="chub-field">
              <label>Vùng lương</label>
              <select id="ch-sal-reg">
                <option value="1">Vùng I (HN/HCM)</option>
                <option value="2">Vùng II</option>
                <option value="3">Vùng III</option>
                <option value="4">Vùng IV</option>
              </select>
            </div>
            <div class="chub-field">
              <label>Giảm trừ gia cảnh</label>
              <select id="ch-sal-pol">
                <option value="2026" selected>Mức mới 2026 (15,5tr / 6,2tr)</option>
                <option value="old">Mức cũ (11tr / 4,4tr)</option>
              </select>
            </div>
          </div>
          <div id="ch-sal-res" class="chub-result-box"></div>
        </div>
      `;
      let sm = 'g2n';
      const amtI = stageEl.querySelector('#ch-sal-amt');
      const depI = stageEl.querySelector('#ch-sal-dep');
      const regS = stageEl.querySelector('#ch-sal-reg');
      const polS = stageEl.querySelector('#ch-sal-pol');
      const lbl = stageEl.querySelector('#ch-sal-lbl');
      const resBox = stageEl.querySelector('#ch-sal-res');

      const recalcSal = () => {
        const val = Number(amtI.value) || 0;
        const r = sm === 'g2n'
          ? grossToNetVN(val, depI.value, Number(regS.value), polS.value)
          : netToGrossVN(val, depI.value, Number(regS.value), polS.value);
        resBox.innerHTML = `
          <div class="chub-res-kicker">${sm === 'g2n' ? 'Lương thực nhận (NET):' : 'Lương GROSS tương đương:'}</div>
          <div class="chub-res-big">${fmtVnd(sm === 'g2n' ? r.net : r.gross)}</div>
          <div class="chub-table">
            <div><span>Lương Gross</span><strong>${fmtVnd(r.gross)}</strong></div>
            <div><span>BHXH (8%)</span><strong>−${fmtVnd(r.bhxh)}</strong></div>
            <div><span>BHYT (1,5%)</span><strong>−${fmtVnd(r.bhyt)}</strong></div>
            <div><span>BHTN (1%)</span><strong>−${fmtVnd(r.bhtn)}</strong></div>
            <div><span>Giảm trừ bản thân + phụ thuộc</span><strong>${fmtVnd(r.selfDed + r.depDed)}</strong></div>
            <div><span>Thu nhập tính thuế</span><strong>${fmtVnd(r.taxable)}</strong></div>
            <div><span>Thuế TNCN</span><strong style="color:#DC2626;">−${fmtVnd(r.pit)}</strong></div>
            <div class="chub-table-hl"><span>Thực nhận (NET)</span><strong>${fmtVnd(r.net)}</strong></div>
          </div>
        `;
      };
      stageEl.querySelectorAll('.chub-seg-btn').forEach((b) => {
        b.addEventListener('click', () => {
          sm = b.dataset.sm;
          stageEl.querySelectorAll('.chub-seg-btn').forEach((x) => x.classList.toggle('active', x === b));
          lbl.textContent = sm === 'g2n' ? 'Thu nhập Gross (VNĐ/tháng)' : 'Thu nhập Net mong muốn (VNĐ/tháng)';
          recalcSal();
        });
      });
      [amtI, depI, regS, polS].forEach((el) => el.addEventListener('input', recalcSal));
      [regS, polS].forEach((el) => el.addEventListener('change', recalcSal));
      recalcSal();
      return;
    }

    if (activeTool === 'numwords') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">📝 Chuyển số tiền thành chữ (Hóa đơn / Chứng từ)</div>
          <div class="chub-grid-2">
            <div class="chub-field"><label>Nhập số tiền</label><input id="ch-nw-inp" type="text" inputmode="numeric" value="125450000" placeholder="VD: 125450000" /></div>
            <div class="chub-field">
              <label>Đơn vị</label>
              <select id="ch-nw-unit">
                <option value="đồng|dong" selected>VNĐ (đồng)</option>
                <option value="đô la Mỹ|US dollars">USD (đô la)</option>
                <option value="|">Chỉ đọc số (không đơn vị)</option>
              </select>
            </div>
          </div>
          <div id="ch-nw-res" class="chub-result-box"></div>
        </div>
      `;
      const inp = stageEl.querySelector('#ch-nw-inp');
      const unitS = stageEl.querySelector('#ch-nw-unit');
      const resBox = stageEl.querySelector('#ch-nw-res');
      const recalcNw = () => {
        const raw = inp.value.replace(/[^\d]/g, '');
        if (!raw) { resBox.innerHTML = '<div class="chub-muted">Nhập dãy số để đọc thành chữ.</div>'; return; }
        const [uVn, uEn] = unitS.value.split('|');
        const vn = numberToVietnameseWords(raw, uVn);
        const en = numberToEnglishWords(raw, uEn);
        const fmt = new Intl.NumberFormat('vi-VN').format(BigInt(raw));
        resBox.innerHTML = `
          <div class="chub-res-kicker">Số đã nhập: <strong>${fmt}</strong></div>
          <div style="margin:6px 0;">
            <div class="chub-muted">🇻🇳 Tiếng Việt:</div>
            <div style="font-size:14.5px;font-weight:700;color:#7F1D1D;margin:2px 0 6px;">${esc(vn)}${uVn ? ' chẵn.' : ''}</div>
            <button type="button" id="ch-nw-copy-vn" class="chub-action-btn">📋 Sao chép Tiếng Việt</button>
          </div>
          <div style="margin-top:9px;padding-top:8px;border-top:1px dashed #E5E7EB;">
            <div class="chub-muted">🇺🇸 Tiếng Anh:</div>
            <div style="font-size:13.5px;font-weight:600;color:#1F2937;margin:2px 0 6px;">${esc(en)}</div>
            <button type="button" id="ch-nw-copy-en" class="chub-action-btn">📋 Sao chép Tiếng Anh</button>
          </div>
        `;
        resBox.querySelector('#ch-nw-copy-vn')?.addEventListener('click', (e) => {
          navigator.clipboard?.writeText(`${vn}${uVn ? ' chẵn' : ''}`).catch(() => {});
          e.currentTarget.textContent = '✓ Đã sao chép!';
        });
        resBox.querySelector('#ch-nw-copy-en')?.addEventListener('click', (e) => {
          navigator.clipboard?.writeText(en).catch(() => {});
          e.currentTarget.textContent = '✓ Đã sao chép!';
        });
      };
      inp.addEventListener('input', recalcNw);
      unitS.addEventListener('change', recalcNw);
      recalcNw();
      return;
    }

    if (activeTool === 'storage') { renderLinearTool('storage'); return; }
    if (activeTool === 'network') {
      renderLinearTool('network', (bps) => {
        const mbs = bps / 8000000;
        if (mbs <= 0) return '';
        const sec1gb = 1024 / mbs;
        const fmtSec = sec1gb >= 60 ? `${Math.floor(sec1gb / 60)} phút ${Math.round(sec1gb % 60)} giây` : `${sec1gb.toFixed(1)} giây`;
        return `📥 Tải file <strong>1 GB</strong> mất khoảng <strong>${fmtSec}</strong> ở tốc độ thực tế ${fmtNum(mbs, 2)} MB/s`;
      });
      return;
    }

    if (activeTool === 'radix') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🔢 Quy đổi Hệ cơ số (Binary ↔ Octal ↔ Decimal ↔ Hex)</div>
          <div class="chub-field"><label>Thập phân — Decimal (Hệ 10)</label><input id="ch-r-dec" type="text" value="2026" /></div>
          <div class="chub-field"><label>Nhị phân — Binary (Hệ 2)</label><input id="ch-r-bin" type="text" /></div>
          <div class="chub-field"><label>Thập lục phân — Hex (Hệ 16)</label><input id="ch-r-hex" type="text" /></div>
          <div class="chub-field"><label>Bát phân — Octal (Hệ 8)</label><input id="ch-r-oct" type="text" /></div>
          <div id="ch-r-err" class="chub-muted"></div>
        </div>
      `;
      const decI = stageEl.querySelector('#ch-r-dec');
      const binI = stageEl.querySelector('#ch-r-bin');
      const hexI = stageEl.querySelector('#ch-r-hex');
      const octI = stageEl.querySelector('#ch-r-oct');
      const errEl = stageEl.querySelector('#ch-r-err');

      const syncRadix = (base, srcEl) => {
        const raw = srcEl.value.trim().replace(/\s+/g, '');
        if (!raw) { errEl.textContent = ''; return; }
        const rx = base === 2 ? /^[01]+$/ : base === 8 ? /^[0-7]+$/ : base === 10 ? /^\d+$/ : /^[0-9a-fA-F]+$/;
        if (!rx.test(raw)) { errEl.textContent = `⚠️ Ký tự không hợp lệ cho hệ cơ số ${base}.`; return; }
        errEl.textContent = '';
        const n = parseInt(raw, base);
        if (!Number.isSafeInteger(n)) { errEl.textContent = '⚠️ Số quá lớn vượt giới hạn an toàn.'; return; }
        if (srcEl !== decI) decI.value = n.toString(10);
        if (srcEl !== binI) binI.value = n.toString(2);
        if (srcEl !== hexI) hexI.value = n.toString(16).toUpperCase();
        if (srcEl !== octI) octI.value = n.toString(8);
      };
      decI.addEventListener('input', () => syncRadix(10, decI));
      binI.addEventListener('input', () => syncRadix(2, binI));
      hexI.addEventListener('input', () => syncRadix(16, hexI));
      octI.addEventListener('input', () => syncRadix(8, octI));
      syncRadix(10, decI);
      return;
    }

    if (activeTool === 'color') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🎨 Quy đổi Mã màu (HEX ↔ RGB ↔ CMYK)</div>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
            <input id="ch-c-pick" type="color" value="#B91C1C" style="width:54px;height:44px;border:none;border-radius:10px;cursor:pointer;" />
            <div class="chub-field" style="flex:1;margin:0;"><label>HEX</label><input id="ch-c-hex" type="text" value="#B91C1C" /></div>
          </div>
          <div class="chub-grid-3">
            <div class="chub-field"><label>R (0–255)</label><input id="ch-c-r" type="number" min="0" max="255" value="185" /></div>
            <div class="chub-field"><label>G (0–255)</label><input id="ch-c-g" type="number" min="0" max="255" value="28" /></div>
            <div class="chub-field"><label>B (0–255)</label><input id="ch-c-b" type="number" min="0" max="255" value="28" /></div>
          </div>
          <div class="chub-grid-4">
            <div class="chub-field"><label>C (%)</label><input id="ch-c-c" type="number" min="0" max="100" /></div>
            <div class="chub-field"><label>M (%)</label><input id="ch-c-m" type="number" min="0" max="100" /></div>
            <div class="chub-field"><label>Y (%)</label><input id="ch-c-y" type="number" min="0" max="100" /></div>
            <div class="chub-field"><label>K (%)</label><input id="ch-c-k" type="number" min="0" max="100" /></div>
          </div>
          <div id="ch-c-preview" class="chub-result-box"></div>
        </div>
      `;
      const pick = stageEl.querySelector('#ch-c-pick');
      const hexI = stageEl.querySelector('#ch-c-hex');
      const rI = stageEl.querySelector('#ch-c-r'), gI = stageEl.querySelector('#ch-c-g'), bI = stageEl.querySelector('#ch-c-b');
      const cI = stageEl.querySelector('#ch-c-c'), mI = stageEl.querySelector('#ch-c-m'), yI = stageEl.querySelector('#ch-c-y'), kI = stageEl.querySelector('#ch-c-k');
      const prev = stageEl.querySelector('#ch-c-preview');

      const paintColor = (rgb, skip) => {
        const hex = rgbToHex(rgb.r, rgb.g, rgb.b);
        const cmyk = rgbToCmyk(rgb.r, rgb.g, rgb.b);
        if (skip !== 'pick') pick.value = hex;
        if (skip !== 'hex') hexI.value = hex;
        if (skip !== 'rgb') { rI.value = rgb.r; gI.value = rgb.g; bI.value = rgb.b; }
        if (skip !== 'cmyk') { cI.value = cmyk.c; mI.value = cmyk.m; yI.value = cmyk.y; kI.value = cmyk.k; }
        prev.innerHTML = `
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:46px;height:46px;border-radius:10px;background:${hex};border:1px solid rgba(0,0,0,0.12);flex-shrink:0;"></div>
            <div style="font-size:12.5px;line-height:1.55;">
              <div><strong>HEX:</strong> <code>${hex}</code></div>
              <div><strong>RGB:</strong> <code>rgb(${rgb.r}, ${rgb.g}, ${rgb.b})</code></div>
              <div><strong>CMYK:</strong> <code>cmyk(${cmyk.c}%, ${cmyk.m}%, ${cmyk.y}%, ${cmyk.k}%)</code></div>
            </div>
          </div>
        `;
      };
      pick.addEventListener('input', () => { const rgb = hexToRgb(pick.value); if (rgb) paintColor(rgb, 'pick'); });
      hexI.addEventListener('input', () => { const rgb = hexToRgb(hexI.value); if (rgb) paintColor(rgb, 'hex'); });
      [rI, gI, bI].forEach((el) => el.addEventListener('input', () => paintColor({ r: Number(rI.value) || 0, g: Number(gI.value) || 0, b: Number(bI.value) || 0 }, 'rgb')));
      [cI, mI, yI, kI].forEach((el) => el.addEventListener('input', () => paintColor(cmykToRgb(cI.value, mI.value, yI.value, kI.value), 'cmyk')));
      paintColor({ r: 185, g: 28, b: 28 }, '');
      return;
    }

    if (activeTool === 'imgconv') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🖼 Chuyển đổi định dạng ảnh tức thì (JPG ↔ PNG ↔ WebP)</div>
          <div class="chub-muted" style="margin-bottom:8px;">Xử lý 100% trực tiếp trên máy (không tải lên máy chủ). Hỗ trợ đổi JPG, PNG, WebP và nén dung lượng ảnh.</div>
          <div class="chub-field">
            <label>Chọn file ảnh từ máy</label>
            <input id="ch-img-file" type="file" accept="image/*" />
          </div>
          <div class="chub-grid-2">
            <div class="chub-field">
              <label>Định dạng đích</label>
              <select id="ch-img-fmt">
                <option value="image/jpeg">JPG (.jpg — nhẹ, phổ biến)</option>
                <option value="image/png">PNG (.png — giữ nền trong suốt)</option>
                <option value="image/webp">WebP (.webp — siêu nhẹ)</option>
              </select>
            </div>
            <div class="chub-field">
              <label>Chất lượng (%)</label>
              <input id="ch-img-q" type="number" min="30" max="100" value="88" />
            </div>
          </div>
          <button type="button" id="ch-img-go" class="chub-primary-btn">✨ Chuyển đổi &amp; Tải ảnh xuống</button>
          <div id="ch-img-status" class="chub-muted" style="margin-top:8px;"></div>
        </div>
      `;
      const fInp = stageEl.querySelector('#ch-img-file');
      const fmtS = stageEl.querySelector('#ch-img-fmt');
      const qInp = stageEl.querySelector('#ch-img-q');
      const stEl = stageEl.querySelector('#ch-img-status');

      stageEl.querySelector('#ch-img-go').addEventListener('click', () => {
        const file = fInp.files?.[0];
        if (!file) { stEl.textContent = '⚠️ Vui lòng chọn 1 file ảnh trước.'; return; }
        const mime = fmtS.value;
        const ext = mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : 'jpg';
        const q = Math.max(0.3, Math.min(1, (Number(qInp.value) || 88) / 100));
        const img = new Image();
        const url = URL.createObjectURL(file);
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          const ctx = canvas.getContext('2d');
          if (mime === 'image/jpeg') {
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }
          ctx.drawImage(img, 0, 0);
          URL.revokeObjectURL(url);
          canvas.toBlob((blob) => {
            if (!blob) { stEl.textContent = '⚠️ Trình duyệt không hỗ trợ xuất định dạng này.'; return; }
            const baseName = file.name.replace(/\.[^.]+$/, '');
            const dlUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = dlUrl;
            a.download = `${baseName}.${ext}`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(dlUrl), 3000);
            stEl.textContent = `✅ Đã chuyển sang .${ext.toUpperCase()} (${(blob.size / 1024).toFixed(1)} KB, gốc ${(file.size / 1024).toFixed(1)} KB) và tải xuống!`;
          }, mime, q);
        };
        img.onerror = () => { URL.revokeObjectURL(url); stEl.textContent = '⚠️ File không phải ảnh hợp lệ.'; };
        img.src = url;
      });
      return;
    }

    if (activeTool === 'sizes') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">👟 Quy đổi Size Giày (VN/EU ↔ US ↔ UK ↔ cm) &amp; Quần áo</div>
          <div class="chub-field">
            <label>Nhập chiều dài bàn chân (cm) để gợi ý size giày chuẩn</label>
            <input id="ch-foot-cm" type="number" step="0.5" min="21" max="31" value="25.5" />
          </div>
          <div id="ch-shoe-res" class="chub-result-box"></div>
          <div style="font-weight:700;font-size:12.5px;margin:10px 0 5px;color:#7F1D1D;">👕 Bảng Size Áo chuẩn Việt Nam (XS – XXL)</div>
          <div class="chub-table">
            <div class="chub-table-hl"><span>Size</span><strong>Cao / Nặng • EU / US</strong></div>
            ${CLOTHING_SIZE_TABLE.map((r) => `<div><span><strong>${r.size}</strong> (Ngực ${r.chest})</span><strong>${r.height} • ${r.weight} • EU ${r.eu}</strong></div>`).join('')}
          </div>
        </div>
      `;
      const cmI = stageEl.querySelector('#ch-foot-cm');
      const resBox = stageEl.querySelector('#ch-shoe-res');
      const recalcShoe = () => {
        const cm = Number(cmI.value);
        if (!Number.isFinite(cm)) return;
        let best = SHOE_SIZE_TABLE[0];
        for (const r of SHOE_SIZE_TABLE) {
          if (Math.abs(r.cm - cm) < Math.abs(best.cm - cm)) best = r;
        }
        resBox.innerHTML = `
          <div class="chub-res-kicker">Gợi ý size cho chân dài ${cm} cm:</div>
          <div class="chub-res-big">Size VN / EU: ${best.eu}</div>
          <div class="chub-res-sub">🇺🇸 US Nam: <strong>${best.usM}</strong> • US Nữ: <strong>${best.usW}</strong> • 🇬🇧 UK: <strong>${best.uk}</strong></div>
        `;
      };
      cmI.addEventListener('input', recalcShoe);
      recalcShoe();
      return;
    }

    if (activeTool === 'cooking') {
      const ingOpts = KITCHEN_INGREDIENTS.map((i) => `<option value="${i.id}">${esc(i.label)}</option>`).join('');
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🍳 Quy đổi Nấu ăn (Cup / Muỗng canh / Muỗng cà phê ↔ g &amp; ml)</div>
          <div class="chub-field"><label>Nguyên liệu (để đổi chính xác sang gram)</label><select id="ch-ck-ing">${ingOpts}</select></div>
          <div class="chub-grid-2">
            <div class="chub-field"><label>Số lượng</label><input id="ch-ck-val" type="number" step="any" value="1" /></div>
            <div class="chub-field">
              <label>Đơn vị</label>
              <select id="ch-ck-unit">
                <option value="cup">Cup / Cốc chuẩn (240 ml)</option>
                <option value="tbsp">Muỗng canh — tbsp (15 ml)</option>
                <option value="tsp">Muỗng cà phê — tsp (5 ml)</option>
                <option value="ml">Mililít (ml)</option>
                <option value="g">Gram (g)</option>
              </select>
            </div>
          </div>
          <div id="ch-ck-res" class="chub-result-box"></div>
        </div>
      `;
      const ingS = stageEl.querySelector('#ch-ck-ing');
      const valI = stageEl.querySelector('#ch-ck-val');
      const unitS = stageEl.querySelector('#ch-ck-unit');
      const resBox = stageEl.querySelector('#ch-ck-res');
      const recalcCk = () => {
        const ing = KITCHEN_INGREDIENTS.find((i) => i.id === ingS.value) || KITCHEN_INGREDIENTS[0];
        const v = Number(valI.value);
        if (!Number.isFinite(v)) return;
        let ml = 0;
        if (unitS.value === 'cup') ml = v * 240;
        else if (unitS.value === 'tbsp') ml = v * 15;
        else if (unitS.value === 'tsp') ml = v * 5;
        else if (unitS.value === 'ml') ml = v;
        else ml = v / ing.density;
        const grams = ml * ing.density;
        resBox.innerHTML = `
          <div class="chub-res-big">${fmtNum(grams, 1)} g  •  ${fmtNum(ml, 1)} ml</div>
          <div class="chub-res-sub">
            ≈ <strong>${fmtNum(ml / 240, 2)}</strong> Cup • <strong>${fmtNum(ml / 15, 1)}</strong> muỗng canh (tbsp) • <strong>${fmtNum(ml / 5, 1)}</strong> muỗng cà phê (tsp)
          </div>
        `;
      };
      [ingS, valI, unitS].forEach((el) => el.addEventListener('input', recalcCk));
      [ingS, unitS].forEach((el) => el.addEventListener('change', recalcCk));
      recalcCk();
      return;
    }

    if (activeTool === 'grades') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🎓 Quy đổi Điểm Học tập (Hệ 10 ↔ GPA 4) &amp; Chứng chỉ Tiếng Anh</div>
          <div class="chub-field">
            <label>Nhập điểm hệ 10 (VD: 8.5)</label>
            <input id="ch-gr-10" type="number" step="0.1" min="0" max="10" value="8.5" />
          </div>
          <div id="ch-gr-res" class="chub-result-box"></div>
          <div style="font-weight:700;font-size:12.5px;margin:10px 0 5px;color:#7F1D1D;">🌐 Bảng quy đổi IELTS ↔ TOEIC ↔ TOEFL iBT ↔ CEFR</div>
          <div class="chub-table">
            <div class="chub-table-hl"><span>CEFR / IELTS</span><strong>TOEIC • TOEFL iBT</strong></div>
            ${LANG_CERT_TABLE.map((r) => `<div><span><strong>${r.cefr}</strong> • IELTS ${r.ielts}</span><strong>TOEIC ${r.toeic} • TOEFL ${r.toefl}</strong></div>`).join('')}
          </div>
        </div>
      `;
      const g10 = stageEl.querySelector('#ch-gr-10');
      const resBox = stageEl.querySelector('#ch-gr-res');
      const recalcGr = () => {
        const s = Number(g10.value);
        if (!Number.isFinite(s) || s < 0 || s > 10) { resBox.innerHTML = '<div class="chub-muted">Nhập điểm từ 0 đến 10.</div>'; return; }
        let gpa = 0, letter = 'F', rank = 'Kém (Không đạt)';
        if (s >= 9.0) { gpa = 4.0; letter = 'A+'; rank = 'Xuất sắc'; }
        else if (s >= 8.5) { gpa = 4.0; letter = 'A'; rank = 'Giỏi / Xuất sắc'; }
        else if (s >= 8.0) { gpa = 3.5; letter = 'B+'; rank = 'Giỏi'; }
        else if (s >= 7.0) { gpa = 3.0; letter = 'B'; rank = 'Khá'; }
        else if (s >= 6.5) { gpa = 2.5; letter = 'C+'; rank = 'Khá'; }
        else if (s >= 5.5) { gpa = 2.0; letter = 'C'; rank = 'Trung bình'; }
        else if (s >= 5.0) { gpa = 1.5; letter = 'D+'; rank = 'Trung bình yếu'; }
        else if (s >= 4.0) { gpa = 1.0; letter = 'D'; rank = 'Trung bình yếu'; }
        resBox.innerHTML = `
          <div class="chub-res-kicker">Điểm hệ 10: <strong>${s.toFixed(1)}</strong></div>
          <div class="chub-res-big">GPA: ${gpa.toFixed(1)} / 4.0  •  Điểm chữ: ${letter}</div>
          <div class="chub-res-sub">🏅 Xếp loại học lực tham khảo: <strong>${rank}</strong></div>
        `;
      };
      g10.addEventListener('input', recalcGr);
      recalcGr();
      return;
    }

    if (activeTool === 'roman') {
      stageEl.innerHTML = `
        <div class="chub-card">
          <div class="chub-card-title">🏛 Quy đổi Số La Mã (I, V, X, L, C, D, M) ↔ Số tự nhiên</div>
          <div class="chub-grid-2">
            <div class="chub-field"><label>Số tự nhiên (1 – 3999)</label><input id="ch-rm-num" type="number" min="1" max="3999" value="2026" /></div>
            <div class="chub-field"><label>Số La Mã</label><input id="ch-rm-str" type="text" value="MMXXVI" style="text-transform:uppercase;" /></div>
          </div>
          <div id="ch-rm-res" class="chub-result-box"></div>
        </div>
      `;
      const nI = stageEl.querySelector('#ch-rm-num');
      const sI = stageEl.querySelector('#ch-rm-str');
      const resBox = stageEl.querySelector('#ch-rm-res');
      const fromN = () => {
        const rom = intToRoman(nI.value);
        if (!rom) { resBox.innerHTML = '<div class="chub-muted">Nhập số nguyên từ 1 đến 3999.</div>'; return; }
        sI.value = rom;
        resBox.innerHTML = `<div class="chub-res-big">${nI.value} = ${rom}</div><div class="chub-res-sub">I=1 • V=5 • X=10 • L=50 • C=100 • D=500 • M=1000</div>`;
      };
      const fromS = () => {
        const n = romanToInt(sI.value);
        if (!n) { resBox.innerHTML = '<div class="chub-muted">Chuỗi La Mã chưa đúng chuẩn (chỉ gồm I, V, X, L, C, D, M).</div>'; return; }
        nI.value = String(n);
        resBox.innerHTML = `<div class="chub-res-big">${sI.value.toUpperCase()} = ${n}</div><div class="chub-res-sub">I=1 • V=5 • X=10 • L=50 • C=100 • D=500 • M=1000</div>`;
      };
      nI.addEventListener('input', fromN);
      sI.addEventListener('input', fromS);
      fromN();
    }
  };

  renderGroupTabs();
  renderToolPills();
  renderActiveTool();

  return {
    openTool(groupId, toolId) {
      if (HUB_GROUPS.some((g) => g.id === groupId)) {
        activeGroup = groupId;
        const g = HUB_GROUPS.find((x) => x.id === groupId);
        activeTool = (toolId && g.tools.some((t) => t.id === toolId)) ? toolId : g.tools[0].id;
        renderGroupTabs();
        renderToolPills();
        renderActiveTool();
      }
    }
  };
}
